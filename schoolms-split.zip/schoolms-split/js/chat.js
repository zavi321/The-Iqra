/* SchoolMS — chat.js — split from index.html (lines 15225-15442). Load order matters: see index.html */
// =====================================================================
// SCHOOL CHAT — text + voice notes between parents, teachers and principal.
// Backend: chat_voice.sql (tables chat_msgs / chat_voice_data, RPCs chat_send,
// chat_list, chat_audio, chat_contact). Voice notes: max 120 s, deleted after 2 days.
// =====================================================================
const CH = { role: null, to: '', cls: '', sid: '', rec: null, chunks: [], tick: null, audio: null, secs: 0, poll: null, cache: {} };

function chCreds() {
  if (CH.role === 'parent') { const c = ppQuizCreds(); return c ? { p_role: 'parent', p_code: c.p_school_code, p_a: c.p_roll, p_b: c.p_pin } : null; }
  if (CH.role === 'teacher') { const s = getClassSession(); return s ? { p_role: 'teacher', p_code: s.schoolCode, p_a: s.loginId, p_b: s.password } : null; }
  return CURRENT_USER ? { p_role: 'owner', p_code: '', p_a: '', p_b: '' } : null;
}
function chStudents() {
  if (CH.role === 'teacher') { const s = getClassSession(); return s ? (s.students || []).map(x => ({ id: x.id, name: x.name, class_name: s.className })) : []; }
  if (CH.role === 'owner') return (DATA.students || []).filter(x => x.status === 'active').map(x => ({ id: x.id, name: x.name, class_name: x.class_name }));
  return [];
}
function chErr(e) {
  const m = String((e && e.message) || '');
  if (/does not exist|schema cache|could not find|chat_/.test(m) && !/too_many|bad_/.test(m)) return qt('Chat is not set up yet (run chat_voice.sql in Supabase).', 'چیٹ ابھی سیٹ اپ نہیں ہوئی (Supabase میں chat_voice.sql چلائیں)۔');
  if (/too_many/.test(m)) return qt('Too many messages today. Try again tomorrow.', 'آج بہت زیادہ پیغامات بھیج دیے۔ کل کوشش کریں۔');
  if (/bad_audio/.test(m)) return qt('Voice note is too large. Record a shorter one.', 'وائس نوٹ بہت بڑا ہے۔ چھوٹا ریکارڈ کریں۔');
  return qt('Could not send. Please try again.', 'پیغام نہیں بھیجا جا سکا۔ دوبارہ کوشش کریں۔');
}

function chOpen(role) {
  chClose();
  CH.role = role; CH.to = role === 'parent' ? 'teacher' : (role === 'teacher' ? 'parents' : 'school');
  CH.cls = ''; CH.sid = ''; CH.audio = null; CH.secs = 0;
  const ov = document.createElement('div'); ov.id = 'ch-ov';
  ov.style.cssText = 'position:fixed;inset:0;z-index:9999;background:var(--cream);display:flex;flex-direction:column;padding-top:env(safe-area-inset-top,0px);';
  ov.innerHTML = `
    <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;background:var(--navy);color:var(--gold-soft);">
      <button onclick="chClose()" style="background:none;border:none;color:inherit;font-size:22px;padding:0 6px;">‹</button>
      <b style="flex:1;">💬 ${esc(qt('Chat', 'چیٹ'))}</b>
    </div>
    <div id="ch-list" style="flex:1;overflow-y:auto;padding:12px;"></div>
    <div style="padding:10px 12px calc(10px + env(safe-area-inset-bottom,0px));border-top:1px solid var(--line);background:#fff;">
      <div id="ch-to"></div>
      <div id="ch-prev"></div>
      <textarea id="ch-text" rows="2" maxlength="1000" placeholder="${esc(qt('Write a message…', 'پیغام لکھیں…'))}" style="width:100%;box-sizing:border-box;"></textarea>
      <div style="display:flex;gap:8px;margin-top:8px;">
        <button class="btn-ghost" id="ch-mic" style="flex:none;min-width:70px;" onclick="chRecToggle()">🎤</button>
        <button class="btn-ghost hidden" id="ch-sms" style="flex:none;" onclick="chSms()">📱 SMS</button>
        <button class="btn-primary" id="ch-send" style="flex:1;" onclick="chSend()">${esc(qt('Send', 'بھیجیں'))}</button>
      </div>
      <div id="ch-msg" class="err" style="margin:6px 0 0;"></div>
    </div>`;
  document.body.appendChild(ov);
  chToPaint(); chLoad();
  CH.poll = setInterval(() => { if (!CH.rec) chLoad(); }, 20000);
}
function chClose() {
  clearInterval(CH.poll); clearInterval(CH.tick);
  if (CH.rec) { CH.rec._cancel = true; try { CH.rec.stop(); } catch (e) {} }
  const o = document.getElementById('ch-ov'); if (o) o.remove();
  CH.role = null;
}

// ---------- recipient picker ----------
function chSetTo(v) { CH.to = v; CH.cls = ''; CH.sid = ''; chToPaint(); }
function chSetCls(v) { CH.cls = v; CH.sid = ''; chToPaint(); }
function chSetSid(v) { CH.sid = v; chToPaint(); }
function chToPaint() {
  const el = document.getElementById('ch-to'); if (!el) return;
  const sel = (opts, val, fn) => `<select onchange="${fn}(this.value)" style="margin-bottom:6px;">${opts.map(o => `<option value="${esc(o[0])}"${o[0] === val ? ' selected' : ''}>${esc(o[1])}</option>`).join('')}</select>`;
  const sts = chStudents();
  const classes = [...new Set(sts.map(s => s.class_name).filter(Boolean))].sort();
  let h = '';
  if (CH.role === 'parent') {
    h = sel([['teacher', qt('To: Teacher', 'استاد کو')], ['owner', qt('To: Principal', 'پرنسپل کو')]], CH.to, 'chSetTo');
  } else if (CH.role === 'teacher') {
    h = sel([['parents', qt('To: All parents of my class', 'میری کلاس کے تمام والدین کو')], ['student', qt('To: One student\'s parent', 'ایک طالب علم کے والدین کو')], ['owner', qt('To: Principal', 'پرنسپل کو')]], CH.to, 'chSetTo');
  } else {
    h = sel([['school', qt('To: All parents of the school', 'پورے اسکول کے والدین کو')], ['class', qt('To: Parents of one class', 'ایک کلاس کے والدین کو')], ['student', qt('To: One student\'s parent', 'ایک طالب علم کے والدین کو')], ['teachers', qt('To: Teachers', 'اساتذہ کو')]], CH.to, 'chSetTo');
    if (['class', 'student', 'teachers'].includes(CH.to)) {
      h += sel([['', CH.to === 'teachers' ? qt('All classes', 'تمام کلاسیں') : qt('— choose class —', '— کلاس منتخب کریں —')]].concat(classes.map(c => [c, c])), CH.cls, 'chSetCls');
    }
  }
  if (CH.to === 'student') {
    const list = CH.role === 'owner' ? sts.filter(s => s.class_name === CH.cls) : sts;
    if (CH.role === 'teacher' || CH.cls) h += sel([['', qt('— choose student —', '— طالب علم منتخب کریں —')]].concat(list.map(s => [s.id, s.name])), CH.sid, 'chSetSid');
  }
  el.innerHTML = h;
  const sms = document.getElementById('ch-sms'); if (sms) sms.classList.toggle('hidden', !(CH.role !== 'parent' && CH.to === 'student' && CH.sid));
}
function chTarget() {
  const to = CH.to, none = { p_class: null, p_student: null };
  if (CH.role === 'parent') return Object.assign({ p_to: to }, none);
  if (CH.role === 'teacher') {
    if (to === 'owner') return Object.assign({ p_to: 'owner' }, none);
    if (to === 'student') return CH.sid ? { p_to: 'parents', p_class: null, p_student: CH.sid } : null;
    return Object.assign({ p_to: 'parents' }, none);
  }
  if (to === 'school') return Object.assign({ p_to: 'parents' }, none);
  if (to === 'class') return CH.cls ? { p_to: 'parents', p_class: CH.cls, p_student: null } : null;
  if (to === 'student') return CH.sid ? { p_to: 'parents', p_class: null, p_student: CH.sid } : null;
  return { p_to: 'teacher', p_class: CH.cls || null, p_student: null };
}

// ---------- voice recording (tap to start, tap again to stop, max 120 s) ----------
async function chRecToggle() {
  const msg = document.getElementById('ch-msg');
  if (CH.rec) { CH.rec.stop(); return; }
  if (!window.MediaRecorder || !navigator.mediaDevices) { msg.textContent = qt('Voice recording is not supported on this browser.', 'اس براؤزر میں وائس ریکارڈنگ دستیاب نہیں۔'); return; }
  msg.textContent = '';
  try {
    const st = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mime = ['audio/webm;codecs=opus', 'audio/mp4', 'audio/webm'].find(m => MediaRecorder.isTypeSupported(m)) || '';
    const rec = new MediaRecorder(st, Object.assign({ audioBitsPerSecond: 16000 }, mime ? { mimeType: mime } : {}));
    CH.chunks = []; CH.rec = rec; CH.audio = null; chPrev();
    const t0 = Date.now();
    rec.ondataavailable = e => { if (e.data && e.data.size) CH.chunks.push(e.data); };
    rec.onstop = () => {
      clearInterval(CH.tick); st.getTracks().forEach(t => t.stop()); CH.rec = null;
      const b = document.getElementById('ch-mic'); if (b) b.textContent = '🎤';
      if (rec._cancel) return;
      CH.secs = Math.min(120, Math.max(1, Math.round((Date.now() - t0) / 1000)));
      const fr = new FileReader();
      fr.onload = () => { CH.audio = fr.result; chPrev(); };
      fr.readAsDataURL(new Blob(CH.chunks, { type: rec.mimeType || mime || 'audio/webm' }));
    };
    rec.start();
    CH.tick = setInterval(() => {
      const s = Math.round((Date.now() - t0) / 1000), b = document.getElementById('ch-mic');
      if (b) b.textContent = '⏹ ' + s + 's';
      if (s >= 120) rec.stop();
    }, 500);
  } catch (e) { msg.textContent = qt('Microphone permission is needed.', 'مائیک کی اجازت ضروری ہے۔'); }
}
function chPrev() {
  const p = document.getElementById('ch-prev'); if (!p) return;
  p.innerHTML = CH.audio ? `<div style="display:flex;gap:6px;align-items:center;margin-bottom:6px;"><audio controls src="${CH.audio}" style="flex:1;height:36px;min-width:0;"></audio><button class="btn-ghost danger" style="flex:none;padding:6px 10px;" onclick="CH.audio=null;chPrev()">✕</button></div>` : '';
}

// ---------- send / SMS ----------
async function chSend() {
  const cr = chCreds(), tg = chTarget(), msg = document.getElementById('ch-msg'), ta = document.getElementById('ch-text'), btn = document.getElementById('ch-send');
  if (!cr || !ta) return;
  msg.textContent = '';
  if (!tg) { msg.textContent = qt('Please choose who to send to.', 'پہلے منتخب کریں کہ کسے بھیجنا ہے۔'); return; }
  const body = ta.value.trim();
  if (!body && !CH.audio) return;
  if (!navigator.onLine) { msg.textContent = qt('Internet is needed.', 'انٹرنیٹ ضروری ہے۔'); return; }
  btn.disabled = true;
  try {
    const { error } = await sb.rpc('chat_send', Object.assign({}, cr, tg, { p_body: body || null, p_audio: CH.audio, p_secs: CH.audio ? CH.secs : null }));
    if (error) msg.textContent = chErr(error);
    else { ta.value = ''; CH.audio = null; chPrev(); await chLoad(true); }
  } catch (e) { msg.textContent = chErr(e); }
  btn.disabled = false;
}
async function chSms() {
  const text = (document.getElementById('ch-text').value || '').trim(), msg = document.getElementById('ch-msg');
  if (!CH.sid) return;
  if (!text) { msg.textContent = qt('Write the SMS text first.', 'پہلے SMS کا متن لکھیں۔'); return; }
  let contact = '';
  try {
    if (CH.role === 'owner') { const s = (DATA.students || []).find(x => x.id === CH.sid); contact = s && s.contact; }
    else { const cr = chCreds(); const { data } = await sb.rpc('chat_contact', { p_code: cr.p_code, p_a: cr.p_a, p_b: cr.p_b, p_student: CH.sid }); contact = data; }
  } catch (e) {}
  if (!contact) { alert(qt('No phone number saved for this student.', 'اس طالب علم کا فون نمبر محفوظ نہیں۔')); return; }
  openFatherWhatsapp(contact, text);   // opens the phone's Messages app, pre-filled
}

// ---------- list + play ----------
function chBubble(m) {
  const mine = m.from_role === CH.role;
  const to = m.to_role === 'parents' ? (m.student_name || (m.class_name ? qt('Class ', 'کلاس ') + m.class_name : qt('All parents', 'تمام والدین')))
    : m.to_role === 'owner' ? qt('Principal', 'پرنسپل') : qt('Teacher', 'استاد') + (m.class_name ? ' (' + m.class_name + ')' : '');
  const voice = m.has_audio
    ? `<button class="btn-ghost" id="chv-${m.id}" style="flex:none;padding:6px 12px;margin-top:6px;" onclick="chPlay('${m.id}')">▶ ${esc(qt('Voice', 'وائس'))} ${m.secs || 0}s</button>`
    : (m.had_audio ? `<div class="sub" style="margin-top:6px;">🎙 ${esc(qt('Voice note expired', 'وائس نوٹ ختم ہو گیا'))}</div>` : '');
  return `<div style="display:flex;justify-content:${mine ? 'flex-end' : 'flex-start'};margin-bottom:10px;">
    <div style="max-width:85%;background:${mine ? '#E9F2E4' : '#fff'};border:1px solid var(--line);border-radius:12px;padding:8px 10px;">
      <div class="sub" style="font-size:11px;"><b>${esc(m.from_label || m.from_role)}</b> → ${esc(to)}</div>
      ${m.body ? `<div dir="auto" style="white-space:pre-wrap;font-size:14px;margin-top:4px;">${esc(m.body)}</div>` : ''}${voice}
      <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-top:4px;">
        ${mine || CH.role === 'owner' ? `<button onclick="chDel('${m.id}')" title="${esc(qt('Delete', 'حذف کریں'))}" style="background:none;border:none;padding:0;font-size:13px;opacity:.55;">🗑</button>` : '<span></span>'}
        <span class="sub" style="font-size:10px;">${esc(new Date(m.created_at).toLocaleString())}</span></div>
    </div></div>`;
}
async function chDel(id) {
  if (!confirm(qt('Delete this message? It will be removed for everyone.', 'یہ پیغام حذف کریں؟ یہ سب کے لیے ختم ہو جائے گا۔'))) return;
  const cr = chCreds(), msg = document.getElementById('ch-msg'); if (!cr) return;
  if (!navigator.onLine) { if (msg) msg.textContent = qt('Internet is needed.', 'انٹرنیٹ ضروری ہے۔'); return; }
  try {
    const { error } = await sb.rpc('chat_delete', Object.assign({}, cr, { p_id: id }));
    if (error) { if (msg) msg.textContent = /not_allowed/.test(String(error.message)) ? qt('You can only delete your own messages.', 'آپ صرف اپنے پیغامات حذف کر سکتے ہیں۔') : chErr(error); return; }
    delete CH.cache[id]; await chLoad(true);
  } catch (e) { if (msg) msg.textContent = chErr(e); }
}
async function chLoad(force) {
  const cr = chCreds(), box = document.getElementById('ch-list'); if (!cr || !box || !navigator.onLine) return;
  try {
    const { data, error } = await sb.rpc('chat_list', Object.assign({}, cr, { p_limit: 60 }));
    if (error) { box.innerHTML = `<div class="err">${esc(chErr(error))}</div>`; return; }
    const list = (data || []).slice().reverse();
    const sig = list.map(m => m.id + (m.has_audio ? 'a' : '')).join(',');
    if (!force && box.dataset.sig === sig) return;   // nothing new: don't disturb a playing voice note
    box.dataset.sig = sig;
    box.innerHTML = list.length ? list.map(chBubble).join('') : `<p class="desc">${esc(qt('No messages yet.', 'ابھی کوئی پیغام نہیں۔'))}</p>`;
    box.scrollTop = box.scrollHeight;
  } catch (e) {}
}
async function chPlay(id) {
  const b = document.getElementById('chv-' + id), cr = chCreds(); if (!b || !cr) return;
  const show = d => { const el = document.getElementById('chv-' + id); if (el) el.outerHTML = `<audio controls autoplay src="${d}" style="width:100%;margin-top:6px;"></audio>`; };
  if (CH.cache[id]) { show(CH.cache[id]); return; }
  b.disabled = true; b.textContent = '…';
  try {
    const { data, error } = await sb.rpc('chat_audio', Object.assign({}, cr, { p_id: id }));
    if (error || !data) { b.outerHTML = `<div class="sub">🎙 ${esc(qt('Voice note expired', 'وائس نوٹ ختم ہو گیا'))}</div>`; return; }
    CH.cache[id] = data; show(data);
  } catch (e) { b.disabled = false; b.textContent = '▶'; }
}

console.log('SchoolMS build: 2026-10-06b-money-round-single-table-reload-csp-blob-img-fix-daily-quiz-7am-latest-result-lightsync-staffreq-chat-voice'); // bump this string on every deploy to verify (in browser console) which version is actually running
