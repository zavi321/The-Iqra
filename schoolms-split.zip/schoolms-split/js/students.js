/* SchoolMS — students.js — split from index.html (lines 5222-6209). Load order matters: see index.html */
// ---------------- Students ----------------
let studentSearch = '';
let classCollapsed = {};
let classPage = {};
const STUDENTS_PAGE_SIZE = 30;
function setClassPage(cls, p) { classPage[cls] = p; renderTab(); }
let studentTypeFilter = 'all';
let duesFilter = 'all'; // 'all' or a dues-bucket threshold (as string, e.g. '10000')
function setStudentTypeFilter(v) { studentTypeFilter = v; classPage = {}; renderTab(); }
function setDuesFilter(v) { duesFilter = (duesFilter===v) ? 'all' : v; classPage = {}; renderTab(); }
function toggleClassSection(cls) {
  classCollapsed[cls] = !classCollapsed[cls];
  renderTab();
}
// ============================================================================
// BULK FEE VOUCHERS (CHALLAN)
// One click prints every fee-paying student's voucher for a month (whole school or one
// class) on A4 landscape: 2 students per page, each with tear-off Bank / School / Student
// copies side by side. Amount payable = previous balance (from the same fee ledger the
// student card uses) + this month's monthly fee. Students who already paid this month in
// full, free/orphan students and students with no fee set are skipped and counted.
// ============================================================================
const FV_L = {
  en: {
    title: 'Fee Vouchers (Challan)', voucher: 'Fee Voucher', month: 'Fee month', cls: 'Class', all: 'All classes',
    due: 'Due date', fine: 'Late fee after due date (optional)', copies: 'Copies on each voucher',
    c3: 'Bank + School + Student', c2: 'Bank + School', bankName: 'Bank name', bankTitle: 'Account title',
    bankNo: 'Account no. / IBAN', print: 'Print vouchers',
    count: (n, paid, free, nofee) => n + ' voucher(s) ready' + (paid ? ' \u00b7 ' + paid + ' already paid' : '') + (free ? ' \u00b7 ' + free + ' free/orphan skipped' : '') + (nofee ? ' \u00b7 ' + nofee + ' with no fee set' : ''),
    bankCopy: 'BANK COPY', schoolCopy: 'SCHOOL COPY', studentCopy: 'STUDENT COPY',
    vno: 'Voucher No', student: 'Student', father: 'Father', klass: 'Class', monthFee: 'Fee for month',
    prev: 'Previous balance', payable: 'Payable by due date', dueOn: 'Due date', afterDue: 'After due date',
    bankDetails: 'Deposit to', cashier: 'Cashier / Stamp', depositor: 'Depositor sign', rs: 'Rs'
  },
  ur: {
    title: '\u0641\u06cc\u0633 \u0648\u0627\u0624\u0686\u0631 (\u0686\u0627\u0644\u0627\u0646)', voucher: '\u0641\u06cc\u0633 \u0648\u0627\u0624\u0686\u0631', month: '\u0641\u06cc\u0633 \u06a9\u0627 \u0645\u06c1\u06cc\u0646\u06c1', cls: '\u062c\u0645\u0627\u0639\u062a', all: '\u062a\u0645\u0627\u0645 \u062c\u0645\u0627\u0639\u062a\u06cc\u06ba',
    due: '\u0622\u062e\u0631\u06cc \u062a\u0627\u0631\u06cc\u062e', fine: '\u062a\u0627\u062e\u06cc\u0631 \u067e\u0631 \u062c\u0631\u0645\u0627\u0646\u06c1 (\u0627\u062e\u062a\u06cc\u0627\u0631\u06cc)', copies: '\u06c1\u0631 \u0648\u0627\u0624\u0686\u0631 \u06a9\u06cc \u06a9\u0627\u067e\u06cc\u0627\u06ba',
    c3: '\u0628\u06cc\u0646\u06a9 + \u0633\u06a9\u0648\u0644 + \u0637\u0627\u0644\u0628 \u0639\u0644\u0645', c2: '\u0628\u06cc\u0646\u06a9 + \u0633\u06a9\u0648\u0644', bankName: '\u0628\u06cc\u0646\u06a9 \u06a9\u0627 \u0646\u0627\u0645', bankTitle: '\u0627\u06a9\u0627\u0624\u0646\u0679 \u0679\u0627\u0626\u0679\u0644',
    bankNo: '\u0627\u06a9\u0627\u0624\u0646\u0679 \u0646\u0645\u0628\u0631 / IBAN', print: '\u0648\u0627\u0624\u0686\u0631 \u067e\u0631\u0646\u0679 \u06a9\u0631\u06cc\u06ba',
    count: (n, paid, free, nofee) => n + ' \u0648\u0627\u0624\u0686\u0631 \u062a\u06cc\u0627\u0631' + (paid ? ' \u00b7 ' + paid + ' \u0627\u062f\u0627 \u0634\u062f\u06c1' : '') + (free ? ' \u00b7 ' + free + ' \u0645\u0641\u062a/\u06cc\u062a\u06cc\u0645 \u0634\u0627\u0645\u0644 \u0646\u06c1\u06cc\u06ba' : '') + (nofee ? ' \u00b7 ' + nofee + ' \u0645\u06cc\u06ba \u0641\u06cc\u0633 \u0645\u0642\u0631\u0631 \u0646\u06c1\u06cc\u06ba' : ''),
    bankCopy: '\u0628\u06cc\u0646\u06a9 \u06a9\u0627\u067e\u06cc', schoolCopy: '\u0633\u06a9\u0648\u0644 \u06a9\u0627\u067e\u06cc', studentCopy: '\u0637\u0627\u0644\u0628 \u0639\u0644\u0645 \u06a9\u0627\u067e\u06cc',
    vno: '\u0648\u0627\u0624\u0686\u0631 \u0646\u0645\u0628\u0631', student: '\u0637\u0627\u0644\u0628 \u0639\u0644\u0645', father: '\u0648\u0627\u0644\u062f', klass: '\u062c\u0645\u0627\u0639\u062a', monthFee: '\u0645\u06c1\u06cc\u0646\u06d2 \u06a9\u06cc \u0641\u06cc\u0633',
    prev: '\u0633\u0627\u0628\u0642\u06c1 \u0628\u0642\u0627\u06cc\u0627', payable: '\u0622\u062e\u0631\u06cc \u062a\u0627\u0631\u06cc\u062e \u062a\u06a9 \u0642\u0627\u0628\u0644\u0650 \u0627\u062f\u0627', dueOn: '\u0622\u062e\u0631\u06cc \u062a\u0627\u0631\u06cc\u062e', afterDue: '\u0622\u062e\u0631\u06cc \u062a\u0627\u0631\u06cc\u062e \u06a9\u06d2 \u0628\u0639\u062f',
    bankDetails: '\u062c\u0645\u0639 \u06a9\u0631\u0627\u0626\u06cc\u06ba', cashier: '\u06a9\u06cc\u0634\u0626\u06cc\u0631 / \u0645\u06c1\u0631', depositor: '\u062c\u0645\u0639 \u06a9\u0631\u0627\u0646\u06d2 \u0648\u0627\u0644\u06d2 \u06a9\u06d2 \u062f\u0633\u062a\u062e\u0637', rs: '\u0631\u0648\u067e\u06d2'
  }
};
const fvL = k => (FV_L[LANG] && FV_L[LANG][k] !== undefined) ? FV_L[LANG][k] : FV_L.en[k];
const fvBankKey = () => 'fv_bank_' + ((CURRENT_USER && CURRENT_USER.id) || '');
function fvLoadBank() { try { return JSON.parse(localStorage.getItem(fvBankKey()) || 'null') || {}; } catch (e) { return {}; } }
function fvSaveBank(b) { try { localStorage.setItem(fvBankKey(), JSON.stringify(b)); } catch (e) {} }
const fvClassIdx = c => { const i = CLASS_OPTIONS.indexOf(c); return i < 0 ? 999 : i; };

// Running balance from the fee ledger, counting entries BEFORE month mk (or up to and including it).
function fvBalance(studentId, mk, inclusive) {
  const entries = studentPayments(studentId)
    .filter(e => inclusive ? e.month <= mk : e.month < mk)
    .sort((a, b) => (a.month > b.month ? 1 : a.month < b.month ? -1 : 0) || (new Date(a.pay_date) - new Date(b.pay_date)));
  let running = 0;
  entries.forEach(e => {
    running = money2(running + Number(e.school_fee || 0) + Number(e.sports_fund || 0) + Number(e.admission_fee || 0)
      + Number(e.exam_fee || 0) + Number(e.other_fee || 0) - Number(e.amount || 0));
  });
  return running;
}

function fvBuild(cls, mk) {
  const rows = []; let paid = 0, free = 0, nofee = 0;
  DATA.students.forEach(s => {
    if (s.status === 'inactive') return;
    if (cls !== '*' && s.class_name !== cls) return;
    if (!isFeePaying(s)) { free++; return; }
    const hasEntry = studentPayments(s.id).some(e => e.month === mk);
    const arrears = fvBalance(s.id, mk, false);
    let fee, payable;
    if (hasEntry) { payable = fvBalance(s.id, mk, true); fee = money2(payable - arrears); }   // month already recorded: bill what is still outstanding
    else { fee = Number(s.monthly_fee || 0); payable = money2(arrears + fee); }
    if (payable <= 0) { if (!hasEntry && fee === 0 && arrears === 0) nofee++; else paid++; return; }
    rows.push({ s, arrears, fee, payable });
  });
  rows.sort((a, b) => fvClassIdx(a.s.class_name) - fvClassIdx(b.s.class_name) || String(a.s.name || '').localeCompare(String(b.s.name || '')));
  return { rows, paid, free, nofee };
}

function fvHtml(rows, o) {
  const ur = LANG === 'ur';
  const school = (ur ? schoolNameUrdu() : (CURRENT_PROFILE.school_name || '')) || CURRENT_PROFILE.school_name || 'School';
  const labels = o.copies === 2 ? ['bankCopy', 'schoolCopy'] : ['bankCopy', 'schoolCopy', 'studentCopy'];
  const money = n => esc(fvL('rs')) + ' ' + fmt(n);
  const hasBank = o.bank && (o.bank.name || o.bank.title || o.bank.no);
  const bankHtml = hasBank ? `<div class="fv-bank"><b>${esc(fvL('bankDetails'))}:</b> ${esc(o.bank.name || '')}${o.bank.title ? '<br>' + esc(o.bank.title) : ''}${o.bank.no ? '<br>' + esc(o.bank.no) : ''}</div>` : '';
  const copy = (r, lbl) => {
    const vno = 'FV-' + o.mk.replace('-', '') + '-' + String(r.s.id).replace(/-/g, '').slice(0, 5).toUpperCase();
    return `<div class="fv-copy">
      <div class="fv-top"><div class="fv-school">${esc(school)}</div><div class="fv-tag">${esc(fvL(lbl))}</div></div>
      <div class="fv-sub">${esc(fvL('voucher'))} \u2014 ${esc(monthLabel(o.mk))}</div>
      <table class="fv-t">
        <tr><td>${esc(fvL('vno'))}</td><td>${esc(vno)}</td></tr>
        <tr><td>${esc(fvL('student'))}</td><td>${esc(ur ? studentNameUrdu(r.s) : r.s.name)}</td></tr>
        <tr><td>${esc(fvL('father'))}</td><td>${esc(r.s.father_name || '')}</td></tr>
        <tr><td>${esc(fvL('klass'))}</td><td>${esc(r.s.class_name || '')}</td></tr>
        <tr><td>${esc(fvL('monthFee'))}</td><td>${money(r.fee)}</td></tr>
        <tr><td>${esc(fvL('prev'))}</td><td>${money(r.arrears)}</td></tr>
        <tr class="fv-total"><td>${esc(fvL('payable'))}</td><td>${money(r.payable)}</td></tr>
        <tr><td>${esc(fvL('dueOn'))}</td><td>${esc(fmtDate(o.due) || '')}</td></tr>
        ${o.fine > 0 ? `<tr><td>${esc(fvL('afterDue'))}</td><td>${money(money2(r.payable + o.fine))}</td></tr>` : ''}
      </table>
      ${bankHtml}
      <div class="fv-sign"><span>${esc(fvL('depositor'))}</span><span>${esc(fvL('cashier'))}</span></div>
    </div>`;
  };
  const row = r => `<div class="fv-row" style="--fvc:${labels.length}">${labels.map(l => copy(r, l)).join('')}</div>`;
  const pages = [];
  for (let i = 0; i < rows.length; i += 2) pages.push(`<div class="fv-page">${row(rows[i])}${rows[i + 1] ? row(rows[i + 1]) : ''}</div>`);
  return `<div class="fv-sheet">${pages.join('')}</div>`;
}

function openFeeVouchers() {
  const bank = fvLoadBank();
  const mk = monthKey();
  const classes = Array.from(new Set(DATA.students.filter(s => s.status !== 'inactive').map(s => s.class_name).filter(Boolean)))
    .sort((a, b) => fvClassIdx(a) - fvClassIdx(b) || String(a).localeCompare(String(b)));
  showModal(fvL('title'), `
    <div class="row2">
      <label style="margin-bottom:0;"><span>${esc(fvL('month'))}</span><input id="fv-month" type="month" value="${mk}" onchange="fvMonthChanged()"></label>
      <label style="margin-bottom:0;"><span>${esc(fvL('cls'))}</span><select id="fv-class" onchange="fvPreview()"><option value="*">${esc(fvL('all'))}</option>${classes.map(c => `<option value="${esc(c)}">${esc(c)}</option>`).join('')}</select></label>
    </div>
    <div class="row2" style="margin-top:10px;">
      <label style="margin-bottom:0;"><span>${esc(fvL('due'))}</span><input id="fv-due" type="date" value="${mk}-10"></label>
      <label style="margin-bottom:0;"><span>${esc(fvL('fine'))}</span><input id="fv-fine" type="number" min="0" placeholder="0"></label>
    </div>
    <label style="margin-top:10px;"><span>${esc(fvL('copies'))}</span><select id="fv-copies"><option value="3">${esc(fvL('c3'))}</option><option value="2">${esc(fvL('c2'))}</option></select></label>
    <label><span>${esc(fvL('bankName'))}</span><input id="fv-bank-name" value="${esc(bank.name || '')}"></label>
    <label><span>${esc(fvL('bankTitle'))}</span><input id="fv-bank-title" value="${esc(bank.title || '')}"></label>
    <label><span>${esc(fvL('bankNo'))}</span><input id="fv-bank-no" value="${esc(bank.no || '')}"></label>
    <div id="fv-preview" style="font-size:13px;margin:6px 0 12px;opacity:.85;"></div>
    <div class="flexgap">
      <button class="btn-ghost" onclick="closeModal()">${esc(t.cancel)}</button>
      <button class="btn-primary" id="fv-print-btn" onclick="fvPrint()">${esc(fvL('print'))}</button>
    </div>`);
  fvPreview();
}
function fvMonthChanged() {
  const m = document.getElementById('fv-month'), d = document.getElementById('fv-due');
  if (m && m.value && d) d.value = m.value + '-10';
  fvPreview();
}
function fvPreview() {
  const m = document.getElementById('fv-month'), c = document.getElementById('fv-class');
  if (!m || !c) return;
  const r = fvBuild(c.value, m.value || monthKey());
  const el = document.getElementById('fv-preview'); if (el) el.textContent = fvL('count')(r.rows.length, r.paid, r.free, r.nofee);
  const btn = document.getElementById('fv-print-btn'); if (btn) btn.disabled = r.rows.length === 0;
}
function fvPrint() {
  const mk = document.getElementById('fv-month').value || monthKey();
  const cls = document.getElementById('fv-class').value;
  const val = id => (document.getElementById(id) ? document.getElementById(id).value.trim() : '');
  const bank = { name: val('fv-bank-name'), title: val('fv-bank-title'), no: val('fv-bank-no') };
  fvSaveBank(bank);
  const { rows } = fvBuild(cls, mk);
  if (!rows.length) return;
  const o = { mk, due: dateVal('fv-due', mk + '-10'), fine: Math.max(0, Number(document.getElementById('fv-fine').value) || 0),
              copies: Number(document.getElementById('fv-copies').value) === 2 ? 2 : 3, bank };
  document.getElementById('print-area').innerHTML = fvHtml(rows, o);
  closeModal();
  const clear = () => { const pa = document.getElementById('print-area'); if (pa) pa.innerHTML = ''; window.removeEventListener('afterprint', clear); };
  window.addEventListener('afterprint', clear);
  printWithOrientation('A4 landscape');
}

function tplStudents() {
  return `
    <div style="padding-top:16px;">
      <div class="type-filter">
        <button class="${studentTypeFilter==='all'?'on':''}" onclick="setStudentTypeFilter('all')">${esc(t.all)}</button>
        <button class="${studentTypeFilter==='paying'?'on':''}" onclick="setStudentTypeFilter('paying')">${esc(t.feePaying)}</button>
        <button class="${studentTypeFilter==='free'?'on':''}" onclick="setStudentTypeFilter('free')">${esc(t.free)}</button>
        <button class="${duesFilter!=='all'?'on':''}" onclick="setDuesFilter('due')">${esc(t.due)}</button>
        ${duesFilter!=='all' ? studentDuesBuckets().map(b => `<button class="${duesFilter===String(b)?'on':''}" onclick="setDuesFilter('${b}')">₨${fmt(b)}+</button>`).join('') : ''}
      </div>
      <div class="searchbar">
        <input id="student-search-input" placeholder="${esc(t.search)}" value="${esc(studentSearch)}" oninput="studentSearch=this.value; classPage={}; updateStudentsResults();">
        <button class="icon-btn" title="${esc(t.quickAdmission)}" onclick="openQuickAdmission()" style="background:var(--gold);">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#0F2740" stroke-width="2.5"><path d="M13 2 3 14h7l-1 8 10-12h-7l1-8z"/></svg>
        </button>
        <button class="icon-btn" title="${esc(fvL('title'))}" onclick="openFeeVouchers()">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#E4C765" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2h9l5 5v15H6z"/><path d="M14 2v6h6M9 13h6M9 17h6"/></svg>
        </button>
        <button class="icon-btn" title="${esc(t.addStudent)}" onclick="openAddStudent()">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#E4C765" stroke-width="2.5"><path d="M12 5v14M5 12h14"/></svg>
        </button>
      </div>
      <div id="students-results">${tplStudentsResults()}</div>
    </div>`;
}

// Split out from tplStudents() so that typing in the search box only ever
// rewrites THIS container (#students-results) instead of the whole tab —
// the search input, filter buttons, and add-student button are never torn
// down while the user is mid-keystroke, so the mobile keyboard can't get
// yanked closed by its own DOM node disappearing underneath it.
function studentDuesBuckets() {
  // Dues category thresholds: fixed low tiers, then extend by ₨10,000 steps to
  // cover whatever the highest current due is, computed across ALL students
  // (not just the filtered list) so the buttons stay stable as filters change.
  const duesBuckets = [1000, 5000, 10000, 20000];
  const maxBalanceAll = Math.max(0, ...DATA.students.map(s => studentBalance(s.id)));
  for (let next = 30000; next <= maxBalanceAll; next += 10000) duesBuckets.push(next);
  return duesBuckets;
}

function updateStudentsResults() {
  const el = document.getElementById('students-results');
  if (el) el.innerHTML = tplStudentsResults();
}

function tplStudentsResults() {
  const duesBuckets = studentDuesBuckets();
  // Each category covers its range up to the next threshold; the highest
  // category has no upper limit.
  const duesRangeMatch = (balance, lower) => {
    const idx = duesBuckets.indexOf(lower);
    const upper = duesBuckets[idx + 1];
    return balance >= lower && (upper === undefined || balance < upper);
  };

  const list = DATA.students
    .filter(s => {
      const q = studentSearch.trim().toLowerCase();
      if (!q) return true;
      const nameMatch = (s.name+ (s.father_name||'') + (s.class_name||'')).toLowerCase().includes(q);
      const dueMatch = String(Math.max(0, studentBalance(s.id))).includes(studentSearch.trim());
      return nameMatch || dueMatch;
    })
    .filter(s => studentTypeFilter==='all' || (s.student_type||'paying')===studentTypeFilter)
    .filter(s => duesFilter==='all' || (duesFilter==='due' ? studentBalance(s.id) > 0 : duesRangeMatch(studentBalance(s.id), Number(duesFilter))));
  const cur = monthKey();

  // Group by class, ordered by CLASS_OPTIONS, unknown classes appended at the end
  const groups = {};
  list.forEach(s => {
    const cls = s.class_name || '—';
    if (!groups[cls]) groups[cls] = [];
    groups[cls].push(s);
  });
  const orderedClasses = [
    ...CLASS_OPTIONS.filter(c => groups[c]),
    ...Object.keys(groups).filter(c => !CLASS_OPTIONS.includes(c))
  ];

  const studentCard = s => {
    const paid = studentPayments(s.id).filter(p=>p.month===cur).reduce((a,b)=>a+Number(b.amount),0);
    const due = Math.max(0, Number(s.monthly_fee||0)-paid);
    const type = s.student_type || 'paying';
    const pill = type==='free' ? `<span class="pill free">${esc(t.free)}</span>`
      : type==='orphan' ? `<span class="pill orphan">${esc(t.orphan)}</span>`
      : `<span class="pill ${due>0?'bad':'good'}">${due>0 ? '₨'+fmt(due)+' '+esc(t.due) : esc(t.paid)}</span>`;
    const overdue = monthsOverdue(s);
    const smsBtn = isFeePaying(s) && studentBalance(s.id) > 0
      ? `<button class="print-btn" title="${esc(t.sendSmsToFather)}" onclick="event.stopPropagation(); sendOverdueReminderWhatsapp('${s.id}')">💬</button>`
      : '';
    return `
      <button class="card-btn" onclick="openStudentDetail('${s.id}')">
        <div><div class="nm">${esc(s.name)}</div><div class="sub">${esc(t.fatherName)}: ${esc(s.father_name||'')}</div></div>
        <div style="display:flex;align-items:center;gap:6px;">${smsBtn}${pill}</div>
      </button>`;
  };

  return `
      ${(() => {
        const overdueCount = DATA.students.filter(s => s.status!=='inactive' && isFeePaying(s) && studentBalance(s.id) > 0).length;
        return `
          <div style="display:flex;gap:8px;margin-bottom:12px;">
            ${overdueCount > 0 ? `
              <button class="btn-ghost" style="flex:1;" onclick="openOverdueReminders()">
                📩 ${esc(t.overdueRemindersTitle)} (${overdueCount})
              </button>` : ''}
            <button class="btn-ghost" style="flex:1;" onclick="openPromoteAllConfirm()">
              🎓 Promote All (New Year)
            </button>
          </div>`;
      })()}
      ${list.length===0 ? `<div class="empty">${esc(t.noStudents)}</div>` :
        orderedClasses.map(cls => {
          const collapsed = !!classCollapsed[cls];
          const dueCount = groups[cls].filter(s => {
            const paid = studentPayments(s.id).filter(p=>p.month===cur).reduce((a,b)=>a+Number(b.amount),0);
            return Math.max(0, Number(s.monthly_fee||0)-paid) > 0;
          }).length;
          const totalPages = Math.max(1, Math.ceil(groups[cls].length / STUDENTS_PAGE_SIZE));
          let page = classPage[cls] || 1;
          if (page > totalPages) page = classPage[cls] = totalPages;
          const start = (page - 1) * STUDENTS_PAGE_SIZE;
          const pageItems = groups[cls].slice(start, start + STUDENTS_PAGE_SIZE);
          const classPager = collapsed || groups[cls].length <= STUDENTS_PAGE_SIZE ? '' : `
            <div class="flexgap" style="align-items:center;margin:6px 0 10px;">
              <button class="btn-ghost" ${page<=1?'disabled':''} onclick="event.stopPropagation(); setClassPage('${esc(cls)}', ${page-1})">‹ ${esc(t.previous)}</button>
              <span style="font-size:12px;opacity:.65;white-space:nowrap;">${page} / ${totalPages}</span>
              <button class="btn-ghost" ${page>=totalPages?'disabled':''} onclick="event.stopPropagation(); setClassPage('${esc(cls)}', ${page+1})">${esc(t.next)} ›</button>
            </div>`;
          return `
          <div class="class-header" onclick="toggleClassSection('${esc(cls)}')">
            <span class="cname">${esc(t.className)}: ${esc(cls)}</span>
            <span class="cright">
              <span class="ccount">${groups[cls].length}${dueCount>0 ? ` · ${dueCount} ${esc(t.due)}` : ''}</span>
              <span class="chev ${collapsed?'collapsed':''}">▾</span>
            </span>
          </div>
          ${collapsed ? '' : pageItems.map(studentCard).join('') + classPager}
        `;
        }).join('')}
    `;
}

// ---------------- Promote All Students (bulk class advancement for a new academic year) ----------------

// Shows exactly what will move where before touching anything, since this
// affects every active student at once and can't be undone with one click.
function openPromoteAllConfirm() {
  const active = DATA.students.filter(s => s.status !== 'inactive');
  const counts = {};
  active.forEach(s => { const c = s.class_name || '—'; counts[c] = (counts[c]||0) + 1; });

  const rows = CLASS_OPTIONS.map((cls, i) => {
    const n = counts[cls] || 0;
    if (!n) return '';
    const next = CLASS_OPTIONS[i + 1];
    return `<div class="list-row">
      <div class="nm">${esc(cls)} (${n})</div>
      <div class="sub">${next ? `→ ${esc(next)}` : 'Graduating — class me koi tabdeeli nahi hogi'}</div>
    </div>`;
  }).join('');

  // Any student sitting in a class name outside CLASS_OPTIONS (custom/typo'd
  // class) has no "next" class to move to and would be silently skipped —
  // flag that clearly instead of the admin discovering it after the fact.
  const unknownCount = active.filter(s => !CLASS_OPTIONS.includes(s.class_name)).length;

  showModal('🎓 Promote All Students', `
    <p style="font-size:13px;opacity:.75;">Har student agli class me move ho jayega. 12th grade wale students ki class change nahi hogi (graduating) — unhe manually handle karein.</p>
    <div class="list-card" style="margin:10px 0;">${rows || `<div class="empty">Koi active student nahi mila</div>`}</div>
    ${unknownCount ? `<p class="err">⚠️ ${unknownCount} student(s) ki class list me nahi hai (custom/typo) — inki class promote nahi hogi.</p>` : ''}
    <p style="font-size:12px;opacity:.6;">Fee/DMC records par koi asar nahi padega — sirf class field badlega.</p>
    <div style="display:flex;gap:8px;margin-top:14px;">
      <button class="btn-ghost" style="flex:1;" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" style="flex:1;" onclick="runPromoteAllStudents()">Confirm — Promote All</button>
    </div>
  `);
}

async function runPromoteAllStudents() {
  const active = DATA.students.filter(s => s.status !== 'inactive');
  const byClass = {};
  active.forEach(s => { const c = s.class_name || ''; (byClass[c] = byClass[c] || []).push(s.id); });

  // One update call per class (not per student) — moves every student in that
  // class to the next one in a single request, so even 10,000 students only
  // needs ~13 requests total (one per non-final class), not 10,000.
  for (let i = 0; i < CLASS_OPTIONS.length - 1; i++) {
    const cls = CLASS_OPTIONS[i], next = CLASS_OPTIONS[i + 1];
    const ids = byClass[cls];
    if (!ids || !ids.length) continue;
    // Offline-aware: applied to the local cache immediately either way; if
    // there's no signal right now it's queued and replayed once reconnected.
    // (No per-row conflict check here, unlike single-record edits — this is
    // a rare, once-a-term bulk action rather than a routine daily one.)
    ids.forEach(id => {
      const idx = DATA.students.findIndex(x => x.id === id);
      if (idx >= 0) { DATA.students[idx] = { ...DATA.students[idx], class_name: next }; idbPutRow('students', DATA.students[idx]); }
    });
    if (navigator.onLine) {
      try {
        const { error } = await sb.from('students').update({ class_name: next }).in('id', ids);
        if (!error) continue;
        if (!isNetworkError(error)) { console.error(`Promote ${cls} → ${next} failed:`, error.message); continue; }
      } catch (e) { /* fall through to queueing */ }
    }
    await idbQueueAdd({ table: 'students', action: 'bulk_update', payload: { class_name: next }, ids, baseRow: null, ts: Date.now() });
  }

  renderOfflineBanner();
  closeModal();
  await loadAllData();
  renderTab();
}

function openOverdueReminders() {
  const overdue = DATA.students
    .filter(s => s.status!=='inactive' && isFeePaying(s) && studentBalance(s.id) > 0)
    .sort((a,b) => studentBalance(b.id) - studentBalance(a.id));
  const rows = overdue.length === 0
    ? `<div class="empty">${esc(t.noOverdueStudents)}</div>`
    : overdue.map(s => `
      <div class="card-btn" style="cursor:default;">
        <div>
          <div class="nm">${esc(s.name)}</div>
          <div class="sub">${esc(t.fatherName)}: ${esc(s.father_name||'')} · ₨${fmt(studentBalance(s.id))} (${monthsOverdue(s)}+ ${esc(t.due)})</div>
        </div>
        <button class="btn-primary" style="padding:6px 14px;" onclick="sendOverdueReminderWhatsapp('${s.id}')">${esc(t.send)}</button>
      </div>`).join('');
  showModal(t.overdueRemindersTitle, `
    <div style="font-size:13px;opacity:.75;margin-bottom:14px;">${esc(t.overdueRemindersDesc)}</div>
    ${rows}
  `);
}

function openAddStudent() {
  showModal(t.addStudent, `
    <label><span>${esc(t.studentName)}</span><input id="f-name"></label>
    <label><span>${esc(t.studentNameUr)}</span><input id="f-name-ur" dir="rtl"></label>
    <label><span>${esc(t.fatherName)}</span><input id="f-father"></label>
    <label><span>${esc(t.className)}</span><select id="f-class">${CLASS_OPTIONS.map(c=>`<option>${c}</option>`).join('')}</select></label>
    <label><span>${esc(t.studentType)}</span><select id="f-type" onchange="onAddTypeChange()">${STUDENT_TYPES.map(v=>`<option value="${v}">${esc(typeLabel(v))}</option>`).join('')}</select></label>
    <label><span>${esc(t.admissionDate)}</span><input id="f-admission" type="date" value="${todayISO()}"></label>
    <label><span>${esc(t.contact)}</span><input id="f-contact" type="tel" placeholder="03XXXXXXXXX"></label>
    <label><span>${esc(t.monthlyFee)}</span><input id="f-fee" type="number" value="0"></label>
    <div class="flexgap">
      <button class="btn-ghost" onclick="closeModal()">${esc(t.cancel)}</button>
      <button class="btn-primary" style="flex:1" onclick="guardedSubmit(this, submitAddStudent)">${esc(t.save)}</button>
    </div>
  `);
}
function onAddTypeChange() {
  const type = document.getElementById('f-type').value;
  const feeInput = document.getElementById('f-fee');
  if (type !== 'paying') { feeInput.value = 0; feeInput.disabled = true; }
  else { feeInput.disabled = false; }
}

async function submitAddStudent() {
  const name = document.getElementById('f-name').value.trim();
  const fee = document.getElementById('f-fee').value;
  const type = document.getElementById('f-type').value;
  if (!name || fee==='') return;
  const payload = {
    id: crypto.randomUUID ? crypto.randomUUID() : `local-${Date.now()}`,
    owner_id: CURRENT_USER.id,
    name, name_ur: document.getElementById('f-name-ur').value.trim() || null, father_name: document.getElementById('f-father').value,
    class_name: document.getElementById('f-class').value,
    student_type: type,
    admission_date: dateVal('f-admission'),
    monthly_fee: type==='paying' ? Number(fee) : 0, contact: document.getElementById('f-contact').value, status:'active'
  };
  // Offline-aware: a brand-new student, so there's nothing on the server yet
  // to conflict with — safe to just insert once the connection is back.
  const { queued, error } = await offlineWrite({
    table: 'students', action: 'insert', payload, id: payload.id, baseRow: null,
    run: () => sb.from('students').insert(payload),
    optimisticApply: () => { DATA.students.push(payload); idbPutRow('students', payload); }
  });
  if (!queued && reportSaveError(error)) return;
  closeModal(); if (!queued) await loadAllData(); renderTab();
}

// Admission number format used across schools here: YEAR-#### (e.g. 2026-0001),
// resetting the sequence at the start of each calendar year. Sequence is based
// on the highest existing number for the current year among already-admitted
// students, so it stays correct even if entries were added out of order.
function generateAdmissionNumber() {
  const year = new Date().getFullYear();
  const prefix = year + '-';
  let maxSeq = 0;
  DATA.students.forEach(s => {
    if (s.admission_number && s.admission_number.startsWith(prefix)) {
      const seq = parseInt(s.admission_number.slice(prefix.length), 10);
      if (!isNaN(seq) && seq > maxSeq) maxSeq = seq;
    }
  });
  return prefix + String(maxSeq + 1).padStart(4, '0');
}

// Quick Admission: a short, separate form (kept apart from the full Add
// Student form) for fast intake — basic info + class + father/guardian +
// an auto-generated admission number. On save it opens the new student's
// full profile (openStudentDetail) right away.
function openQuickAdmission() {
  const admissionNo = generateAdmissionNumber();
  showModal(t.quickAdmission, `
    <label><span>${esc(t.admissionNo)}</span><input id="q-admission-no" value="${esc(admissionNo)}" readonly style="opacity:.7;"></label>
    <label><span>${esc(t.studentName)}</span><input id="q-name"></label>
    <label><span>${esc(t.studentNameUr)}</span><input id="q-name-ur" dir="rtl"></label>
    <div class="row2">
      <label style="margin-bottom:0;"><span>${esc(t.gender)}</span><select id="q-gender"><option value="male">${esc(t.male)}</option><option value="female">${esc(t.female)}</option></select></label>
      <label style="margin-bottom:0;"><span>${esc(t.dateOfBirth)}</span><input id="q-dob" type="date"></label>
    </div>
    <label><span>${esc(t.className)}</span><select id="q-class">${CLASS_OPTIONS.map(c=>`<option>${c}</option>`).join('')}</select></label>
    <label><span>${esc(t.fatherName)}</span><input id="q-father"></label>
    <label><span>${esc(t.contact)}</span><input id="q-contact" type="tel" placeholder="03XXXXXXXXX"></label>
    <div class="flexgap">
      <button class="btn-ghost" onclick="closeModal()">${esc(t.cancel)}</button>
      <button class="btn-primary" style="flex:1" onclick="guardedSubmit(this, submitQuickAdmission)">${esc(t.save)}</button>
    </div>
  `);
}

async function submitQuickAdmission() {
  const name = document.getElementById('q-name').value.trim();
  if (!name) return;
  const payload = {
    id: crypto.randomUUID ? crypto.randomUUID() : `local-${Date.now()}`,
    owner_id: CURRENT_USER.id,
    admission_number: document.getElementById('q-admission-no').value,
    name, name_ur: document.getElementById('q-name-ur').value.trim() || null,
    gender: document.getElementById('q-gender').value,
    dob: dateVal('q-dob', null),
    father_name: document.getElementById('q-father').value,
    class_name: document.getElementById('q-class').value,
    student_type: 'paying',
    admission_date: todayISO(),
    monthly_fee: 0, contact: document.getElementById('q-contact').value, status:'active'
  };
  const { queued, error } = await offlineWrite({
    table: 'students', action: 'insert', payload, id: payload.id, baseRow: null,
    run: () => sb.from('students').insert(payload),
    optimisticApply: () => { DATA.students.push(payload); idbPutRow('students', payload); }
  });
  if (!queued && reportSaveError(error)) return;
  closeModal(); if (!queued) await loadAllData(); renderTab();
  openStudentDetail(payload.id);
}

// Builds the same 12-month (Feb-Jan academic year) ledger rows used on the physical
// fee card, so the on-screen ledger and the printed card always match.
// If overrideStartYear is given, that specific academic year is built instead of
// the auto-detected latest one — used to let the user browse older years' records.
function buildAcademicYearLedger(studentId, overrideStartYear) {
  const s = DATA.students.find(x => x.id === studentId);
  const entries = studentPayments(studentId);
  // Grouped as arrays (not a single overwrite) so that if more than one payment
  // row ever exists for the same student+month, every row stays visible and
  // individually deletable — instead of silently hiding all but one, which
  // previously let duplicate entries inflate dashboard totals invisibly.
  const entriesByMonth = {};
  entries.forEach(e => { (entriesByMonth[e.month] = entriesByMonth[e.month] || []).push(e); });

  // The fee card covers Feb–Jan. A calendar month of Feb-Dec belongs to that same
  // year's academic year; January belongs to the *previous* year's academic year.
  const academicYearOf = (year, month) => (month >= 2 ? year : year - 1);

  let startYear;
  if (overrideStartYear) {
    startYear = overrideStartYear;
  } else if (entries.length) {
    // Anchor to the most recent entry so newly-added months always show up here,
    // even if that falls in a different calendar year than admission_date.
    const latest = entries.reduce((a, b) => (a.month > b.month ? a : b));
    const [ey, em] = latest.month.split('-').map(Number);
    startYear = academicYearOf(ey, em);
  } else if (s.admission_date) {
    const d = new Date(s.admission_date);
    startYear = academicYearOf(d.getFullYear(), d.getMonth() + 1);
  } else {
    const now = new Date();
    startYear = academicYearOf(now.getFullYear(), now.getMonth() + 1);
  }

  const CARD_MONTH_ORDER = [2,3,4,5,6,7,8,9,10,11,12,1];
  const monthKeys = CARD_MONTH_ORDER.map(m => {
    const y = m >= 2 ? startYear : startYear + 1;
    return `${y}-${String(m).padStart(2,'0')}`;
  });

  // Opening balance = whatever was still due (or credit) from all months BEFORE this
  // academic year, so the card/ledger always agrees with studentBalance().
  let running = 0;
  entries.filter(e => e.month < monthKeys[0]).forEach(e => {
    running = money2(running + Number(e.school_fee||0) + Number(e.sports_fund||0) + Number(e.admission_fee||0) + Number(e.exam_fee||0) + Number(e.other_fee||0) - Number(e.amount||0));
  });
  const currentMk = todayISO().slice(0,7);
  const rows = [];
  monthKeys.forEach(mk => {
    const list = entriesByMonth[mk] || [];
    if (!list.length) {
      const lastBalance = running;
      // Months that haven't arrived yet shouldn't show a carried-forward due —
      // only months that have actually passed (or the current month) without an
      // entry represent a real missed/unrecorded payment.
      const isFuture = mk > currentMk;
      rows.push({ mk, lastBalance, blank:true, isFuture });
      return;
    }
    list.forEach((e, i) => {
      const lastBalance = running;
      const totalDues = lastBalance + Number(e.school_fee||0) + Number(e.sports_fund||0) + Number(e.admission_fee||0) + Number(e.exam_fee||0) + Number(e.other_fee||0);
      const totalPaid = Number(e.amount||0);
      const balance = money2(totalDues - totalPaid);
      running = balance;
      // dup marks any 2nd+ entry recorded for the same month — flagged in the UI
      // so an accidental duplicate (e.g. from repeated tapping) is easy to spot
      // and remove, rather than being invisible while still counted in totals.
      rows.push({ mk, e, lastBalance, totalDues, totalPaid, balance, blank:false, dup: i>0 });
    });
  });
  return { startYear, rows };
}

// The earliest academic year this student has any record for (from either their
// earliest fee entry or their admission date) — used to stop "Previous Year" once
// there's nothing older to show.
function earliestAcademicYear(studentId) {
  const s = DATA.students.find(x => x.id === studentId);
  const academicYearOf = (year, month) => (month >= 2 ? year : year - 1);
  const entries = studentPayments(studentId);
  let years = entries.map(e => {
    const [ey, em] = e.month.split('-').map(Number);
    return academicYearOf(ey, em);
  });
  if (s && s.admission_date) {
    const d = new Date(s.admission_date);
    years.push(academicYearOf(d.getFullYear(), d.getMonth() + 1));
  }
  return years.length ? Math.min(...years) : null;
}

function openStudentDetail(id, viewYear) {
  const s = DATA.students.find(x=>x.id===id);
  const entries = studentPayments(id).slice().sort((a,b)=> (a.month>b.month?1:a.month<b.month?-1:0) || (new Date(a.pay_date)-new Date(b.pay_date)));
  const { startYear, rows } = buildAcademicYearLedger(id, viewYear);
  const earliestYear = earliestAcademicYear(id);
  const currentBalance = studentBalance(id);
  const totalPaidAllTime = entries.reduce((a,b)=>a+Number(b.amount||0),0);

  showModal(s.name, `
    <div style="font-size:12px;opacity:.7;margin-bottom:12px;display:flex;flex-wrap:wrap;gap:12px;">
      ${s.admission_number ? `<span>${esc(t.admissionNo)}: ${esc(s.admission_number)}</span>` : ''}
      <span>${esc(t.className)}: ${esc(s.class_name||'')}</span>
      <span>${esc(t.fatherName)}: ${esc(s.father_name||'')}</span>
      <span>${esc(t.monthlyFee)}: ₨${fmt(s.monthly_fee)}</span>
      ${s.gender ? `<span>${esc(t.gender)}: ${esc(s.gender===  'female' ? t.female : t.male)}</span>` : ''}
      ${s.dob ? `<span>${esc(t.dateOfBirth)}: ${esc(fmtDate(s.dob))}</span>` : ''}
      ${s.contact ? `<span>${esc(t.contact)}: ${esc(s.contact)}</span>` : ''}
    </div>
    <div class="row2" style="align-items:end;margin-bottom:16px;">
      <label style="margin-bottom:0;"><span>${esc(t.studentType)}</span>
        <select id="d-type">${STUDENT_TYPES.map(v=>`<option value="${v}" ${((s.student_type||'paying')===v)?'selected':''}>${esc(typeLabel(v))}</option>`).join('')}</select>
      </label>
      <button class="btn-ghost" onclick="updateStudentType('${id}')">${esc(t.updateType)}</button>
    </div>
    <div class="row2" style="align-items:end;margin-bottom:16px;">
      <label style="margin-bottom:0;"><span>${esc(t.className)}</span>
        <select id="d-class">
          ${CLASS_OPTIONS.map(c=>`<option value="${esc(c)}" ${s.class_name===c?'selected':''}>${esc(c)}</option>`).join('')}
          ${!CLASS_OPTIONS.includes(s.class_name) && s.class_name ? `<option value="${esc(s.class_name)}" selected>${esc(s.class_name)}</option>` : ''}
        </select>
      </label>
      <button class="btn-ghost" onclick="updateStudentClass('${id}')">${esc(t.save)}</button>
    </div>
    <div class="row2" style="align-items:end;margin-bottom:16px;">
      <label style="margin-bottom:0;"><span>${esc(t.studentNameUr)}</span>
        <input id="d-name-ur" dir="rtl" value="${esc(s.name_ur||'')}">
      </label>
      <button class="btn-ghost" onclick="updateStudentNameUr('${id}')">${esc(t.save)}</button>
    </div>
    <div style="display:flex;gap:8px;margin-bottom:16px;">
      <div class="greenbox" style="flex:1;margin-bottom:0;"><div class="lbl">${esc(t.totalCollectedAllTime)}</div><div class="val">₨${fmt(totalPaidAllTime)}</div></div>
      <div class="greenbox" style="flex:1;margin-bottom:0;background:${currentBalance>0?'#FBEAE5':'#EAF2EC'};">
        <div class="lbl" style="color:${currentBalance>0?'var(--rust)':'var(--sage)'};">${esc(t.balanceCol)}</div>
        <div class="val" style="color:${currentBalance>0?'var(--rust)':'var(--sage)'};">₨${fmt(currentBalance)}</div>
      </div>
    </div>
    ${isFeePaying(s) && currentBalance > 0 ? `
    <button class="btn-ghost" style="width:100%;margin-bottom:16px;color:var(--rust);border-color:var(--rust);" onclick="sendOverdueReminderWhatsapp('${id}')">
      💬 ${esc(t.sendSmsToFather)}
    </button>` : ''}

    <h4 class="section-title" style="margin-top:0;">${esc(t.addEntry)}</h4>
    <div class="row2">
      <input id="p-month" type="month" value="${monthKey()}">
      <input id="p-receipt" placeholder="${esc(t.receiptNo)} (${esc(t.optional)})">
    </div>
    <div class="row2" style="margin-top:8px;">
      <label style="margin-bottom:0;"><span>${esc(t.schoolFeeCol)}</span><input id="p-schoolfee" type="number" value="${s.monthly_fee||0}"></label>
      <label style="margin-bottom:0;"><span>${esc(t.sportsFund)}</span><input id="p-sports" type="number" value="0"></label>
    </div>
    <div class="row2" style="margin-top:8px;">
      <label style="margin-bottom:0;"><span>${esc(t.admissionFeeCol)}</span><input id="p-admission" type="number" value="0"></label>
      <label style="margin-bottom:0;"><span>${esc(t.examFeeCol)}</span><input id="p-exam" type="number" value="0"></label>
    </div>
    <div class="row2" style="margin-top:8px;">
      <label style="margin-bottom:0;"><span>${esc(t.otherFeeCol)}</span><input id="p-other" type="number" value="0"></label>
      <label style="margin-bottom:0;"><span>${esc(t.totalPaidCol)}</span><input id="p-amount" type="number" placeholder="${esc(t.enterAmount)}" value="${s.monthly_fee||''}"></label>
    </div>
    <div class="row2" style="margin-top:8px;">
      <label style="margin-bottom:0;"><span>${esc(t.dateCol)}</span><input id="p-date" type="date" value="${todayISO()}"></label>
    </div>
    <div style="margin-top:10px;"><button class="btn-primary" onclick="guardedSubmit(this, ()=>submitFeePayment('${id}'))">+ ${esc(t.save)}</button></div>

    <div style="display:flex;align-items:center;justify-content:space-between;margin-top:16px;">
      <h4 class="section-title" style="margin:0;">${esc(t.feeLedger)} · ${startYear}–${startYear+1}</h4>
      <div style="display:flex;gap:6px;">
        <button class="btn-ghost" style="padding:5px 10px;font-size:12px;" ${earliestYear!==null && startYear<=earliestYear?'disabled':''} onclick="openStudentDetail('${id}', ${startYear-1})">‹ ${esc(t.previous)}</button>
        <button class="btn-ghost" style="padding:5px 10px;font-size:12px;" onclick="openStudentDetail('${id}', ${startYear+1})">${esc(t.next)} ›</button>
      </div>
    </div>
    <div class="card-table-wrap">
      <table class="card-table">
        <thead><tr>
          <th>${esc(t.month)}</th><th>${esc(t.lastBalance)}</th><th>${esc(t.schoolFeeCol)}</th>
          <th>${esc(t.sportsFund)}</th><th>${esc(t.admissionFeeCol)}</th><th>${esc(t.examFeeCol)}</th><th>${esc(t.otherFeeCol)}</th>
          <th>${esc(t.totalDuesCol)}</th><th>${esc(t.totalPaidCol)}</th><th>${esc(t.balanceCol)}</th>
          <th>${esc(t.receiptNo)}</th><th>${esc(t.dateCol)}</th><th></th><th></th><th></th>
        </tr></thead>
        <tbody>
          ${rows.map(r=>`
            <tr class="${!r.blank && r.dup ? 'dup-row' : ''}">
              <td class="mo">${esc(monthLabel(r.mk))}${!r.blank && r.dup ? ` <span class="dup-tag" title="${LANG==='ur'?'اس مہینے کی دہرائی گئی انٹری — اگر غلطی سے بن گئی ہے تو ہٹا دیں':'Duplicate entry for this month — remove it if added by mistake'}">⚠ ${esc(LANG==='ur'?'ڈپلیکیٹ':'duplicate')}</span>` : ''}</td>
              <td>${r.blank ? '—' : '₨'+fmt(r.lastBalance)}</td>
              <td>${r.blank ? '—' : '₨'+fmt(r.e.school_fee)}</td>
              <td>${r.blank ? '—' : '₨'+fmt(r.e.sports_fund)}</td>
              <td>${r.blank ? '—' : '₨'+fmt(r.e.admission_fee)}</td>
              <td>${r.blank ? '—' : '₨'+fmt(r.e.exam_fee)}</td>
              <td>${r.blank ? '—' : '₨'+fmt(r.e.other_fee)}</td>
              <td>${r.blank ? '—' : '₨'+fmt(r.totalDues)}</td>
              <td>${r.blank ? '—' : '₨'+fmt(r.totalPaid)}</td>
              <td class="${!r.blank && r.balance>0?'bal-neg':'bal-pos'}">${r.blank ? '—' : '₨'+fmt(r.balance)}</td>
              <td>${r.blank ? '—' : esc(r.e.receipt_no||'—')}</td>
              <td>${r.blank ? '—' : esc(fmtDate(r.e.pay_date)||'')}</td>
              <td>${r.blank ? '' : `<button class="print-btn" title="${esc(t.print)}" onclick="printReceipt('${id}','${r.e.id}')">🖨️</button>`}</td>
              <td>${r.blank ? '' : `<button class="print-btn" title="Send SMS to father" onclick="sendPaidReceiptSms('${id}','${r.mk}')">💬</button>`}</td>
              <td>${r.blank ? '' : `<button class="del-x" onclick="deleteFeePayment('${r.e.id}','${id}')">✕</button>`}</td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>
    <div style="margin-top:16px;display:flex;gap:8px;">
      <button class="btn-ghost" style="flex:1;" onclick="printFeeCard('${id}', ${startYear})">🖨️ ${esc(t.printCard)}</button>
      ${s.status === 'inactive'
        ? `<button class="btn-ghost" style="flex:1;" onclick="guardedSubmit(this, ()=>unstrikeStudent('${id}'))">${esc(t.restoreStudent)}</button>`
        : `<button class="btn-ghost danger" style="flex:1;" onclick="confirmStrikeOffStudent('${id}')">${esc(t.strikeOffStudent)}</button>`}
      <button class="btn-ghost danger" style="flex:1;" onclick="confirmDelete('student','${id}')">${esc(t.delete)}</button>
    </div>
  `);
}

// "Strike Off" marks a student who has left the school as inactive (status
// = 'inactive') rather than deleting them — every existing active-student
// filter across the app (`s.status !== 'inactive'`) already excludes them
// from rosters, fee lists, dashboards, etc, while their full fee/admission
// history stays intact and can still be viewed/printed from their record,
// and "un-strike" is always possible if this was done by mistake.
function confirmStrikeOffStudent(id) {
  showModal(t.strikeOffStudent, `
    <p style="font-size:14px;">${esc(t.confirmStrikeOff)}</p>
    <div class="flexgap">
      <button class="btn-ghost" onclick="closeModal()">${esc(t.no)}</button>
      <button class="btn-primary" style="flex:1;background:var(--rust);" onclick="guardedSubmit(this, ()=>strikeOffStudent('${id}'))">${esc(t.yes)}</button>
    </div>
  `);
}
async function strikeOffStudent(id) {
  const { error } = await offlineUpdateStudent(id, { status: 'inactive' });
  if (reportSaveError(error)) return;
  closeModal();
  await loadAllData();
  openStudentDetail(id);
}
async function unstrikeStudent(id) {
  const { error } = await offlineUpdateStudent(id, { status: 'active' });
  if (reportSaveError(error)) return;
  await loadAllData();
  openStudentDetail(id);
}

// Shared offline-aware single-student update — used by the name/class/type
// edit functions below. `patch` is just the changed column(s).
async function offlineUpdateStudent(studentId, patch) {
  const baseRow = DATA.students.find(x => x.id === studentId) || null;
  return offlineWrite({
    table: 'students', action: 'update', payload: patch, id: studentId, baseRow,
    run: () => sb.from('students').update(patch).eq('id', studentId),
    optimisticApply: () => {
      const idx = DATA.students.findIndex(x => x.id === studentId);
      if (idx >= 0) { DATA.students[idx] = { ...DATA.students[idx], ...patch }; idbPutRow('students', DATA.students[idx]); }
    }
  });
}

async function updateStudentType(studentId) {
  const type = document.getElementById('d-type').value;
  const update = { student_type: type };
  if (type !== 'paying') update.monthly_fee = 0;
  const { queued, error } = await offlineUpdateStudent(studentId, update);
  if (!queued && reportSaveError(error)) return;
  if (!queued) await reloadTable('students'); openStudentDetail(studentId);
}

async function updateStudentNameUr(studentId) {
  const nameUr = document.getElementById('d-name-ur').value.trim();
  const { queued, error } = await offlineUpdateStudent(studentId, { name_ur: nameUr || null });
  if (!queued && reportSaveError(error)) return;
  if (!queued) await reloadTable('students'); openStudentDetail(studentId);
}

async function updateStudentClass(studentId) {
  const cls = document.getElementById('d-class').value;
  const { queued, error } = await offlineUpdateStudent(studentId, { class_name: cls });
  if (!queued && reportSaveError(error)) return;
  if (!queued) await reloadTable('students'); openStudentDetail(studentId);
}

async function submitFeePayment(studentId) {
  const month = document.getElementById('p-month').value;
  const schoolFee = document.getElementById('p-schoolfee').value || 0;
  const sportsFund = document.getElementById('p-sports').value || 0;
  const admissionFee = document.getElementById('p-admission').value || 0;
  const examFee = document.getElementById('p-exam').value || 0;
  const otherFee = document.getElementById('p-other').value || 0;
  const amount = document.getElementById('p-amount').value;
  const receiptNo = document.getElementById('p-receipt').value;
  const date = dateVal('p-date');
  if (!month || amount === '' || !Number.isFinite(Number(amount))) {
    alert(LANG === 'ur' ? '\u0645\u06c1\u06cc\u0646\u06c1 \u0627\u0648\u0631 \u0627\u062f\u0627 \u0634\u062f\u06c1 \u0631\u0642\u0645 \u062f\u0631\u062c \u06a9\u0631\u06cc\u06ba\u06d4' : 'Please choose the month and enter the amount paid.');
    return;
  }
  for (const v of [schoolFee, sportsFund, admissionFee, examFee, otherFee]) {
    if (!Number.isFinite(Number(v))) { alert(LANG === 'ur' ? '\u0641\u06cc\u0633 \u06a9\u06cc \u0631\u0642\u0645 \u0645\u06cc\u06ba \u063a\u0644\u0637\u06cc \u06c1\u06d2\u06d4' : 'One of the fee amounts is not a valid number.'); return; }
  }

  // Looked up from the local cache (works offline too) — this is purely for
  // the parent-notification decision below (new entry vs. correcting an
  // existing one), and doubles as the "before" snapshot for conflict checks.
  const existingRow = DATA.feePayments.find(x => x.student_id === studentId && x.month === month) || null;
  const isNewEntry = !existingRow;

  const payload = {
    id: existingRow ? existingRow.id : (crypto.randomUUID ? crypto.randomUUID() : `local-${Date.now()}`),
    owner_id: CURRENT_USER.id, student_id: studentId, month,
    school_fee: Number(schoolFee), sports_fund: Number(sportsFund),
    admission_fee: Number(admissionFee), exam_fee: Number(examFee), other_fee: Number(otherFee),
    amount: Number(amount), receipt_no: receiptNo || null, pay_date: date
  };
  // Root-level duplicate prevention: an atomic upsert keyed on the
  // (student_id, month) UNIQUE constraint in the database (see the one-time
  // SQL migration note above submitFeePayment). This makes it impossible for
  // a second row to ever be created for the same student+month — even if two
  // saves fire at the exact same instant (a double-tap that slips past the
  // button's disabled state, two tabs/devices saving together, etc.) — because
  // the database itself, not just this client's JS, enforces the rule.
  //
  // Offline-aware: with no signal this is applied to the local copy right
  // away and queued — it syncs automatically once the connection is back
  // (see offlineWrite/flushSyncQueue), with a manual conflict prompt if
  // another device changed this same month's entry in the meantime.
  const { queued, error } = await offlineWrite({
    table: 'fee_payments', action: 'upsert', payload, id: payload.id, onConflict: 'student_id,month',
    baseRow: existingRow,
    run: () => sb.from('fee_payments').upsert(payload, { onConflict: 'student_id,month' }),
    optimisticApply: () => {
      const idx = DATA.feePayments.findIndex(x => x.id === payload.id);
      if (idx >= 0) DATA.feePayments[idx] = { ...DATA.feePayments[idx], ...payload };
      else DATA.feePayments.push(payload);
      idbPutRow('fee_payments', payload);
    }
  });
  if (!queued && reportSaveError(error)) return;
  const student = DATA.students.find(x => x.id === studentId);
  // Only auto-fire the parent notification for a genuinely new entry dated today —
  // not when correcting/updating an existing month's entry (that would otherwise
  // re-notify the parent every time a typo is fixed), and not for backdated /
  // historical entries (data import, past-month catch-up). No longer skipped
  // while queued offline — unlike the old wa.me link, the sms: link opens the
  // phone's own Messages app with no internet needed at all.
  if (isNewEntry && student && date === todayISO()) {
    const [my, mm] = month.split('-').map(Number);
    const academicYearOf = (y, m) => (m >= 2 ? y : y - 1);
    const { rows: ledgerRows } = buildAcademicYearLedger(studentId, academicYearOf(my, mm));
    const row = ledgerRows.find(r => !r.blank && r.mk === month);
    const msg = paidReceiptMessage(student.name, monthLabel(month), payload, row ? row.balance : 0);
    openFatherWhatsapp(student.contact, msg); // opens the phone's Messages app, pre-filled, ready to send
  }
  if (!queued) await reloadFeeRow(studentId, month);
  openStudentDetail(studentId);
}

function printReceipt(studentId, entryId) {
  const s = DATA.students.find(x=>x.id===studentId);
  const entries = studentPayments(studentId).slice().sort((a,b)=> (a.month>b.month?1:a.month<b.month?-1:0) || (new Date(a.pay_date)-new Date(b.pay_date)));
  let running = 0, target = null;
  entries.forEach(e => {
    const lastBalance = running;
    const totalDues = lastBalance + Number(e.school_fee||0) + Number(e.sports_fund||0) + Number(e.admission_fee||0) + Number(e.exam_fee||0) + Number(e.other_fee||0);
    const balance = money2(totalDues - Number(e.amount||0));
    running = balance;
    if (e.id === entryId) target = { e, lastBalance, totalDues, balance };
  });
  if (!target) return;
  const { e, lastBalance, totalDues, balance } = target;

  const rowsHtml = [
    [t.lastBalance, lastBalance],
    [t.schoolFeeCol, e.school_fee],
    [t.sportsFund, e.sports_fund],
    [t.admissionFeeCol, e.admission_fee],
    [t.examFeeCol, e.exam_fee],
    [t.otherFeeCol, e.other_fee],
    [t.totalDuesCol, totalDues],
  ].map(([lbl,val]) => `<tr><td class="lbl">${esc(lbl)}</td><td style="text-align:right;">₨${fmt(val)}</td></tr>`).join('');

  document.getElementById('print-area').innerHTML = `
    <div class="receipt-box">
      <h2>${esc(CURRENT_PROFILE.school_name || 'School')}</h2>
      <div class="sub">${esc(t.feeReceipt)} — ${esc(monthLabel(e.month))}</div>
      <table>
        <tr><td class="lbl">${esc(t.receivedFrom)}</td><td style="text-align:right;">${esc(s.name)}</td></tr>
        <tr><td class="lbl">${esc(t.className)}</td><td style="text-align:right;">${esc(s.class_name||'')}</td></tr>
        <tr><td class="lbl">${esc(t.fatherName)}</td><td style="text-align:right;">${esc(s.father_name||'')}</td></tr>
        ${rowsHtml}
        <tr class="total-row"><td>${esc(t.totalAmount)}</td><td style="text-align:right;">₨${fmt(e.amount)}</td></tr>
        <tr><td class="lbl">${esc(t.balanceCol)}</td><td style="text-align:right;">₨${fmt(balance)}</td></tr>
        <tr><td class="lbl">${esc(t.receiptNo)}</td><td style="text-align:right;">${esc(e.receipt_no||'—')}</td></tr>
        <tr><td class="lbl">${esc(t.dateCol)}</td><td style="text-align:right;">${esc(fmtDate(e.pay_date)||'')}</td></tr>
      </table>
      <div class="foot">${esc(t.thankYou)}</div>
    </div>`;
  window.print();
}
async function deleteFeePayment(paymentId, studentId) {
  const baseRow = DATA.feePayments.find(x => x.id === paymentId) || null;
  const { queued, error } = await offlineWrite({
    table: 'fee_payments', action: 'delete', payload: null, id: paymentId, baseRow,
    run: () => sb.from('fee_payments').delete().eq('id', paymentId),
    optimisticApply: () => { DATA.feePayments = DATA.feePayments.filter(x => x.id !== paymentId); idbDeleteRow('fee_payments', paymentId); }
  });
  // Delete already applied locally; only re-read the table if the server rejected it
  // (so the row reappears instead of silently differing from the database).
  if (!queued && error) await reloadTable('fee_payments'); else if (!queued) saveOfflineSnapshotSoon();
  openStudentDetail(studentId);
}

// Print the full 12-month fee card (Feb–Jan), matching the school's printed physical card layout
function printFeeCard(studentId, viewYear) {
  const s = DATA.students.find(x=>x.id===studentId);
  const { startYear, rows } = buildAcademicYearLedger(studentId, viewYear);

  const todayMk = todayISO().slice(0,7);
  const rowsHtml = rows.map(r => `
    <tr class="${r.mk===todayMk ? 'fc-current' : ''}">
      <td class="fc-mo">${esc(monthLabel(r.mk))}</td>
      <td class="${!r.blank && r.lastBalance>0?'fc-due':'fc-zero'}">${r.blank ? '—' : '₨'+fmt(r.lastBalance)}</td>
      <td class="fc-zero">${r.blank ? '—' : '₨'+fmt(r.e.school_fee)}</td>
      <td class="fc-zero">${r.blank ? '—' : '₨'+fmt(r.e.sports_fund)}</td>
      <td class="fc-zero">${r.blank ? '—' : '₨'+fmt(r.e.admission_fee)}</td>
      <td class="fc-zero">${r.blank ? '—' : '₨'+fmt(r.e.exam_fee)}</td>
      <td class="fc-zero">${r.blank ? '—' : '₨'+fmt(r.e.other_fee)}</td>
      <td>${r.blank ? '—' : '₨'+fmt(r.totalDues)}</td>
      <td class="fc-paid">${r.blank ? '—' : '₨'+fmt(r.totalPaid)}</td>
      <td class="${!r.blank && r.balance > 0 ? 'fc-due' : 'fc-paid'}">${r.blank ? '—' : '₨'+fmt(r.balance)}</td>
      <td class="fc-zero">${r.blank ? '—' : esc(r.e.receipt_no||'—')}</td>
      <td class="fc-zero">${r.blank ? '—' : esc(fmtDate(r.e.pay_date)||'—')}</td>
    </tr>`).join('');

  document.getElementById('print-area').innerHTML = `
    <div class="fc-wrap">
      <div class="fc-head">
        <div class="eyebrow">${esc(t.feeLedger)} · ${startYear}–${startYear+1}</div>
        <h2>${esc(CURRENT_PROFILE.school_name || 'School')}</h2>
        <div class="fc-sub">Annual Fee Card</div>
      </div>
      <div class="fc-info">
        <div class="fc-cell"><div class="fc-lbl">${esc(t.studentNameLbl || t.receivedFrom)}</div><div class="fc-val">${esc(s.name)}</div></div>
        <div class="fc-cell"><div class="fc-lbl">${esc(t.className)}</div><div class="fc-val">${esc(s.class_name||'—')}</div></div>
        <div class="fc-cell"><div class="fc-lbl">${esc(t.fatherName)}</div><div class="fc-val">${esc(s.father_name||'—')}</div></div>
      </div>
      <table class="fc-table">
        <thead><tr>
          <th>${esc(t.month)}</th>
          <th>${esc(t.lastBalance)}</th>
          <th>${esc(t.schoolFeeCol)}</th>
          <th>${esc(t.sportsFund)}</th>
          <th>${esc(t.admissionFeeCol)}</th>
          <th>${esc(t.examFeeCol)}</th>
          <th>${esc(t.otherFeeCol)}</th>
          <th>${esc(t.totalDuesCol)}</th>
          <th>${esc(t.totalPaidCol)}</th>
          <th>${esc(t.balanceCol)}</th>
          <th>${esc(t.receiptNo)}</th>
          <th>${esc(t.dateCol)}</th>
        </tr></thead>
        <tbody>${rowsHtml}</tbody>
      </table>
      <div class="fc-foot">
        <div class="fc-brand">${esc(CURRENT_PROFILE.school_name || '')}</div>
        <div class="fc-sig">Principal Signature: <span class="line"></span></div>
      </div>
    </div>`;
  window.print();
}

