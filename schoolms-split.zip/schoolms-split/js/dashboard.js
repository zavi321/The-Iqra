/* SchoolMS — dashboard.js — split from index.html (lines 4752-5221). Load order matters: see index.html */
// ---------------- Dashboard ----------------
// The "Recent Activity" panel is a drill-down menu rather than a flat
// chronological feed: Teacher Salaries / Expenses / Collected Fees, each
// opening its own record list. Collected Fees drills one level deeper into
// a class list, and picking a class shows that class's students.
let dashActivityView = 'menu'; // 'menu' | 'salaries' | 'expenses' | 'fees-classes' | 'fees-class'
let dashActivityClass = null;
function setDashActivityView(view, cls) {
  dashActivityView = view;
  dashActivityClass = cls || null;
  renderTab();
}

// ---------------- Dashboard drill-down popups (click a stat card → related records) ----------------
function dashListRow(nm, sub, right, onclick) {
  return `<div class="list-row" style="cursor:pointer;" onclick="closeModal(); ${onclick}">
    <div><div class="nm">${esc(nm)}</div>${sub ? `<div class="sub">${esc(sub)}</div>` : ''}</div>
    ${right ? `<div>${right}</div>` : ''}

  </div>`;
}
// Like dashListRow, but drills into another dashboard popup (re-renders the
// same modal via showModal) instead of closing it — used for class lists.
function dashDrillRow(nm, sub, right, onclick, isBack) {
  return `<div class="list-row" style="cursor:pointer;${isBack?'border:none;background:none;':''}" onclick="${onclick}">
    <div><div class="nm"${isBack?' style="color:var(--navy);"':''}>${esc(nm)}</div>${sub ? `<div class="sub">${esc(sub)}</div>` : ''}</div>
    ${right ? `<div>${right}</div>` : ''}
  </div>`;
}
function dashEmptyRow() { return `<div style="padding:16px;text-align:center;opacity:.5;font-size:13px;">${esc(t.noRecords)}</div>`; }

function openDashStudentsModal() {
  const active = DATA.students.filter(s => s.status !== 'inactive').slice().sort((a,b)=> (a.name||'').localeCompare(b.name||''));
  const body = active.length ? active.map(s => dashListRow(s.name, s.class_name || '', '', `openStudentDetail('${s.id}')`)).join('') : dashEmptyRow();
  showModal(t.totalStudents, `<div class="list-card">${body}</div>`);
}
function openDashTeachersModal() {
  const list = DATA.teachers.slice().sort((a,b)=> (a.name||'').localeCompare(b.name||''));
  const body = list.length ? list.map(tc => dashListRow(tc.name, tc.subject || '', '', `openTeacherDetail('${tc.id}')`)).join('') : dashEmptyRow();
  showModal(t.totalTeachers, `<div class="list-card">${body}</div>`);
}
function openDashTeacherSalariesModal() {
  const list = DATA.teachers.slice().sort((a,b)=> (a.name||'').localeCompare(b.name||''));
  const body = list.length ? list.map(tc => {
    const paid = teacherPayments(tc.id).reduce((a,b)=>a+Number(b.amount||0),0);
    return dashListRow(tc.name, tc.subject || '', `₨${fmt(paid)}`, `openTeacherDetail('${tc.id}')`);
  }).join('') : dashEmptyRow();
  showModal(t.teacherSalaries, `<div class="list-card">${body}</div>`);
}
function openDashFeesCollectedModal() {
  const cur = monthKey();
  const rows = [];
  DATA.students.forEach(s => studentPayments(s.id).filter(p=>p.month===cur).forEach(p => rows.push({ name: s.name, id: s.id, amount: Number(p.amount||0), date: p.pay_date })));
  rows.sort((a,b)=> new Date(b.date) - new Date(a.date));
  const body = rows.length ? rows.map(r => dashListRow(r.name, fmtDate(r.date)||'', `<span class="amt-pos">+₨${fmt(r.amount)}</span>`, `openStudentDetail('${r.id}')`)).join('') : dashEmptyRow();
  showModal(t.feesCollected, `<div class="list-card">${body}</div>`);
}
function openDashFeesDueModal() {
  const cur = monthKey();
  const rows = [];
  DATA.students.filter(s=>s.status!=='inactive' && isFeePaying(s)).forEach(s => {
    const curEntries = studentPayments(s.id).filter(p=>p.month===cur);
    const paid = curEntries.reduce((a,b)=>a+Number(b.amount||0),0);
    const monthCharge = curEntries.reduce((a,e)=>a+Number(e.school_fee||0)+Number(e.sports_fund||0)+Number(e.admission_fee||0)+Number(e.exam_fee||0),0);
    const due = Math.max(0, monthCharge - paid);
    if (due > 0) rows.push({ name: s.name, id: s.id, class_name: s.class_name, due });
  });
  rows.sort((a,b)=> b.due - a.due);
  const body = rows.length ? rows.map(r => dashListRow(r.name, r.class_name||'', `<span class="amt-neg">₨${fmt(r.due)}</span>`, `openStudentDetail('${r.id}')`)).join('') : dashEmptyRow();
  showModal(t.feesDue, `<div class="list-card">${body}</div>`);
}
function openDashDuesModal() {
  const rows = [];
  DATA.students.filter(s=>s.status!=='inactive' && isFeePaying(s)).forEach(s => {
    const bal = studentBalance(s.id);
    if (bal > 0) rows.push({ name: s.name, id: s.id, class_name: s.class_name, bal });
  });
  rows.sort((a,b)=> b.bal - a.bal);
  const body = rows.length ? rows.map(r => dashListRow(r.name, r.class_name||'', `<span class="amt-neg">₨${fmt(r.bal)}</span>`, `openStudentDetail('${r.id}')`)).join('') : dashEmptyRow();
  showModal(t.totalDuesAllTime, `<div class="list-card">${body}</div>`);
}

// Uses the 'am' session record as each student's status for the day (falls back
// to 'pm' if only that was marked). Data comes from the Class Portal attendance
// feature (DATA.studentAttendance), so a class that hasn't marked yet shows
// those students as not-marked rather than absent.
function todayStudentAttendanceStatuses() {
  const today = todayISO();
  const map = {};
  DATA.studentAttendance.filter(r => r.date === today).forEach(r => {
    if (!map[r.student_id]) map[r.student_id] = {};
    map[r.student_id][r.session] = r.status;
  });
  return map;
}
function todayStudentAttendanceSummary() {
  const map = todayStudentAttendanceStatuses();
  let marked=0, present=0, absent=0, leave=0, sick=0;
  DATA.students.filter(s=>s.status!=='inactive').forEach(s => {
    const rec = map[s.id];
    if (!rec) return;
    const st = rec.am || rec.pm;
    if (!st) return;
    marked++;
    if (st==='present') present++; else if (st==='absent') absent++; else if (st==='leave') leave++; else if (st==='sick') sick++;
  });
  return { marked, present, absent, leave, sick };
}
function classGroupsOf(list) {
  const groups = {};
  list.forEach(s => { const c = s.class_name || '—'; (groups[c] = groups[c] || []).push(s); });
  return [...CLASS_OPTIONS.filter(c => groups[c]), ...Object.keys(groups).filter(c => !CLASS_OPTIONS.includes(c))].map(c => ({ cls: c, students: groups[c] }));
}
function openDashTodayAttendanceModal(cls) {
  const map = todayStudentAttendanceStatuses();
  const statusLabel = st => st==='present'?t.present : st==='absent'?t.absent : st==='leave'?t.leave : st==='sick'?t.sick : t.notMarkedYet;
  const statusColor = st => st==='present'?'var(--sage)' : st==='absent'?'var(--rust)' : st==='leave'?'var(--gold)' : st==='sick'?'#3B6FA0' : 'inherit';
  const active = DATA.students.filter(s=>s.status!=='inactive');

  if (!cls) {
    const groups = classGroupsOf(active);
    const rows = groups.map(g => {
      let marked=0, present=0, absent=0;
      g.students.forEach(s => { const rec=map[s.id]; const st=rec?(rec.am||rec.pm):null; if (st) { marked++; if (st==='present') present++; else if (st==='absent') absent++; } });
      return dashDrillRow(`${t.className}: ${g.cls}`, `${marked}/${g.students.length} ${t.totalStudents}`,
        `<span style="font-size:12px;">${esc(t.present)}: ${present} · ${esc(t.absent)}: ${absent}</span>`,
        `openDashTodayAttendanceModal('${esc(g.cls)}')`);
    }).join('');
    showModal(t.todayAttendance, `<div class="list-card">${rows || dashEmptyRow()}</div>`);
    return;
  }

  const students = active.filter(s => (s.class_name||'—') === cls).slice().sort((a,b)=> (a.name||'').localeCompare(b.name||''));
  const back = dashDrillRow(`‹ ${t.todayAttendance}`, '', '', `openDashTodayAttendanceModal()`, true);
  const rows = students.map(s => {
    const rec = map[s.id]; const st = rec ? (rec.am || rec.pm) : null;
    return dashListRow(s.name, '', `<span style="color:${statusColor(st)};font-weight:600;">${esc(statusLabel(st))}</span>`, `openStudentDetail('${s.id}')`);
  }).join('');
  showModal(cls, `<div class="list-card">${back}${rows || dashEmptyRow()}</div>`);
}

// Teacher attendance is saved as status_am / status_pm / status (old rows that still
// carry checked_in_at_* fields are honoured).
function teacherIsPresent(rec) {
  return !!(rec && (rec.status_am === 'present' || rec.status_pm === 'present' || rec.checked_in_at_am || rec.checked_in_at_pm || rec.checked_in_at));
}
function teacherHasMark(rec) {
  return !!(rec && (rec.status_am || rec.status_pm || rec.status || rec.checked_in_at_am || rec.checked_in_at_pm || rec.checked_in_at));
}
function todayTeacherAttendanceSummary() {
  const today = todayISO();
  let checkedIn = 0;
  DATA.teachers.forEach(tc => {
    const rec = DATA.teacherAttendance.find(a => a.teacher_id === tc.id && a.date === today);
    if (teacherIsPresent(rec)) checkedIn++;
  });
  return { checkedIn };
}
function openDashTeacherAttendanceModal() {
  const today = todayISO();
  const list = DATA.teachers.slice().sort((a,b)=> (a.name||'').localeCompare(b.name||''));
  const rows = list.map(tc => {
    const rec = DATA.teacherAttendance.find(a => a.teacher_id === tc.id && a.date === today);
    const checkedIn = teacherIsPresent(rec);
    return dashListRow(tc.name, tc.subject||'', `<span style="color:${checkedIn?'var(--sage)':'var(--rust)'};font-weight:600;">${esc(checkedIn?t.checkedIn:t.notCheckedIn)}</span>`, `openTeacherDetail('${tc.id}')`);
  }).join('');
  showModal(t.teacherAttendanceToday, `<div class="list-card">${rows || dashEmptyRow()}</div>`);
}

function openDashIncomeExpenseModal() {
  showModal(t.monthlyChartTitle, tplIncomeExpenseChart() || `<div style="padding:16px;text-align:center;opacity:.5;font-size:13px;">${esc(t.noRecords)}</div>`);
}

// Last 6 months of total fee collected — across all students for the small
// dashboard preview, or scoped to one class for the drill-down popup.
function feeCollectionSeries(n, cls) {
  n = n || 6;
  const now = new Date();
  const months = [];
  for (let i = n - 1; i >= 0; i--) { const d = new Date(now.getFullYear(), now.getMonth() - i, 1); months.push(`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`); }
  const students = cls ? DATA.students.filter(s => (s.class_name||'—') === cls) : DATA.students;
  return months.map(mk => {
    let total = 0;
    students.forEach(s => { total += studentPayments(s.id).filter(p=>p.month===mk).reduce((a,b)=>a+Number(b.amount||0),0); });
    return { month: mk, total };
  });
}
function tplFeeCollectionMiniChart() {
  const series = feeCollectionSeries(6);
  const max = Math.max(1, ...series.map(s=>s.total));
  const chartH = 60, barW = 16, gap = 10;
  const chartW = series.length * (barW + gap);
  const bars = series.map((s,i) => {
    const h = Math.round((s.total / max) * chartH);
    return `<rect x="${i*(barW+gap)}" y="${chartH-h}" width="${barW}" height="${Math.max(h,1)}" rx="3" fill="var(--sage)"/>`;
  }).join('');
  return `<svg viewBox="0 0 ${chartW} ${chartH}" style="width:100%;height:60px;display:block;">${bars}</svg>`;
}
function tplFeeCollectionChartSvg(cls) {
  const series = feeCollectionSeries(6, cls);
  const max = Math.max(1, ...series.map(s=>s.total));
  const chartH = 130, barW = 24, gap = 18;
  const chartW = series.length * (barW + gap);
  const bars = series.map((s,i) => {
    const h = Math.round((s.total / max) * chartH);
    return `<g>
      <rect x="${i*(barW+gap)}" y="${chartH-h}" width="${barW}" height="${Math.max(h,1)}" rx="3" fill="var(--sage)"/>
      <text x="${i*(barW+gap)+barW/2}" y="${chartH+16}" text-anchor="middle" font-size="9" fill="var(--ink)" opacity=".65">${esc(monthLabel(s.month))}</text>
    </g>`;
  }).join('');
  return `<svg viewBox="0 0 ${chartW} ${chartH+28}" style="width:100%;height:auto;display:block;margin-top:6px;">${bars}</svg>`;
}
function openDashFeeCollectionGraphModal(cls) {
  if (!cls) {
    const groups = classGroupsOf(DATA.students.filter(s=>s.status!=='inactive'));
    const rows = groups.map(g => {
      const total = feeCollectionSeries(6, g.cls).reduce((a,b)=>a+b.total,0);
      return dashDrillRow(`${t.className}: ${g.cls}`, `${g.students.length} ${t.totalStudents}`, `₨${fmt(total)}`, `openDashFeeCollectionGraphModal('${esc(g.cls)}')`);
    }).join('');
    showModal(t.feeCollectionGraphTitle, `<div class="list-card">${rows || dashEmptyRow()}</div>`);
    return;
  }
  const back = dashDrillRow(`‹ ${t.feeCollectionGraphTitle}`, '', '', `openDashFeeCollectionGraphModal()`, true);
  showModal(cls, `${back}${tplFeeCollectionChartSvg(cls)}`);
}

// ---------------- Dashboard: icon tiles (Overview, Today, This Month, Student Type, More) ----------------
let DASH_OPEN_STAT = null;
const DI = {
  stu:'<path d="M22 10l-10-5-10 5 10 5zM6 12v5c3 3 9 3 12 0v-5"/>',
  tea:'<circle cx="9" cy="7" r="4"/><path d="M2 21v-2a4 4 0 014-4h6a4 4 0 014 4v2"/>',
  inc:'<path d="M12 19V5M5 12l7-7 7 7"/>',
  exp:'<path d="M12 5v14M19 12l-7 7-7-7"/>',
  bal:'<path d="M3 7h18v12H3zM3 7l2-3h14l2 3"/><circle cx="16" cy="13" r="1.5"/>',
  due:'<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18v.5"/>',
  sal:'<rect x="2" y="6" width="20" height="13" rx="2"/><circle cx="12" cy="12.5" r="2.5"/><path d="M6 12.5h.01M18 12.5h.01"/>',
  att:'<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18M9 16l2 2 4-4"/>',
  fee:'<path d="M3 7h18v12H3zM3 7l2-3h14l2 3"/><circle cx="16" cy="13" r="1.5"/>',
  mrk:'<path d="M6 20V11M12 20V4M18 20v-6"/>',
  cer:'<path d="M14 3H6a2 2 0 00-2 2v14a2 2 0 002 2h12a2 2 0 002-2V9zM14 3v6h6M8 13h8M8 17h5"/>',
  pap:'<path d="M14 3H6a2 2 0 00-2 2v14a2 2 0 002 2h12a2 2 0 002-2V9z"/><path d="M8 9h4"/>',
  tmt:'<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M3 10h18M8 15h3"/>',
  adm:'<path d="M4 19.5A2.5 2.5 0 016.5 17H20V3H6.5A2.5 2.5 0 004 5.5z"/>',
  dol:'<path d="M12 1v22M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/>',
  bld:'<path d="M3 21h18M5 21V7l7-4 7 4v14M9 21v-6h6v6"/>',
  crd:'<rect x="2" y="6" width="20" height="13" rx="2"/><path d="M2 10h20"/>',
  gft:'<path d="M20 12v9H4v-9M2 7h20v5H2zM12 21V7M12 7a3 3 0 10-3-3c0 1.7 3 3 3 3zm0 0a3 3 0 113-3c0 1.7-3 3-3 3z"/>',
  hrt:'<path d="M20.8 4.6a5.5 5.5 0 00-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 00-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 000-7.8z"/>',
  gra:'<path d="M3 3v18h18M7 15l4-4 3 3 5-6"/>',
  clk:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  bel:'<path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 01-3.4 0"/>',
  ovw:'<rect x="3" y="3" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="2"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="2"/>',
  bolt:'<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
  sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  cal:'<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
  usr:'<circle cx="9" cy="8" r="3.5"/><path d="M2 21v-1.5a5 5 0 015-5h4a5 5 0 015 5V21M17 4.5a3.5 3.5 0 010 7M22 21v-1.5a5 5 0 00-3.5-4.8"/>',
  dots:'<circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/>'
};
const diSvg = k => `<svg viewBox="0 0 24 24" aria-hidden="true">${DI[k]}</svg>`;

// Every tile: g = group (each group has its own panel right under it), n = tile label,
// l = panel heading, v = value (optional), x = extra HTML shown inside the panel (optional),
// open = existing detail screen to jump to (optional), ic = icon key, c = colour class.
let _dsCache = null;
function dashStatInfo(k) {
  if (!_dsCache) _dsCache = dashBuildStatMap();
  return _dsCache[k];
}
function dashBuildStatMap() {
  const s = computeStats();
  const ur = LANG==='ur';
  const m = {
    stu:{g:'ov', ic:'stu', c:'c2', n:t.students,  l:t.totalStudents, v:dv(s.activeCount), open:'openDashStudentsModal()'},
    tea:{g:'ov', ic:'tea', c:'c4', n:t.teachers,  l:t.totalTeachers, v:dv(DATA.teachers.length), open:'openDashTeachersModal()'},
    inc:{g:'ov', ic:'inc', c:'c3', n:ur?'آمدنی':'Income',  l:t.totalIncome,  v:dv('₨'+fmt(s.totalIncomeAllTime)),  col:'var(--sage)', open:'openDashIncomeExpenseModal()'},
    exp:{g:'ov', ic:'exp', c:'c5', n:ur?'اخراجات':'Expense', l:t.totalExpense, v:dv('₨'+fmt(s.totalExpenseAllTime)), col:'var(--rust)', open:'openDashIncomeExpenseModal()'},
    sal:{g:'ov', ic:'sal', c:'c8', n:ur?'تنخواہیں':'Salaries', l:t.teacherSalaries, v:dv('₨'+fmt(s.totalSalariesAllTime)), open:'openDashTeacherSalariesModal()'},
    bal:{g:'ov', ic:'bal', c:'c7', n:ur?'بقایا':'Net Balance', l:t.netBalance, v:dv('₨'+fmt(s.netBalance)), open:'openDashIncomeExpenseModal()'},
    due:{g:'ov', ic:'due', c:'c1', n:ur?'واجبات':'Total Dues', l:t.totalDuesAllTime, v:dv('₨'+fmt(s.totalDuesAllTime)), col:'var(--rust)', open:'openDashDuesModal()'},

    sat:{g:'td', ic:'att', c:'c1', n:t.students, l:t.todayAttendance, v:dv(todayStudentAttendanceSummary().marked+'/'+s.activeCount), open:'openDashTodayAttendanceModal()'},
    tat:{g:'td', ic:'tea', c:'c4', n:t.teachers, l:t.teacherAttendanceToday, v:dv(todayTeacherAttendanceSummary().checkedIn+'/'+DATA.teachers.length), open:'openDashTeacherAttendanceModal()'},

    fcl:{g:'mo', ic:'dol', c:'c3', n:ur?'وصول':'Collected', l:t.feesCollected, v:dv('₨'+fmt(s.feesCollectedThisMonth)), open:'openDashFeesCollectedModal()'},
    fdu:{g:'mo', ic:'due', c:'c1', n:ur?'واجب':'Fees Due', l:t.feesDue, v:dv('₨'+fmt(s.feesDueThisMonth)), open:'openDashFeesDueModal()'},
    spd:{g:'mo', ic:'sal', c:'c8', n:ur?'تنخواہ':'Salaries', l:t.salaryPaid, v:dv('₨'+fmt(s.salaryPaidThisMonth)), open:'openDashTeacherSalariesModal()'},
    exm:{g:'mo', ic:'exp', c:'c5', n:ur?'اخراجات':'Expenses', l:t.expensesThisMonth, v:dv('₨'+fmt(s.totalExpenseThisMonth)), col:'var(--rust)', open:"setTab('finance')"},
    ofe:{g:'mo', ic:'bld', c:'c6', n:ur?'دیگر فیس':'Other Fees', l:t.otherFeeStandalone, v:dv('₨'+fmt(s.otherFeeThisMonth))},

    pay:{g:'st', ic:'crd', c:'c2', n:t.feePaying, l:t.feePaying, v:dv(s.payingCount)},
    fre:{g:'st', ic:'gft', c:'c6', n:t.free,      l:t.free,      v:dv(s.freeCount), col:'#2563A6'},
    orp:{g:'st', ic:'hrt', c:'c7', n:t.orphan,    l:t.orphan,    v:dv(s.orphanCount), col:'#8A6200'},

    gra:{g:'mr', ic:'gra', c:'c3', n:ur?'فیس گراف':'Fee Graph', l:t.feeCollectionGraphTitle,
         x:() => `<div style="cursor:pointer;" onclick="openDashFeeCollectionGraphModal()">${tplFeeCollectionMiniChart()}</div>`},
    act:{g:'mr', ic:'clk', c:'c4', n:t.recentActivity, l:t.recentActivity, x:() => tplDashActivity()},
  };
  return m;
}

function dashPanelHtml(k) {
  const i = dashStatInfo(k);
  if (!i) return '';
  return `
    <span class="d-tile d-md ${i.c}">${diSvg(i.ic)}</span>
    <div class="d-pbody">
      <div class="d-pl">${esc(i.l)}</div>
      ${i.v!==undefined ? `<div class="d-pv" style="${i.col?'color:'+i.col+';':''}">${esc(String(i.v))}</div>` : ''}
    </div>
    ${i.open ? `<button class="d-pgo" onclick="${i.open}">${esc(LANG==='ur'?'تفصیل':'Details')} ›</button>` : ''}
    <button class="d-px" aria-label="Close" onclick="toggleDashStat('${k}')">✕</button>
    ${i.x ? `<div class="d-pextra">${i.x()}</div>` : ''}`;
}

function toggleDashStat(k) {
  _dsCache = null;
  DASH_OPEN_STAT = (DASH_OPEN_STAT === k) ? null : k;
  document.querySelectorAll('.d-ob').forEach(b => b.classList.toggle('open', b.dataset.k === DASH_OPEN_STAT));
  document.querySelectorAll('.d-panel').forEach(p => { p.classList.remove('show'); p.innerHTML = ''; });
  if (!DASH_OPEN_STAT) return;
  const info = dashStatInfo(DASH_OPEN_STAT);
  const panel = document.getElementById('dash-panel-' + info.g);
  if (!panel) return;
  panel.innerHTML = dashPanelHtml(DASH_OPEN_STAT);
  void panel.offsetWidth; panel.classList.add('show');
}

function tplDashOverview(s) {
  _dsCache = null;
  const ur = LANG==='ur';
  const group = (g, title, keys, sub, icon, desc) => `
    <div class="d-box">
    <div class="d-sec"><span class="d-sec-ic">${diSvg(icon || 'ovw')}</span><span class="d-sec-txt"><span class="d-sec-t">${esc(title)}</span>${desc ? `<span class="d-sec-d">${esc(desc)}</span>` : ''}</span>${sub ? `<small>${esc(sub)}</small>` : ''}</div>
    <div class="d-quick">${keys.map(k => { const i = dashStatInfo(k);
      return `<button class="d-q d-ob ${DASH_OPEN_STAT===k?'open':''}" data-k="${k}" onclick="toggleDashStat('${k}')"><span class="d-tile d-lg ${i.c}">${diSvg(i.ic)}</span>${esc(i.n)}</button>`; }).join('')}</div>
    <div class="d-panel ${DASH_OPEN_STAT && dashStatInfo(DASH_OPEN_STAT).g===g ? 'show' : ''}" id="dash-panel-${g}">${DASH_OPEN_STAT && dashStatInfo(DASH_OPEN_STAT).g===g ? dashPanelHtml(DASH_OPEN_STAT) : ''}</div>
    </div>`;
  const qa = [
    ['att', t.navAttendance,        'openAttendanceHub()', 'c1'],
    ['bel', qt('Teacher Requests', 'اساتذہ کی درخواستیں'), 'openStaffRequests()', 'c8',
      `<span class="sr-badge" style="display:${SR_PENDING ? '' : 'none'};position:absolute;top:-5px;right:-5px;background:#c0392b;color:#fff;border-radius:10px;font-size:10px;line-height:1;padding:3px 6px;font-weight:700;">${SR_PENDING}</span>`],
    ['fee', t.navFees,              "setTab('finance')", 'c3'],
    ['mrk', t.navExamsMarks,        "setTab('marksSheet')", 'c7'],
    ['cer', t.dmc,                  "setTab('dmc')", 'c6'],
    ['pap', t.papers,               "setTab('papers')", 'c2'],
    ['tmt', ur?'ٹائم ٹیبل':'Timetable', "setTab('timetable')", 'c4'],
    ['adm', t.admissionRegister,    "setTab('admissionRegister')", 'c5']
  ].map(([k,label,act,c,extra]) => `<button class="d-q" onclick="${act}"><span class="d-tile d-lg ${c}"${extra ? ' style="position:relative"' : ''}>${diSvg(k)}${extra || ''}</span>${esc(label)}</button>`).join('');
  return `
    ${group('ov', ur?'جائزہ':'Overview', ['stu','tea','inc','exp','sal','bal','due'], ur?'ٹیپ کریں':'tap to open', 'ovw', ur?'طلبہ، اساتذہ، آمدنی اور بقایا':'Students, staff, money & dues')}
    <div class="d-box">
      <div class="d-sec"><span class="d-sec-ic">${diSvg('bolt')}</span><span class="d-sec-txt"><span class="d-sec-t">${esc(ur?'فوری رسائی':'Quick Access')}</span><span class="d-sec-d">${esc(ur?'سب سے زیادہ استعمال ہونے والے ٹولز ایک ٹیپ میں':'Your most-used tools, one tap away')}</span></span></div>
      <div class="d-quick">${qa}</div>
    </div>
    ${group('td', t.todayAttendance, ['sat','tat'], '', 'sun', ur?'آج کتنے طلبہ اور اساتذہ حاضر ہیں':'How many students & teachers are present today')}
    ${group('mo', t.thisMonth, ['fcl','fdu','spd','exm','ofe'], '', 'cal', ur?'اس مہینے کی فیس، تنخواہیں اور اخراجات':'This month’s fees, salaries & expenses')}
    ${group('st', t.studentType, ['pay','fre','orp'], '', 'usr', ur?'فیس دینے والے، مفت اور یتیم طلبہ':'Fee-paying, free & orphan students')}
    ${group('mr', ur?'مزید':'More', ['gra','act'], '', 'dots', ur?'فیس گراف اور حالیہ سرگرمی':'Fee graph & recent activity')}`;
}

function tplDashboard() {
  const s = computeStats();

  const alerts = generateAlerts();
  return `
    <div style="padding-top:16px;">
      ${CACHE_UNAVAILABLE ? `<div style="background:#B00020;color:#fff;font-size:12px;font-weight:600;text-align:center;padding:8px 10px;border-radius:10px;margin-bottom:12px;">${esc(LANG==='ur'
        ? '⚠️ اس ڈیوائس پر کوئی محفوظ ڈیٹا موجود نہیں۔ نیچے دیے گئے اعداد اصل نہیں — انٹرنیٹ سے جوڑیں۔'
        : '⚠️ No cached data on this device yet. Figures below are placeholders, not real balances — please connect to the internet once.')}${OFFLINE_DEBUG_INFO ? `<div style="font-weight:400;opacity:.85;margin-top:4px;font-size:11px;">${esc(OFFLINE_DEBUG_INFO)}</div>` : ''}</div>` : ''}
      ${alerts.length ? `<div onclick="openAlertsModal()" style="cursor:pointer;background:#FBEAE5;color:var(--rust);font-size:13px;font-weight:600;padding:10px 14px;border-radius:12px;margin-bottom:12px;display:flex;justify-content:space-between;align-items:center;">
        <span>🔔 ${esc(LANG==='ur' ? `${alerts.length} اہم الرٹس` : `${alerts.length} Important Alert${alerts.length>1?'s':''}`)}</span>
        <span style="font-size:12px;opacity:.8;">${esc(LANG==='ur' ? 'دیکھیں ›' : 'View ›')}</span>
      </div>` : ''}
      ${tplDashOverview(s)}
    </div>`;
}

// Renders whichever level of the Recent Activity drill-down is currently open.
function tplDashActivity() {
  const backRow = (label, view, cls) => `
    <button class="list-row" style="cursor:pointer;width:100%;border:none;background:none;text-align:left;padding:10px 4px;" onclick="setDashActivityView('${view}'${cls?`,'${esc(cls)}'`:''})">
      <div class="nm" style="color:var(--navy);">‹ ${esc(label)}</div>
    </button>`;

  if (dashActivityView === 'salaries') {
    const rows = [];
    DATA.teachers.forEach(tc => teacherPayments(tc.id).forEach(p => rows.push({ name: tc.name, id: tc.id, amount: p.amount, date: p.pay_date })));
    rows.sort((a,b)=> new Date(b.date) - new Date(a.date));
    return `
      <div class="list-card">
        ${backRow(t.recentActivity, 'menu')}
        ${rows.length===0 ? `<div style="padding:16px;text-align:center;opacity:.5;font-size:13px;">${esc(t.noRecords)}</div>` :
          rows.map(r=>`
            <div class="list-row" style="cursor:pointer;" onclick="openActivityHistory('salary','${r.id}')">
              <div><div class="nm">${esc(r.name)}</div><div class="sub">${esc(fmtDate(r.date)||'')}</div></div>
              <div class="amt-neg">−₨${fmt(r.amount)}</div>
            </div>`).join('')}
      </div>`;
  }

  if (dashActivityView === 'expenses') {
    const rows = DATA.transactions.filter(x=>x.type==='expense').slice().sort((a,b)=> new Date(b.txn_date) - new Date(a.txn_date));
    return `
      <div class="list-card">
        ${backRow(t.recentActivity, 'menu')}
        ${rows.length===0 ? `<div style="padding:16px;text-align:center;opacity:.5;font-size:13px;">${esc(t.noRecords)}</div>` :
          rows.map(x=>`
            <div class="list-row" style="cursor:pointer;" onclick="openActivityHistory('expense','${x.id}')">
              <div><div class="nm">${esc(x.description||'')}</div><div class="sub">${esc(x.category||'')} · ${esc(fmtDate(x.txn_date)||'')}</div></div>
              <div class="amt-neg">−₨${fmt(x.amount)}</div>
            </div>`).join('')}
      </div>`;
  }

  if (dashActivityView === 'fees-classes') {
    const groups = {};
    DATA.students.forEach(s => { const cls = s.class_name || '—'; (groups[cls] = groups[cls]||[]).push(s); });
    const orderedClasses = [...CLASS_OPTIONS.filter(c => groups[c]), ...Object.keys(groups).filter(c => !CLASS_OPTIONS.includes(c))];
    return `
      <div class="list-card">
        ${backRow(t.recentActivity, 'menu')}
        ${orderedClasses.length===0 ? `<div style="padding:16px;text-align:center;opacity:.5;font-size:13px;">${esc(t.noRecords)}</div>` :
          orderedClasses.map(cls=>{
            const collected = groups[cls].reduce((a,s)=> a + studentPayments(s.id).reduce((x,p)=>x+Number(p.amount),0), 0);
            return `
            <div class="list-row" style="cursor:pointer;" onclick="setDashActivityView('fees-class','${esc(cls)}')">
              <div><div class="nm">${esc(t.className)}: ${esc(cls)}</div><div class="sub">${groups[cls].length} ${esc(t.totalStudents)}</div></div>
              <div class="amt-pos">+₨${fmt(collected)}</div>
            </div>`;
          }).join('')}
      </div>`;
  }

  if (dashActivityView === 'fees-class') {
    const cls = dashActivityClass;
    const students = DATA.students.filter(s => (s.class_name || '—') === cls);
    return `
      <div class="list-card">
        ${backRow(t.className + ': ' + cls, 'fees-classes')}
        ${students.length===0 ? `<div style="padding:16px;text-align:center;opacity:.5;font-size:13px;">${esc(t.noRecords)}</div>` :
          students.map(s=>{
            const collected = studentPayments(s.id).reduce((a,p)=>a+Number(p.amount),0);
            const due = Math.max(0, studentBalance(s.id));
            return `
            <div class="list-row" style="cursor:pointer;" onclick="openStudentDetail('${s.id}')">
              <div><div class="nm">${esc(s.name)}</div><div class="sub">${esc(t.fatherName)}: ${esc(s.father_name||'')}${due>0?` · ${esc(t.due)}: ₨${fmt(due)}`:''}</div></div>
              <div class="amt-pos">+₨${fmt(collected)}</div>
            </div>`;
          }).join('')}
      </div>`;
  }

  // Default: top-level menu with the three categories.
  return `
    <div class="list-card">
      <div class="list-row" style="cursor:pointer;" onclick="setDashActivityView('salaries')">
        <div class="nm">${esc(t.teacherSalaries)}</div>
        <div style="opacity:.5;">›</div>
      </div>
      <div class="list-row" style="cursor:pointer;" onclick="setDashActivityView('expenses')">
        <div class="nm">${esc(t.expenses)}</div>
        <div style="opacity:.5;">›</div>
      </div>
      <div class="list-row" style="cursor:pointer;" onclick="setDashActivityView('fees-classes')">
        <div class="nm">${esc(t.collectedFees)}</div>
        <div style="opacity:.5;">›</div>
      </div>
    </div>`;
}

