/* SchoolMS — class-portal.js — split from index.html (lines 12258-12439). Load order matters: see index.html */
// ---------------- Class / Teacher Portal (public, no real login — reached via ?class=1) ----------------
// A teacher on the shared class device logs in once with School Code + the
// class's Login ID + Password (set by the owner under Teachers > Class
// Logins). No Supabase Auth session is ever created for this device — every
// write (attendance mark, exam marks save) re-verifies those same three
// values server-side, so the device can safely stay "logged in" indefinitely,
// including while offline, per class_attendance_marks_migration.sql.
const CLASS_SESSION_KEY = 'sms_class_session'; // { schoolCode, loginId, password, ownerId, className, students, schoolName }
const CLASS_QUEUE_KEY = 'sms_class_queue';

// ---- Diary Portal storage (single school-wide login, separate from the
// per-class Attendance/Marks login above) ----
const DIARY_SESSION_KEY = 'sms_diary_session'; // { schoolCode, password, ownerId, schoolName }
const DIARY_QUEUE_KEY = 'sms_diary_queue';
const DIARY_SUBJECTS_KEY = 'sms_diary_subjects'; // subject names used on this device, remembered as quick-tap buttons
function getDiarySession() { try { return JSON.parse(localStorage.getItem(DIARY_SESSION_KEY) || 'null'); } catch(e) { return null; } }
function setDiarySession(s) { localStorage.setItem(DIARY_SESSION_KEY, JSON.stringify(s)); }
function clearDiarySession() { localStorage.removeItem(DIARY_SESSION_KEY); }
function getDiaryQueue() { try { return JSON.parse(localStorage.getItem(DIARY_QUEUE_KEY) || '[]'); } catch(e) { return []; } }
function setDiaryQueue(q) { localStorage.setItem(DIARY_QUEUE_KEY, JSON.stringify(q)); }
function queueDiaryWrite(item) { const q = getDiaryQueue(); q.push({ ...item, ts: Date.now() }); setDiaryQueue(q); }
function getDiarySubjects() { try { return JSON.parse(localStorage.getItem(DIARY_SUBJECTS_KEY) || '[]'); } catch(e) { return []; } }
function rememberDiarySubject(name) {
  const list = getDiarySubjects();
  if (!list.includes(name)) { list.push(name); localStorage.setItem(DIARY_SUBJECTS_KEY, JSON.stringify(list)); }
  // re-adding a subject that was removed earlier brings it back
  const hidden = getDiaryHiddenSubjects();
  if (hidden.includes(name)) localStorage.setItem(DIARY_HIDDEN_KEY, JSON.stringify(hidden.filter(x => x !== name)));
}
const DIARY_HIDDEN_KEY = 'sms_diary_hidden_subjects'; // starter subjects this device has removed
function getDiaryHiddenSubjects() { try { return JSON.parse(localStorage.getItem(DIARY_HIDDEN_KEY) || '[]'); } catch(e) { return []; } }
function diarySubjectList() {
  const hidden = new Set(getDiaryHiddenSubjects());
  return Array.from(new Set([...DIARY_DEFAULT_SUBJECTS, ...getDiarySubjects()])).filter(x => !hidden.has(x));
}
function removeDiarySubject(name) {
  if (!confirm(t.diaryRemoveConfirm + '\n\n' + name)) return;
  localStorage.setItem(DIARY_SUBJECTS_KEY, JSON.stringify(getDiarySubjects().filter(x => x !== name)));
  const hidden = getDiaryHiddenSubjects();
  if (!hidden.includes(name)) { hidden.push(name); localStorage.setItem(DIARY_HIDDEN_KEY, JSON.stringify(hidden)); }
  renderDiaryMenu();
}
let DIARY_EDIT_SUBJECTS = false;
function toggleDiaryEditSubjects() { DIARY_EDIT_SUBJECTS = !DIARY_EDIT_SUBJECTS; renderDiaryMenu(); }
// A small starter list so the subject screen isn't empty on first use —
// schools can add more (or ones not in this list) with "+ Add Subject",
// and anything added is remembered on that device from then on.
const DIARY_DEFAULT_SUBJECTS = ['Urdu','English','Math','Science','Islamiat','Pak Studies','Computer','Social Studies'];

function getClassSession() { try { return JSON.parse(localStorage.getItem(CLASS_SESSION_KEY) || 'null'); } catch(e) { return null; } }
function setClassSession(s) { localStorage.setItem(CLASS_SESSION_KEY, JSON.stringify(s)); }
function clearClassSession() {
  localStorage.removeItem(CLASS_SESSION_KEY);
  try { history.replaceState(null, '', location.pathname + location.search); } catch (e) {}
}
// Same idea as the parent portal: the class login is kept in the page link (after the #, never sent to a server),
// so the home-screen icon / saved link opens straight into the class without asking again.
function cpSyncUrl() {
  const s = getClassSession(); if (!s) return;
  try { history.replaceState(null, '', location.pathname + (location.search || '?class=1') + '#c=' + [s.schoolCode, s.loginId, s.password].map(x => encodeURIComponent(String(x))).join('/')); } catch (e) {}
}
async function cpLoginFromHash(current) {
  const m = location.hash.match(/^#c=(.+)$/); if (!m || !navigator.onLine) return null;
  let parts; try { parts = m[1].split('/').map(decodeURIComponent); } catch (e) { return null; }
  if (parts.length !== 3 || parts.some(x => !x)) return null;
  const [schoolCode, loginId, password] = parts;
  if (current && current.schoolCode === schoolCode && current.loginId === loginId && current.password === password) return null;
  try {
    const { data } = await sb.rpc('class_login_verify', { p_school_code: schoolCode, p_login_id: loginId, p_password: password });
    if (!data || !data.length) return null;
    setClassSession({ schoolCode, loginId, password, ownerId: data[0].owner_id, className: data[0].class_name, teacherName: data[0].teacher_name || '', schoolName: data[0].school_name || '', students: data[0].students || [] });
    return getClassSession();
  } catch (e) { return null; }
}
function getClassQueue() { try { return JSON.parse(localStorage.getItem(CLASS_QUEUE_KEY) || '[]'); } catch(e) { return []; } }
function setClassQueue(q) { localStorage.setItem(CLASS_QUEUE_KEY, JSON.stringify(q)); }

let CLASS_PORTAL_SCREEN = 'menu'; // 'menu' | 'attendance' | 'marks' | 'register' | 'marksView' | 'addStudent'

// Home-screen manifest for the class attendance portal (?class=1). No token needs to be baked into the URL here — the
// class login persists in localStorage (CLASS_SESSION_KEY) — so every class's
// icon shares the same start_url and just relogs in automatically from that
// saved session. Only the displayed name/title changes per class.
function setupClassPortalManifest(className) {
  try {
    const manifest = {
      name: (className ? className + ' — ' : '') + t.classPortalTitle,
      short_name: className || t.classPortalTitle,
      start_url: './?class=1',
      scope: './',
      display: 'standalone',
      orientation: 'portrait',
      background_color: '#FAF6EC',
      theme_color: '#0F2740',
      icons: [
        { src: 'icon-180.png', sizes: '180x180', type: 'image/png' },
        { src: 'icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
        { src: 'icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' }
      ]
    };
    const blobUrl = URL.createObjectURL(new Blob([JSON.stringify(manifest)], { type: 'application/manifest+json' }));
    const link = document.querySelector('link[rel="manifest"]');
    if (link) link.setAttribute('href', blobUrl);
    const appleTitle = document.querySelector('meta[name="apple-mobile-web-app-title"]');
    if (appleTitle) appleTitle.setAttribute('content', className || t.classPortalTitle);
    document.title = (className ? className + ' — ' : '') + t.classPortalTitle;
  } catch (e) { /* Add to Home Screen just falls back to the main app's manifest — not fatal. */ }
}

async function renderClassPortalEntry() {
  document.getElementById('loading').classList.add('hidden');
  renderAuthShell(`<div id="class-portal-body"><div style="text-align:center;padding:20px 0;opacity:.6;">…</div></div>`);
  await flushClassQueue(); // clear any older offline writes first
  await flushDiaryQueue();
  let session = getClassSession();
  const fromHash = await cpLoginFromHash(session);
  if (fromHash) session = fromHash;
  setupClassPortalManifest(session && session.className);
  if (session) {
    CLASS_PORTAL_SCREEN = 'menu';
    // Silently try to refresh the roster if online; the cached one still works if this fails.
    if (navigator.onLine) {
      try {
        const { data } = await sb.rpc('class_login_verify', { p_school_code: session.schoolCode, p_login_id: session.loginId, p_password: session.password });
        if (data && data.length) {
          session.students = data[0].students || [];
          session.className = data[0].class_name;
          setClassSession(session);
        }
      } catch(e) {}
    }
    renderClassPortalMenu();
  } else {
    renderClassPortalLoginForm();
  }
  window.addEventListener('online', () => { flushClassQueue(); flushDiaryQueue(); });
  setInterval(() => { if (navigator.onLine) { flushClassQueue(); flushDiaryQueue(); } }, 20000);
}

function renderClassPortalLoginForm() {
  const body = document.getElementById('class-portal-body');
  body.innerHTML = `
    <h2>${esc(t.classPortalTitle)}</h2>
    <p class="desc">${esc(t.classPortalDesc)}</p>
    <label><span>${esc(t.parentSchoolCodeLabel)}</span><input id="cp-school-code" style="text-transform:uppercase;" autocapitalize="characters"></label>
    <label><span>${esc(t.loginId)}</span><input id="cp-login" autocapitalize="none"></label>
    <label><span>${esc(t.classLoginPassword)}</span><input id="cp-pw" type="password"></label>
    <div id="cp-msg" style="font-size:12px;margin-bottom:8px;"></div>
    <button class="btn-primary" style="width:100%;" onclick="submitClassPortalLogin()">${esc(t.classPortalLoginButton)}</button>
  `;
}

async function submitClassPortalLogin() {
  const msg = document.getElementById('cp-msg');
  const schoolCode = document.getElementById('cp-school-code').value.trim();
  const loginId = document.getElementById('cp-login').value.trim();
  const password = document.getElementById('cp-pw').value;
  if (!schoolCode || !loginId || !password) return;
  msg.textContent = '…';
  if (!navigator.onLine) { msg.innerHTML = `<div class="err">${esc(t.classPortalOfflineNoList)}</div>`; return; }
  try {
    const { data, error } = await sb.rpc('class_login_verify', { p_school_code: schoolCode, p_login_id: loginId, p_password: password });
    if (error) { console.error('class_login_verify', error); const locked = /too_many/.test(error.message||''); msg.innerHTML = `<div class="err">${locked ? 'Too many wrong attempts. Please try again after 15 minutes. / بہت زیادہ غلط کوششیں۔ 15 منٹ بعد دوبارہ کوشش کریں۔' : esc(t.classPortalInvalid)}</div>`; return; }
    if (!data || !data.length) { msg.innerHTML = `<div class="err">${esc(t.classPortalInvalid)}</div>`; return; }
    setClassSession({
      schoolCode, loginId, password,
      ownerId: data[0].owner_id, className: data[0].class_name, teacherName: data[0].teacher_name || '',
      schoolName: data[0].school_name || '', students: data[0].students || []
    });
    setupClassPortalManifest(data[0].class_name);
    CLASS_PORTAL_SCREEN = 'menu';
    renderClassPortalMenu();
  } catch(e) {
    console.error(e); msg.innerHTML = `<div class="err">${esc(t.classPortalInvalid)}</div>`;
  }
}

function classPortalLogout() {
  clearClassSession();
  renderClassPortalLoginForm();
}

