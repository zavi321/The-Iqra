/* SchoolMS — diary-portal.js — split from index.html (lines 13883-14390). Load order matters: see index.html */
// ---------------- Diary Portal (public, ?diary=1) ----------------
// One school-wide login (School Code + Diary Password, set by the owner and
// checked server-side by diary_login_verify), used by whichever teacher is
// in the room at the time. A subject is picked first, then a class, then the
// entry is written — so no teacher can write into a subject that isn't
// theirs to begin with by simply not tapping it. Entries save straight to
// Supabase when online, or queue locally (same pattern as the Class Portal
// above) and sync automatically once the connection is back.
let DIARY_SCREEN = 'menu'; // 'menu' | 'classes' | 'entry'
let DIARY_SUBJECT = '';
let DIARY_CLASS = '';
let DIARY_FROM_CLASS = false; // true when the diary is opened from inside the Teacher Portal (?class=1)

async function renderDiaryPortalEntry() {
  document.getElementById('loading').classList.add('hidden');
  renderAuthShell(`<div id="diary-portal-body"><div style="text-align:center;padding:20px 0;opacity:.6;">…</div></div>`);
  await flushDiaryQueue(); // clear any older offline writes first
  const session = getDiarySession();
  try { history.replaceState({ diary: 'menu' }, ''); } catch(e) {}
  window.addEventListener('popstate', diaryPopState);
  if (session) {
    DIARY_SCREEN = 'menu';
    renderDiaryMenu();
  } else {
    renderDiaryLoginForm();
  }
  window.addEventListener('online', () => flushDiaryQueue());
  setInterval(() => { if (navigator.onLine) flushDiaryQueue(); }, 20000);
}

function renderDiaryLoginForm() {
  const body = document.getElementById('diary-portal-body');
  body.innerHTML = `
    <h2>${esc(t.diaryPortalTitle)}</h2>
    <p class="desc">${esc(t.diaryPortalDesc)}</p>
    <label><span>${esc(t.parentSchoolCodeLabel)}</span><input id="dp-school-code" style="text-transform:uppercase;" autocapitalize="characters"></label>
    <label><span>${esc(t.diaryPasswordLabel)}</span><input id="dp-pw" type="password"></label>
    <div id="dp-msg" style="font-size:12px;margin-bottom:8px;"></div>
    <button class="btn-primary" style="width:100%;" onclick="submitDiaryLogin()">${esc(t.diaryPortalLoginButton)}</button>
  `;
}

async function submitDiaryLogin() {
  const msg = document.getElementById('dp-msg');
  const schoolCode = document.getElementById('dp-school-code').value.trim();
  const password = document.getElementById('dp-pw').value;
  if (!schoolCode || !password) return;
  msg.textContent = '…';
  if (!navigator.onLine) { msg.innerHTML = `<div class="err">${esc(t.classPortalOfflineNoList)}</div>`; return; }
  try {
    const { data, error } = await sb.rpc('diary_login_verify', { p_school_code: schoolCode, p_password: password });
    if (error && /too_many/.test(error.message||'')) { msg.innerHTML = `<div class="err">Too many wrong attempts. Please try again after 15 minutes. / بہت زیادہ غلط کوششیں۔ 15 منٹ بعد دوبارہ کوشش کریں۔</div>`; return; }
    if (error || !data || !data.length) { msg.innerHTML = `<div class="err">${esc(t.diaryPortalInvalid)}</div>`; return; }
    setDiarySession({ schoolCode, password, ownerId: data[0].owner_id, schoolName: data[0].school_name || '' });
    DIARY_SCREEN = 'menu';
    renderDiaryMenu();
  } catch(e) {
    msg.innerHTML = `<div class="err">${esc(t.diaryPortalInvalid)}</div>`;
  }
}

function diaryPortalLogout() {
  clearDiarySession();
  renderDiaryLoginForm();
}

// Phone back button: every Diary screen gets its own history entry, so Back
// goes dashboard <- classes <- entry instead of closing the whole Diary.
function diaryBack(kind) {
  const st = history.state;
  if (st && st.diary && st.diary !== 'menu') { history.back(); return; }
  if (kind === 'classes') renderDiaryClasses(DIARY_SUBJECT, true); else renderDiaryMenu();
}
function diaryPopState(e) {
  if (DIARY_FROM_CLASS || !document.getElementById('diary-portal-body')) return;
  const st = e.state;
  if (st && st.diary === 'classes') renderDiaryClasses(st.subject, true);
  else if (st && st.diary === 'entry') { DIARY_SUBJECT = st.subject; renderDiaryEntryForm(st.cls, true); }
  else renderDiaryMenu();
}
// ---- Parent Messages inside Diary Portal (subject-wise) ----
let DPM_NAMES = [], DPM_IDX = 0;
function dpmArgs(s) { return { p_school_code: s.schoolCode, p_password: s.password }; }
function dpmBox() { return document.getElementById('dpm-body'); }
function dpmErr(e) {
  const m = String((e && e.message) || '');
  if (/does not exist|schema cache|could not find/.test(m)) return qt('Not set up yet (run the SQL in Supabase).', 'ابھی سیٹ اپ نہیں ہوا۔');
  if (/invalid_login|too_many/.test(m)) return qt('Login failed. Please login again.', 'دوبارہ لاگ اِن کریں۔');
  return qt('Something went wrong. Please try again.', 'کچھ غلط ہو گیا۔ دوبارہ کوشش کریں۔');
}
function dpmKey(s, kind, name) { return 'dpm_' + kind + '_' + s.schoolCode + (name ? '_' + String(name).toLowerCase().trim() : ''); }
async function dpmFetchList(s, name) {
  const k = dpmKey(s, 'list', name);
  if (!navigator.onLine) return pmCacheGet(k);
  let res;
  try { res = await sb.rpc('parent_message_list_subject', Object.assign(dpmArgs(s), { p_subject: name })); }
  catch (e) { return pmCacheGet(k); }
  if (res.error) { if (pmIsNet(res.error)) return pmCacheGet(k); throw res.error; }
  pmCacheSet(k, res.data || []); return res.data || [];
}
async function dpmOpen() {
  const s = getDiarySession(), body = document.getElementById('diary-portal-body');
  if (!s || !body) return;
  DIARY_SCREEN = 'pm';
  body.innerHTML = `
    <button class="btn-ghost" style="padding:9px 14px;margin-bottom:10px;" onclick="renderDiaryMenu()">‹ ${esc(qt('Back', 'واپس'))}</button>
    <h2 style="margin-top:0;">📩 ${esc(qt('Parent Messages', 'والدین کے پیغامات'))}</h2>
    <div id="dpm-body"><div style="opacity:.6;">…</div></div>`;
  const ck = dpmKey(s, 'counts');
  let data = null;
  if (navigator.onLine) {
    try {
      const res = await sb.rpc('parent_message_subject_counts', dpmArgs(s));
      if (res.error) { if (!pmIsNet(res.error)) throw res.error; }
      else { data = res.data || []; pmCacheSet(ck, data); }
    } catch (e) {
      if (!pmIsNet(e)) { dpmBox().innerHTML = `<div class="err">${esc(dpmErr(e))}</div>`; return; }
    }
  }
  const offline = data === null;
  if (offline) data = pmCacheGet(ck) || [];
  const unread = {}; data.forEach(r => { unread[r.subject] = r.unread; });
  DPM_NAMES = Array.from(new Set([...diarySubjectList(), ...Object.keys(unread)]));
  dpmBox().innerHTML = (offline ? `<p class="desc">📴 ${esc(qt('Offline — showing saved messages.', 'آف لائن — محفوظ پیغامات دکھائے جا رہے ہیں۔'))}</p>` : '')
    + `<div style="display:flex;flex-wrap:wrap;gap:8px;">${DPM_NAMES.map((n, i) =>
      `<button class="btn-primary" style="flex:none;padding:9px 16px;" onclick="dpmSubject(${i})">${esc(n)}${unread[n] ? ` <span style="background:#d33;color:#fff;border-radius:10px;padding:1px 7px;font-size:12px;margin-inline-start:4px;">${unread[n]}</span>` : ''}</button>`).join('')}</div>`;
  // save every subject's messages on this phone so they open without internet too
  if (!offline) data.forEach(r => { dpmFetchList(s, r.subject).catch(() => {}); });
}
async function dpmSubject(i) {
  const s = getDiarySession(), body = document.getElementById('diary-portal-body');
  if (!s || !body) return;
  DPM_IDX = i; const name = DPM_NAMES[i];
  body.innerHTML = `
    <button class="btn-ghost" style="padding:9px 14px;margin-bottom:10px;" onclick="dpmOpen()">‹ ${esc(qt('Back', 'واپس'))}</button>
    <h2 style="margin-top:0;">${esc(name)}</h2>
    <div id="dpm-body"><div style="opacity:.6;">…</div></div>`;
  try {
    const wasOnline = navigator.onLine;
    const list = await dpmFetchList(s, name);
    if (list === null) { dpmBox().innerHTML = `<div class="err">${esc(qt('Not saved on this phone yet. Open once with internet.', 'ابھی اس فون میں محفوظ نہیں۔ ایک بار انٹرنیٹ پر کھولیں۔'))}</div>`; return; }
    dpmBox().innerHTML = (wasOnline && navigator.onLine ? '' : `<p class="desc">📴 ${esc(qt('Offline — showing saved messages.', 'آف لائن — محفوظ پیغامات دکھائے جا رہے ہیں۔'))}</p>`)
      + (list.length ? list.map(dpmRow).join('') : `<p class="desc">${esc(qt('No messages yet.', 'ابھی کوئی پیغام نہیں۔'))}</p>`);
    if (wasOnline && navigator.onLine) sb.rpc('parent_message_mark_read_subject', Object.assign(dpmArgs(s), { p_subject: name })).then(() => {}, () => {});
  } catch (e) { dpmBox().innerHTML = `<div class="err">${esc(dpmErr(e))}</div>`; }
}
function dpmRow(m) {
  const unread = !m.subject_read_at;
  return `
    <div class="list-row" style="flex-direction:column;align-items:stretch;">
      <div style="display:flex;justify-content:space-between;gap:8px;">
        <div class="nm">${esc(m.student_name || '')}${m.class_name ? ' · ' + esc(m.class_name) : ''}${unread ? pmNewTag() : ''}</div>
        <div class="sub" style="flex:none;">${esc(fmtDate((m.created_at || '').slice(0, 10)) || '')}</div>
      </div>
      ${m.father_name ? `<div class="sub">${esc(t.fatherName)}: ${esc(m.father_name)}</div>` : ''}
      <div style="margin-top:6px;font-size:13px;line-height:1.5;white-space:pre-wrap;">${esc(m.message || '')}</div>
      ${pmRepliesHtml(m)}
      <div style="display:flex;justify-content:flex-end;margin-top:6px;">
        <button class="btn-ghost" style="flex:none;padding:4px 12px;font-size:12px;" onclick="pmToggleReply('${m.id}')">↩ ${esc(qt('Reply', 'جواب'))}</button>
      </div>
      <div id="pm-rbox-${m.id}" class="hidden" style="margin-top:6px;">
        <textarea id="pm-rtxt-${m.id}" maxlength="500" rows="2" style="width:100%;box-sizing:border-box;" placeholder="${esc(qt('Write your reply…', 'اپنا جواب لکھیں…'))}"></textarea>
        <button class="btn-primary" style="width:100%;margin-top:6px;" onclick="dpmSendReply('${m.id}')">${esc(qt('Send reply', 'جواب بھیجیں'))}</button>
        <div id="pm-rst-${m.id}" style="font-size:12px;margin-top:6px;"></div>
      </div>
    </div>`;
}
async function dpmSendReply(id) {
  const s = getDiarySession(), ta = document.getElementById('pm-rtxt-' + id), st = document.getElementById('pm-rst-' + id);
  if (!s || !ta || !st) return;
  const text = ta.value.trim();
  const bad = m => { st.innerHTML = `<div class="err">${esc(m)}</div>`; };
  if (!text) { bad(qt('Please write a reply first.', 'پہلے جواب لکھیں۔')); return; }
  const saveOffline = () => {
    queueDiaryWrite({ type: 'pm_reply_subject', schoolCode: s.schoolCode, password: s.password, messageId: id, text });
    pmCacheAddReply(dpmKey(s, 'list', DPM_NAMES[DPM_IDX]), id, text);
    dpmSubject(DPM_IDX);
  };
  if (!navigator.onLine) { saveOffline(); return; }
  st.textContent = '…';
  try {
    const { error } = await sb.rpc('parent_message_reply_subject', Object.assign(dpmArgs(s), { p_message_id: id, p_text: text }));
    if (error) { if (pmIsNet(error)) { saveOffline(); return; } bad(dpmErr(error)); return; }
    dpmSubject(DPM_IDX);
  } catch (e) { saveOffline(); }
}

function renderDiaryMenu() {
  DIARY_SCREEN = 'menu';
  DIARY_EDIT_SUBJECTS = DIARY_EDIT_SUBJECTS && !!document.getElementById('diary-portal-body');
  const session = getDiarySession();
  const body = document.getElementById('diary-portal-body');
  if (!session || !body) return;
  const queue = getDiaryQueue();
  const subjects = diarySubjectList();
  const editing = DIARY_EDIT_SUBJECTS;
  body.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;">
      <h2 style="margin:0;">${esc(session.schoolName || t.diaryMenuTitle)}</h2>
      <button class="btn-ghost" style="flex:none;padding:7px 12px;font-size:12px;" onclick="diaryPortalLogout()">${esc(t.diaryLogout)}</button>
    </div>
    <p class="desc">${esc(t.diaryMenuDesc)}</p>
    <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px;">
      ${subjects.map(s => editing
        ? `<span style="display:inline-flex;align-items:stretch;border-radius:10px;overflow:hidden;border:1px solid var(--rust,#b5452f);"><span style="padding:9px 12px;">${esc(s)}</span><button style="flex:none;border:0;background:var(--rust,#b5452f);color:#fff;padding:0 12px;font-size:16px;" onclick="removeDiarySubject('${esc(s).replace(/'/g,"\\'")}')">✕</button></span>`
        : `<button class="btn-primary" style="flex:none;padding:9px 16px;" onclick="renderDiaryClasses('${esc(s).replace(/'/g,"\\'")}')">${esc(s)}</button>`).join('')}
      ${editing ? '' : `<button class="btn-ghost" style="flex:none;padding:9px 16px;" onclick="promptDiaryNewSubject()">${esc(t.diaryAddSubject)}</button>`}
    </div>
    <button class="btn-primary" style="margin-bottom:12px;" onclick="renderStaffAttScreen()">🙋 ${esc(qt('My Attendance / Leave', 'میری حاضری / رخصت'))}</button>
    <button class="btn-primary" style="margin-bottom:12px;" onclick="qzOpen()">📝 ${esc(qt('Daily Quiz', 'روزانہ کوئز'))}</button>
    <button class="btn-primary" style="margin-bottom:12px;" onclick="noticeOpenScreen('diary')">📢 ${esc(qt('Notice Board', 'نوٹس بورڈ'))}</button>
    <button class="btn-primary" style="margin-bottom:12px;" onclick="dpmOpen()">📩 ${esc(qt('Parent Messages', 'والدین کے پیغامات'))}</button>
    <button class="btn-ghost" style="font-size:12px;padding:7px 12px;" onclick="toggleDiaryEditSubjects()">${esc(editing ? t.diaryDone : t.diaryRemoveSubject)}</button>
    ${queue.length ? `<p style="font-size:11px;opacity:.6;margin-top:14px;">${esc(t.classPortalOffline)} (${queue.length})</p>` : ''}
  `;
}

function promptDiaryNewSubject() {
  const name = (prompt(t.diaryNewSubjectPrompt) || '').trim();
  if (!name) return;
  rememberDiarySubject(name);
  renderDiaryClasses(name);
}

function renderDiaryClasses(subject, noPush) {
  DIARY_SCREEN = 'classes';
  DIARY_SUBJECT = subject;
  if (!noPush && !DIARY_FROM_CLASS) history.pushState({ diary: 'classes', subject }, '');
  const body = document.getElementById('diary-portal-body');
  if (!body) return;
  body.innerHTML = `
    <button class="btn-ghost" style="padding:9px 14px;margin-bottom:10px;" onclick="diaryBack('menu')">${esc(t.diaryBackToSubjects)}</button>
    <h2 style="margin-top:0;">${esc(subject)}</h2>
    <p class="desc">${esc(t.diaryChooseClassTitle)}</p>
    <div style="display:flex;flex-wrap:wrap;gap:8px;">
      ${CLASS_OPTIONS.map(c => `<button class="btn-primary" style="flex:none;padding:9px 16px;" onclick="renderDiaryEntryForm('${esc(c).replace(/'/g,"\\'")}')">${esc(c)}</button>`).join('')}
    </div>
  `;
}

function renderDiaryEntryForm(className, noPush) {
  DIARY_SCREEN = 'entry';
  DIARY_CLASS = className;
  if (!noPush && !DIARY_FROM_CLASS) history.pushState({ diary: 'entry', subject: DIARY_SUBJECT, cls: className }, '');
  const body = document.getElementById('diary-portal-body');
  if (!body) return;
  body.innerHTML = `
    <button class="btn-ghost" style="padding:9px 14px;margin-bottom:10px;" onclick="diaryBack('classes')">${esc(t.diaryBackToClasses)}</button>
    <h2 style="margin-top:0;">${esc(DIARY_SUBJECT)} — ${esc(className)}</h2>
    <label><span>${esc(t.diaryEntryDate)}</span><input id="de-date" type="date" value="${todayISO()}"></label>
    <label><span>${esc(t.diaryEntryTitle)}</span><textarea id="de-text" rows="5" placeholder="${esc(t.diaryEntryPlaceholder)}"></textarea></label>
    <div id="de-msg" style="font-size:12px;margin-bottom:8px;"></div>
    <button class="btn-primary" style="width:100%;" onclick="submitDiaryEntry()">${esc(t.diarySave)}</button>
  `;
}

async function submitDiaryEntry() {
  const session = getDiarySession();
  if (!session) return;
  const date = document.getElementById('de-date').value || todayISO();
  const text = document.getElementById('de-text').value.trim();
  const msg = document.getElementById('de-msg');
  if (!text) return;
  rememberDiarySubject(DIARY_SUBJECT);
  const payload = {
    schoolCode: session.schoolCode, password: session.password,
    className: DIARY_CLASS, subject: DIARY_SUBJECT, date, text
  };
  if (!navigator.onLine) {
    queueDiaryWrite({ type: 'entry', ...payload });
    msg.innerHTML = `<div class="ok">${esc(t.diaryOfflineSaved)}</div>`;
    setTimeout(() => diaryAfterSave(), 900);
    return;
  }
  try {
    const { data: addOk, error } = await sb.rpc('diary_add_entry', {
      p_school_code: payload.schoolCode, p_password: payload.password, p_class_name: payload.className,
      p_subject: payload.subject, p_entry_date: payload.date, p_entry_text: payload.text
    });
    if (!error && addOk === false) { msg.innerHTML = `<div class="err">${esc(t.diaryPortalInvalid)}</div>`; return; }
    if (error) { queueDiaryWrite({ type: 'entry', ...payload }); msg.innerHTML = `<div class="ok">${esc(t.diaryOfflineSaved)}</div>`; setTimeout(() => diaryAfterSave(), 900); return; }
    msg.innerHTML = `<div class="ok">${esc(t.diarySaved)}</div>`;
    setTimeout(() => diaryAfterSave(), 900);
  } catch(e) {
    queueDiaryWrite({ type: 'entry', ...payload });
    msg.innerHTML = `<div class="ok">${esc(t.diaryOfflineSaved)}</div>`;
    setTimeout(() => diaryAfterSave(), 900);
  }
}

// ---------------- Teacher self-attendance request (Diary portal) ----------------
// Teacher taps Present / Leave / Sick -> a *pending* request is stored (offline-safe queue,
// same as diary entries). Nothing reaches the attendance register until the principal approves.
const STAFF_TEACHERS_KEY = 'sms_diary_staff_teachers';
const STAFF_LAST_KEY = 'sms_diary_staff_last';
function pkClock() {
  const p = new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Karachi', hour: '2-digit', minute: '2-digit', hour12: false }).formatToParts(new Date());
  const h = Number(p.find(x => x.type === 'hour').value) % 24, m = Number(p.find(x => x.type === 'minute').value);
  return { h, m, mins: h * 60 + m };
}
function staffPresentOpen() { const n = pkClock().mins; return n >= 7 * 60 && n <= 14 * 60 + 30; } // 7:00 AM - 2:30 PM (phone clock)
function getStaffTeachers() { try { return JSON.parse(localStorage.getItem(STAFF_TEACHERS_KEY) || 'null'); } catch (e) { return null; } }

async function renderStaffAttScreen() {
  DIARY_SCREEN = 'staff';
  const session = getDiarySession();
  const body = document.getElementById('diary-portal-body');
  if (!session || !body) return;
  let cache = getStaffTeachers();
  if (cache && cache.school !== session.schoolCode) cache = null;
  const stale = !cache || !cache.list || !cache.list.length || (Date.now() - (cache.ts || 0)) > 24 * 3600 * 1000;
  if (stale && navigator.onLine) {
    try {
      const { data, error } = await sb.rpc('staff_att_teachers', { p_school_code: session.schoolCode, p_password: session.password });
      if (!error && Array.isArray(data)) { cache = { school: session.schoolCode, ts: Date.now(), list: data }; localStorage.setItem(STAFF_TEACHERS_KEY, JSON.stringify(cache)); }
    } catch (e) {}
  }
  const list = (cache && cache.list) || [];
  const last = localStorage.getItem(STAFF_LAST_KEY) || '';
  const open = staffPresentOpen();
  body.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;">
      <h2 style="margin:0;">${esc(qt('My Attendance', 'میری حاضری'))}</h2>
      <button class="btn-ghost" style="flex:none;padding:7px 12px;font-size:12px;" onclick="renderDiaryMenu()">${esc(qt('Back', 'واپس'))}</button>
    </div>
    <p class="desc">${esc(qt('Your request goes to the principal. It counts only after he approves it.', 'آپ کی درخواست پرنسپل کو جائے گی۔ ان کی منظوری کے بعد ہی حاضری لگے گی۔'))}</p>
    ${list.length ? `
      <label><span>${esc(qt('Your name', 'آپ کا نام'))}</span>
        <select id="sa-teacher"><option value="">${esc(qt('— Select your name —', '— اپنا نام منتخب کریں —'))}</option>
        ${list.map(x => `<option value="${esc(String(x.id))}" ${String(x.id) === last ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></label>
      <div id="sa-msg" style="font-size:12px;margin:8px 0;"></div>
      <button class="btn-primary" style="width:100%;margin-bottom:8px;${open ? '' : 'opacity:.45;'}" onclick="submitStaffAtt('present')">✅ ${esc(qt('Mark me present', 'میری حاضری لگائیں'))}</button>
      ${open ? '' : `<p style="font-size:11px;opacity:.65;margin:-2px 0 10px;">${esc(qt('Present can be sent only between 7:00 AM and 2:30 PM.', 'حاضری صرف صبح 7:00 سے دوپہر 2:30 بجے تک بھیجی جا سکتی ہے۔'))}</p>`}
      <div style="display:flex;gap:8px;">
        <button class="btn-ghost" style="flex:1;" onclick="submitStaffAtt('leave')">${esc(t.leave)}</button>
        <button class="btn-ghost" style="flex:1;" onclick="submitStaffAtt('sick')">${esc(t.sick)}</button>
      </div>`
    : `<p style="font-size:13px;">${esc(qt('Teacher list could not be loaded. Connect to the internet once and open this screen again.', 'اساتذہ کی فہرست نہیں ملی۔ ایک بار انٹرنیٹ سے جوڑ کر دوبارہ کھولیں۔'))}</p>`}
  `;
}

async function submitStaffAtt(kind) {
  const session = getDiarySession();
  const sel = document.getElementById('sa-teacher');
  const msg = document.getElementById('sa-msg');
  if (!session || !sel || !msg) return;
  if (!sel.value) { msg.innerHTML = `<div class="err">${esc(qt('Please select your name first.', 'پہلے اپنا نام منتخب کریں۔'))}</div>`; return; }
  if (kind === 'present' && !staffPresentOpen()) { msg.innerHTML = `<div class="err">${esc(qt('Present can be sent only between 7:00 AM and 2:30 PM.', 'حاضری صرف صبح 7:00 سے دوپہر 2:30 بجے تک بھیجی جا سکتی ہے۔'))}</div>`; return; }
  localStorage.setItem(STAFF_LAST_KEY, sel.value);
  const payload = {
    type: 'staff_att', schoolCode: session.schoolCode, password: session.password,
    teacherId: sel.value, kind,
    session: kind === 'present' ? (pkClock().h < 12 ? 'am' : 'pm') : 'both',
    requestedAt: new Date().toISOString()
  };
  const offlineMsg = () => { msg.innerHTML = `<div class="ok">${esc(qt('Saved on this phone. It will be sent automatically when internet is back.', 'اس فون میں محفوظ ہو گیا۔ انٹرنیٹ آتے ہی خود بھیج دیا جائے گا۔'))}</div>`; };
  if (!navigator.onLine) { queueDiaryWrite(payload); offlineMsg(); return; }
  try {
    const { data, error } = await sb.rpc('staff_att_request', {
      p_school_code: payload.schoolCode, p_password: payload.password, p_teacher_id: payload.teacherId,
      p_kind: payload.kind, p_session: payload.session, p_requested_at: payload.requestedAt
    });
    if (error) {
      if (/invalid_login|not_found|bad_input/.test(error.message || '')) { msg.innerHTML = `<div class="err">${esc(t.diaryPortalInvalid)}</div>`; return; }
      queueDiaryWrite(payload); offlineMsg(); return;
    }
    msg.innerHTML = data === 'duplicate'
      ? `<div class="ok">${esc(qt('This request was already sent.', 'یہ درخواست پہلے ہی بھیجی جا چکی ہے۔'))}</div>`
      : `<div class="ok">${esc(qt('Sent to the principal. Waiting for approval.', 'پرنسپل کو بھیج دی گئی۔ منظوری کا انتظار ہے۔'))}</div>`;
  } catch (e) { queueDiaryWrite(payload); offlineMsg(); }
}

async function flushDiaryQueue() {
  if (!navigator.onLine) return;
  const q = getDiaryQueue();
  if (!q.length) return;
  const remaining = [];
  for (const item of q) {
    try {
      if (item.type === 'staff_att') {
        const { error: sErr } = await sb.rpc('staff_att_request', {
          p_school_code: item.schoolCode, p_password: item.password, p_teacher_id: item.teacherId,
          p_kind: item.kind, p_session: item.session, p_requested_at: item.requestedAt
        });
        if (sErr && !/invalid_login|not_found|bad_input/.test(sErr.message || '')) remaining.push(item);
        continue;
      }
      if (item.type === 'pm_reply_subject') {
        const { error: pErr } = await sb.rpc('parent_message_reply_subject', {
          p_school_code: item.schoolCode, p_password: item.password, p_message_id: item.messageId, p_text: item.text
        });
        if (pErr && !/invalid_login|not_found|bad_message|too_many_replies/.test(pErr.message || '')) remaining.push(item);
        continue;
      }
      const { error } = await sb.rpc('diary_add_entry', {
        p_school_code: item.schoolCode, p_password: item.password, p_class_name: item.className,
        p_subject: item.subject, p_entry_date: item.date, p_entry_text: item.text
      });
      if (error) remaining.push(item);
    } catch(e) { remaining.push(item); }
  }
  setDiaryQueue(remaining);
  const body = document.getElementById('diary-portal-body');
  if (body && DIARY_SCREEN === 'menu') renderDiaryMenu();
}

// ---------------- Diary inside the Teacher Portal ----------------
// The teacher is already logged in to their class (class login), so the class
// is fixed — only the school-wide Diary Password is asked once per device
// (checked by the same diary_login_verify / diary_add_entry as ?diary=1).
// Then: pick subject -> write entry for this class.
function diaryAfterSave() {
  if (DIARY_FROM_CLASS && document.getElementById('class-portal-body')) { renderClassPortalDiary(); return; }
  const st = history.state;
  renderDiaryMenu();
  if (st && st.diary && st.diary !== 'menu') history.go(st.diary === 'entry' ? -2 : -1);
}

function classPortalDiarySessionOk() {
  const cs = getClassSession(), ds = getDiarySession();
  return !!(cs && ds && String(ds.schoolCode || '').trim().toUpperCase() === String(cs.schoolCode || '').trim().toUpperCase());
}

function renderClassPortalDiary() {
  DIARY_FROM_CLASS = true;
  CLASS_PORTAL_SCREEN = 'diary';
  const cs = getClassSession();
  const body = document.getElementById('class-portal-body');
  if (!cs || !body) return;
  if (!classPortalDiarySessionOk()) { renderClassPortalDiaryLogin(); return; }
  const queue = getDiaryQueue();
  const subjects = diarySubjectList();
  body.innerHTML = `
    <button class="btn-ghost" style="padding:9px 14px;margin-bottom:10px;" onclick="CLASS_PORTAL_SCREEN='menu'; renderClassPortalMenu()">‹ ${esc(t.classPortalBackToMenu)}</button>
    <h2 style="margin-top:0;">${esc(t.classPortalMenuDiary)} — ${esc(cs.className)}</h2>
    <p class="desc">${esc(t.classPortalDiaryDesc)}</p>
    <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px;">
      ${subjects.map(s => `<button class="btn-primary" style="flex:none;padding:9px 16px;" onclick="renderClassPortalDiaryEntry('${esc(s).replace(/'/g,"\\'")}')">${esc(s)}</button>`).join('')}
      <button class="btn-ghost" style="flex:none;padding:9px 16px;" onclick="promptClassPortalDiarySubject()">${esc(t.diaryAddSubject)}</button>
    </div>
    <button class="btn-primary" style="margin-bottom:12px;" onclick="qzOpen()">📝 ${esc(qt('Daily Quiz', 'روزانہ کوئز'))}</button>
    <button class="btn-ghost" style="font-size:12px;padding:7px 12px;" onclick="classPortalDiaryChangePw()">${esc(t.classPortalDiaryChangePw)}</button>
    ${queue.length ? `<p style="font-size:11px;opacity:.6;margin-top:14px;">${esc(t.classPortalOffline)} (${queue.length})</p>` : ''}
  `;
}

function classPortalDiaryChangePw() {
  clearDiarySession();
  renderClassPortalDiaryLogin();
}

function promptClassPortalDiarySubject() {
  const name = (prompt(t.diaryNewSubjectPrompt) || '').trim();
  if (!name) return;
  rememberDiarySubject(name);
  renderClassPortalDiaryEntry(name);
}

function renderClassPortalDiaryLogin() {
  const body = document.getElementById('class-portal-body');
  if (!body) return;
  body.innerHTML = `
    <button class="btn-ghost" style="padding:9px 14px;margin-bottom:10px;" onclick="CLASS_PORTAL_SCREEN='menu'; renderClassPortalMenu()">‹ ${esc(t.classPortalBackToMenu)}</button>
    <h2 style="margin-top:0;">${esc(t.diaryPortalTitle)}</h2>
    <p class="desc">${esc(t.classPortalDiaryPwDesc)}</p>
    <label><span>${esc(t.diaryPasswordLabel)}</span><input id="cpd-pw" type="password"></label>
    <div id="cpd-msg" style="font-size:12px;margin-bottom:8px;"></div>
    <button class="btn-primary" style="width:100%;" onclick="submitClassPortalDiaryLogin()">${esc(t.diaryPortalLoginButton)}</button>
  `;
}

async function submitClassPortalDiaryLogin() {
  const cs = getClassSession();
  const msg = document.getElementById('cpd-msg');
  const password = document.getElementById('cpd-pw').value;
  if (!cs || !password) return;
  msg.textContent = '…';
  if (!navigator.onLine) { msg.innerHTML = `<div class="err">${esc(t.classPortalOfflineNoList)}</div>`; return; }
  try {
    const { data, error } = await sb.rpc('diary_login_verify', { p_school_code: cs.schoolCode, p_password: password });
    if (error && /too_many/.test(error.message||'')) { msg.innerHTML = `<div class="err">Too many wrong attempts. Please try again after 15 minutes. / بہت زیادہ غلط کوششیں۔ 15 منٹ بعد دوبارہ کوشش کریں۔</div>`; return; }
    if (error || !data || !data.length) { msg.innerHTML = `<div class="err">${esc(t.diaryPortalInvalid)}</div>`; return; }
    setDiarySession({ schoolCode: cs.schoolCode, password, ownerId: data[0].owner_id, schoolName: data[0].school_name || cs.schoolName || '' });
    renderClassPortalDiary();
  } catch(e) {
    msg.innerHTML = `<div class="err">${esc(t.diaryPortalInvalid)}</div>`;
  }
}

function renderClassPortalDiaryEntry(subject) {
  DIARY_FROM_CLASS = true;
  CLASS_PORTAL_SCREEN = 'diary';
  const cs = getClassSession();
  const body = document.getElementById('class-portal-body');
  if (!cs || !body) return;
  DIARY_SCREEN = 'entry';
  DIARY_SUBJECT = subject;
  DIARY_CLASS = cs.className;
  body.innerHTML = `
    <button class="btn-ghost" style="padding:9px 14px;margin-bottom:10px;" onclick="renderClassPortalDiary()">${esc(t.diaryBackToSubjects)}</button>
    <h2 style="margin-top:0;">${esc(subject)} — ${esc(cs.className)}</h2>
    <label><span>${esc(t.diaryEntryDate)}</span><input id="de-date" type="date" value="${todayISO()}"></label>
    <label><span>${esc(t.diaryEntryTitle)}</span><textarea id="de-text" rows="5" placeholder="${esc(t.diaryEntryPlaceholder)}"></textarea></label>
    <div id="de-msg" style="font-size:12px;margin-bottom:8px;"></div>
    <button class="btn-primary" style="width:100%;" onclick="submitDiaryEntry()">${esc(t.diarySave)}</button>
  `;
}

