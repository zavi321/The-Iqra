/* SchoolMS — core.js — split from index.html (lines 1043-2348). Load order matters: see index.html */
// Every Supabase call (auth, table queries, RPCs) goes through fetch under
// the hood. On a weak/flaky mobile connection a request can just hang
// instead of failing — the browser never gives up on its own for a long
// time — which is what was leaving loading skeletons shimmering forever
// with nothing loading, saving, or deleting. Rather than remembering to
// wrap every individual call site (there are 70+ across this file, and any
// new one added later would silently be unprotected again), this forces an
// 8-second hard cutoff at the network layer itself: ONE fix that covers
// every call, present and future. An aborted request comes back as a normal
// {data:null, error} result (same shape the rest of the code already
// expects), not a hang and not an uncaught exception.
// ---- Hardened network layer -------------------------------------------------
// 1) Concurrency limiter: browsers only run ~6 requests per host at once; the rest
//    wait in the browser's own queue. The old 8s abort timer started BEFORE that
//    wait, so under load (10 tables x paged requests at boot) perfectly healthy
//    requests were being aborted just for waiting their turn. Now the timer starts
//    only when a request really gets its slot.
// 2) Retry with backoff + jitter for reads (GET/HEAD) on network errors, 429 and
//    502/503/504. A timed-out read is retried once. Writes are never blindly
//    retried after a timeout (they may already have been applied) — they go through
//    offlineWrite/flushSyncQueue which are idempotent — except on 429/503, where
//    the server certainly did not process them.
// 3) Per-type timeouts: reads 15s, writes 12s, storage uploads 60s.
// 4) The caller's own AbortSignal is honoured now.
const NET = { active: 0, max: 6, waiters: [] };
function _netAcquire() { return new Promise(res => { if (NET.active < NET.max) { NET.active++; res(); } else NET.waiters.push(res); }); }
function _netRelease() { const n = NET.waiters.shift(); if (n) n(); else NET.active--; }
const _sleep = ms => new Promise(r => setTimeout(r, ms));
function timeoutFetch(timeoutMs) {
  return async (url, options = {}) => {
    options = options || {};
    const method = String(options.method || (url && url.method) || 'GET').toUpperCase();
    const u = String((url && url.url) || url);
    const isRead = method === 'GET' || method === 'HEAD';
    const perTry = timeoutMs || (u.indexOf('/storage/v1/') > -1 ? 60000 : isRead ? 15000 : 12000);
    const maxRetries = isRead ? 2 : 1;
    for (let attempt = 0; ; attempt++) {
      await _netAcquire();
      const controller = new AbortController();
      let timedOut = false;
      const timer = setTimeout(() => { timedOut = true; controller.abort(); }, perTry);
      const ext = options.signal;
      let onExtAbort = null;
      if (ext) { if (ext.aborted) controller.abort(); else { onExtAbort = () => controller.abort(); ext.addEventListener('abort', onExtAbort); } }
      let res = null, err = null;
      try { res = await fetch(url, { ...options, signal: controller.signal }); }
      catch (e) { err = e; }
      finally { clearTimeout(timer); if (ext && onExtAbort) ext.removeEventListener('abort', onExtAbort); _netRelease(); }
      if (err) {
        if (ext && ext.aborted) throw err;                          // caller cancelled on purpose
        const canRetry = isRead && attempt < maxRetries && (!timedOut || attempt === 0) && navigator.onLine !== false;
        if (!canRetry) throw err;
        await _sleep(400 * Math.pow(2, attempt) + Math.random() * 250);
        continue;
      }
      const st = res.status;
      const transient = isRead ? (st === 429 || st === 502 || st === 503 || st === 504) : (st === 429 || st === 503);
      if (transient && attempt < maxRetries) {
        const ra = parseFloat(res.headers && res.headers.get && res.headers.get('Retry-After'));
        const wait = Number.isFinite(ra) ? Math.min(ra * 1000, 5000) : 400 * Math.pow(2, attempt) + Math.random() * 250;
        await _sleep(wait);
        continue;
      }
      return res;
    }
  };
}


const sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  global: { fetch: timeoutFetch() }
});

// A second, isolated Supabase client used ONLY when the admin confirms a
// school's OTP code. auth.verifyOtp() would otherwise replace the current
// browser session with the school's session — using a separate client
// keeps the admin logged in as themselves throughout.
function makeOtpVerifyClient() {
  return supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { fetch: timeoutFetch() }
  });
}


// Normalizes a Pakistani mobile number (however it was typed/pasted — with or
// without a leading 0, with or without a country code, with spaces or dashes)
// into the bare digits-only international format WhatsApp's wa.me links need,
// e.g. "923001234567". Returns null when no usable 10-digit PK mobile number
// can be found in the input, so callers can show a clear "no valid number" message
// instead of silently failing.
//
// This function was previously being CALLED (in whatsappUri below) but was never
// actually defined anywhere in the app — every WhatsApp send attempt was hitting
// a silent "normalizePkMobile is not defined" error and doing nothing at all,
// which is why the WhatsApp button (and the automatic fee-received notification)
// appeared completely inactive no matter what was tapped.
function normalizePkMobile(raw) {
  if (!raw) return null;
  let d = String(raw).replace(/\D/g, ''); // keep digits only
  if (!d) return null;
  if (d.startsWith('0092')) d = d.slice(2);        // 00923001234567 -> 923001234567
  else if (d.startsWith('0')) d = '92' + d.slice(1); // 03001234567 -> 923001234567
  else if (d.length === 10) d = '92' + d;            // 3001234567 -> 923001234567
  // A valid PK mobile in wa.me format is "92" + 10 digits = 12 digits total.
  if (d.length !== 12 || !d.startsWith('92')) return null;
  return d;
}

// ---------- SMS helper (parents) ----------
// Opens the phone's own Messages app, pre-filled with the father's number and
// the message, sent from the school's own SIM/number — via the "sms:" URI.
// Same tap-to-send UX as before (the user still taps "Send" inside Messages),
// but unlike wa.me this needs NO internet connection at all to open.
// Function/param names kept as-is (whatsappUri/openFatherWhatsapp) everywhere
// they're already called from, so only this implementation had to change.
function smsUriFromDigits(digits, message) {
  if (!digits) return null;
  // Platforms disagree on the separator for the sms: URI's prefilled body:
  // iOS wants "&body=", Android wants "?body=".
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
  return `sms:+${digits}${isIOS ? '&' : '?'}body=${encodeURIComponent(message)}`;
}
function whatsappUri(mobileRaw, message) {
  const mobile = normalizePkMobile(mobileRaw);
  if (!mobile) return null;
  return smsUriFromDigits(mobile, message);
}
function openFatherWhatsapp(mobileRaw, message) {
  const uri = whatsappUri(mobileRaw, message);
  if (!uri) { alert('No valid contact number on file for this student.'); return; }
  location.href = uri;
}
// --------------------------------------

const T = {
  en: {
    appName:'School Finance & Records', tagline:'For school administration',
    dashboard:'Dashboard', students:'Students', teachers:'Teachers', finance:'Finance', reports:'Reports', dmc:'Certificates', marksSheet:'Marks Sheet',
    navFees:'Fees', navExamsMarks:'Exams & Marks', navAttendance:'Attendance', navSettings:'Settings',
    navAttendanceDesc:'Mark teacher attendance, review the attendance register, or approve teachers\' attendance requests.',
    thisMonth:'This Month',
    totalStudents:'Active Students', feesCollected:'Fees Collected (this month)', feesDue:'Fees Due (this month)',
    salaryPaid:'Salaries Paid (this month)', expensesThisMonth:'Expenses (this month)', otherFeeStandalone:'Other Fees (Hostel/Transport) — held separately, not part of school totals', netBalance:'Net Balance (all-time)', totalDuesAllTime:'Total Dues (all-time)', recentActivity:'Recent Activity',
    totalIncome:'Total Income (all-time)', totalExpense:'Total Expenses (all-time)', teacherSalaries:'Teacher Salaries (all-time)',
    totalTeachers:'Total Teachers', todayAttendance:"Today's Attendance", teacherAttendanceToday:'Teacher Attendance (Today)',
    notMarkedYet:'Not marked yet', feeCollectionGraphTitle:'Fee Collection (last 6 months)', checkedIn:'Checked In', notCheckedIn:'Not Checked In',
    dueThisMonth:'Due (this month)',
    expenses:'Expenses', collectedFees:'Collected Fees', back:'Back', noRecords:'No records yet',
    addStudent:'Add Student', studentName:'Student Name', studentNameUr:'Student Name (Urdu)', fatherName:"Father's Name", fatherNameUr:"Father's Name (Urdu)", casteTribeUr:'Caste/Tribe (Urdu)', residenceUr:'Residence (Urdu)', className:'Class',
    quickAdmission:'Quick Admission', admissionNo:'Admission No.', dateOfBirth:'Date of Birth',
    printSelected:'Print Selected', clear:'Clear',
    aiSuccessNote:'Questions generated below — review, edit, or delete any of them before printing.',
    papers:'Question Papers', paperClass:'Class', paperSubject:'Subject', paperTotalMarks:'Total Marks',
    paperTime:'Time Allowed', paperDate:'Date', mcqSection:'Section A — Objective Questions', shortSection:'Section B — Short Questions',
    longSection:'Section C — Long Questions', marksEach:'Marks (each)', addQuestion:'+ Add Question', marks:'Marks',
    mcqType:'Multiple Choice Questions (MCQs)', blanksType:'Fill in the Blanks', tfType:'True / False', matchType:'Matching Column',
    instructionLabel:'Instruction (optional)', instructionPh:'e.g. Choose the correct option',
    paperEndImageLabel:'Diagram / Image (optional)', paperEndImageHint:'Printed once at the end of the paper — e.g. for Science subjects',
    addImage:'+ Add Image', removeImage:'Remove Image',
    logo:'Logo', paperExamName:'Exam Name',
    paperPreviewNote:'Fill in the questions below, then print. Blank option/answer boxes are left empty on the printed paper. To underline a word, type it inside double brackets, e.g. [[word]].',
    paperBreakPh:'Optional line here (e.g. OR) — leave blank to skip',
    groupByClass:'By Class', groupByFee:'By Fee', noFeeCategory:'No Fee', studentsCount:'students',
    admissionDate:'Admission Date', monthlyFee:'Monthly Fee (Rs)', contact:'Contact Number',
    studentType:'Student Type', feePaying:'Fee-Paying', free:'Free', orphan:'Orphan', all:'All',
    updateType:'Update Type', typeUpdated:'Type updated',
    search:'Search name or amount...', noStudents:'No students yet. Add your first student to get started.',
    feeLedger:'Fee Ledger', markPaid:'Mark Month Paid', month:'Month', amount:'Amount (Rs)',
    save:'Save', cancel:'Cancel', delete:'Delete', paid:'Paid', due:'Due',
    addTeacher:'Add Teacher', teacherName:'Teacher Name', subject:'Subject / Role', monthlySalary:'Monthly Salary (Rs)',
    qualification:'Qualification',
    joinDate:'Join Date', searchTeachers:'Search teachers...', noTeachers:'No teachers yet. Add your first teacher to get started.',
    markAttendance:'Mark Attendance', attendanceDate:'Date', present:'Present', absent:'Absent', leave:'Leave', sick:'Sick',
    suggestedSalary:'Suggested Salary (from attendance)', noAttendanceMarked:'No attendance marked for this month — full salary shown.',
    saveAttendance:'Save Attendance', attendanceSaved:'Attendance saved.',
    morning:'Morning', afternoon:'Afternoon', teacherRegister:'Register', teacherRegisterTitle:'Teacher Attendance Register',
    registerMonth:'Month', registerSelectTeacher:'Teacher', registerAllTeachers:'All Teachers',
    registerLegend:'P = Present · L = Leave · A = Absent · — = not yet due',
    registerTapHint:'Tap a mark to change it (Morning and Afternoon are set independently).',
    registerSaved:'Updated.',
    attRegPrevMonths:'Previous Months', attRegThisMonth:'This Month', attRegTotal:'Total Attendance',
    time1:'1st Time', time2:'2nd Time', srNo:'Sr.',
    holiday:'Holiday', tapToUnmark:'tap to un-mark', holidayHint:'Sundays are always a holiday. Tap any other date to mark/unmark it as a holiday.',
    salaryLedger:'Salary Ledger', payMonth:'Pay Month',
    baseSalary:'Base Salary', attendanceBonus:'Attendance Bonus', extraClass:'Extra Class',
    addTransaction:'Add Entry', income:'Income', expense:'Expense', category:'Category', description:'Description', date:'Date',
    monthlyChartTitle:'Monthly Income vs Expense',
    noTransactions:'No entries yet.',
    summaryReport:'Summary Report', totalCollectedAllTime:'Total Fees Collected (all-time)', totalSalariesAllTime:'Total Salaries Paid (all-time)',
    totalOtherIncomeAllTime:'Total Other Income (all-time)', totalOtherExpenseAllTime:'Total Other Expenses (all-time)',
    perClassBreakdown:'Per-Class Fee Status', duesOutstanding:'Dues Outstanding',
    confirmDelete:'Delete this record? This cannot be undone.', yes:'Yes, delete', no:'No, keep it',
    strikeOffStudent:'Strike Off', confirmStrikeOff:'Mark this student as left the school? They will be hidden from active lists, attendance, and rosters, but their fee and admission history is kept and this can be undone anytime.', restoreStudent:'Restore Student',
    langToggle:'اردو', sharedNotice:'Your data is private to your school account — no other school can see it.',
    copyrightNotice:'© 2026 Zavi Software. All rights reserved. This software is licensed for use by your school only — it may not be resold, redistributed, or transferred to any other party.',
    enterAmount:'Enter amount',
    lastBalance:'Last Balance', schoolFeeCol:'School Fee', sportsFund:'Sports Fund', admissionFeeCol:'Admission Fee',
    examFeeCol:'Annual Exam Fee', otherFeeCol:'Other (Hostel/Transport)', totalDuesCol:'Total Dues', totalPaidCol:'Total Paid', balanceCol:'Balance',
    receiptNo:'Receipt No', dateCol:'Date', addEntry:'Add Month Entry', optional:'optional',
    print:'Print', printCard:'Print Card', feeReceipt:'Fee Receipt', studentNameLbl:'Student Name', receivedFrom:'Received From',
    forMonth:'For Month', totalAmount:'Total Amount Paid', thankYou:'Thank you for your payment.',
    // Auth
    signUpTitle:'Create your school account', signUpDesc:'Register your school to start using the system.',
    logInTitle:'Log In', logInDesc:'Log in to your school account.',
    schoolName:'School Name', email:'Email Address', password:'Password', confirmPassword:'Confirm Password',
    signUp:'Sign Up', logIn:'Log In', haveAccount:'Already have an account?', noAccount:"Don't have an account?",
    phoneNumber:'Phone Number', forgotPassword:'Forgot password?', forgotEmail:'Forgot your registered email?',
    forgotPasswordTitle:'Reset your password', forgotPasswordDesc:'Enter the email you signed up with. We\u2019ll send a password reset link to it.',
    sendResetLink:'Send Reset Link', resetLinkSentTitle:'Reset link sent', resetLinkSentDesc:'Check your email (and spam folder) for a link to set a new password.',
    newPasswordTitle:'Set a new password', newPasswordDesc:'Enter and confirm your new password below.',
    setNewPassword:'Set New Password', passwordUpdatedTitle:'Password updated', passwordUpdatedDesc:'Your password has been changed. You can now log in.',
    forgotEmailTitle:'Forgot your registered email?', forgotEmailDesc:'For security, we can\u2019t look up or reveal an account email here. Message your school administrator via SMS with your school name and phone number, and they can confirm which email your account is registered under.',
    backToLogin:'Back to Log In',
    passwordTooShort:'Password must be at least 6 characters.', passwordMismatch:'Passwords do not match.',
    signUpSuccess:'Account created! You can now log in.',
    settings:'Account Settings', changeSchoolName:'School Name', changeSchoolNameUr:'School Name (Urdu)', changePassword:'New Password (leave blank to keep current)',
    saveSettings:'Save Changes', settingsSaved:'Saved successfully.', logOut:'Log Out',
    exportBackup:'Download Backup (Excel)', exportHint:'Save a full copy of your records to your device.',
    clearCache:'Clear App Cache', clearCacheHint:'Deletes locally saved data and cached files on this device, then reloads the latest version of the app. Your account and records on the server are not affected.',
    clearCacheConfirm:'This will clear locally cached data on this device and reload the app. Continue?',
    clearCachePending:'You have unsynced changes on this device waiting to upload. Please go online and wait for them to finish syncing before clearing the cache — clearing now could lose them.',
    clearCacheWorking:'Clearing…',
    // Whitelist / Admin onboarding
    notWhitelistedTitle:'This email is not registered with us yet.',
    notWhitelistedDesc:'To register your school, please contact us via SMS first.',
    contactOnWhatsApp:'Contact us via SMS',
    sendSmsToFather:'SMS Parents', overdueRemindersTitle:'Send due reminders',
    overdueRemindersDesc:'These students have pending fee dues. Tap Send next to each to open your Messages app with a month-by-month reminder pre-filled for their father.',
    noOverdueStudents:'No students have pending dues right now.', send:'Send',
    sendFeeRequest:'Send fee request', feeRequestTitle:'Send fee request', feeRequestDesc:'These students currently have pending dues. Tap Send next to each to open your Messages app with a month-by-month reminder pre-filled for their father.',
    noDueStudents:'No students currently have pending dues.',
    signUpPendingTitle:'Almost done!',
    signUpPendingDesc:'A confirmation email has been sent to your inbox. Please forward that email (or the link inside it) to us via SMS to activate your account.',
    admin:'Admin', adminPanel:'Admin Panel',
    addSchoolEmail:'Add a school email', schoolEmailPlaceholder:'School owner\'s Gmail address',
    addToWhitelist:'Add & Allow Sign Up', emailAdded:'Email added — they can now sign up.',
    whitelistedSchools:'Registered Schools', statusWhitelisted:'Waiting for sign up', statusAttempted:'Awaiting your OTP confirmation', statusVerified:'Active',
    confirmOtpTitle:'How to activate a school', confirmOtpDesc:'Open the confirmation link the school sent you (use a Private/Incognito tab so it doesn\'t affect your own login), then mark them verified below.',
    otpCode:'6-digit code', markVerified:'Mark as Verified', otpConfirmed:'Marked as verified.', otpWrong:'That code is incorrect or expired.',
    noWhitelistYet:'No schools added yet.', notAdmin:'Admin access only.',
    subscriptionsTitle:'Subscriptions', planType:'Plan Type', monthlyPlan:'Monthly', lifetimePlan:'Lifetime',
    monthlyPrice:'Monthly Price (Rs)', paidUntil:'Paid Until', pendingPayments:'Pending Payments', noPendingPayments:'No pending payments.',
    approve:'Approve', submittedOn:'Submitted',
    renewalLockedTitle:'Subscription Expired', renewalLockedDesc:'Please pay', renewalToNumber:'via EasyPaisa to',
    trxIdLabel:'EasyPaisa Transaction ID (TID)', submitTrxButton:'Submit Transaction ID',
    trxSubmittedMsg:'Received. Your access will unlock automatically once the payment is confirmed — this usually takes a few minutes. Tap "Check Again" after paying.',
    checkAgainButton:'Check Again',
    parentSchoolCode:'Parent Portal School Code', parentSchoolCodeHint:'Parents will use this code (with their child\'s Roll No. & PIN) to view fee status and results online.',
    parentSchoolCodeRequired:'Please enter a school code.', parentSchoolCodeTaken:'This code is already in use — please choose another.',
    generate:'Generate', saved:'Saved.',
    linkStudent:'Link to Student (for fee status)', linkStudentNone:'— Not linked —',
    parentCode:'Parent Portal Code', parentSchoolCodeMissing:'Set a School Code in Settings first so this code works.',
    parentCodeNone:'No parent code yet for this entry.', parentGenerateCode:'Generate Parent Code',
    parentPortalTitle:'Parent Portal', parentPortalDesc:'Enter your School Code, your child\'s Roll No. and PIN to view fee status and results.',
    parentSchoolCodeLabel:'School Code', parentRollLabel:'Roll No.', parentPinLabel:'PIN',
    parentViewButton:'View', parentNotFound:'No matching record found — please check the School Code, Roll No. and PIN.',
    parentFeeBalance:'Fee Balance Due', parentLastPayment:'Last Payment', parentNoFeeLinked:'Fee status is not available for this student yet.',
    parentResults:'Results', parentNoResults:'No results published yet.', parentBackToStart:'Search Again',
    parentFeeHistory:'View Full Fee History', parentMonth:'Month', parentDues:'Dues', parentPaid:'Paid', parentBalance:'Balance',
    // Admission & Withdrawal Register — a standalone record with no link to the
    // students/finance data above.
    admissionRegister:'Admission Register', admissionRegisterDesc:'A standalone admission & withdrawal record, separate from the Students/Finance data.',
    serialNo:'Serial No.', dobFigures:'Date of Birth (figures)', dobWords:'Date of Birth (in words)', dobLabel:'Date of Birth in words and figures', casteTribe:'Caste / Tribe', occupation:'Occupation',
    residence:'Residence', classAdmitted:'Class Admitted', arrearsDue:'Arrears Due',
    classWithdrawn:'Class Withdrawn', withdrawalDate:'Date of Withdrawal', remarks:'Remarks',
    highMiddleSlcNo:'High/Middle/S.L.C No.', bise:'BISE Enrolment No.',
    attendancePossible:'Attendance: Possible', attendanceActual:'Attendance: Actual',
    schoolFundReport:'Report about School Fund', slcIssueDateField:'Date of Issue S.L.C',
    addRegisterEntry:'Add Entry', editRegisterEntry:'Edit Entry', searchRegister:'Search by name, father\'s name, or AD number...',
    noRegisterEntries:'No entries yet. Add your first admission record to get started.', headOfInstitution:'Head of the Institution',
    previous:'Prev', next:'Next', printThisPage:'Print this page',
    religion:'Religion', nationality:'Nationality', conduct:'Conduct', loadingData:'Loading your data…',
    gender:'Gender', male:'Male', female:'Female',
    defaultersReport:'Defaulters Report', total:'Total',
    slcTitle:'School Leaving Certificate', slcNo:'Certificate No.', slcIssueDate:'Date of Issue',
    slcSignature:'Signature & Stamp', officialSeal:'Office Seal',
    registerDashboard:'Dashboard', registerAdmitted:'Admitted', registerSlc:'SLC',
    globalSearch:'Search Student', globalSearchPlaceholder:"Search by student or father's name...",
    noSearchResults:'No matching students found.', hasFeeRecord:'Fee Record', hasRegisterEntry:'Register Entry',
    viewFeeLedger:'View Full Fee Ledger', viewRegisterEntry:'View Register Entry', printSlc:'Print Leaving Certificate',
    registerInfo:'Admission Register Info', notInRegister:'No admission register entry found for this name.',
    notActiveStudent:'No active fee record found for this name.',
    ccTitle:'Character Certificate', printCc:'Print Character Certificate', ccNo:'Certificate No.', ccIssueDate:'Date of Issue',
    // ---- Class Logins (owner side) + Class/Teacher Portal (public, no real login) ----
    classLoginsBtn:'Class Logins', classLoginsTitle:'Class Logins',
    classLoginsDesc:'Create a login for each class so a teacher can mark attendance and enter exam marks from a shared class device — no separate account needed.',
    addClassLogin:'Add Class Login', editClassLogin:'Edit Class Login', noClassLogins:'No class logins yet. Add one for each class.',
    loginId:'Login ID', classLoginPassword:'Password', loginIdTaken:'This Login ID is already in use — please choose another.',
    classTeacherName:'Class Teacher Name',
    viewAttendance:'Attendance', viewMarks:'Exam Marks', classLoginSavedHint:'Share this Login ID & Password with the class teacher.',
    selectDate:'Date', noAttendanceRecords:'No attendance recorded for this date.', noExamsYet:'No exams saved yet.',
    examMarksTitle:'Exam Marks', backToClassLogins:'Back to Class Logins', shareLoginLink:'Portal Link',
    classPortalTitle:'Class Login', classPortalDesc:'Enter your School Code and the Login ID & Password given by your school.',
    classPortalLoginButton:'Log In', classPortalInvalid:'Incorrect School Code, Login ID or Password.',
    classPortalMenuAttendance:'Mark Attendance', classPortalMenuDiary:'Diary', classPortalDiaryPwDesc:'Enter the Diary Password given by your school. You only need to do this once on this device.', classPortalDiaryDesc:'Tap a subject to write the diary for this class.', classPortalDiaryChangePw:'Change Diary Password', classPortalMenuRegister:'View Register', classPortalMenuMarks:'Enter Exam Marks',
    classPortalLogout:'Switch Class', classPortalBackToMenu:'Back',
    classPortalAttendanceSaved:'Attendance saved.', classPortalOffline:'Saved offline — will sync automatically once you\'re back online.',
    classPortalOfflineNoList:'You are offline and this class list is not cached yet. Please connect to the internet once to load it.',
    classPortalExamName:'Exam Name', classPortalExamNamePlaceholder:'e.g. Mid-Term 2026',
    classPortalAddSubject:'Add Subject', classPortalSubjectName:'Subject', classPortalSubjectTotal:'Total Marks',
    classPortalNoSubjects:'Add at least one subject first.', classPortalSaveMarks:'Save Marks', classPortalMarksSaved:'Marks saved.',
    classPortalMarksExceed:'Marks cannot exceed the subject total.',
    classPortalMenuAddStudent:'Add Student', classPortalAddStudentTitle:'Add Student', classPortalAddStudentDesc:"Enter the student's name to add them to this class. Father's name and contact are optional.",
    classPortalMenuManageStudents:'Manage Students', classPortalManageStudentsDesc:'If a student has left the school, strike them off here. They will be removed from attendance, register and marks, but their record and history stay safe and can be restored by the school.', classPortalNoStudents:'No students in this class yet.',
    classPortalStudentNamePlaceholder:'Student Name', classPortalAddStudentSaved:'Student added.', classPortalAddStudentOffline:'You are offline — connect to the internet to add a student.',
    classPortalFatherNameRequired:"Father's name is required.",
    classPortalPhoneRequired:"Contact number is required.",
    classPortalLoadExam:'Load a saved exam to edit', classPortalNewExam:'— New Exam —',
    classPortalMenuMarksView:'View Marks Sheet', classPortalSelectExam:'Select Exam', classPortalNoExams:'No exam marks saved yet.',
    classPortalTotal:'Total', classPortalDownloadExcel:'Download Excel', classPortalSendWhatsapp:'Send via WhatsApp',
    classPortalWhatsappFallbackMsg:'Marks sheet Excel file has been downloaded to your phone — please attach it here and send.',
    suggestions:'Suggestions', suggestionsTitle:'Suggestions for Your School',
    suggestionsDesc:'A few observations based on your current records to help improve the school.',
    suggestionsAllGood:'Everything looks healthy right now — no urgent suggestions.',
    aiSuggestionsTitle:'AI Insights', aiSuggestionsDesc:'Personalized suggestions from AI, based on your school\'s current records. Refreshes a few times a day.',
    aiSuggestionsUpdatedAt:'Updated:', aiSuggestionsCachedNote:'Offline — showing last saved AI insights from:',
    aiSuggestionsOfflineNone:'AI insights need internet the first time — connect once to load them, then they\'ll be available offline too.',
    aiSuggestionsError:'Could not load AI insights right now. Please try again later.',
    diaryPortalTitle:'Diary Login', diaryPortalDesc:'Enter your School Code and the Diary Password given by your school.',
    diaryPasswordLabel:'Diary Password', diaryPortalLoginButton:'Log In', diaryPortalInvalid:'Incorrect School Code or Diary Password.',
    diaryMenuTitle:'Select Subject', diaryMenuDesc:'Tap a subject, then choose the class you want to write an entry for.',
    diaryAddSubject:'+ Add Subject', diaryRemoveSubject:'Remove Subject', diaryDone:'Done', diaryRemoveConfirm:'Remove this subject from the list?', diaryNewSubjectPrompt:'Enter subject name', diaryLogout:'Switch School',
    diaryChooseClassTitle:'Select Class', diaryEntryTitle:'New Diary Entry', diaryEntryDate:'Date',
    diaryEntryPlaceholder:'Write homework / class work / notice…', diarySave:'Save Entry',
    diarySaved:'Diary entry saved.', diaryOfflineSaved:'Saved offline — will sync automatically once you\'re back online.',
    diaryBackToSubjects:'‹ Subjects', diaryBackToClasses:'‹ Classes',
    parentDiaryTitle:'Diary', parentNoDiary:'No diary entries yet.',
    parentPortalOfflineNote:'You are offline — showing last saved data from:',
    parentPortalSwitchStudent:'View a different child', parentPortalOfflineNoCache:'You are offline and no saved data is available yet. Please connect to the internet once to load your child\'s info.',
    diaryPasswordHint:'One password for the whole school — any teacher uses this on the Diary device to write entries.',
    diaryPasswordRequired:'Please enter a diary password.',
  },
  ur: {
    appName:'مالیاتی و ریکارڈ سسٹم', tagline:'اسکول انتظامیہ کے لیے',
    dashboard:'ڈیش بورڈ', students:'طلبہ', teachers:'اساتذہ', finance:'مالیات', reports:'رپورٹس', dmc:'سرٹیفکیٹس', marksSheet:'نتائج کی فہرست',
    navFees:'فیس', navExamsMarks:'امتحانات و نمبرات', navAttendance:'حاضری', navSettings:'ترتیبات',
    navAttendanceDesc:'اساتذہ کی حاضری لگائیں، حاضری رجسٹر دیکھیں، یا اساتذہ کی حاضری کی درخواستیں منظور کریں۔',
    thisMonth:'اس ماہ',
    totalStudents:'فعال طلبہ', feesCollected:'وصول شدہ فیس (اس ماہ)', feesDue:'واجب الادا فیس (اس ماہ)',
    salaryPaid:'ادا شدہ تنخواہ (اس ماہ)', expensesThisMonth:'اخراجات (اس ماہ)', otherFeeStandalone:'دیگر فیس (ہاسٹل/ٹرانسپورٹ) — الگ رکھی گئی، اسکول کی کل رقم میں شامل نہیں', netBalance:'کل بیلنس', totalDuesAllTime:'کل واجب الادا (تمام وقت)', recentActivity:'حالیہ سرگرمی',
    totalIncome:'کل آمدنی', totalExpense:'کل اخراجات', teacherSalaries:'اساتذہ کی تنخواہیں',
    totalTeachers:'کل اساتذہ', todayAttendance:'آج کی حاضری', teacherAttendanceToday:'اساتذہ حاضری (آج)',
    notMarkedYet:'ابھی حاضری نہیں لگی', feeCollectionGraphTitle:'فیس وصولی (پچھلے 6 ماہ)', checkedIn:'حاضر لگی', notCheckedIn:'حاضری نہیں لگی',
    dueThisMonth:'واجب الادا (اس ماہ)',
    expenses:'اخراجات', collectedFees:'وصول شدہ فیس', back:'واپس', noRecords:'ابھی کوئی ریکارڈ نہیں',
    addStudent:'طالب علم شامل کریں', studentName:'طالب علم کا نام', studentNameUr:'طالب علم کا نام (اردو)', fatherName:'والد کا نام', fatherNameUr:'والد کا نام (اردو)', casteTribeUr:'ذات/قبیلہ (اردو)', residenceUr:'رہائش (اردو)', className:'جماعت',
    quickAdmission:'فوری داخلہ', admissionNo:'داخلہ نمبر', dateOfBirth:'تاریخ پیدائش',
    printSelected:'منتخب پرنٹ کریں', clear:'صاف کریں',
    aiSuccessNote:'نیچے سوالات بن چکے ہیں — پرنٹ سے پہلے دیکھ لیں، ترمیم یا حذف کر سکتے ہیں۔',
    papers:'سوالیہ پرچہ جات', paperClass:'جماعت', paperSubject:'مضمون', paperTotalMarks:'کل نمبر',
    paperTime:'وقت', paperDate:'تاریخ', mcqSection:'حصہ اول — معروضی سوالات', shortSection:'حصہ دوم — مختصر سوالات',
    longSection:'حصہ سوم — تفصیلی سوالات', marksEach:'نمبر (فی سوال)', addQuestion:'+ سوال شامل کریں', marks:'نمبر',
    mcqType:'معروضی سوالات (MCQs)', blanksType:'خالی جگہ پر کریں', tfType:'درست / غلط', matchType:'مطابقت کریں',
    instructionLabel:'ہدایت (اختیاری)', instructionPh:'مثلاً درست جواب منتخب کریں',
    paperEndImageLabel:'خاکہ/تصویر (اختیاری)', paperEndImageHint:'پرچے کے آخر میں ایک بار پرنٹ ہو گی — مثلاً سائنس کے مضامین کیلئے',
    addImage:'+ تصویر شامل کریں', removeImage:'تصویر ہٹائیں',
    logo:'لوگو', paperExamName:'امتحان کا نام',
    paperPreviewNote:'نیچے سوالات بھریں، پھر پرنٹ کریں۔ کسی لفظ کے نیچے لکیر کیلئے اسے دہرے بریکٹ میں لکھیں، مثلاً [[لفظ]]۔',
    paperBreakPh:'یہاں اختیاری لائن (مثلاً OR) — خالی چھوڑ دیں تو کچھ نہیں چھپے گا',
    groupByClass:'جماعت کے مطابق', groupByFee:'فیس کے مطابق', noFeeCategory:'بغیر فیس', studentsCount:'طلباء',
    admissionDate:'داخلہ کی تاریخ', monthlyFee:'ماہانہ فیس (روپے)', contact:'رابطہ نمبر',
    studentType:'طالب علم کی قسم', feePaying:'فیس ادا کرنے والا', free:'مفت', orphan:'یتیم', all:'تمام',
    updateType:'قسم اپڈیٹ کریں', typeUpdated:'قسم اپڈیٹ ہو گئی',
    search:'نام یا رقم تلاش کریں...', noStudents:'ابھی کوئی طالب علم شامل نہیں۔',
    feeLedger:'فیس کھاتہ', markPaid:'مہینہ ادا شدہ نشان زد کریں', month:'مہینہ', amount:'رقم (روپے)',
    save:'محفوظ کریں', cancel:'منسوخ کریں', delete:'حذف کریں', paid:'ادا شدہ', due:'واجب الادا',
    addTeacher:'استاد شامل کریں', teacherName:'استاد کا نام', subject:'مضمون / عہدہ', monthlySalary:'ماہانہ تنخواہ (روپے)',
    qualification:'تعلیمی قابلیت',
    joinDate:'شمولیت کی تاریخ', searchTeachers:'اساتذہ تلاش کریں...', noTeachers:'ابھی کوئی استاد شامل نہیں۔',
    markAttendance:'حاضری لگائیں', attendanceDate:'تاریخ', present:'حاضر', absent:'غیر حاضر', leave:'رخصت', sick:'بیمار',
    suggestedSalary:'تجویز کردہ تنخواہ (حاضری کی بنیاد پر)', noAttendanceMarked:'اس مہینے کے لیے حاضری درج نہیں — پوری تنخواہ دکھائی جا رہی ہے۔',
    saveAttendance:'حاضری محفوظ کریں', attendanceSaved:'حاضری محفوظ ہو گئی۔',
    morning:'صبح', afternoon:'دوپہر', teacherRegister:'رجسٹر', teacherRegisterTitle:'اساتذہ حاضری رجسٹر',
    registerMonth:'مہینہ', registerSelectTeacher:'استاد', registerAllTeachers:'تمام اساتذہ',
    registerLegend:'P = حاضر · L = رخصت · A = غیر حاضر · — = ابھی وقت نہیں ہوا',
    registerTapHint:'نشان تبدیل کرنے کے لیے اس پر ٹیپ کریں (صبح اور دوپہر الگ الگ لگتے ہیں)۔',
    registerSaved:'اپڈیٹ ہو گیا۔',
    attRegPrevMonths:'پچھلے مہینے', attRegThisMonth:'اس مہینے', attRegTotal:'کل حاضری',
    time1:'پہلا وقت', time2:'دوسرا وقت', srNo:'نمبر',
    holiday:'چھٹی', tapToUnmark:'ہٹانے کے لیے ٹیپ کریں', holidayHint:'اتوار ہمیشہ چھٹی ہوتی ہے۔ کسی بھی دوسری تاریخ کو چھٹی کے طور پر لگانے/ہٹانے کے لیے اس پر ٹیپ کریں۔',
    salaryLedger:'تنخواہ کھاتہ', payMonth:'ادائیگی کا مہینہ',
    baseSalary:'بنیادی تنخواہ', attendanceBonus:'حاضری بونس', extraClass:'اضافی کلاس',
    addTransaction:'اندراج شامل کریں', income:'آمدنی', expense:'اخراجات', category:'قسم', description:'تفصیل', date:'تاریخ',
    monthlyChartTitle:'ماہانہ آمدنی بمقابلہ اخراجات',
    noTransactions:'ابھی کوئی اندراج نہیں۔',
    summaryReport:'خلاصہ رپورٹ', totalCollectedAllTime:'کل وصول شدہ فیس', totalSalariesAllTime:'کل ادا شدہ تنخواہیں',
    totalOtherIncomeAllTime:'کل دیگر آمدنی', totalOtherExpenseAllTime:'کل دیگر اخراجات',
    perClassBreakdown:'جماعت کے لحاظ سے فیس کی صورتحال', duesOutstanding:'واجب الادا رقم',
    confirmDelete:'یہ ریکارڈ حذف کریں؟ یہ واپس نہیں ہو سکتا۔', yes:'ہاں، حذف کریں', no:'نہیں',
    strikeOffStudent:'اسکول چھوڑنے پر نشان زد کریں', confirmStrikeOff:'اس طالب علم کو اسکول چھوڑنے والا نشان زد کریں؟ یہ فعال فہرستوں، حاضری اور رجسٹر سے چھپ جائے گا، مگر اس کا فیس اور داخلہ ریکارڈ محفوظ رہے گا اور یہ کسی بھی وقت واپس کیا جا سکتا ہے۔', restoreStudent:'طالب علم کو بحال کریں',
    langToggle:'English', sharedNotice:'آپ کا ڈیٹا صرف آپ کے اسکول کے اکاؤنٹ تک محدود ہے — کوئی اور اسکول اسے نہیں دیکھ سکتا۔',
    copyrightNotice:'© 2026 Zavi Software۔ جملہ حقوق محفوظ ہیں۔ یہ سافٹ ویئر صرف آپ کے اسکول کے استعمال کے لیے لائسنس یافتہ ہے — اسے دوبارہ فروخت، تقسیم، یا کسی اور کو منتقل نہیں کیا جا سکتا۔',
    enterAmount:'رقم درج کریں',
    lastBalance:'پچھلا بیلنس', schoolFeeCol:'اسکول فیس', sportsFund:'اسپورٹس فنڈ', admissionFeeCol:'داخلہ فیس',
    examFeeCol:'سالانہ امتحان فیس', otherFeeCol:'دیگر (ہاسٹل/ٹرانسپورٹ)', totalDuesCol:'کل واجب الادا', totalPaidCol:'کل ادا شدہ', balanceCol:'بیلنس',
    receiptNo:'رسید نمبر', dateCol:'تاریخ', addEntry:'ماہانہ اندراج شامل کریں', optional:'اختیاری',
    print:'پرنٹ', printCard:'کارڈ پرنٹ کریں', feeReceipt:'فیس رسید', studentNameLbl:'طالب علم کا نام', receivedFrom:'وصول شدہ از',
    forMonth:'مہینہ', totalAmount:'کل ادا شدہ رقم', thankYou:'ادائیگی کا شکریہ۔',
    signUpTitle:'اپنا اسکول اکاؤنٹ بنائیں', signUpDesc:'سسٹم استعمال کرنے کے لیے اپنا اسکول رجسٹر کریں۔',
    logInTitle:'لاگ ان کریں', logInDesc:'اپنے اسکول اکاؤنٹ میں لاگ ان کریں۔',
    schoolName:'اسکول کا نام', email:'ای میل ایڈریس', password:'پاس ورڈ', confirmPassword:'پاس ورڈ کی تصدیق',
    signUp:'اکاؤنٹ بنائیں', logIn:'لاگ ان', haveAccount:'پہلے سے اکاؤنٹ ہے؟', noAccount:'اکاؤنٹ نہیں ہے؟',
    phoneNumber:'فون نمبر', forgotPassword:'پاس ورڈ بھول گئے؟', forgotEmail:'رجسٹرڈ ای میل بھول گئے؟',
    forgotPasswordTitle:'اپنا پاس ورڈ ری سیٹ کریں', forgotPasswordDesc:'وہ ای میل درج کریں جس سے آپ نے سائن اپ کیا تھا۔ ہم اس پر پاس ورڈ ری سیٹ کرنے کا لنک بھیجیں گے۔',
    sendResetLink:'ری سیٹ لنک بھیجیں', resetLinkSentTitle:'ری سیٹ لنک بھیج دیا گیا', resetLinkSentDesc:'نیا پاس ورڈ سیٹ کرنے کے لنک کے لیے اپنا ای میل (اور اسپیم فولڈر) چیک کریں۔',
    newPasswordTitle:'نیا پاس ورڈ سیٹ کریں', newPasswordDesc:'نیچے اپنا نیا پاس ورڈ درج اور تصدیق کریں۔',
    setNewPassword:'نیا پاس ورڈ سیٹ کریں', passwordUpdatedTitle:'پاس ورڈ اپڈیٹ ہو گیا', passwordUpdatedDesc:'آپ کا پاس ورڈ تبدیل ہو گیا ہے۔ اب آپ لاگ ان کر سکتے ہیں۔',
    forgotEmailTitle:'رجسٹرڈ ای میل بھول گئے؟', forgotEmailDesc:'حفاظتی وجوہات کی بنا پر ہم یہاں اکاؤنٹ کی ای میل تلاش یا ظاہر نہیں کر سکتے۔ اپنے اسکول ایڈمنسٹریٹر کو SMS پر اپنے اسکول کا نام اور فون نمبر بھیجیں، وہ تصدیق کر دیں گے کہ آپ کا اکاؤنٹ کس ای میل پر رجسٹرڈ ہے۔',
    backToLogin:'لاگ ان پر واپس جائیں',
    passwordTooShort:'پاس ورڈ کم از کم 6 حروف کا ہونا چاہیے۔', passwordMismatch:'پاس ورڈ مماثل نہیں ہیں۔',
    signUpSuccess:'اکاؤنٹ بن گیا! اب آپ لاگ ان کر سکتے ہیں۔',
    settings:'اکاؤنٹ کی ترتیبات', changeSchoolName:'اسکول کا نام', changeSchoolNameUr:'اسکول کا نام (اردو)', changePassword:'نیا پاس ورڈ (خالی چھوڑیں اگر تبدیل نہیں کرنا)',
    saveSettings:'تبدیلیاں محفوظ کریں', settingsSaved:'کامیابی سے محفوظ ہو گیا۔', logOut:'لاگ آؤٹ',
    exportBackup:'بیک اپ ڈاؤن لوڈ کریں (ایکسل)', exportHint:'اپنے تمام ریکارڈ کی مکمل کاپی اپنے ڈیوائس میں محفوظ کریں۔',
    clearCache:'ایپ کیش صاف کریں', clearCacheHint:'اس ڈیوائس پر محفوظ شدہ مقامی ڈیٹا اور کیش شدہ فائلیں حذف کر کے ایپ کا تازہ ترین ورژن لوڈ کرتا ہے۔ سرور پر آپ کا اکاؤنٹ اور ریکارڈ محفوظ رہتے ہیں۔',
    clearCacheConfirm:'یہ اس ڈیوائس پر مقامی طور پر کیش شدہ ڈیٹا صاف کر کے ایپ دوبارہ لوڈ کرے گا۔ جاری رکھیں؟',
    clearCachePending:'اس ڈیوائس پر کچھ غیر مطابقت پذیر (unsynced) تبدیلیاں اپ لوڈ ہونے کی منتظر ہیں۔ کیش صاف کرنے سے پہلے آن لائن ہو کر ان کے sync مکمل ہونے کا انتظار کریں — ابھی صاف کرنے سے یہ ضائع ہو سکتی ہیں۔',
    clearCacheWorking:'صاف ہو رہا ہے…',
    notWhitelistedTitle:'یہ ای میل ابھی تک ہمارے ساتھ رجسٹرڈ نہیں ہے۔',
    notWhitelistedDesc:'اپنا اسکول رجسٹر کروانے کے لیے پہلے ہم سے SMS پر رابطہ کریں۔',
    contactOnWhatsApp:'SMS پر رابطہ کریں',
    sendSmsToFather:'والدین کو SMS', overdueRemindersTitle:'واجبات کی یاد دہانی بھیجیں',
    overdueRemindersDesc:'ان طلبہ کی فیس واجب الادا ہے۔ ہر ایک کے سامنے "بھیجیں" دبائیں تاکہ والد کے میسجز ایپ میں ہر مہینے کی تفصیل کے ساتھ پیغام کھل جائے۔',
    noOverdueStudents:'فی الحال کسی طالب علم کی کوئی فیس واجب الادا نہیں ہے۔', send:'بھیجیں',
    sendFeeRequest:'فیس کی درخواست بھیجیں', feeRequestTitle:'فیس کی درخواست بھیجیں', feeRequestDesc:'ان طلبہ کی فیس واجب الادا ہے۔ ہر ایک کے سامنے "بھیجیں" دبائیں تاکہ والد کے میسجز ایپ میں ہر مہینے کی تفصیل کے ساتھ پیغام کھل جائے۔',
    noDueStudents:'فی الحال کسی طالب علم کی کوئی فیس واجب الادا نہیں ہے۔',
    signUpPendingTitle:'تقریباً مکمل!',
    signUpPendingDesc:'آپ کے ای میل پر ایک تصدیقی ای میل بھیجی گئی ہے۔ اپنا اکاؤنٹ فعال کروانے کے لیے وہ ای میل (یا اس کے اندر موجود لنک) ہمیں SMS پر بھیجیں۔',
    admin:'ایڈمن', adminPanel:'ایڈمن پینل',
    addSchoolEmail:'اسکول کی ای میل شامل کریں', schoolEmailPlaceholder:'اسکول مالک کا جی میل ایڈریس',
    addToWhitelist:'شامل کریں اور سائن اپ کی اجازت دیں', emailAdded:'ای میل شامل ہو گئی — وہ اب سائن اپ کر سکتے ہیں۔',
    whitelistedSchools:'رجسٹرڈ اسکولز', statusWhitelisted:'سائن اپ کا انتظار', statusAttempted:'آپ کی OTP تصدیق کا انتظار', statusVerified:'فعال',
    confirmOtpTitle:'اسکول کو کیسے فعال کریں', confirmOtpDesc:'اسکول نے آپ کو جو تصدیقی لنک بھیجا ہے وہ کھولیں (Private/Incognito tab استعمال کریں تاکہ آپ کا اپنا لاگ ان متاثر نہ ہو)، پھر نیچے "فعال کریں" پر تصدیق کریں۔',
    otpCode:'6 ہندسوں کا کوڈ', markVerified:'فعال کریں', otpConfirmed:'فعال کے طور پر نشان زد ہو گیا۔', otpWrong:'یہ کوڈ غلط ہے یا میعاد ختم ہو گئی ہے۔',
    noWhitelistYet:'ابھی تک کوئی اسکول شامل نہیں کیا گیا۔', notAdmin:'صرف ایڈمن رسائی۔',
    subscriptionsTitle:'سبسکرپشنز', planType:'پلان کی قسم', monthlyPlan:'ماہانہ', lifetimePlan:'لائف ٹائم',
    monthlyPrice:'ماہانہ قیمت (روپے)', paidUntil:'کب تک ادا شدہ', pendingPayments:'زیر التوا ادائیگیاں', noPendingPayments:'کوئی زیر التوا ادائیگی نہیں۔',
    approve:'منظور کریں', submittedOn:'جمع کرایا گیا',
    renewalLockedTitle:'سبسکرپشن ختم ہو گئی', renewalLockedDesc:'براہ کرم ادا کریں', renewalToNumber:'ایزی پیسہ کے ذریعے اس نمبر پر:',
    trxIdLabel:'ایزی پیسہ ٹرانزیکشن آئی ڈی (TID)', submitTrxButton:'ٹرانزیکشن آئی ڈی جمع کرائیں',
    trxSubmittedMsg:'موصول ہو گیا۔ ادائیگی کی تصدیق ہوتے ہی آپ کی رسائی خودکار طور پر بحال ہو جائے گی — اس میں چند منٹ لگ سکتے ہیں۔ ادائیگی کے بعد "دوبارہ چیک کریں" دبائیں۔',
    checkAgainButton:'دوبارہ چیک کریں',
    parentSchoolCode:'پیرنٹ پورٹل اسکول کوڈ', parentSchoolCodeHint:'والدین یہ کوڈ (بچے کے رول نمبر اور پن کے ساتھ) استعمال کر کے فیس اور نتیجہ آن لائن دیکھ سکیں گے۔',
    parentSchoolCodeRequired:'براہ کرم اسکول کوڈ درج کریں۔', parentSchoolCodeTaken:'یہ کوڈ پہلے سے استعمال میں ہے — براہ کرم دوسرا منتخب کریں۔',
    generate:'بنائیں', saved:'محفوظ ہو گیا۔',
    linkStudent:'طالب علم سے منسلک کریں (فیس اسٹیٹس کے لیے)', linkStudentNone:'— منسلک نہیں —',
    parentCode:'پیرنٹ پورٹل کوڈ', parentSchoolCodeMissing:'پہلے سیٹنگز میں اسکول کوڈ سیٹ کریں تاکہ یہ کوڈ کام کرے۔',
    parentCodeNone:'اس اندراج کے لیے ابھی کوئی پیرنٹ کوڈ نہیں ہے۔', parentGenerateCode:'پیرنٹ کوڈ بنائیں',
    parentPortalTitle:'پیرنٹ پورٹل', parentPortalDesc:'فیس اسٹیٹس اور نتیجہ دیکھنے کے لیے اسکول کوڈ، بچے کا رول نمبر اور پن درج کریں۔',
    parentSchoolCodeLabel:'اسکول کوڈ', parentRollLabel:'رول نمبر', parentPinLabel:'پن',
    parentViewButton:'دیکھیں', parentNotFound:'کوئی ریکارڈ نہیں ملا — براہ کرم اسکول کوڈ، رول نمبر اور پن چیک کریں۔',
    parentFeeBalance:'واجب الادا فیس', parentLastPayment:'آخری ادائیگی', parentNoFeeLinked:'اس طالب علم کی فیس اسٹیٹس ابھی دستیاب نہیں ہے۔',
    parentResults:'نتیجہ', parentNoResults:'ابھی تک کوئی نتیجہ شائع نہیں ہوا۔', parentBackToStart:'دوبارہ تلاش کریں',
    parentFeeHistory:'مکمل فیس تاریخ دیکھیں', parentMonth:'مہینہ', parentDues:'واجبات', parentPaid:'ادا شدہ', parentBalance:'بیلنس',
    admissionRegister:'داخلہ رجسٹر', admissionRegisterDesc:'ایک علیحدہ داخلہ و اخراج ریکارڈ، طلبہ/مالیات کے ڈیٹا سے الگ۔',
    serialNo:'سیریل نمبر', dobFigures:'تاریخ پیدائش (ہندسوں میں)', dobWords:'تاریخ پیدائش (الفاظ میں)', dobLabel:'تاریخ پیدائش (الفاظ اور ہندسوں میں)', casteTribe:'ذات / قبیلہ', occupation:'پیشہ',
    residence:'رہائش', classAdmitted:'جس جماعت میں داخلہ', arrearsDue:'واجب الادا رقم',
    classWithdrawn:'جس جماعت سے اخراج', withdrawalDate:'تاریخ اخراج', remarks:'تبصرہ',
    highMiddleSlcNo:'ہائی/مڈل/ایس ایل سی نمبر', bise:'بی آئی ایس ای انرولمنٹ نمبر',
    attendancePossible:'حاضری: ممکنہ', attendanceActual:'حاضری: اصل',
    schoolFundReport:'اسکول فنڈ رپورٹ', slcIssueDateField:'ایس ایل سی جاری کرنے کی تاریخ',
    addRegisterEntry:'اندراج شامل کریں', editRegisterEntry:'اندراج میں ترمیم', searchRegister:'نام، والد کا نام، یا AD نمبر تلاش کریں...',
    noRegisterEntries:'ابھی کوئی اندراج نہیں۔ اپنا پہلا داخلہ ریکارڈ شامل کریں۔', headOfInstitution:'سربراہ ادارہ',
    previous:'پچھلا', next:'اگلا', printThisPage:'یہ صفحہ پرنٹ کریں',
    religion:'مذہب', nationality:'قومیت', conduct:'اخلاق', loadingData:'آپ کا ڈیٹا لوڈ ہو رہا ہے…',
    gender:'جنس', male:'مرد', female:'خاتون',
    defaultersReport:'واجب الادا رپورٹ', total:'کل',
    slcTitle:'اسکول چھوڑنے کا سرٹیفکیٹ', slcNo:'سرٹیفکیٹ نمبر', slcIssueDate:'تاریخ اجراء',
    slcSignature:'دستخط و مہر', officialSeal:'مہر دفتر',
    registerDashboard:'ڈیش بورڈ', registerAdmitted:'داخل شدہ', registerSlc:'ایس ایل سی',
    globalSearch:'طالب علم تلاش کریں', globalSearchPlaceholder:'طالب علم یا والد کے نام سے تلاش کریں...',
    noSearchResults:'کوئی مماثل طالب علم نہیں ملا۔', hasFeeRecord:'فیس ریکارڈ', hasRegisterEntry:'رجسٹر اندراج',
    viewFeeLedger:'مکمل فیس کھاتہ دیکھیں', viewRegisterEntry:'رجسٹر اندراج دیکھیں', printSlc:'اسکول چھوڑنے کا سرٹیفکیٹ پرنٹ کریں',
    registerInfo:'داخلہ رجسٹر کی معلومات', notInRegister:'اس نام کے لیے داخلہ رجسٹر میں کوئی اندراج نہیں ملا۔',
    notActiveStudent:'اس نام کے لیے کوئی فعال فیس ریکارڈ نہیں ملا۔',
    ccTitle:'کریکٹر سرٹیفکیٹ', printCc:'کریکٹر سرٹیفکیٹ پرنٹ کریں', ccNo:'سرٹیفکیٹ نمبر', ccIssueDate:'تاریخ اجراء',
    // ---- Class Logins / Class Portal ----
    classLoginsBtn:'کلاس لاگ اِن', classLoginsTitle:'کلاس لاگ اِنز',
    classLoginsDesc:'ہر کلاس کے لیے ایک لاگ اِن بنائیں تاکہ استاد مشترکہ کلاس ڈیوائس سے حاضری اور امتحانی نمبرات درج کر سکیں — الگ اکاؤنٹ کی ضرورت نہیں۔',
    addClassLogin:'کلاس لاگ اِن شامل کریں', editClassLogin:'کلاس لاگ اِن میں ترمیم', noClassLogins:'ابھی کوئی کلاس لاگ اِن نہیں۔ ہر کلاس کے لیے ایک شامل کریں۔',
    loginId:'لاگ اِن آئی ڈی', classLoginPassword:'پاس ورڈ', loginIdTaken:'یہ لاگ اِن آئی ڈی پہلے سے استعمال میں ہے — دوسری منتخب کریں۔',
    classTeacherName:'کلاس ٹیچر کا نام',
    viewAttendance:'حاضری', viewMarks:'امتحانی نمبرات', classLoginSavedHint:'یہ لاگ اِن آئی ڈی اور پاس ورڈ کلاس ٹیچر کو دیں۔',
    selectDate:'تاریخ', noAttendanceRecords:'اس تاریخ کے لیے کوئی حاضری درج نہیں۔', noExamsYet:'ابھی کوئی امتحان محفوظ نہیں۔',
    examMarksTitle:'امتحانی نمبرات', backToClassLogins:'کلاس لاگ اِنز پر واپس', shareLoginLink:'پورٹل لنک',
    classPortalTitle:'کلاس لاگ اِن', classPortalDesc:'اپنا اسکول کوڈ اور اسکول کی طرف سے دی گئی لاگ اِن آئی ڈی و پاس ورڈ درج کریں۔',
    classPortalLoginButton:'لاگ اِن', classPortalInvalid:'غلط اسکول کوڈ، لاگ اِن آئی ڈی یا پاس ورڈ۔',
    classPortalMenuAttendance:'حاضری لگائیں', classPortalMenuDiary:'ڈائری', classPortalDiaryPwDesc:'اسکول کی طرف سے دیا گیا ڈائری پاس ورڈ درج کریں۔ اس ڈیوائس پر یہ صرف ایک بار کرنا ہے۔', classPortalDiaryDesc:'مضمون منتخب کریں اور اس کلاس کی ڈائری لکھیں۔', classPortalDiaryChangePw:'ڈائری پاس ورڈ تبدیل کریں', classPortalMenuRegister:'رجسٹر دیکھیں', classPortalMenuMarks:'امتحانی نمبرات درج کریں',
    classPortalLogout:'کلاس تبدیل کریں', classPortalBackToMenu:'واپس',
    classPortalAttendanceSaved:'حاضری محفوظ ہو گئی۔', classPortalOffline:'آف لائن محفوظ ہو گیا — انٹرنیٹ آنے پر خود بخود بھیج دیا جائے گا۔',
    classPortalOfflineNoList:'آپ آف لائن ہیں اور یہ کلاس لسٹ ابھی محفوظ نہیں — براہ کرم ایک بار انٹرنیٹ سے جڑیں۔',
    classPortalExamName:'امتحان کا نام', classPortalExamNamePlaceholder:'مثال: مڈ ٹرم 2026',
    classPortalAddSubject:'مضمون شامل کریں', classPortalSubjectName:'مضمون', classPortalSubjectTotal:'کل نمبر',
    classPortalNoSubjects:'پہلے کم از کم ایک مضمون شامل کریں۔', classPortalSaveMarks:'نمبرات محفوظ کریں', classPortalMarksSaved:'نمبرات محفوظ ہو گئے۔',
    classPortalMarksExceed:'نمبر مضمون کے کل نمبروں سے زیادہ نہیں ہو سکتے۔',
    classPortalMenuAddStudent:'طالب علم شامل کریں', classPortalAddStudentTitle:'طالب علم شامل کریں', classPortalAddStudentDesc:'اس کلاس میں شامل کرنے کے لیے طالب علم کا نام درج کریں۔ والد کا نام اور رابطہ نمبر اختیاری ہیں۔',
    classPortalMenuManageStudents:'طلبہ کا انتظام', classPortalManageStudentsDesc:'اگر کوئی طالب علم اسکول چھوڑ چکا ہے تو یہاں سے اسے نشان زد کریں۔ وہ حاضری، رجسٹر اور نمبروں سے ہٹ جائے گا، مگر اس کا ریکارڈ محفوظ رہے گا اور اسکول اسے دوبارہ بحال کر سکتا ہے۔', classPortalNoStudents:'اس کلاس میں ابھی کوئی طالب علم نہیں۔',
    classPortalStudentNamePlaceholder:'طالب علم کا نام', classPortalAddStudentSaved:'طالب علم شامل ہو گیا۔', classPortalAddStudentOffline:'آپ آف لائن ہیں — طالب علم شامل کرنے کے لیے انٹرنیٹ سے جڑیں۔',
    classPortalFatherNameRequired:'والد کا نام درج کرنا ضروری ہے۔',
    classPortalPhoneRequired:'رابطہ نمبر درج کرنا ضروری ہے۔',
    classPortalLoadExam:'محفوظ امتحان میں ترمیم کے لیے منتخب کریں', classPortalNewExam:'— نیا امتحان —',
    classPortalMenuMarksView:'مارکس شیٹ دیکھیں', classPortalSelectExam:'امتحان منتخب کریں', classPortalNoExams:'ابھی تک کوئی امتحانی نمبرات محفوظ نہیں۔',
    classPortalTotal:'ٹوٹل', classPortalDownloadExcel:'ایکسل ڈاؤن لوڈ کریں', classPortalSendWhatsapp:'واٹس ایپ پر بھیجیں',
    classPortalWhatsappFallbackMsg:'مارکس شیٹ کی ایکسل فائل آپ کے فون میں ڈاؤن لوڈ ہو گئی ہے — براہ کرم یہاں اٹیچ کر کے بھیج دیں۔',
    suggestions:'تجاویز', suggestionsTitle:'آپ کے اسکول کے لیے تجاویز',
    suggestionsDesc:'اسکول کی بہتری میں مدد کے لیے آپ کے موجودہ ریکارڈ کی بنیاد پر چند مشاہدات۔',
    suggestionsAllGood:'اس وقت سب کچھ بہتر نظر آ رہا ہے — کوئی فوری تجویز نہیں۔',
    aiSuggestionsTitle:'AI تجاویز', aiSuggestionsDesc:'آپ کے اسکول کے موجودہ ریکارڈ کی بنیاد پر AI کی ذاتی نوعیت کی تجاویز۔ دن میں چند بار اپڈیٹ ہوتی ہیں۔',
    aiSuggestionsUpdatedAt:'اپڈیٹ:', aiSuggestionsCachedNote:'آف لائن — آخری محفوظ شدہ AI تجاویز دکھائی جا رہی ہیں، وقت:',
    aiSuggestionsOfflineNone:'AI تجاویز کے لیے پہلی بار انٹرنیٹ درکار ہے — ایک بار انٹرنیٹ سے جڑیں، پھر یہ آف لائن بھی دستیاب ہوں گی۔',
    aiSuggestionsError:'اس وقت AI تجاویز لوڈ نہیں ہو سکیں۔ براہ کرم بعد میں دوبارہ کوشش کریں۔',
    diaryPortalTitle:'ڈائری لاگ اِن', diaryPortalDesc:'اپنا اسکول کوڈ اور اسکول کی طرف سے دیا گیا ڈائری پاس ورڈ درج کریں۔',
    diaryPasswordLabel:'ڈائری پاس ورڈ', diaryPortalLoginButton:'لاگ اِن', diaryPortalInvalid:'غلط اسکول کوڈ یا ڈائری پاس ورڈ۔',
    diaryMenuTitle:'مضمون منتخب کریں', diaryMenuDesc:'ایک مضمون منتخب کریں، پھر وہ کلاس منتخب کریں جس کے لیے اندراج کرنا ہے۔',
    diaryAddSubject:'+ نیا مضمون شامل کریں', diaryRemoveSubject:'مضمون ہٹائیں', diaryDone:'مکمل', diaryRemoveConfirm:'اس مضمون کو فہرست سے ہٹائیں؟', diaryNewSubjectPrompt:'مضمون کا نام درج کریں', diaryLogout:'اسکول تبدیل کریں',
    diaryChooseClassTitle:'کلاس منتخب کریں', diaryEntryTitle:'نئی ڈائری اندراج', diaryEntryDate:'تاریخ',
    diaryEntryPlaceholder:'ہوم ورک / کلاس ورک / نوٹس لکھیں…', diarySave:'اندراج محفوظ کریں',
    diarySaved:'ڈائری اندراج محفوظ ہو گئی۔', diaryOfflineSaved:'آف لائن محفوظ ہو گیا — انٹرنیٹ آنے پر خود بخود بھیج دیا جائے گا۔',
    diaryBackToSubjects:'‹ مضامین', diaryBackToClasses:'‹ کلاسز',
    parentDiaryTitle:'ڈائری', parentNoDiary:'ابھی تک کوئی ڈائری اندراج نہیں۔',
    parentPortalOfflineNote:'آپ آف لائن ہیں — آخری محفوظ شدہ ڈیٹا دکھایا جا رہا ہے، وقت:',
    parentPortalSwitchStudent:'دوسرا بچہ دیکھیں', parentPortalOfflineNoCache:'آپ آف لائن ہیں اور ابھی تک کوئی محفوظ ڈیٹا دستیاب نہیں۔ براہ کرم ایک بار انٹرنیٹ سے جڑیں۔',
    diaryPasswordHint:'پورے اسکول کے لیے ایک پاس ورڈ — کوئی بھی استاد ڈائری ڈیوائس پر یہی استعمال کرے گا۔',
    diaryPasswordRequired:'براہ کرم ڈائری پاس ورڈ درج کریں۔',
  }
};

let LANG = localStorage.getItem('sms_lang') || 'en';
let t = T[LANG];
const CLASS_OPTIONS = ['Nursery','KG','1st','2nd','3rd','4th','5th','6th','7th','8th','9th','10th','11th','12th'];
const STUDENT_TYPES = ['paying','free','orphan'];
function typeLabel(type) { return type==='free' ? t.free : type==='orphan' ? t.orphan : t.feePaying; }
function isFeePaying(s) { return (s.student_type || 'paying') === 'paying'; }
const EXPENSE_CATS = ['Electricity','Rent','Stationery','Salary','Transport','Maintenance','Other'];
const INCOME_CATS = ['Donation','Grant','Sale','Fundraiser','Other'];

const fmt = n => Number(n||0).toLocaleString('en-US');
// Money maths in JS floats can leave dust like 0.30000000000000004, which would show a
// student as owing a few paisa forever. Round every running balance to 2 decimals.
const money2 = n => Math.round((Number(n) || 0) * 100) / 100;
// Used on the dashboard to show "—" instead of a real-looking number/amount
// when there is no cached data to show at all (see CACHE_UNAVAILABLE) — so
// "we have nothing cached yet" never reads as "your balance is ₨0".
const dv = (str) => CACHE_UNAVAILABLE ? '—' : str;
const monthKey = (d=new Date()) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
const monthLabel = mk => { const [y,m]=mk.split('-').map(Number); return new Date(y,m-1,1).toLocaleDateString(LANG==='ur'?'ur-PK':'en-US',{month:'short',year:'numeric'}); };
// Local calendar date as YYYY-MM-DD. NOT toISOString(): that is UTC, which in Pakistan (UTC+5)
// gives YESTERDAY between 00:00 and 05:00, and shifts any local-midnight Date back by a day.
const localISO = (d) => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const todayISO = () => localISO(new Date());

// ============================================================================
// SAFE DATE FIELD READING — mandatory pattern for every <input type="date">
// ============================================================================
// Some Android WebView/browser combinations fail to reliably commit a
// pre-filled date input's value until the user manually opens the picker and
// interacts with it. Reading `.value` directly in that state silently returns
// an empty string — which previously caused Save to either do nothing or
// write a blank/invalid date whenever a date field was left untouched.
//
// dateVal() is the single fix point for this: it always returns a usable
// date string, defaulting to `fallback` (today, by default) when the field
// reads empty. EVERY date field in this app must be read through dateVal()
// instead of calling document.getElementById(id).value directly — that is
// what prevents this bug class from silently resurfacing wherever a new date
// field gets added later.
//   dateVal('p-date')                    -> defaults to today if empty
//   dateVal('ar-withdrawal-date', null)  -> defaults to null if empty (optional field)
//   dateVal('ar-dob-figures', '')        -> defaults to '' if empty (optional field)
function dateVal(id, fallback = todayISO()) {
  const el = document.getElementById(id);
  const v = el ? el.value : '';
  return v || fallback;
}
// Reformats a plain 'YYYY-MM-DD' date string to 'DD-MM-YYYY' for display/printing.
// Anything that isn't a clean ISO date (blank, free text, already-formatted, etc.)
// is returned unchanged so it never mangles non-date values.
const fmtDate = (iso) => {
  if (!iso) return iso;
  const s = String(iso).slice(0, 10);
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  if (!m) return iso;
  return `${m[3]}-${m[2]}-${m[1]}`;
};
const escJs = s => esc(String(s==null?'':s).replace(/\\/g,'\\\\').replace(/'/g,"\\'"));
const esc = s => (s==null?'':String(s)).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// Wraps free-typed text (question wording, MCQ options, matching entries...)
// in a <bdi> element so it gets its own bidi-isolated run: the browser reads
// its first strong character to pick left-to-right or right-to-left on its
// own, independent of the English (LTR) paragraph/labels around it. This is
// what keeps an Urdu sentence typed inside an otherwise-English question
// paper displaying right-to-left, while any digits inside that sentence
// (or the separate question-number prefix outside the <bdi>) stay exactly
// where they were typed instead of being dragged around by the surrounding
// direction.
const bidi = s => `<bdi>${esc(s)}</bdi>`;

// Used only for the printed Question Paper (see printQuestionPaper): decides
// a line's direction from its own text rather than relying on the browser's
// dir="auto" heuristic, which fails when an MCQ's options are plain digits
// (e.g. "1971") — digits carry no strong bidi character, so dir="auto" on
// the options row alone would default to ltr even for an Urdu question. Here
// the question's own wording decides, and that same direction is applied to
// its options row too, so the options always follow the question's language.
const RTL_CHAR_RE = /[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]/;
const qDir = s => RTL_CHAR_RE.test(s) ? 'rtl' : 'ltr';

// Ring buffer of the last 30 client errors (kept in localStorage) — nothing is shown to the
// user, but support can read them with: localStorage.getItem('sms_client_errors')
function _logClientError(where, err) {
  try {
    console.error('[' + where + ']', err);
    const k = 'sms_client_errors';
    const l = JSON.parse(localStorage.getItem(k) || '[]');
    l.push({ t: new Date().toISOString(), where, msg: String((err && err.message) || err).slice(0, 300) });
    localStorage.setItem(k, JSON.stringify(l.slice(-30)));
  } catch (e) {}
}
window.addEventListener('unhandledrejection', e => _logClientError('promise', e.reason));
window.addEventListener('error', e => _logClientError('error', e.error || e.message));

// Prevents double-submission (e.g. from impatient repeated tapping on a slow
// connection): disables the clicked button for the duration of the async submit
// function, so a second tap before the first save finishes is simply ignored
// instead of creating a duplicate record. Also swaps the button's label to a
// "Saving…" state so the user gets immediate visual proof the tap registered
// and doesn't feel the need to keep tapping. If the button is still in the page
// afterwards (e.g. a validation error kept the same modal open), both the label
// and disabled state are restored; on success the modal/tab normally re-renders
// anyway, replacing the button fresh.
async function guardedSubmit(btn, fn) {
  if (!btn || btn.disabled) return;
  const savingLabel = LANG === 'ur' ? 'محفوظ ہو رہا ہے…' : 'Saving…';
  const prevHtml = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = savingLabel;
  try {
    await fn();
  } finally {
    if (btn.isConnected) { btn.disabled = false; btn.innerHTML = prevHtml; }
  }
}

// Shared error surface for Supabase writes. Returns true (and alerts the user)
// if an error occurred, so callers can `if (reportSaveError(error)) return;`
// instead of silently continuing as if the save succeeded.
function reportSaveError(error) {
  if (!error) return false;
  console.error('Save failed:', error);
  alert(LANG === 'ur'
    ? `محفوظ کرنے میں خرابی پیش آئی: ${error.message}\nبراہ کرم انٹرنیٹ کنکشن چیک کریں اور دوبارہ کوشش کریں۔`
    : `Save failed: ${error.message}\nPlease check your internet connection and try again.`);
  return true;
}

// A raw "TypeError: Failed to fetch" (the browser's generic network-failure
// message) is meaningless to a non-technical user — it just means the
// request never reached the server (no signal, airplane mode, DNS hiccup,
// etc). Used by spots that show error.message inline (Account Settings)
// rather than through the reportSaveError() alert above.
function friendlyErrorMsg(error) {
  const msg = (error && error.message) || '';
  if (/failed to fetch/i.test(msg) || /networkerror/i.test(msg) || /load failed/i.test(msg)) {
    return LANG === 'ur'
      ? 'انٹرنیٹ کنکشن نہیں مل رہا۔ براہ کرم سگنل چیک کر کے دوبارہ کوشش کریں۔'
      : 'No internet connection. Please check your signal and try again.';
  }
  return msg;
}

let DATA = { students:[], feePayments:[], teachers:[], salaryPayments:[], transactions:[], admissionRegister:[], teacherAttendance:[], holidays:[], classLogins:[], studentAttendance:[] };
let TAB = 'dashboard';
let CURRENT_USER = null;   // { id, email }
let CURRENT_PROFILE = null; // { school_name }
// Remembers the id of the last account that successfully logged in on this
// device. Used only as a fallback at boot when the device is offline (or on
// too weak a signal) to confirm a live Supabase session — see boot() below —
// so a school that logged in once with internet can still reopen the app
// offline later instead of being stuck on a login screen they can't use.
const LAST_UID_KEY = 'sms_last_uid';

// ---------------- Offline Support (IndexedDB cache + sync queue) ----------------
// Covers fee_payments, students, and teachers — the day-to-day actions most
// likely to happen with no signal. To extend to another table later: add its
// name to OFFLINE_TABLES, mirror it in offlineCacheStore/offlineCacheRestore,
// and route its writes through offlineWrite() the same way submitFeePayment,
// submitAddStudent, and submitAddTeacher do below.
//
// How it works: every successful online loadAllData() mirrors these tables
// into IndexedDB. While offline, writes are applied immediately to DATA (so
// the UI updates instantly) and queued in IndexedDB. As soon as the browser
// comes back online, the queue is replayed against Supabase automatically —
// UNLESS the same row was changed on another device in the meantime, in
// which case that item is held and the user is asked which version to keep
// (see renderSyncConflictModal), never overwritten silently.
const OFFLINE_TABLES = ['fee_payments', 'students', 'teachers', 'salary_payments', 'teacher_attendance', 'transactions', 'holidays', 'class_logins', 'admission_register'];
// Everything here is mirrored to IndexedDB purely for read access while
// fully offline (e.g. opening the app with no signal at all) — only the
// tables in OFFLINE_TABLES above also support making new changes offline.
const READ_CACHE_TABLES = ['students', 'fee_payments', 'teachers', 'salary_payments', 'transactions', 'teacher_attendance', 'holidays', 'class_logins', 'student_attendance', 'admission_register'];
const IDB_NAME = 'sms_offline_v1';
let _idbPromise = null;
function idbOpen() {
  if (_idbPromise) return _idbPromise;
  _idbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(IDB_NAME, 6);
    req.onupgradeneeded = () => {
      const db = req.result;
      READ_CACHE_TABLES.forEach(tbl => { if (!db.objectStoreNames.contains(tbl)) db.createObjectStore(tbl, { keyPath: 'id' }); });
      if (!db.objectStoreNames.contains('sync_queue')) db.createObjectStore('sync_queue', { keyPath: 'qid', autoIncrement: true });
      // DMC certificate config (logo, school name, subjects, design) — cached
      // locally so certificates can be generated/printed with zero internet.
      if (!db.objectStoreNames.contains('dmc_config')) db.createObjectStore('dmc_config', { keyPath: 'id' });
      // Marks Sheet data — one row per academic year (keyed by the year
      // itself), cached locally so the sheet can be viewed, edited, and
      // printed/exported with zero internet.
      if (!db.objectStoreNames.contains('marks_sheet_data')) db.createObjectStore('marks_sheet_data', { keyPath: 'id' });
      // Class Exam Marks (Class Marks View) — one row per class (keyed by
      // class_name), cached locally so admin can still open a class's saved
      // exam marks with zero internet, same as the other on-demand caches.
      if (!db.objectStoreNames.contains('class_exam_marks')) db.createObjectStore('class_exam_marks', { keyPath: 'class_name' });
      // The DMC Excel upload (dmcResults) previously lived only in memory —
      // reloading the page (or opening the app offline after uploading while
      // online) wiped it, even though dmc_config/subjects survived. Cached
      // here as a single row so the last-uploaded batch survives a reload
      // with zero internet.
      if (!db.objectStoreNames.contains('dmc_upload')) db.createObjectStore('dmc_upload', { keyPath: 'id' });
      // AI-generated suggestions (see loadAiSuggestions) — cached locally,
      // same on-demand pattern as dmc_config, so the last-fetched AI
      // insights can still be shown while offline instead of nothing.
      if (!db.objectStoreNames.contains('ai_suggestions')) db.createObjectStore('ai_suggestions', { keyPath: 'id' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return _idbPromise;
}
async function idbGetAll(store) {
  try {
    const db = await idbOpen();
    return await new Promise((res, rej) => {
      const r = db.transaction(store, 'readonly').objectStore(store).getAll();
      r.onsuccess = () => res(r.result || []); r.onerror = () => rej(r.error);
    });
  } catch { return []; }
}
async function idbReplaceAll(store, rows) {
  try {
    const db = await idbOpen();
    // Waits for the transaction to actually finish committing to disk before
    // resolving — previously this returned right after queuing the writes,
    // so if the tab was reloaded (or fully closed) in the same instant —
    // e.g. saving data, then immediately turning off mobile data and hitting
    // refresh to test offline mode — the writes could still be in flight and
    // never actually land, leaving the offline cache empty (dashboard showing
    // all-zero on the next offline load) even though nothing was ever lost
    // on the server side.
    await new Promise((resolve, reject) => {
      const tx = db.transaction(store, 'readwrite');
      const os = tx.objectStore(store);
      os.clear();
      // Each put() is wrapped individually so one malformed/keyless row can't
      // throw mid-loop and abort the whole transaction — that would leave the
      // store empty (it was already cleared above) even though every other
      // row was perfectly fine, which is exactly the "all data disappears
      // offline" symptom, just triggered by a single bad record instead of a
      // timing issue.
      rows.forEach(row => { try { os.put(row); } catch (e) { console.error('idbReplaceAll: skipped bad row in', store, e); } });
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  } catch (e) { console.error('idbReplaceAll failed', store, e); }
}
// All single-row helpers now wait for the transaction to actually COMMIT (the old
// versions returned as soon as the write was queued — a tab closed or killed in that
// instant lost the change, which for the sync queue means a lost offline save).
function idbTx(store, mode, fn) {
  return idbOpen().then(db => new Promise((resolve, reject) => {
    const tx = db.transaction(store, mode);
    let out;
    try { out = fn(tx.objectStore(store)); } catch (e) { reject(e); return; }
    tx.oncomplete = () => resolve(out && out.result !== undefined ? out.result : undefined);
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  }));
}
async function idbPutRow(store, row) {
  try { await idbTx(store, 'readwrite', os => os.put(row)); }
  catch (e) { console.error('idbPutRow failed', store, e); }
}
async function idbDeleteRow(store, id) {
  try { await idbTx(store, 'readwrite', os => os.delete(id)); }
  catch (e) { console.error('idbDeleteRow failed', store, e); }
}
// If IndexedDB itself is unavailable/full (private mode, quota, broken WebView), the
// queued change is parked in localStorage instead of being dropped; flushSyncQueue
// moves it back into IndexedDB / replays it on the next run.
const SYNC_FALLBACK_KEY = 'sms_sync_queue_fallback';
function _fallbackRead() { try { return JSON.parse(localStorage.getItem(SYNC_FALLBACK_KEY) || '[]') || []; } catch (e) { return []; } }
function _fallbackWrite(list) { try { if (list.length) localStorage.setItem(SYNC_FALLBACK_KEY, JSON.stringify(list)); else localStorage.removeItem(SYNC_FALLBACK_KEY); } catch (e) { console.error('fallback queue write failed', e); } }
async function idbQueueAdd(entry) {
  try { await idbTx('sync_queue', 'readwrite', os => os.add(entry)); return true; }
  catch (e) {
    console.error('idbQueueAdd failed — parking in localStorage', e);
    const l = _fallbackRead(); l.push(entry); _fallbackWrite(l);
    return false;
  }
}
async function idbQueueRemove(qid) {
  try { await idbTx('sync_queue', 'readwrite', os => os.delete(qid)); }
  catch (e) { console.error('idbQueueRemove failed', e); }
}
async function idbQueueUpdate(item) {
  try { await idbTx('sync_queue', 'readwrite', os => os.put(item)); }
  catch (e) { console.error('idbQueueUpdate failed', e); }
}

// Mirrors every READ_CACHE_TABLES table into IndexedDB after a successful
// online loadAllData(), so the app has something to show if it's later
// opened with no signal at all.
async function offlineCacheStore() {
  await Promise.all([
    idbReplaceAll('students', DATA.students),
    idbReplaceAll('fee_payments', DATA.feePayments),
    idbReplaceAll('teachers', DATA.teachers),
    idbReplaceAll('salary_payments', DATA.salaryPayments),
    idbReplaceAll('transactions', DATA.transactions),
    idbReplaceAll('teacher_attendance', DATA.teacherAttendance),
    idbReplaceAll('holidays', DATA.holidays),
    idbReplaceAll('class_logins', DATA.classLogins),
    idbReplaceAll('student_attendance', DATA.studentAttendance),
    idbReplaceAll('admission_register', DATA.admissionRegister),
  ]);
  saveOfflineSnapshot();
}
// Second, independent copy of the same synced data, written to localStorage
// instead of IndexedDB. Some in-app/WebView browsers (common on Android when
// this kind of app is wrapped into an .apk) silently fail to persist
// IndexedDB across app restarts even though every write above reports
// success — localStorage is far more consistently reliable in exactly those
// environments. This is purely a last-resort backup; IndexedDB stays the
// primary cache.
const OFFLINE_SNAPSHOT_KEY = 'sms_offline_snapshot';
function saveOfflineSnapshot() {
  try {
    const snap = {
      students: DATA.students, feePayments: DATA.feePayments, teachers: DATA.teachers,
      salaryPayments: DATA.salaryPayments, transactions: DATA.transactions,
      teacherAttendance: DATA.teacherAttendance, holidays: DATA.holidays,
      classLogins: DATA.classLogins, studentAttendance: DATA.studentAttendance,
      admissionRegister: DATA.admissionRegister, savedAt: Date.now(),
    };
    const key = OFFLINE_SNAPSHOT_KEY + '_' + (CURRENT_USER ? CURRENT_USER.id : 'anon');
    localStorage.setItem(key, JSON.stringify(snap));
  } catch (e) { console.error('saveOfflineSnapshot failed', e); }
}
function loadOfflineSnapshot() {
  try {
    const key = OFFLINE_SNAPSHOT_KEY + '_' + (CURRENT_USER ? CURRENT_USER.id : 'anon');
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : null;
  } catch (e) { return null; }
}
// Restores the last-synced snapshot from IndexedDB when loadAllData() can't
// reach the server at all (opening the app with no signal, or losing signal
// mid-request). The Admission Register is now cached too, so it stays
// viewable (read-only, same as the other tables) while fully offline.
// Human-readable trail of exactly what offlineCacheRestore() found (or
// didn't) on this device, last time it ran. Shown in the CACHE_UNAVAILABLE
// banner so a "why is this offline?" report comes with the actual numbers
// instead of a screenshot of just the symptom — no PC/remote-debugging
// needed to see whether IndexedDB, the localStorage snapshot, or both, came
// back empty.
let OFFLINE_DEBUG_INFO = '';
async function offlineCacheRestore() {
  const [st, fp, tc, sp, tx, ta, hd, cl, sa, ar] = await Promise.all(
    READ_CACHE_TABLES.map(tbl => idbGetAll(tbl))
  );
  const totalRows = st.length + fp.length + tc.length + sp.length + tx.length + ta.length + hd.length + cl.length + sa.length + ar.length;
  if (totalRows === 0) {
    // IndexedDB came back completely empty. Either this device has never
    // synced yet (genuinely nothing to show), or IndexedDB failed to persist
    // on this browser — the exact "all data becomes zero while offline" bug.
    // Fall back to the localStorage snapshot before accepting an all-zero
    // dashboard, so a real prior sync is never silently discarded.
    const snap = loadOfflineSnapshot();
    // A snapshot object existing is not the same as it holding real rows —
    // an empty-but-present snapshot (e.g. saved before the first real sync
    // ever completed) used to be accepted as "we have data" and silently
    // rendered ₨0 everywhere with no warning banner. Only trust it once it
    // actually contains at least one cached row.
    const snapRows = snap ? (snap.students||[]).length + (snap.feePayments||[]).length + (snap.teachers||[]).length +
      (snap.salaryPayments||[]).length + (snap.transactions||[]).length + (snap.teacherAttendance||[]).length +
      (snap.holidays||[]).length + (snap.classLogins||[]).length + (snap.studentAttendance||[]).length +
      (snap.admissionRegister||[]).length : 0;
    if (snap && snapRows > 0) {
      DATA.students = snap.students || []; DATA.feePayments = snap.feePayments || []; DATA.teachers = snap.teachers || [];
      DATA.salaryPayments = snap.salaryPayments || []; DATA.transactions = snap.transactions || []; DATA.teacherAttendance = snap.teacherAttendance || [];
      DATA.holidays = snap.holidays || []; DATA.classLogins = snap.classLogins || []; DATA.studentAttendance = snap.studentAttendance || [];
      DATA.admissionRegister = snap.admissionRegister || [];
      CACHE_UNAVAILABLE = false;
      OFFLINE_DEBUG_INFO = `IndexedDB: 0 rows · localStorage snapshot: ${snapRows} rows (saved ${snap.savedAt ? new Date(snap.savedAt).toLocaleString() : 'unknown time'})`;
      return;
    }
    // Genuinely nothing anywhere on this device — never synced yet, or the
    // browser wiped both caches. Flag it so the dashboard shows "—" instead
    // of "₨0" (see CACHE_UNAVAILABLE above) rather than looking like real
    // financial data.
    CACHE_UNAVAILABLE = true;
    OFFLINE_DEBUG_INFO = snap
      ? `IndexedDB: 0 rows · localStorage snapshot: found but empty (saved ${snap.savedAt ? new Date(snap.savedAt).toLocaleString() : 'unknown time'})`
      : 'IndexedDB: 0 rows · localStorage snapshot: none found on this device';
  } else {
    CACHE_UNAVAILABLE = false;
    OFFLINE_DEBUG_INFO = `IndexedDB: ${totalRows} rows (students ${st.length}, fee_payments ${fp.length}, teachers ${tc.length}, salary_payments ${sp.length}, transactions ${tx.length})`;
  }
  DATA.students = st; DATA.feePayments = fp; DATA.teachers = tc;
  DATA.salaryPayments = sp; DATA.transactions = tx; DATA.teacherAttendance = ta; DATA.holidays = hd; DATA.classLogins = cl; DATA.studentAttendance = sa;
  DATA.admissionRegister = ar;
}

let SYNCING = false;
let PENDING_CONFLICTS = [];
// True only when offlineCacheRestore() found literally nothing anywhere on
// this device (no IndexedDB rows, no localStorage snapshot either) — i.e.
// there is no cached data to show, as opposed to the school's real balances
// genuinely being 0. tplDashboard() checks this to show "—" placeholders
// instead of "₨0" figures, so a school never mistakes "we have no cached
// copy yet" for "our money disappeared". Cleared the moment any real data
// is found — from cache while offline, or freshly from the server once
// back online.
let CACHE_UNAVAILABLE = false;
// Generic offline-aware write. `run` performs the real Supabase call when
// online; `optimisticApply` updates DATA immediately so the UI reflects the
// change with no network round-trip; `baseRow` is the last-known-synced copy
// of the row (for conflict detection when the queue is later replayed).
// Supabase-js does not throw when the request never reaches the server —
// it catches the underlying fetch() failure itself and hands it back as a
// normal { error } result, with error.message literally being something
// like "TypeError: Failed to fetch". That has to be told apart from a real,
// server-answered error (wrong data, permission denied, etc.), which should
// still be reported to the user immediately rather than silently queued.
function isNetworkError(error) {
  if (!error) return false;
  const msg = String(error.message || error).toLowerCase();
  return msg.includes('failed to fetch') || msg.includes('networkerror') || msg.includes('load failed') || msg.includes('network request failed') || msg.includes('timeout');
}
// navigator.onLine only means "this device has a network interface active"
// (e.g. connected to a router) — NOT that the connection actually reaches
// the internet. On a weak/fake signal a request can just hang instead of
// failing, so every network call made during boot/loading races against this
// timeout and is treated as a network failure the moment it's hit, instead
// of leaving the loading screen stuck for however long the browser's own
// (often very long) fetch timeout is.
function withTimeout(promise, ms = 6000) {
  return Promise.race([
    promise,
    new Promise((resolve) => setTimeout(() => resolve({ data: null, error: { message: 'TypeError: Failed to fetch (timed out)' } }), ms))
  ]);
}
// ---------------- Activity Log ----------------
// Fire-and-forget audit trail. Hooked once here inside offlineWrite instead of
// at each of the ~20 call sites, so every insert/update/upsert/delete that
// already flows through offlineWrite is covered automatically, present and
// future. Deliberately NOT awaited by callers and wrapped so it can never
// throw or slow down / block the real save — if the activity_log table
// hasn't been created yet (see the ONE-TIME SETUP comment near CONFIG above),
// or the device is offline, this silently does nothing.
const ACTIVITY_LOG_TABLES = new Set([
  'students', 'fee_payments', 'teachers', 'salary_payments',
  'transactions', 'admission_register', 'class_logins'
  // teacher_attendance / holidays intentionally excluded — too high-volume
  // (marked daily) to be a useful audit trail and would drown out everything else.
]);
function describeActivity(table, action, payload, baseRow) {
  const row = payload || baseRow || {};
  const verb = action === 'insert' ? 'Added' : action === 'delete' ? 'Deleted' : action === 'upsert' ? 'Recorded' : 'Updated';
  if (table === 'students') {
    const name = row.name || (baseRow && baseRow.name) || 'student';
    return `${verb} student: ${name}${row.class_name ? ' (' + row.class_name + ')' : ''}`;
  }
  if (table === 'fee_payments') {
    const sid = row.student_id || (baseRow && baseRow.student_id);
    const s = DATA.students.find(x => x.id === sid);
    const month = row.month || (baseRow && baseRow.month);
    return `${verb} fee payment: ${s ? s.name : 'student'}${month ? ' — ' + monthLabel(month) : ''}${row.amount != null ? ' — Rs ' + fmt(row.amount) : ''}`;
  }
  if (table === 'teachers') {
    const name = row.name || (baseRow && baseRow.name) || 'teacher';
    return `${verb} teacher: ${name}`;
  }
  if (table === 'salary_payments') {
    const tid = row.teacher_id || (baseRow && baseRow.teacher_id);
    const tc = DATA.teachers.find(x => x.id === tid);
    const month = row.month || (baseRow && baseRow.month);
    return `${verb} salary payment: ${tc ? tc.name : 'teacher'}${month ? ' — ' + monthLabel(month) : ''}${row.amount != null ? ' — Rs ' + fmt(row.amount) : ''}`;
  }
  if (table === 'transactions') {
    return `${verb} ${row.type || ''} transaction: ${row.category || ''}${row.amount != null ? ' — Rs ' + fmt(row.amount) : ''}`.trim();
  }
  if (table === 'admission_register') {
    const name = row.student_name || (baseRow && baseRow.student_name) || 'entry';
    return `${verb} admission register entry: ${name}`;
  }
  if (table === 'class_logins') {
    const cls = row.class_name || (baseRow && baseRow.class_name) || '';
    return `${verb} class login${cls ? ': ' + cls : ''}`;
  }
  return `${verb} ${table} record`;
}
function logActivity(table, action, payload, id, baseRow) {
  if (!ACTIVITY_LOG_TABLES.has(table)) return;
  if (!navigator.onLine || !CURRENT_USER) return; // best-effort only — no offline queueing for log entries
  try {
    const description = describeActivity(table, action, payload, baseRow);
    sb.from('activity_log').insert({
      owner_id: CURRENT_USER.id,
      actor_email: CURRENT_USER.email || null,
      action, table_name: table, description
    }).then(() => {}).catch(() => {}); // table may not exist yet — never let this break a real save
  } catch (e) { /* never let logging break the actual save */ }
}

async function offlineWrite({ table, action, payload, id, onConflict, baseRow, run, optimisticApply }) {
  optimisticApply();
  bumpIdx();
  logActivity(table, action, payload, id, baseRow);
  if (navigator.onLine) {
    try {
      const result = await run();
      if (result && result.error) {
        if (isNetworkError(result.error)) { /* connectivity problem, not a real rejection — fall through to queueing */ }
        else return { queued: false, error: result.error }; // a genuine server-answered error — report it, don't queue it
      } else {
        return { queued: false };
      }
    } catch (e) { /* the request itself never reached the server — queue it */ }
  }
  await idbQueueAdd({ table, action, payload, id, onConflict, baseRow, ts: Date.now() });
  renderOfflineBanner();
  return { queued: true };
}

// On a weak/flaky connection the browser's 'online' event can fire the
// instant a signal blip reconnects — and can keep firing repeatedly as the
// connection flickers — completely independent of whatever the user happens
// to be doing at that moment. flushSyncQueue() below runs on every 'online'
// event and, once done, used to call renderTab() unconditionally: that tears
// down and rebuilds the ENTIRE current tab, including any input the user is
// mid-keystroke in, on ANY screen — which is exactly the "keyboard closes as
// soon as I type" bug, happening at effectively random moments tied to
// connection flakiness rather than to any particular field or tab. That's
// also why it started once the offline/sync feature was added, and why it
// showed up everywhere at once rather than in one place.
// safeRenderTab() defers that redraw if the user is currently typing in a
// field inside #main, and fires it once they leave that field instead — the
// data has already synced either way, this only delays the *visual* refresh.
let pendingRenderOnBlur = false;
// Same "don't redraw out from under the user" problem also applies to an
// in-progress drag-scroll on the Admission Register / Teacher Attendance
// ledger tables (see initRegBookScroll below) — that drag isn't an INPUT or
// TEXTAREA, so the focus check below never caught it. A flaky-connection
// 'online' event firing mid-drag would tear down and rebuild the tab, which
// recreates the scroll wrapper from scratch at scrollLeft 0 — that's what
// looked like the table scrolling, then snapping back to the start.
let _regBookDragActive = false;
let pendingRenderOnDragEnd = false;
function safeRenderTab() {
  const ae = document.activeElement;
  const main = document.getElementById('main');
  if (ae && main && main.contains(ae) && (ae.tagName === 'INPUT' || ae.tagName === 'TEXTAREA' || ae.tagName === 'SELECT' || ae.isContentEditable)) {
    pendingRenderOnBlur = true;
    return;
  }
  if (_regBookDragActive) {
    pendingRenderOnDragEnd = true;
    return;
  }
  renderTab();
}
document.addEventListener('focusout', (e) => {
  if (!pendingRenderOnBlur) return;
  if (!e.target || (e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA' && e.target.tagName !== 'SELECT' && !e.target.isContentEditable)) return;
  pendingRenderOnBlur = false;
  // Let the blur/value-commit finish first, then redraw with fresh data.
  setTimeout(() => { if (TAB) renderTab(); }, 0);
});

let _syncRetryMs = 0, _syncRetryTimer = null;
function scheduleSyncRetry() {
  clearTimeout(_syncRetryTimer);
  _syncRetryMs = Math.min(_syncRetryMs ? _syncRetryMs * 2 : 5000, 120000);
  _syncRetryTimer = setTimeout(() => { flushSyncQueue(); }, _syncRetryMs);
}
function isDupKey(error) { return !!error && (error.code === '23505' || /duplicate key/i.test(error.message || '')); }
// Runs ONE queued change against Supabase and returns the real result object
// ({ error, status }). The old code never looked at the result: supabase-js does
// not throw on failure, it returns { error } — so a failed replay was treated as
// success and the queued change was DELETED from the queue (silent data loss).
async function execQueueItem(item) {
  const q = sb.from(item.table);
  if (item.action === 'upsert') return await q.upsert(item.payload, { onConflict: item.onConflict });
  if (item.action === 'update') return await q.update(item.payload).eq('id', item.id);
  if (item.action === 'bulk_update') return await q.update(item.payload).in('id', item.ids);
  if (item.action === 'delete') return await q.delete().eq('id', item.id);
  if (item.action === 'insert') return await q.insert(item.payload);
  return { error: null };
}
function isTransientResult(r) {
  if (!r || !r.error) return false;
  if (isNetworkError(r.error)) return true;
  const st = r.status;
  return st === 408 || st === 429 || (st >= 500 && st <= 599);
}
const MAX_SYNC_ATTEMPTS = 4;
async function flushSyncQueue() {
  if (SYNCING || !navigator.onLine) return;
  SYNCING = true;
  const conflicts = [];
  let stoppedEarly = false;
  try {
    // Move anything parked in localStorage (IndexedDB was unavailable) back into the queue.
    const parked = _fallbackRead();
    if (parked.length) {
      let ok = true;
      for (const e of parked) { if (!(await idbQueueAdd(e))) { ok = false; break; } }
      if (ok) _fallbackWrite([]);
    }
    const queue = await idbGetAll('sync_queue');
    for (const item of queue) {
      if (item.failed) continue;                       // waiting for the user (see openFailedSync)
      try {
        let serverRow = null;
        if (item.id && item.baseRow) {
          const r = await sb.from(item.table).select('*').eq('id', item.id).maybeSingle();
          if (r.error) {
            if (isTransientResult(r)) { stoppedEarly = true; break; }   // keep order, retry later
          } else serverRow = r.data;
        }
        const changed = item.baseRow && serverRow && JSON.stringify(serverRow) !== JSON.stringify(item.baseRow);
        if (changed) { conflicts.push({ ...item, serverRow }); continue; } // held for the user, not overwritten
        const r = await execQueueItem(item);
        if (!r.error || (item.action === 'insert' && isDupKey(r.error))) {
          await idbQueueRemove(item.qid);              // genuinely applied (or was already applied)
          continue;
        }
        if (isTransientResult(r)) { stoppedEarly = true; break; }       // connectivity/server load — retry later, in order
        // A real rejection from the server (permission, constraint, bad data). Retrying forever
        // would block the banner; discarding silently would lose data. Count it, and after a few
        // attempts park it as "failed" so the user can see, retry, export or discard it.
        item.attempts = (item.attempts || 0) + 1;
        item.lastError = String((r.error && r.error.message) || r.error).slice(0, 300);
        if (item.attempts >= MAX_SYNC_ATTEMPTS) item.failed = true;
        await idbQueueUpdate(item);
        console.error('sync rejected by server', item, r.error);
      } catch (e) {
        console.error('sync failed for item', item, e);
        stoppedEarly = true; break;                    // request never completed — keep it, retry later
      }
    }
  } catch (e) {
    console.error('flushSyncQueue crashed', e);
    stoppedEarly = true;
  } finally {
    SYNCING = false;                                   // can never get stuck on true again
  }
  await renderOfflineBanner();
  const remaining = (await idbGetAll('sync_queue')).filter(x => !x.failed);
  if (stoppedEarly || (remaining.length && !conflicts.length && remaining.some(x => !x.failed))) {
    if (remaining.length) scheduleSyncRetry();
  } else { _syncRetryMs = 0; }
  if (conflicts.length) { PENDING_CONFLICTS = conflicts; renderSyncConflictModal(); }
  else { await loadAllData(); if (TAB) safeRenderTab(); }
}

function renderSyncConflictModal() {
  if (!PENDING_CONFLICTS.length) return;
  const c = PENDING_CONFLICTS[0];
  const rows = (obj) => Object.keys(obj||{}).filter(k=>!['id','owner_id','created_at'].includes(k))
    .map(k=>`<div class="list-row"><span style="opacity:.65;font-size:12px;">${esc(k)}</span><span style="font-size:12px;">${esc(String(obj[k]))}</span></div>`).join('');
  showModal(LANG==='ur' ? 'ٹکراؤ — کون سا ورژن رکھیں؟' : 'Sync Conflict — Which version should win?', `
    <div style="font-size:12px;opacity:.75;margin-bottom:10px;">${esc(LANG==='ur'
      ? 'یہ ریکارڈ کسی اور ڈیوائس نے آپ کے آفلائن ہونے کے دوران بدل دیا ہے۔'
      : 'This record was changed on another device while this one was offline.')}</div>
    <div style="font-weight:700;margin-top:8px;">${esc(LANG==='ur'?'آپ کا (آفلائن) ورژن':'Your (offline) version')}</div>
    ${rows(c.payload)}
    <div style="font-weight:700;margin-top:12px;">${esc(LANG==='ur'?'سرور کا ورژن':'Server version')}</div>
    ${rows(c.serverRow)}
    <div style="display:flex;gap:10px;margin-top:16px;">
      <button class="btn-primary" style="flex:1;" onclick="resolveConflict('mine')">${esc(LANG==='ur'?'میرا رکھیں':'Keep Mine')}</button>
      <button class="btn-ghost" style="flex:1;" onclick="resolveConflict('server')">${esc(LANG==='ur'?'سرور کا رکھیں':'Keep Server')}</button>
    </div>
  `);
}
async function resolveConflict(choice) {
  const c = PENDING_CONFLICTS[0];
  if (!c) return;
  if (choice === 'mine') {
    let r;
    try { r = await execQueueItem(c); } catch (e) { r = { error: e }; }
    if (r.error && !(c.action === 'insert' && isDupKey(r.error))) {
      // Not applied — keep it in the queue instead of throwing the user's version away.
      alert(LANG === 'ur' ? 'ابھی محفوظ نہیں ہو سکا۔ تبدیلی قطار میں موجود ہے، بعد میں دوبارہ کوشش ہوگی۔' : 'Could not apply your version right now. It stays queued and will be retried.');
      PENDING_CONFLICTS.shift();
      closeModal();
      scheduleSyncRetry();
      if (PENDING_CONFLICTS.length) renderSyncConflictModal();
      return;
    }
  }
  PENDING_CONFLICTS.shift();
  await idbQueueRemove(c.qid);
  closeModal();
  if (PENDING_CONFLICTS.length) renderSyncConflictModal();
  else { await loadAllData(); if (TAB) safeRenderTab(); }
}

// Changes the server refused several times in a row. Shown instead of being lost.
async function openFailedSync() {
  const items = (await idbGetAll('sync_queue')).filter(x => x.failed);
  if (!items.length) { closeModal(); return; }
  const rows = items.map(x => `<div class="list-row" style="display:block;"><div style="font-weight:600;font-size:13px;">${esc(x.table)} · ${esc(x.action)}</div><div style="font-size:11px;opacity:.7;word-break:break-word;">${esc(x.lastError || '')}</div></div>`).join('');
  showModal(LANG === 'ur' ? 'جو تبدیلیاں sync نہیں ہو سکیں' : 'Changes that could not sync', `
    <div style="font-size:12px;opacity:.75;margin-bottom:10px;">${esc(LANG === 'ur' ? 'سرور نے یہ تبدیلیاں قبول نہیں کیں۔ دوبارہ کوشش کریں، فائل میں محفوظ کریں، یا ختم کریں۔' : 'The server refused these changes. Retry them, save them to a file, or discard them.')}</div>
    ${rows}
    <div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap;">
      <button class="btn-primary" style="flex:1;" onclick="retryFailedSync()">${esc(LANG === 'ur' ? 'دوبارہ کوشش' : 'Retry')}</button>
      <button class="btn-ghost" style="flex:1;" onclick="exportFailedSync()">${esc(LANG === 'ur' ? 'فائل' : 'Save file')}</button>
      <button class="btn-ghost" style="flex:1;" onclick="discardFailedSync()">${esc(LANG === 'ur' ? 'ختم' : 'Discard')}</button>
    </div>`);
}
async function retryFailedSync() {
  const items = (await idbGetAll('sync_queue')).filter(x => x.failed);
  for (const x of items) { x.failed = false; x.attempts = 0; await idbQueueUpdate(x); }
  closeModal(); _syncRetryMs = 0; flushSyncQueue();
}
async function exportFailedSync() {
  const items = (await idbGetAll('sync_queue')).filter(x => x.failed);
  const blob = new Blob([JSON.stringify(items, null, 2)], { type: 'application/json' });
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
  a.download = 'failed-sync-' + new Date().toISOString().slice(0, 10) + '.json';
  document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
}
async function discardFailedSync() {
  if (!confirm(LANG === 'ur' ? 'یہ تبدیلیاں مستقل ختم ہو جائیں گی۔ جاری رکھیں؟' : 'These changes will be permanently discarded. Continue?')) return;
  const items = (await idbGetAll('sync_queue')).filter(x => x.failed);
  for (const x of items) await idbQueueRemove(x.qid);
  closeModal(); renderOfflineBanner(); await loadAllData(); if (TAB) safeRenderTab();
}

async function renderOfflineBanner() {
  const el = document.getElementById('offline-banner');
  if (!el) return;
  // The "Offline — changes are saved..." message is intentionally removed
  // per request. The "Syncing..." message is kept, and a warning now shows if the
  // server refused some changes (previously those were silently deleted).
  const q = await idbGetAll('sync_queue');
  const failed = q.filter(x => x.failed).length;
  const pending = q.length - failed;
  if (failed) {
    el.style.display = 'block'; el.style.cursor = 'pointer';
    el.onclick = openFailedSync;
    el.textContent = LANG === 'ur' ? `⚠ ${failed} تبدیلیاں sync نہیں ہو سکیں — دیکھنے کے لیے ٹیپ کریں` : `⚠ ${failed} change(s) could not sync — tap to review`;
  } else if (navigator.onLine && pending) {
    el.style.display = 'block'; el.style.cursor = ''; el.onclick = null;
    el.textContent = LANG === 'ur' ? `⏳ Sync ہو رہا ہے (${pending})...` : `⏳ Syncing (${pending})...`;
  } else {
    el.style.display = 'none'; el.onclick = null;
  }
}
// Self-heal: the moment signal comes back, always pull fresh data from the
// server and silently redraw — this is what fixes an already-affected
// client (one whose local cache was empty/stale from before this fix
// existed) without them having to do anything or ask "what happened".
// flushSyncQueue() already does a loadAllData()+redraw at the end of a
// clean run, but it skips entirely if SYNCING is already true or the queue
// handling short-circuits — this direct call is the guaranteed fallback so
// a refresh always happens on reconnect, queue or no queue, conflict or no
// conflict.
async function reconcileOnReconnect() {
  if (!navigator.onLine) return;
  ensurePersistentStorage(); // heuristics for granting this can change over a session — worth re-asking
  await flushSyncQueue();
  if (!SYNCING && CACHE_UNAVAILABLE) { await loadAllData(); }
  renderOfflineBanner();
  if (TAB) safeRenderTab();
}
window.addEventListener('online', () => { renderOfflineBanner(); reconcileOnReconnect(); });
window.addEventListener('offline', () => renderOfflineBanner());
// Mobile browsers can leave a backgrounded tab "frozen" without ever firing
// online/offline while connectivity actually changes underneath it — the
// tab can come back to the foreground still showing an old offline/zero
// state even though the device has signal again. Re-checking on every
// return to the foreground closes that gap. Throttled so rapid tab
// switching doesn't spam the server.
let _lastForegroundCheck = 0;
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState !== 'visible') return;
  const now = Date.now();
  if (now - _lastForegroundCheck < 15000) return;
  _lastForegroundCheck = now;
  reconcileOnReconnect();
});

