/* SchoolMS — teachers.js — split from index.html (lines 6210-6659). Load order matters: see index.html */
// ---------------- Teachers ----------------
let teacherSearch = '';
let teacherPage = 1;
const TEACHERS_PAGE_SIZE = 30;
function setTeacherSearch(v) { teacherSearch = v; teacherPage = 1; updateTeachersResults(); }
function setTeacherPage(p) { teacherPage = p; updateTeachersResults(); }

// Like tplStudents/tplStudentsResults: the search box and action buttons live
// in the shell (tplTeachers) and are rendered exactly once when the tab
// opens. Typing only rewrites #teachers-results, so the input's own DOM node
// is never destroyed mid-keystroke and the mobile keyboard stays open.
function updateTeachersResults() {
  const el = document.getElementById('teachers-results');
  if (el) el.innerHTML = tplTeachersResults();
}

function tplTeachers() {
  return `
    <div style="padding-top:16px;">
      <div class="searchbar">
        <input id="teacher-search-input" placeholder="${esc(t.searchTeachers)}" value="${esc(teacherSearch)}" oninput="setTeacherSearch(this.value)">
        <button class="icon-btn" title="${esc(t.markAttendance)}" onclick="openMarkAttendance()">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#E4C765" stroke-width="2.5"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>
        </button>
        <button class="icon-btn" title="${esc(t.teacherRegister)}" onclick="openTeacherRegister()">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#E4C765" stroke-width="2.5"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/><path d="M9 7h7M9 11h7"/></svg>
        </button>
        <button class="icon-btn" title="${esc(t.classLoginsBtn)}" onclick="openClassLogins()">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#E4C765" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.778 7.778 5.5 5.5 0 017.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3"/></svg>
        </button>
        <button class="icon-btn" onclick="openAddTeacher()">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#E4C765" stroke-width="2.5"><path d="M12 5v14M5 12h14"/></svg>
        </button>
      </div>
      <div id="teachers-results">${tplTeachersResults()}</div>
    </div>`;
}

function tplTeachersResults() {
  const full = DATA.teachers.filter(tc => (tc.name+(tc.subject||'')).toLowerCase().includes(teacherSearch.toLowerCase()));
  const totalPages = Math.max(1, Math.ceil(full.length / TEACHERS_PAGE_SIZE));
  if (teacherPage > totalPages) teacherPage = totalPages;
  const start = (teacherPage - 1) * TEACHERS_PAGE_SIZE;
  const list = full.slice(start, start + TEACHERS_PAGE_SIZE);
  const cur = monthKey();
  const pager = full.length <= TEACHERS_PAGE_SIZE ? '' : `
    <div class="flexgap" style="align-items:center;margin-top:12px;">
      <button class="btn-ghost" ${teacherPage<=1?'disabled':''} onclick="setTeacherPage(${teacherPage-1})">‹ ${esc(t.previous)}</button>
      <span style="font-size:12px;opacity:.65;white-space:nowrap;">${teacherPage} / ${totalPages}</span>
      <button class="btn-ghost" ${teacherPage>=totalPages?'disabled':''} onclick="setTeacherPage(${teacherPage+1})">${esc(t.next)} ›</button>
    </div>`;
  return `
      ${list.length===0 ? `<div class="empty">${esc(t.noTeachers)}</div>` :
        list.map(tc=>{
          const paid = teacherPayments(tc.id).filter(p=>p.month===cur).reduce((a,b)=>a+Number(b.amount),0);
          const due = Math.max(0, Number(tc.monthly_salary||0)-paid);
          return `
          <button class="card-btn" onclick="openTeacherDetail('${tc.id}')">
            <div><div class="nm">${esc(tc.name)}</div><div class="sub">${esc(tc.subject||'')}</div></div>
            <span class="pill ${due>0?'bad':'good'}">${due>0 ? '₨'+fmt(due)+' '+esc(t.due) : esc(t.paid)}</span>
          </button>`;
        }).join('')}
      ${pager}
    `;
}

function openAddTeacher() {
  showModal(t.addTeacher, `
    <label><span>${esc(t.teacherName)}</span><input id="f-name"></label>
    <label><span>${esc(t.subject)}</span><input id="f-subject"></label>
    <label><span>${esc(t.qualification)}</span><input id="f-qualification"></label>
    <label><span>${esc(t.monthlySalary)}</span><input id="f-salary" type="number"></label>
    <label><span>${esc(t.joinDate)}</span><input id="f-join" type="date" value="${todayISO()}"></label>
    <label><span>${esc(t.contact)}</span><input id="f-contact" type="tel" placeholder="03XXXXXXXXX"></label>
    <div class="flexgap">
      <button class="btn-ghost" onclick="closeModal()">${esc(t.cancel)}</button>
      <button class="btn-primary" style="flex:1" onclick="guardedSubmit(this, submitAddTeacher)">${esc(t.save)}</button>
    </div>
  `);
}

async function submitAddTeacher() {
  const name = document.getElementById('f-name').value.trim();
  const qualification = document.getElementById('f-qualification').value.trim();
  const salary = document.getElementById('f-salary').value;
  if (!name || !qualification || salary==='') return;
  const payload = {
    id: crypto.randomUUID ? crypto.randomUUID() : `local-${Date.now()}`,
    owner_id: CURRENT_USER.id,
    name, subject: document.getElementById('f-subject').value,
    qualification,
    monthly_salary: Number(salary), join_date: dateVal('f-join'),
    contact: document.getElementById('f-contact').value
  };
  // Offline-aware: a brand-new teacher, so there's nothing on the server yet
  // to conflict with — safe to just insert once the connection is back.
  const { queued, error } = await offlineWrite({
    table: 'teachers', action: 'insert', payload, id: payload.id, baseRow: null,
    run: () => sb.from('teachers').insert(payload),
    optimisticApply: () => { DATA.teachers.push(payload); idbPutRow('teachers', payload); }
  });
  if (!queued && reportSaveError(error)) return;
  closeModal(); if (!queued) await loadAllData(); renderTab();
}

let attendanceDraft = {}; // { teacherId: { am:'present'|'absent'|'leave'|undefined, pm: same } } — working state for the currently open Mark Attendance modal

// Combines the morning + afternoon marks for one day into the single overall
// 'status' the rest of the app (salary calc, old reports) already understands.
// - either session on leave -> the whole day counts as leave (never deducts)
// - both sessions present -> present
// - both sessions known but not both present -> absent (a single missed mark
//   fails the day, per school policy)
// - only one session marked so far (the other still empty) -> null, i.e. not
//   final yet; salary calc ignores days with no status, same as before.
function deriveDayStatus(am, pm) {
  if (am === 'leave' || pm === 'leave') return 'leave';
  if (am === 'sick' || pm === 'sick') return 'sick';
  if (am && pm) return (am === 'present' && pm === 'present') ? 'present' : 'absent';
  return null;
}

function openMarkAttendance() {
  // Attendance is always for today — the date is fixed from the device's/
  // server's current day and cannot be changed by hand, so nobody can go
  // back (or forward) and mark a different day's attendance here. (Past
  // dates can still be corrected from the Register screen.)
  const date = todayISO();
  // Pre-fill the draft from whatever is already saved for today.
  attendanceDraft = {};
  DATA.teacherAttendance.filter(a => a.date === date).forEach(a => {
    attendanceDraft[a.teacher_id] = { am: a.status_am || undefined, pm: a.status_pm || undefined };
  });
  showModal(t.markAttendance, `
    <label><span>${esc(t.attendanceDate)}</span><input id="att-date" type="date" value="${date}" disabled></label>
    <div id="attendance-roster">${renderAttendanceRoster()}</div>
    <div class="flexgap" style="margin-top:12px;">
      <button class="btn-ghost" onclick="closeModal()">${esc(t.cancel)}</button>
      <button class="btn-primary" style="flex:1" onclick="guardedSubmit(this, ()=>submitAttendance('${date}'))">${esc(t.saveAttendance)}</button>
    </div>
  `);
}

function renderAttendanceRoster() {
  if (!DATA.teachers.length) return `<div class="empty">${esc(t.noTeachers)}</div>`;
  const opt = (id, session, val, label, color) => {
    const cur = (attendanceDraft[id] || {})[session];
    return `<button type="button" onclick="setAttendanceMark('${id}','${session}','${val}')" style="flex:1;padding:6px 3px;border-radius:8px;font-size:10.5px;font-weight:600;border:1.5px solid ${cur===val?color:'var(--line)'};background:${cur===val?color:'#fff'};color:${cur===val?'#fff':'var(--ink)'};">${esc(label)}</button>`;
  };
  return DATA.teachers.map(tc => `
    <div style="border-bottom:1px solid var(--line);padding:8px 0;">
      <div style="font-size:13px;font-weight:600;margin-bottom:6px;">${esc(tc.name)}</div>
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:5px;">
        <div style="width:56px;font-size:10.5px;opacity:.65;">${esc(t.morning)}</div>
        <div style="display:flex;gap:5px;flex:1;">
          ${opt(tc.id,'am','present',t.present,'var(--sage)')}
          ${opt(tc.id,'am','leave',t.leave,'var(--gold)')}
          ${opt(tc.id,'am','absent',t.absent,'var(--rust)')}
          ${opt(tc.id,'am','sick',t.sick,'#3B6FA0')}
        </div>
      </div>
      <div style="display:flex;align-items:center;gap:6px;">
        <div style="width:56px;font-size:10.5px;opacity:.65;">${esc(t.afternoon)}</div>
        <div style="display:flex;gap:5px;flex:1;">
          ${opt(tc.id,'pm','present',t.present,'var(--sage)')}
          ${opt(tc.id,'pm','leave',t.leave,'var(--gold)')}
          ${opt(tc.id,'pm','absent',t.absent,'var(--rust)')}
          ${opt(tc.id,'pm','sick',t.sick,'#3B6FA0')}
        </div>
      </div>
    </div>`).join('');
}

function setAttendanceMark(teacherId, session, status) {
  if (!attendanceDraft[teacherId]) attendanceDraft[teacherId] = {};
  const rec = attendanceDraft[teacherId];
  rec[session] = rec[session] === status ? undefined : status;
  const el = document.getElementById('attendance-roster');
  if (el) el.innerHTML = renderAttendanceRoster();
}

async function submitAttendance(date) {
  const rows = Object.keys(attendanceDraft)
    .filter(id => attendanceDraft[id].am || attendanceDraft[id].pm)
    .map(id => {
      const rec = attendanceDraft[id];
      // Looked up from the local cache (works offline too) — doubles as the
      // "before" snapshot for conflict checks when the queue is later replayed.
      const existingRow = DATA.teacherAttendance.find(x => x.teacher_id === id && x.date === date) || null;
      return {
        existingRow,
        payload: {
          id: existingRow ? existingRow.id : (crypto.randomUUID ? crypto.randomUUID() : `local-${Date.now()}-${id}`),
          owner_id: CURRENT_USER.id, teacher_id: id, date,
          status_am: rec.am || null, status_pm: rec.pm || null,
          status: deriveDayStatus(rec.am, rec.pm)
        }
      };
    });
  if (!rows.length) { closeModal(); return; }
  // Offline-aware: each teacher's row is upserted individually, keyed on the
  // (teacher_id, date) UNIQUE constraint (same duplicate-prevention approach
  // as fee/salary payments), so it queues and syncs the same way — with a
  // conflict prompt if another device marked this same teacher+date meanwhile.
  let anyError = null, anyQueued = false;
  for (const { existingRow, payload } of rows) {
    const { queued, error } = await offlineWrite({
      table: 'teacher_attendance', action: 'upsert', payload, id: payload.id, onConflict: 'teacher_id,date',
      baseRow: existingRow,
      run: () => sb.from('teacher_attendance').upsert(payload, { onConflict: 'teacher_id,date' }),
      optimisticApply: () => {
        const idx = DATA.teacherAttendance.findIndex(x => x.id === payload.id);
        if (idx >= 0) DATA.teacherAttendance[idx] = { ...DATA.teacherAttendance[idx], ...payload };
        else DATA.teacherAttendance.push(payload);
        idbPutRow('teacher_attendance', payload);
      }
    });
    if (queued) anyQueued = true;
    if (!queued && error) anyError = error;
  }
  if (anyError && reportSaveError(anyError)) return;
  closeModal(); if (!anyQueued) await loadAllData(); renderTab();
}

// Attendance-based salary: full monthly salary minus a per-day deduction.
// 'leave' never deducts, and days with no attendance record at all
// (weekends/holidays) are ignored.
// For 'absent' days, the first 2 in a month are forgiven (no deduction).
// From the 3rd absent day onward, deducted days = absent - 2, e.g.:
//   1 or 2 absent -> 0 days deducted
//   3 absent -> 1 day deducted
//   4 absent -> 2 days deducted
//   5 absent -> 3 days deducted, and so on.
function teacherAttendanceForMonth(teacherId, month) {
  return DATA.teacherAttendance.filter(a => a.teacher_id === teacherId && (a.date || '').slice(0,7) === month);
}
function calcAttendanceSalary(teacherId, month) {
  const tc = DATA.teachers.find(x => x.id === teacherId);
  const recs = teacherAttendanceForMonth(teacherId, month);
  const present = recs.filter(r => r.status === 'present').length;
  const leave = recs.filter(r => r.status === 'leave').length;
  const absent = recs.filter(r => r.status === 'absent').length;
  const [y, m] = month.split('-').map(Number);
  const daysInMonth = new Date(y, m, 0).getDate();
  const dailyRate = Number(tc && tc.monthly_salary || 0) / daysInMonth;
  const deductedDays = Math.max(0, absent - 2);
  const amount = Math.max(0, Math.round(Number(tc && tc.monthly_salary || 0) - dailyRate * deductedDays));
  return { present, leave, absent, deductedDays, hasRecords: recs.length > 0, amount };
}
function updateAttendanceSalaryInfo(teacherId) {
  const monthInput = document.getElementById('p-month');
  const infoEl = document.getElementById('attendance-info');
  const amountEl = document.getElementById('p-amount');
  if (!monthInput || !infoEl || !amountEl) return;
  const tc = DATA.teachers.find(x => x.id === teacherId);
  const r = calcAttendanceSalary(teacherId, monthInput.value);
  infoEl.innerHTML = r.hasRecords
    ? `${esc(t.present)}: ${r.present} · ${esc(t.leave)}: ${r.leave} · ${esc(t.absent)}: ${r.absent}${r.deductedDays > 0 ? ` (-${r.deductedDays}d)` : ''} — ${esc(t.suggestedSalary)}: ₨${fmt(r.amount)}`
    : esc(t.noAttendanceMarked);
  amountEl.value = r.hasRecords ? r.amount : (tc && tc.monthly_salary || '');
}

// ---------------- Teacher Attendance Register (month grid, Morning + Afternoon per date) ----------------
let registerMonth = monthKey();
let registerTeacherFilter = 'all';

function openTeacherRegister() {
  TAB = 'teacherRegister';
  renderTab();
}

function datesInMonth(monthStr) {
  const [y, m] = monthStr.split('-').map(Number);
  const days = new Date(y, m, 0).getDate();
  const out = [];
  for (let d = 1; d <= days; d++) out.push(`${monthStr}-${String(d).padStart(2,'0')}`);
  return out;
}

// What a single Morning/Afternoon cell should show for a given teacher+date,
// falling back to a computed default when nothing has been entered yet:
// - a real record always wins
// - a past due-time with no record reads as Absent (a missed mark)
// - a not-yet-due slot (later today, or a future date) shows as pending ('—')
function registerCellInfo(teacherId, date, session) {
  const rec = DATA.teacherAttendance.find(a => a.teacher_id === teacherId && a.date === date);
  const explicit = rec ? (session === 'am' ? rec.status_am : rec.status_pm) : null;
  if (explicit) return { code: explicit[0].toUpperCase(), status: explicit, pending: false };
  const today = todayISO();
  let due;
  if (date < today) due = true;
  else if (date > today) due = false;
  else {
    const hour = new Date().getHours();
    due = session === 'am' ? hour >= 12 : hour >= 14;
  }
  return due ? { code: 'A', status: 'absent', pending: false } : { code: '—', status: null, pending: true };
}

function registerCellColor(status) {
  if (status === 'present') return 'var(--sage)';
  if (status === 'leave') return 'var(--gold)';
  if (status === 'absent') return 'var(--rust)';
  if (status === 'sick') return '#3B6FA0';
  return 'var(--ink)';
}

// Sunday is always a holiday and can't be un-marked; any other date can be
// toggled on/off as a holiday by the admin (e.g. Eid, a school event day).
// Holiday rows skip attendance entirely — no P/L/A is expected that day.
function isSunday(date) { return new Date(date + 'T00:00:00').getDay() === 0; }
function isHoliday(date) { return isSunday(date) || DATA.holidays.some(h => h.date === date); }

async function toggleHoliday(date) {
  if (isSunday(date)) return; // Sunday is a fixed holiday, nothing to toggle
  const existing = DATA.holidays.find(h => h.date === date);
  let queued, error;
  if (existing) {
    ({ queued, error } = await offlineWrite({
      table: 'holidays', action: 'delete', payload: null, id: existing.id, baseRow: existing,
      run: () => sb.from('holidays').delete().eq('id', existing.id),
      optimisticApply: () => { DATA.holidays = DATA.holidays.filter(h => h.id !== existing.id); idbDeleteRow('holidays', existing.id); }
    }));
  } else {
    const payload = { id: crypto.randomUUID ? crypto.randomUUID() : `local-${Date.now()}`, owner_id: CURRENT_USER.id, date };
    ({ queued, error } = await offlineWrite({
      table: 'holidays', action: 'insert', payload, id: payload.id, baseRow: null,
      run: () => sb.from('holidays').insert(payload),
      optimisticApply: () => { DATA.holidays.push(payload); idbPutRow('holidays', payload); }
    }));
  }
  if (!queued && reportSaveError(error)) return;
  if (!queued) await loadAllData();
  if (TAB === 'teacherRegister') renderTab();
}

function tplTeacherRegister() {
  const teachersToShow = registerTeacherFilter === 'all' ? DATA.teachers : DATA.teachers.filter(x => x.id === registerTeacherFilter);
  const dates = datesInMonth(registerMonth);
  const colCount = 1 + teachersToShow.length * 2;
  const head1 = teachersToShow.map(tc => `<th colspan="2">${esc(tc.name)}</th>`).join('');
  const head2 = teachersToShow.map(() => `<th>${esc(t.time1)}</th><th>${esc(t.time2)}</th>`).join('');
  const rows = dates.map(date => {
    const d = new Date(date + 'T00:00:00');
    const dayNum = d.getDate();
    const wk = d.toLocaleDateString(LANG==='ur'?'ur-PK':'en-PK', { weekday:'short' });
    const sunday = isSunday(date);
    const holiday = isHoliday(date);
    const dateCell = `<td class="date-col" style="${sunday?'':'cursor:pointer;'}" ${sunday?'':`onclick="toggleHoliday('${date}')"`}>${dayNum} <span style="font-weight:400;opacity:.6;font-size:9.5px;">${esc(wk)}</span></td>`;
    if (holiday) {
      return `<tr class="hol-row">${dateCell}<td colspan="${colCount-1}" style="font-style:italic;opacity:.65;font-weight:600;">${esc(t.holiday)}${sunday?'':` · ${esc(t.tapToUnmark)}`}</td></tr>`;
    }
    const cells = teachersToShow.map(tc => {
      const am = registerCellInfo(tc.id, date, 'am');
      const pm = registerCellInfo(tc.id, date, 'pm');
      const cell = (info, session) => `<td style="cursor:pointer;color:${registerCellColor(info.status)};" onclick="registerCycleMark('${tc.id}','${date}','${session}')">${esc(info.code)}</td>`;
      return cell(am,'am') + cell(pm,'pm');
    }).join('');
    return `<tr>${dateCell}${cells}</tr>`;
  }).join('');
  return `
    <div style="padding-top:16px;">
      <div class="flexgap" style="margin-top:0;">
        <button class="btn-ghost" style="flex:none;padding:9px 14px;" onclick="setTab('teachers')">‹ ${esc(t.back)}</button>
        <div style="flex:1;font-family:Fraunces,serif;font-size:16px;color:var(--navy);align-self:center;">${esc(t.teacherRegisterTitle)}</div>
      </div>
      <div class="row2" style="margin-top:14px;">
        <label><span>${esc(t.registerMonth)}</span><input type="month" value="${registerMonth}" onchange="registerMonth=this.value; renderTab();"></label>
        <label><span>${esc(t.registerSelectTeacher)}</span>
          <select onchange="registerTeacherFilter=this.value; renderTab();">
            <option value="all" ${registerTeacherFilter==='all'?'selected':''}>${esc(t.registerAllTeachers)}</option>
            ${DATA.teachers.map(tc => `<option value="${tc.id}" ${registerTeacherFilter===tc.id?'selected':''}>${esc(tc.name)}</option>`).join('')}
          </select>
        </label>
      </div>
      ${DATA.teachers.length===0 ? `<div class="empty">${esc(t.noTeachers)}</div>` : `
      <div class="card-table-wrap reg-drag-wrap" style="margin-top:6px;">
        <table class="reg-physical">
          <thead>
            <tr><th rowspan="2" style="text-align:left;">${esc(t.dateCol)}</th>${head1}</tr>
            <tr class="sub-head">${head2}</tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
      <p style="font-size:10.5px;opacity:.55;margin-top:8px;">${esc(t.registerLegend)}<br>${esc(t.registerTapHint)}<br>${esc(t.holidayHint)}</p>`}
    </div>`;
}

// Tapping a cell cycles Present -> Leave -> Absent -> (cleared, back to computed
// default) and saves immediately, so corrections don't need the Mark Attendance modal.
async function registerCycleMark(teacherId, date, session) {
  const rec = DATA.teacherAttendance.find(a => a.teacher_id === teacherId && a.date === date) || {};
  const cur = session === 'am' ? rec.status_am : rec.status_pm;
  const order = ['present','leave','absent','sick', null];
  const next = order[(order.indexOf(cur || null) + 1) % order.length];
  const otherSession = session === 'am' ? (rec.status_pm || null) : (rec.status_am || null);
  const payload = {
    owner_id: CURRENT_USER.id, teacher_id: teacherId, date,
    status_am: session === 'am' ? next : (rec.status_am || null),
    status_pm: session === 'pm' ? next : (rec.status_pm || null),
  };
  payload.status = deriveDayStatus(payload.status_am, payload.status_pm);
  const { error } = await sb.from('teacher_attendance').upsert(payload, { onConflict: 'teacher_id,date' });
  if (reportSaveError(error)) return;
  await loadAllData();
  if (TAB === 'teacherRegister') renderTab();
}

// ---------------- Class Logins (owner side: create/manage, view attendance & marks) ----------------
// One login per class. No real Supabase Auth session is ever issued for
// these — a teacher on the shared class device visits ?class=1 and enters
// School Code + this Login ID + Password, which the class_login_verify RPC
// checks fresh server-side on every visit (see class_attendance_marks_migration.sql).
function openClassLogins() {
  TAB = 'classLogins';
  renderTab();
}

function tplClassLogins() {
  const rows = DATA.classLogins.slice().sort((a,b) => (a.class_name||'').localeCompare(b.class_name||''));
  return `
    <div style="padding-top:16px;">
      <div class="flexgap" style="margin-top:0;">
        <button class="btn-ghost" style="flex:none;padding:9px 14px;" onclick="setTab('teachers')">‹ ${esc(t.back)}</button>
        <div style="flex:1;font-family:Fraunces,serif;font-size:16px;color:var(--navy);align-self:center;">${esc(t.classLoginsTitle)}</div>
        <button class="icon-btn" onclick="openAddClassLogin()">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#E4C765" stroke-width="2.5"><path d="M12 5v14M5 12h14"/></svg>
        </button>
      </div>
      <p style="font-size:11px;opacity:.6;margin:10px 0 14px;">${esc(t.classLoginsDesc)}</p>
      ${!CURRENT_PROFILE.school_code ? `<div class="notice" style="margin-top:0;">${esc(t.parentSchoolCodeMissing)}</div>` : ''}
      ${rows.length===0 ? `<div class="empty">${esc(t.noClassLogins)}</div>` :
        rows.map(cl => `
          <div class="card-btn" style="cursor:default;flex-direction:column;align-items:stretch;">
            <div style="display:flex;justify-content:space-between;align-items:center;">
              <div><div class="nm">${esc(cl.class_name)}</div><div class="sub">${cl.teacher_name ? esc(cl.teacher_name) + ' · ' : ''}${esc(t.loginId)}: ${esc(cl.login_id)}</div></div>
              <div style="display:flex;gap:6px;">
                <button title="${esc(t.editClassLogin)}" style="background:none;border:none;font-size:15px;padding:4px;" onclick="openAddClassLogin('${cl.id}')">✎</button>
                <button title="${esc(t.delete)}" style="background:none;border:none;color:var(--rust);font-size:15px;padding:4px;" onclick="confirmDelete('classLogin','${cl.id}')">🗑️</button>
              </div>
            </div>
            <div class="flexgap" style="margin-top:10px;">
              <button class="btn-ghost" style="flex:1;font-size:12px;padding:8px;" onclick="openClassAttendanceView('${escJs(cl.class_name)}')">${esc(t.viewAttendance)}</button>
              <button class="btn-ghost" style="flex:1;font-size:12px;padding:8px;" onclick="openClassMarksView('${escJs(cl.class_name)}')">${esc(t.viewMarks)}</button>
            </div>
          </div>`).join('')}
    </div>`;
}

