/* SchoolMS — datesheet.js — split from index.html (lines 8141-8451). Load order matters: see index.html */
// =========================================================================
// Exam Date Sheet (one sheet for the whole school: classes = rows, exam
// dates = columns, like the Timetable) + Roll Number Slips
// =========================================================================
// The date sheet lives only on this phone/browser (localStorage), the same
// way the Timetable does — nothing new is needed in Supabase.
// Roll number printed on a slip = the student's Admission Register Serial No
// (linked by the register's "Link student" field, else matched by name +
// father's name).
let dsData = null;        // { examName, instructions, cols:[{id,date,start,end}], cells:{ [className]: { [colId]: subject } } }
let dsSlipClass = 'all';  // 'all' or one class — which students get slips

function dsKey() { return 'ds_local_v2_' + (CURRENT_USER ? CURRENT_USER.id : 'guest'); }
function dsLoad() {
  let d = null;
  try { d = JSON.parse(localStorage.getItem(dsKey())); } catch (e) { d = null; }
  if (!d || typeof d !== 'object') d = {};
  dsData = {
    examName: d.examName || '',
    instructions: d.instructions || '',
    cols: Array.isArray(d.cols) ? d.cols : [],
    cells: (d.cells && typeof d.cells === 'object') ? d.cells : {}
  };
}
function dsSave() {
  try { localStorage.setItem(dsKey(), JSON.stringify(dsData)); }
  catch (e) { alert(qt('Could not save: ', 'محفوظ نہیں ہوا: ') + e.message); }
}
function dsNewId() { return 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }

function dsDayName(iso) {
  if (!iso) return '';
  const d = new Date(iso + 'T00:00:00');
  if (isNaN(d)) return '';
  return d.toLocaleDateString(LANG === 'ur' ? 'ur-PK' : 'en-GB', { weekday: 'long' });
}
function dsTime12(v) {
  const m = /^(\d{1,2}):(\d{2})/.exec(v || '');
  if (!m) return '';
  let h = Number(m[1]);
  const ap = h >= 12 ? 'PM' : 'AM';
  h = h % 12 || 12;
  return h + ':' + m[2] + ' ' + ap;
}
function dsTimeRange(r) {
  const a = dsTime12(r.start), b = dsTime12(r.end);
  return a && b ? a + ' – ' + b : (a || b || '');
}
function dsSchoolName() {
  return (dmcSchoolName && dmcSchoolName !== 'SCHOOL NAME') ? dmcSchoolName : ((CURRENT_PROFILE && CURRENT_PROFILE.school_name) || 'School');
}
// Exam dates in date order (the editor keeps entry order so columns don't jump while editing).
function dsSortedCols() {
  return ((dsData && dsData.cols) || []).slice().sort((a, b) => (a.date || '9999').localeCompare(b.date || '9999'));
}
// The subjects one class sits, in date order — used for that class's roll number slips.
function dsSortedRows(cls) {
  const cells = (dsData && dsData.cells[cls]) || {};
  return dsSortedCols()
    .filter(c => (cells[c.id] || '').trim())
    .map(c => ({ date: c.date, subject: cells[c.id].trim(), start: c.start, end: c.end }));
}
// Classes shown as rows: every class that has active students, plus any class that already has data.
function dsClassList() {
  const withStudents = DATA.students.filter(s => s.status !== 'inactive').map(s => s.class_name).filter(Boolean);
  const withData = Object.keys(dsData.cells).filter(c => Object.values(dsData.cells[c] || {}).some(v => (v || '').trim()));
  const all = [...new Set([...withStudents, ...withData])];
  if (!all.length) return CLASS_OPTIONS.slice();
  const order = c => { const i = CLASS_OPTIONS.indexOf(c); return i < 0 ? 999 : i; };
  return all.sort((a, b) => order(a) - order(b) || String(a).localeCompare(String(b)));
}

// ---------- editor actions ----------
function dsSetMeta(field, value) { dsData[field] = value; dsSave(); }
function dsSetCol(id, field, value) {
  const c = dsData.cols.find(x => x.id === id);
  if (!c) return;
  c[field] = value;
  dsSave();
  if (field === 'date') {
    const el = document.getElementById('ds-day-' + id);
    if (el) el.textContent = dsDayName(value);
  }
}
function dsSetCell(cls, colId, value) {
  if (!dsData.cells[cls]) dsData.cells[cls] = {};
  dsData.cells[cls][colId] = value;
  dsSave();
}
function dsAddCol() {
  let date = '';
  const last = dsData.cols.map(c => c.date).filter(Boolean).sort().pop();
  if (last) {
    const d = new Date(last + 'T00:00:00');
    d.setDate(d.getDate() + 1);
    if (d.getDay() === 0) d.setDate(d.getDate() + 1); // skip Sunday
    date = localISO(d);
  }
  const prev = dsData.cols[dsData.cols.length - 1];
  dsData.cols.push({ id: dsNewId(), date, start: prev ? prev.start : '', end: prev ? prev.end : '' });
  dsSave();
  renderTab();
  // show the newly added date column (scroll the grid to the far right)
  const _w = document.querySelector('#main .tt-scroll-wrap');
  if (_w) { _w.scrollLeft = _w.scrollWidth; _regBookScrollPositions[_w.className + '_0'] = _w.scrollLeft; }
}
function dsDeleteCol(id) {
  const filled = Object.values(dsData.cells).some(m => m && (m[id] || '').trim());
  if (filled && !confirm(qt('Remove this date and the subjects entered under it?', 'یہ تاریخ اور اس کے نیچے درج مضامین ہٹا دیں؟'))) return;
  dsData.cols = dsData.cols.filter(c => c.id !== id);
  Object.values(dsData.cells).forEach(m => { if (m) delete m[id]; });
  dsSave();
  renderTab();
}
// Re-draws only the slips card (warnings/counts) so typing in the grid is never interrupted.
function dsRefreshSlips() {
  const el = document.getElementById('ds-slips');
  if (el) el.innerHTML = tplDsSlips();
}

// ---------- roll numbers ----------
// One running sequence across the whole school, class by class, following the
// Students (fee) list: Nursery 1–10, KG 11–30, 1st 31–… and so on to the last
// class. Active students only, classes in CLASS_OPTIONS order, A→Z by name
// inside a class. The number is for the slip only — it is not saved on the student.
function dsSlipStudents(scope) {
  const order = c => { const i = CLASS_OPTIONS.indexOf(c); return i < 0 ? 999 : i; };
  return DATA.students
    .filter(s => s.status !== 'inactive')
    .slice()
    .sort((a, b) => order(a.class_name) - order(b.class_name)
      || String(a.class_name || '').localeCompare(String(b.class_name || ''))
      || normName(a.name).localeCompare(normName(b.name)))
    .map((s, i) => ({ s, roll: String(i + 1) }))
    .filter(x => scope === 'all' || x.s.class_name === scope);
}
// 4 slips per A4 page (2 x 2), and every class starts on a fresh page so slips can be handed out class by class.
function dsSlipPages(list) {
  const groups = [];
  list.forEach(x => {
    const last = groups[groups.length - 1];
    if (last && last.cls === x.s.class_name) last.items.push(x);
    else groups.push({ cls: x.s.class_name, items: [x] });
  });
  const pages = [];
  groups.forEach(g => { for (let i = 0; i < g.items.length; i += 4) pages.push({ cls: g.cls, items: g.items.slice(i, i + 4) }); });
  return pages;
}

// ---------- the tab ----------
function tplDsSlips() {
  const classes = dsClassList();
  if (dsSlipClass !== 'all' && !classes.includes(dsSlipClass)) dsSlipClass = 'all';
  const counts = {};
  DATA.students.forEach(s => { if (s.status !== 'inactive') counts[s.class_name] = (counts[s.class_name] || 0) + 1; });
  const totalStudents = Object.values(counts).reduce((a, b) => a + b, 0);
  const slip = dsSlipStudents(dsSlipClass);
  const pages = dsSlipPages(slip).length;
  const noSheet = [...new Set(slip.map(x => x.s.class_name))].filter(c => !dsSortedRows(c).length);
  const range = slip.length ? slip[0].roll + ' – ' + slip[slip.length - 1].roll : '';

  const warnSheet = noSheet.length ? `
    <div class="ds-warn">${esc(qt('No subjects entered in the date sheet for: ', 'ڈیٹ شیٹ میں ان کلاسوں کے مضامین درج نہیں: '))}<b>${noSheet.map(c => esc(c)).join('، ')}</b></div>` : '';

  return `
    <p style="font-size:12px;opacity:.7;margin:0 0 10px;">${esc(qt('Roll numbers run in one sequence through the whole school, class by class (Nursery first), A–Z by name inside each class. Each slip also shows that class\'s subjects from the date sheet above.', 'رول نمبر پورے اسکول میں کلاس وار ایک ہی ترتیب میں چلتے ہیں (نرسری سے شروع)، ہر کلاس میں نام کی ترتیب سے۔ ہر سلپ پر اوپر والی ڈیٹ شیٹ سے اس کلاس کے مضامین بھی چھپیں گے۔'))}</p>
    <label><span>${esc(qt('Print slips for', 'سلپس کس کے لیے'))}</span>
      <select onchange="dsSlipClass=this.value;dsRefreshSlips();">
        <option value="all" ${dsSlipClass === 'all' ? 'selected' : ''}>${esc(qt('All classes', 'تمام کلاسیں'))} (${totalStudents})</option>
        ${classes.filter(c => counts[c]).map(c => `<option value="${esc(c)}" ${dsSlipClass === c ? 'selected' : ''}>${esc(c)} (${counts[c]})</option>`).join('')}
      </select></label>
    <p style="font-size:12px;opacity:.7;margin:0 0 10px;">${esc(qt(`${slip.length} slips · Roll No. ${range} · 4 per A4 page · ${pages} page(s)`, `${slip.length} سلپس · رول نمبر ${range} · ہر A4 صفحے پر 4 · ${pages} صفحات`))}</p>
    ${warnSheet}
    <button class="btn-primary" onclick="dsPrintSlips()" ${slip.length ? '' : 'disabled'}>🎫 ${esc(qt('Print Roll Number Slips', 'رول نمبر سلپس پرنٹ کریں'))}</button>`;
}

function tplDateSheet() {
  if (!dsData) dsLoad();
  const classes = dsClassList();
  const cols = dsData.cols;
  const ur = LANG === 'ur';

  const headCell = c => `
    <th>
      <div style="display:flex;align-items:center;gap:2px;margin-bottom:3px;">
        <input type="date" value="${esc(c.date || '')}" style="flex:1;min-width:0;font-size:11px;padding:2px;" onchange="dsSetCol('${c.id}','date',this.value)">
        <button class="del-x" style="padding:0 4px;" onclick="dsDeleteCol('${c.id}')">✕</button>
      </div>
      <div class="tt-period-label" id="ds-day-${c.id}">${esc(dsDayName(c.date))}</div>
      <div class="tt-period-time">
        <input type="time" value="${esc(c.start || '')}" onchange="dsSetCol('${c.id}','start',this.value)">
        <span>${esc(qt('to', 'تا'))}</span>
        <input type="time" value="${esc(c.end || '')}" onchange="dsSetCol('${c.id}','end',this.value)">
      </div>
    </th>`;
  const bodyRow = cl => `<tr><td class="tt-class-name">${esc(cl)}</td>${cols.map(c => `
      <td class="tt-cell"><input type="text" class="tt-subject" autocomplete="off" placeholder="${esc(qt('Subject', 'مضمون'))}"
        value="${esc(((dsData.cells[cl] || {})[c.id]) || '')}"
        oninput="dsSetCell('${escJs(cl)}','${c.id}',this.value)" onchange="dsRefreshSlips()"></td>`).join('')}</tr>`;

  const gridHtml = cols.length ? `
    <div class="tt-scroll-wrap">
      <table class="tt-grid" style="width:${70 + 150 * cols.length}px;">
        <colgroup><col style="width:70px">${cols.map(() => '<col style="width:150px">').join('')}</colgroup>
        <tr><th>${esc(qt('Class', 'جماعت'))}</th>${cols.map(headCell).join('')}</tr>
        ${classes.map(bodyRow).join('')}
      </table>
    </div>` : `<div class="empty">${esc(qt('No exam dates yet. Tap "Add Date" to start.', 'ابھی کوئی امتحانی تاریخ نہیں۔ شروع کرنے کے لیے "تاریخ شامل کریں" دبائیں۔'))}</div>`;

  return `
    <div style="padding-top:16px;">
      <div class="section-title" style="margin-top:0;display:flex;justify-content:space-between;align-items:center;">
        <span>${esc(qt('Exam Date Sheet', 'امتحانی ڈیٹ شیٹ'))}</span>
        <button onclick="dsPrintDateSheet()" style="border:none;background:var(--navy);color:var(--gold-soft);border-radius:8px;padding:5px 12px;font-size:11px;font-weight:600;">🖨️ ${esc(t.print)}</button>
      </div>
      <div class="list-card" style="padding:14px;margin-bottom:12px;">
        <label><span>${esc(qt('Exam Name', 'امتحان کا نام'))}</span>
          <input type="text" autocomplete="off" value="${esc(dsData.examName)}" placeholder="${esc(qt('e.g. Mid-Term Exam 2026', 'مثال: مڈ ٹرم امتحان 2026'))}" oninput="dsSetMeta('examName',this.value)"></label>
        <label style="margin-bottom:0;"><span>${esc(qt('Instructions (printed under the date sheet)', 'ہدایات (ڈیٹ شیٹ کے نیچے چھپیں گی)'))}</span>
          <textarea rows="2" placeholder="${esc(qt('e.g. Reach 15 minutes early. Bring your own pen.', 'مثال: 15 منٹ پہلے پہنچیں۔ اپنا قلم ساتھ لائیں۔'))}" oninput="dsSetMeta('instructions',this.value)">${esc(dsData.instructions)}</textarea></label>
      </div>
      ${gridHtml}
      <div class="ds-btns"><button class="btn-ghost" onclick="dsAddCol()">+ ${esc(qt('Add Date', 'تاریخ شامل کریں'))}</button></div>

      <div class="section-title">${esc(qt('Roll Number Slips', 'رول نمبر سلپس'))}</div>
      <div class="list-card" style="padding:14px;" id="ds-slips">${tplDsSlips()}</div>
    </div>`;
}

// ---------- printing ----------
// Same landscape-on-portrait A4 layout the Timetable uses (see .tt-print-rotate).
function dsPrintDateSheet() {
  if (!dsData) dsLoad();
  const cols = dsSortedCols().filter(c => c.date);
  if (!cols.length) {
    alert(qt('Add at least one exam date first.', 'پہلے کم از کم ایک امتحانی تاریخ شامل کریں۔'));
    return;
  }
  const ur = LANG === 'ur';
  const school = dsSchoolName();
  const headerRow = `<tr><th>${esc(qt('Class', 'جماعت'))}</th>${cols.map(c => `<th>${esc(fmtDate(c.date))}<span class="tt-print-time">${esc(dsDayName(c.date))}</span>${dsTimeRange(c) ? `<span class="tt-print-time">${esc(dsTimeRange(c))}</span>` : ''}</th>`).join('')}</tr>`;
  const rows = dsClassList().map(cl => `<tr><td class="tt-print-classname">${esc(cl)}</td>${cols.map(c => {
    const v = (((dsData.cells[cl] || {})[c.id]) || '').trim();
    return `<td>${v ? `<span class="tt-print-subject">${esc(v)}</span>` : `<span class="tt-print-empty">—</span>`}</td>`;
  }).join('')}</tr>`).join('');
  document.getElementById('print-area').innerHTML = `
    <div class="tt-print-page"><div class="tt-print-rotate">
    <div class="tt-print" dir="${ur ? 'rtl' : 'ltr'}">
      <div class="tt-print-head">
        ${dmcLogo ? `<img class="tt-print-logo" src="${dmcLogo}">` : ''}
        <div class="eyebrow">${esc(qt('Exam Date Sheet', 'امتحانی ڈیٹ شیٹ'))}</div>
        <h2>${esc(school)}</h2>
        ${dsData.examName ? `<div class="tt-print-sub">${esc(dsData.examName)}</div>` : ''}
      </div>
      <table class="tt-print-table"><thead>${headerRow}</thead><tbody>${rows}</tbody></table>
      ${dsData.instructions ? `<div class="ds-instr"><b>${esc(qt('Instructions', 'ہدایات'))}:</b> ${esc(dsData.instructions).replace(/\n/g, '<br>')}</div>` : ''}
      <div class="tt-print-foot">
        <span class="tt-print-brand">${esc(school)}</span>
        <span>${esc(qt('Principal', 'پرنسپل'))}: ______________</span>
      </div>
    </div>
    </div></div>`;
  printAsA4(0);
}

function dsSlipHtml(x, cls) {
  const s = x.s, ur = LANG === 'ur';
  const rows = dsSortedRows(cls);
  const name = (ur && s.name_ur) ? s.name_ur : s.name;
  const table = rows.length ? `
    <table class="rs-table">
      <thead><tr><th>${esc(qt('Date', 'تاریخ'))}</th><th>${esc(qt('Day', 'دن'))}</th><th>${esc(qt('Subject', 'مضمون'))}</th><th>${esc(qt('Time', 'وقت'))}</th></tr></thead>
      <tbody>${rows.map(r => `<tr><td>${esc(fmtDate(r.date) || '')}</td><td>${esc(dsDayName(r.date))}</td><td>${esc(r.subject || '')}</td><td>${esc(dsTimeRange(r))}</td></tr>`).join('')}</tbody>
    </table>` : `<div class="rs-nosheet">${esc(qt('Date sheet not entered yet', 'ڈیٹ شیٹ ابھی درج نہیں'))}</div>`;
  return `
    <div class="rs-slip${rows.length > 10 ? ' rs-tight' : ''}" dir="${ur ? 'rtl' : 'ltr'}"><div class="rs-card">
      <div class="rs-head">
        ${dmcLogo ? `<img class="rs-logo" src="${dmcLogo}">` : ''}
        <div>
          <div class="rs-school">${esc(dsSchoolName())}</div>
          <div class="rs-title">${esc(qt('Roll Number Slip', 'رول نمبر سلپ'))}${dsData.examName ? ' · ' + esc(dsData.examName) : ''}</div>
        </div>
      </div>
      <div class="rs-body">
        <div class="rs-info">
          <div class="rs-who">
            <div class="rs-full"><span>${esc(qt('Name', 'نام'))}</span><b>${esc(name || '')}</b></div>
            <div><span>${esc(qt('Father', 'والد'))}</span><b>${esc(s.father_name || '--')}</b></div>
            <div><span>${esc(qt('Class', 'جماعت'))}</span><b>${esc(cls || '--')}</b></div>
          </div>
          <div class="rs-roll"><span>${esc(qt('Roll No.', 'رول نمبر'))}</span><b>${esc(x.roll || '--')}</b></div>
        </div>
        ${table}
        <div class="rs-foot"><em>${esc(qt('Bring this slip to the exam hall.', 'یہ پرچی امتحانی ہال میں ساتھ لائیں۔'))}</em><span>${esc(qt('Principal', 'پرنسپل'))}</span></div>
      </div>
    </div></div>`;
}
function dsPrintSlips() {
  const list = dsSlipStudents(dsSlipClass);
  if (!list.length) {
    alert(qt('No students found.', 'کوئی طالب علم نہیں ملا۔'));
    return;
  }
  const noSheet = [...new Set(list.map(x => x.s.class_name))].filter(c => !dsSortedRows(c).length);
  if (noSheet.length && !confirm(qt(`No date sheet entered for: ${noSheet.join(', ')}. Print anyway?`,
                                    `ان کلاسوں کی ڈیٹ شیٹ درج نہیں: ${noSheet.join('، ')}۔ پھر بھی پرنٹ کریں؟`))) return;
  document.getElementById('print-area').innerHTML = dsSlipPages(list)
    .map(p => `<div class="rs-page">${p.items.map(x => dsSlipHtml(x, p.cls)).join('')}</div>`).join('');
  printAsA4(8);
}

