/* SchoolMS — timetable.js — split from index.html (lines 6660-7043). Load order matters: see index.html */
// ---------------- Timetable (master grid: all classes × periods) ----------------
// One single grid for the whole school: rows are classes, columns are periods
// (each with an editable start/end time), each cell holds a Subject + Teacher
// for that class in that period. Same schedule applies every day, so there is
// no day-of-week axis. Deliberately lazy-loaded (not part of loadAllData's
// critical Promise.all) so the rest of the app keeps working even before the
// one-time SQL setup (see CONFIG comment near the top of this file) has been
// run in Supabase.
//
// Schools differ a lot here — some only go up to 5th, some to 8th/10th/12th,
// period counts vary (7 vs 8), and where the break falls varies too (after
// period 4 vs after period 5) — so which classes show as rows, how many
// period columns there are, and the break position are all editable per
// school and saved in timetable_settings, instead of being hardcoded.
const TT_ORDINAL_EN = ['1st','2nd','3rd','4th','5th','6th','7th','8th','9th','10th','11th','12th'];
const TT_ORDINAL_UR = ['پہلا','دوسرا','تیسرا','چوتھا','پانچواں','چھٹا','ساتواں','آٹھواں','نواں','دسواں','گیارہواں','بارہواں'];
function ttPeriodLabel(n) {
  if (LANG === 'ur') return (TT_ORDINAL_UR[n - 1] || (n + 'واں')) + ' پیریڈ';
  return (TT_ORDINAL_EN[n - 1] || (n + 'th')) + ' Period';
}
let ttRows = [];              // all timetable rows for this school: {id, class_name, period, subject, teacher_id}
let ttPeriodTimes = {};       // period number -> {start_time, end_time}
let ttPeriods = 7;            // number of period columns shown (school-editable, saved in timetable_settings)
let ttClasses = null;         // null = use the default class list (CLASS_OPTIONS ∪ any class names already on students);
                               // otherwise an explicit, school-chosen list of classes to show as rows
let ttBreakAfter = 0;         // 0 = no break column; otherwise the period number the break is shown right after
let ttBreakStart = '';
let ttBreakEnd = '';
let ttStatus = 'idle';        // 'idle' | 'loading' | 'ready' | 'missing_table'

function ttDefaultClassOptions() {
  const set = new Set(CLASS_OPTIONS);
  DATA.students.forEach(s => { if (s.class_name) set.add(s.class_name); });
  return Array.from(set);
}
function ttClassOptions() {
  return (ttClasses && ttClasses.length) ? ttClasses : ttDefaultClassOptions();
}

// The columns to render left-to-right: period 1..ttPeriods, with a single
// non-editable "Break" column spliced in right after period `ttBreakAfter`
// (if set). The header, body rows, colgroup and the printed version all walk
// this same list so they never fall out of sync with each other.
function ttColumns() {
  const cols = [];
  for (let p = 1; p <= ttPeriods; p++) {
    cols.push({ type: 'period', period: p });
    if (ttBreakAfter === p) cols.push({ type: 'break' });
  }
  return cols;
}

// Timetable data lives ONLY in this phone/browser (localStorage) — never sent to Supabase.
// Clearing the browser/app data erases it completely.
function ttLocalKey() { return 'tt_local_v1_' + (CURRENT_USER ? CURRENT_USER.id : 'guest'); }
function ttLocalWrite() {
  try {
    localStorage.setItem(ttLocalKey(), JSON.stringify({
      rows: ttRows, times: ttPeriodTimes,
      settings: { classes: ttClasses, periods_count: ttPeriods, break_after: ttBreakAfter, break_start: ttBreakStart, break_end: ttBreakEnd }
    }));
  } catch (e) { alert((LANG === 'ur' ? 'محفوظ نہیں ہوا: ' : 'Could not save: ') + e.message); }
}
async function loadTimetableGrid() {
  let d = {};
  try { d = JSON.parse(localStorage.getItem(ttLocalKey())) || {}; } catch (e) { d = {}; }
  ttRows = Array.isArray(d.rows) ? d.rows : [];
  ttPeriodTimes = d.times || {};
  const st = d.settings || null;
  if (st) {
    ttPeriods = st.periods_count || 7;
    ttClasses = Array.isArray(st.classes) ? st.classes : null;
    ttBreakAfter = st.break_after || 0;
    ttBreakStart = st.break_start || '';
    ttBreakEnd = st.break_end || '';
  } else {
    ttPeriods = Math.max(7, ...ttRows.map(r => r.period), 0);
    ttClasses = null; ttBreakAfter = 0; ttBreakStart = ''; ttBreakEnd = '';
  }
  ttStatus = 'ready';
  await loadDMCConfig(); // pulls the editable school logo/name shown at the top of the timetable
  if (TAB === 'timetable') renderTab();
}

async function saveTimetableSettings() { ttLocalWrite(); }

function ttAddPeriod() { ttPeriods += 1; saveTimetableSettings(); renderTab(); }
function ttRemovePeriod() {
  if (ttPeriods <= 1) return;
  if (ttBreakAfter >= ttPeriods) ttBreakAfter = 0; // don't leave the break dangling past the last period
  ttPeriods -= 1;
  saveTimetableSettings();
  renderTab();
}
function ttSetBreakAfter(value) {
  ttBreakAfter = Math.max(0, Math.min(ttPeriods, parseInt(value, 10) || 0));
  saveTimetableSettings();
  renderTab();
}
function ttSaveBreakTime(field, value) {
  if (field === 'start') ttBreakStart = value; else ttBreakEnd = value;
  saveTimetableSettings();
}

// "Manage Classes" — lets a school hide the class rows it doesn't have
// (a school that only goes up to 5th, say, unticks 6th–12th) without
// touching CLASS_OPTIONS itself, which every other tab in the app still
// relies on for its own class dropdowns.
function openManageTtClasses() {
  const current = ttClassOptions();
  const allOptions = Array.from(new Set([...CLASS_OPTIONS, ...current]));
  showModal(LANG === 'ur' ? 'جماعتیں منتخب کریں' : 'Manage Classes', `
    <p style="font-size:12px;opacity:.65;margin:-4px 0 12px;">${LANG === 'ur'
      ? 'صرف وہ جماعتیں منتخب کریں جو آپ کے اسکول میں موجود ہیں۔'
      : 'Tick only the classes that exist at your school — this only changes what shows on the Timetable.'}</p>
    <div id="tt-class-list" style="display:flex;flex-direction:column;gap:2px;max-height:44vh;overflow-y:auto;margin-bottom:12px;">
      ${allOptions.map(c => `
        <label style="display:flex;align-items:center;gap:8px;margin:0;padding:7px 4px;border-bottom:1px solid var(--line);">
          <input type="checkbox" value="${esc(c)}" ${current.includes(c) ? 'checked' : ''} style="width:auto;">
          <span style="font-size:13px;">${esc(c)}</span>
        </label>`).join('')}
    </div>
    <label><span>${LANG === 'ur' ? 'نئی جماعت شامل کریں (اختیاری)' : 'Add a custom class (optional)'}</span>
      <input id="tt-custom-class" placeholder="${LANG === 'ur' ? 'مثلاً منٹیسوری' : 'e.g. Montessori'}">
    </label>
    <div class="flexgap">
      <button class="btn-ghost" onclick="closeModal()">${esc(t.cancel)}</button>
      <button class="btn-primary" style="flex:1" onclick="submitManageTtClasses()">${esc(t.save)}</button>
    </div>
  `);
}

function submitManageTtClasses() {
  const checked = Array.from(document.querySelectorAll('#tt-class-list input[type="checkbox"]:checked')).map(el => el.value);
  const custom = (document.getElementById('tt-custom-class').value || '').trim();
  if (custom && !checked.includes(custom)) checked.push(custom);
  ttClasses = checked; // an empty selection just falls back to the default list via ttClassOptions()
  saveTimetableSettings();
  closeModal();
  renderTab();
}

async function saveTimetableCell(className, period, field, value) {
  const idx = ttRows.findIndex(r => r.class_name === className && r.period === period);
  const existing = idx >= 0 ? ttRows[idx] : null;
  const row = {
    id: existing ? existing.id : 'local_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
    class_name: className, day_of_week: 'ALL', period,
    subject: field === 'subject' ? (value || null) : (existing ? existing.subject : null),
    teacher_id: field === 'teacher_id' ? (value || null) : (existing ? existing.teacher_id : null),
  };
  if (idx >= 0) ttRows[idx] = row; else ttRows.push(row);
  ttLocalWrite();
}

async function savePeriodTime(period, field, value) {
  ttPeriodTimes[period] = { ...(ttPeriodTimes[period] || {}), [field]: value };
  ttLocalWrite();
}

// Lightweight logo upload for the Timetable header — reuses the same school
// logo/name shown on certificates (dmcLogo/dmcSchoolName, saved via
// saveDMCConfig), so it's one editable identity across the whole app rather
// than a separate copy just for this screen.
function handleTimetableLogoUpload(file) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    dmcLogo = e.target.result;
    saveDMCConfig();
    if (TAB === 'timetable') renderTab();
  };
  reader.readAsDataURL(file);
}

// One fixed pixel width per column type. table-layout:fixed + a matching
// <colgroup> means the browser lays the table out once from these numbers
// instead of re-measuring every input/select's content on every scroll
// frame — see the .tt-grid CSS comment for why that mattered.
const TT_COL_CLASS_W = 92, TT_COL_PERIOD_W = 132, TT_COL_BREAK_W = 60;
function ttColGroup(cols) {
  return `<colgroup><col style="width:${TT_COL_CLASS_W}px">${cols.map(c =>
    `<col style="width:${c.type === 'break' ? TT_COL_BREAK_W : TT_COL_PERIOD_W}px">`).join('')}</colgroup>`;
}
function ttTableWidth(cols) {
  return TT_COL_CLASS_W + cols.reduce((sum, c) => sum + (c.type === 'break' ? TT_COL_BREAK_W : TT_COL_PERIOD_W), 0);
}

function tplTimetable() {
  const classes = ttClassOptions();
  let gridHtml;
  if (ttStatus === 'loading') {
    gridHtml = `<p style="font-size:13px;opacity:.6;">${LANG === 'ur' ? 'لوڈ ہو رہا ہے…' : 'Loading…'}</p>`;
  } else if (ttStatus === 'missing_table') {
    gridHtml = `<p style="font-size:13px;opacity:.7;">${LANG === 'ur'
      ? 'ٹائم ٹیبل ابھی سیٹ اپ نہیں ہوا۔ فائل کے شروع میں CONFIG کے قریب دیا گیا SQL، Supabase میں ایک بار چلائیں، پھر دوبارہ کوشش کریں۔'
      : "Timetable isn't set up yet — run the one-time SQL near CONFIG at the top of this file in your Supabase SQL editor, then try again."}</p>`;
  } else {
    const cols = ttColumns();
    const periodHeader = (p) => {
      const times = ttPeriodTimes[p] || {};
      return `
        <th>
          <div class="tt-period-label">${esc(ttPeriodLabel(p))}</div>
          <div class="tt-period-time">
            <input type="time" value="${esc(times.start_time || '')}" onchange="savePeriodTime(${p},'start_time',this.value)">
            <span>${LANG === 'ur' ? 'تا' : 'to'}</span>
            <input type="time" value="${esc(times.end_time || '')}" onchange="savePeriodTime(${p},'end_time',this.value)">
          </div>
        </th>`;
    };
    const breakHeader = () => `
      <th class="tt-break-th">
        <div class="tt-period-label">${LANG === 'ur' ? 'وقفہ' : 'Break'}</div>
        <div class="tt-period-time">
          <input type="time" value="${esc(ttBreakStart)}" onchange="ttSaveBreakTime('start',this.value)">
          <span>${LANG === 'ur' ? 'تا' : 'to'}</span>
          <input type="time" value="${esc(ttBreakEnd)}" onchange="ttSaveBreakTime('end',this.value)">
        </div>
      </th>`;
    const cell = (className, period) => {
      const row = ttRows.find(r => r.class_name === className && r.period === period);
      const teacherOptions = DATA.teachers.map(tc =>
        `<option value="${tc.id}" ${row && row.teacher_id === tc.id ? 'selected' : ''}>${esc(tc.name)}</option>`).join('');
      return `
        <td class="tt-cell">
          <input type="text" class="tt-subject" placeholder="${LANG === 'ur' ? 'مضمون' : 'Subject'}"
            value="${esc(row && row.subject ? row.subject : '')}"
            onchange="saveTimetableCell('${esc(className).replace(/'/g,"\\'")}',${period},'subject',this.value)">
          <select class="tt-teacher" onchange="saveTimetableCell('${esc(className).replace(/'/g,"\\'")}',${period},'teacher_id',this.value)">
            <option value="">${LANG === 'ur' ? '— استاد —' : '— Teacher —'}</option>
            ${teacherOptions}
          </select>
        </td>`;
    };
    const breakCell = () => `<td class="tt-break-col"><span class="tt-break-label">${LANG === 'ur' ? 'وقفہ' : 'Break'}</span></td>`;
    const headerRow = `<tr><th>${LANG === 'ur' ? 'جماعت' : 'Class'}</th>${cols.map(c => c.type === 'break' ? breakHeader() : periodHeader(c.period)).join('')}</tr>`;
    const bodyRows = classes.map(c =>
      `<tr><td class="tt-class-name">${esc(c)}</td>${cols.map(col => col.type === 'break' ? breakCell() : cell(c, col.period)).join('')}</tr>`).join('');
    gridHtml = `
      <div class="tt-scroll-wrap">
        <table class="tt-grid" style="width:${ttTableWidth(cols)}px;">${ttColGroup(cols)}${headerRow}${bodyRows}</table>
      </div>
      <div class="flexgap" style="margin-top:10px;flex-wrap:wrap;">
        <button class="btn-ghost" onclick="ttAddPeriod()">+ ${LANG === 'ur' ? 'پیریڈ شامل کریں' : 'Add Period'}</button>
        <button class="btn-ghost" onclick="ttRemovePeriod()">− ${LANG === 'ur' ? 'پیریڈ ہٹائیں' : 'Remove Period'}</button>
        <button class="btn-ghost" onclick="openManageTtClasses()">${LANG === 'ur' ? 'جماعتیں منتخب کریں' : 'Manage Classes'}</button>
      </div>
      <label style="margin-top:10px;max-width:260px;">
        <span>${LANG === 'ur' ? 'وقفہ کس پیریڈ کے بعد؟' : 'Break after which period?'}</span>
        <select onchange="ttSetBreakAfter(this.value)">
          <option value="0" ${ttBreakAfter === 0 ? 'selected' : ''}>${LANG === 'ur' ? 'کوئی وقفہ نہیں' : 'No break'}</option>
          ${Array.from({ length: ttPeriods }, (_, i) => i + 1).map(p =>
            `<option value="${p}" ${ttBreakAfter === p ? 'selected' : ''}>${esc(ttPeriodLabel(p))} ${LANG === 'ur' ? 'کے بعد' : 'after'}</option>`).join('')}
        </select>
      </label>`;
  }
  return `
    <div style="padding-top:16px;">
      <div class="section-title" style="margin-top:0;display:flex;justify-content:space-between;align-items:center;">
        <span>${LANG === 'ur' ? 'ٹائم ٹیبل' : 'Timetable'}</span>
        <button onclick="printTimetable()" style="border:none;background:var(--navy);color:var(--gold-soft);border-radius:8px;padding:5px 12px;font-size:11px;font-weight:600;">🖨️ ${esc(t.print)}</button>
      </div>
      <div class="card" style="display:flex;align-items:center;gap:12px;margin-bottom:14px;">
        <div style="flex-shrink:0;text-align:center;">
          ${dmcLogo ? `<img src="${dmcLogo}" style="height:46px;width:46px;object-fit:contain;border-radius:8px;display:block;margin:0 auto 4px;">`
            : `<div style="height:46px;width:46px;border-radius:8px;background:var(--line);display:flex;align-items:center;justify-content:center;font-size:9px;color:#999;margin:0 auto 4px;">${LANG === 'ur' ? 'لوگو' : 'Logo'}</div>`}
          <input type="file" accept="image/*" style="font-size:9px;width:100px;" onchange="handleTimetableLogoUpload(this.files[0])">
        </div>
        <input type="text" value="${esc(dmcSchoolName === 'SCHOOL NAME' ? '' : dmcSchoolName)}" placeholder="${LANG === 'ur' ? 'اسکول کا نام' : 'School Name'}"
          style="flex:1;font-family:Fraunces,serif;font-size:15px;font-weight:600;border:none;border-bottom:1px solid var(--line);background:transparent;padding:6px 2px;color:var(--navy);"
          onchange="dmcSchoolName=this.value||'SCHOOL NAME'; saveDMCConfig();">
      </div>
      ${gridHtml}
    </div>`;
}

function printTimetable() {
  if (ttStatus !== 'ready') return;
  const classes = ttClassOptions();
  const cols = ttColumns();
  const periodTimeStr = (p) => {
    const times = ttPeriodTimes[p] || {};
    return (times.start_time && times.end_time) ? `<span class="tt-print-time">${esc(times.start_time)} ${LANG === 'ur' ? 'تا' : 'to'} ${esc(times.end_time)}</span>` : '';
  };
  const breakTimeStr = () => (ttBreakStart && ttBreakEnd) ? `<span class="tt-print-time">${esc(ttBreakStart)} ${LANG === 'ur' ? 'تا' : 'to'} ${esc(ttBreakEnd)}</span>` : '';
  // Back to the original shape (classes as rows, periods as columns —
  // matches the on-screen editable grid). The whole thing is rotated 90°
  // in CSS instead (see .tt-print-rotate) so a wide grid still prints on a
  // portrait A4 page — you turn the printed page sideways to read it.
  const headerRow = `<tr><th>${LANG === 'ur' ? 'جماعت' : 'Class'}</th>${cols.map(c => c.type === 'break'
    ? `<th class="tt-print-break-th">${LANG === 'ur' ? 'وقفہ' : 'Break'}${breakTimeStr()}</th>`
    : `<th>${esc(ttPeriodLabel(c.period))}${periodTimeStr(c.period)}</th>`).join('')}</tr>`;
  const rows = classes.map(c => {
    const cells = cols.map(col => {
      if (col.type === 'break') return `<td class="tt-print-break-td">${LANG === 'ur' ? 'وقفہ' : 'Break'}</td>`;
      const row = ttRows.find(r => r.class_name === c && r.period === col.period);
      const tc = row && row.teacher_id ? DATA.teachers.find(x => x.id === row.teacher_id) : null;
      const subj = row && row.subject ? `<span class="tt-print-subject">${esc(row.subject)}</span>` : `<span class="tt-print-empty">—</span>`;
      return `<td>${subj}${tc ? `<span class="tt-print-teacher">${esc(tc.name)}</span>` : ''}</td>`;
    }).join('');
    return `<tr><td class="tt-print-classname">${esc(c)}</td>${cells}</tr>`;
  }).join('');
  const schoolName = (dmcSchoolName && dmcSchoolName !== 'SCHOOL NAME') ? dmcSchoolName : (CURRENT_PROFILE.school_name || 'School');
  document.getElementById('print-area').innerHTML = `
    <div class="tt-print-page"><div class="tt-print-rotate">
    <div class="tt-print" dir="${LANG === 'ur' ? 'rtl' : 'ltr'}">
      <div class="tt-print-head">
        ${dmcLogo ? `<img class="tt-print-logo" src="${dmcLogo}">` : ''}
        <div class="eyebrow">${LANG === 'ur' ? 'ٹائم ٹیبل' : 'School Timetable'}</div>
        <h2>${esc(schoolName)}</h2>
      </div>
      <table class="tt-print-table">
        <thead>${headerRow}</thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="tt-print-foot">
        <span class="tt-print-brand">${esc(schoolName)}</span>
        <span>${LANG === 'ur' ? 'تاریخ اجراء' : 'Printed'}: ${esc(fmtDate(new Date().toISOString()))}</span>
      </div>
    </div>
    </div></div>`;
  printAsA4(0); // explicit portrait A4, 0 margin (full-bleed) — a browser can otherwise remember landscape from the last thing printed (e.g. the Admission Register)
}


function openAddClassLogin(id) {
  const existing = id ? DATA.classLogins.find(x => x.id === id) : null;
  showModal(existing ? t.editClassLogin : t.addClassLogin, `
    <label><span>${esc(t.className)}</span>
      <select id="cl-class">${CLASS_OPTIONS.map(c => `<option ${existing && existing.class_name===c?'selected':''}>${esc(c)}</option>`).join('')}</select>
    </label>
    <label><span>${esc(t.classTeacherName)}</span><input id="cl-teacher" value="${existing?esc(existing.teacher_name||''):''}"></label>
    <label><span>${esc(t.loginId)}</span><input id="cl-login" value="${existing?esc(existing.login_id):''}" autocapitalize="none"></label>
    <label><span>${esc(t.classLoginPassword)}</span><input id="cl-pw" autocomplete="off" placeholder="${existing?'(blank = keep current password)':''}"></label>
    <p style="font-size:11px;opacity:.6;margin:-6px 0 12px;">${esc(t.classLoginSavedHint)}</p>
    <div id="cl-msg"></div>
    <div class="flexgap">
      <button class="btn-ghost" onclick="closeModal()">${esc(t.cancel)}</button>
      <button class="btn-primary" style="flex:1" onclick="guardedSubmit(this, ()=>submitClassLogin('${existing?existing.id:''}'))">${esc(t.save)}</button>
    </div>
  `);
}

async function submitClassLogin(id) {
  const msg = document.getElementById('cl-msg');
  const className = document.getElementById('cl-class').value;
  const teacherName = document.getElementById('cl-teacher').value.trim();
  const loginId = document.getElementById('cl-login').value.trim();
  const password = document.getElementById('cl-pw').value;
  if (!loginId || (!id && !password)) return;
  let queued, error;
  if (id) {
    const baseRow = DATA.classLogins.find(x => x.id === id) || null;
    const patch = { class_name: className, teacher_name: teacherName, login_id: loginId };
    if (password) patch.password = password;
    ({ queued, error } = await offlineWrite({
      table: 'class_logins', action: 'update', payload: patch, id, baseRow,
      run: () => sb.from('class_logins').update(patch).eq('id', id),
      optimisticApply: () => {
        const idx = DATA.classLogins.findIndex(x => x.id === id);
        if (idx >= 0) { DATA.classLogins[idx] = { ...DATA.classLogins[idx], ...patch }; idbPutRow('class_logins', DATA.classLogins[idx]); }
      }
    }));
  } else {
    // A brand-new class login, so there's nothing on the server yet to
    // conflict with — safe to just insert once the connection is back.
    // (One offline caveat: the Login ID's uniqueness can only be confirmed
    // against the server, so two classes given the same Login ID while both
    // offline won't be caught until they both come back online.)
    const payload = { id: crypto.randomUUID ? crypto.randomUUID() : `local-${Date.now()}`, owner_id: CURRENT_USER.id, class_name: className, teacher_name: teacherName, login_id: loginId, password };
    ({ queued, error } = await offlineWrite({
      table: 'class_logins', action: 'insert', payload, id: payload.id, baseRow: null,
      run: () => sb.from('class_logins').insert(payload),
      optimisticApply: () => { DATA.classLogins.push(payload); idbPutRow('class_logins', payload); }
    }));
  }
  if (!queued && error) {
    msg.innerHTML = `<div class="err">${error.code === '23505' ? esc(t.loginIdTaken) : esc(error.message)}</div>`;
    return;
  }
  closeModal(); if (!queued) await loadAllData(); renderTab();
}

