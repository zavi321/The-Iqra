/* SchoolMS — search-alerts.js — split from index.html (lines 3464-4025). Load order matters: see index.html */
// ---------------- Global Student Search (fee + admission register, from any tab) ----------------
let globalSearchQuery = '';

function normName(s) { return (s || '').toString().trim().toLowerCase().replace(/\s+/g, ' '); }

// Merges live student records with admission-register entries into one people index,
// matched by normalized name (+ father's name where available), since the register
// has no student_id foreign key back to the students table.
function buildGlobalPeopleIndex() {
  const people = [];
  const byKey = new Map();
  DATA.students.forEach(s => {
    const key = normName(s.name) + '|' + normName(s.father_name);
    const entry = { name: s.name, father_name: s.father_name, class_name: s.class_name, studentId: s.id, registerId: null };
    byKey.set(key, entry);
    people.push(entry);
  });
  DATA.admissionRegister.forEach(r => {
    const key = normName(r.student_name) + '|' + normName(r.father_name);
    if (byKey.has(key)) { byKey.get(key).registerId = r.id; return; }
    const nameOnlyMatch = people.find(p => !p.registerId && normName(p.name) === normName(r.student_name));
    if (nameOnlyMatch) { nameOnlyMatch.registerId = r.id; return; }
    const entry = { name: r.student_name, father_name: r.father_name, class_name: r.class_admitted, studentId: null, registerId: r.id };
    byKey.set(key + '#' + r.id, entry);
    people.push(entry);
  });
  return people;
}

// Marks Sheet students live in their own independent table (marks_sheet_data), keyed
// by class, and are only fetched on first visit to that tab. Preload them here too so
// they're searchable from global search even if the user never opened that tab.
function buildMarksheetSearchIndex() {
  const list = [];
  Object.keys(msStudents).forEach(cls => {
    (msStudents[cls] || []).forEach(st => {
      list.push({ name: st.name, class_name: cls, msId: st.id });
    });
  });
  return list;
}

// DMC (Detail Marks Certificate) results only exist in-memory for the batch most
// recently uploaded via Excel in the Certificates tab — they are not saved to the
// database — so these are searchable only for the current session's upload.
function buildDMCSearchIndex() {
  return (dmcResults || []).map(r => ({ name: r.studentName, class_name: r.class, rollNo: r.rollNo }));
}

function openGlobalSearch() {
  globalSearchQuery = '';
  showModal(t.globalSearch, `
    <div class="searchbar" style="margin-bottom:10px;">
      <input id="gs-input" placeholder="${esc(t.globalSearchPlaceholder)}" oninput="globalSearchQuery=this.value; renderGlobalSearchResults();">
    </div>
    <div id="gs-results"></div>
  `);
  const inp = document.getElementById('gs-input');
  if (inp) inp.focus();
  renderGlobalSearchResults();
  // Marks sheet data may not be loaded yet if the user hasn't visited that tab —
  // fetch it now and refresh results once it's in, so it's searchable right away.
  loadMarksSheetData().then(() => { if (document.getElementById('gs-input')) renderGlobalSearchResults(); });
}

function renderGlobalSearchResults() {
  const el = document.getElementById('gs-results');
  if (!el) return;
  const q = normName(globalSearchQuery);
  if (!q) { el.innerHTML = ''; return; }

  const peopleMatches = buildGlobalPeopleIndex()
    .filter(p => (normName(p.name) + ' ' + normName(p.father_name)).includes(q))
    .slice(0, 25);
  const msMatches = buildMarksheetSearchIndex()
    .filter(p => normName(p.name).includes(q))
    .slice(0, 15);
  const dmcMatches = buildDMCSearchIndex()
    .filter(p => normName(p.name).includes(q))
    .slice(0, 15);

  if (!peopleMatches.length && !msMatches.length && !dmcMatches.length) {
    el.innerHTML = `<div class="empty">${esc(t.noSearchResults)}</div>`;
    return;
  }

  const peopleRows = peopleMatches.map(p => `
    <div class="list-row" style="cursor:pointer;" onclick="openFullRecord('${p.studentId || ''}','${p.registerId || ''}')">
      <div>
        <div class="nm">${esc(p.name)}</div>
        <div class="sub">${esc(t.fatherName)}: ${esc(p.father_name || '')}${p.class_name ? ' · ' + esc(p.class_name) : ''}</div>
      </div>
      <div style="display:flex;gap:6px;flex-shrink:0;">
        ${p.studentId ? `<span class="pill good">${esc(t.hasFeeRecord)}</span>` : ''}
        ${p.registerId ? `<span class="pill free">${esc(t.hasRegisterEntry)}</span>` : ''}
      </div>
    </div>`).join('');

  const msRows = msMatches.map(p => `
    <div class="list-row" style="cursor:pointer;" onclick="openMarksheetFromSearch('${escJs(p.class_name)}')">
      <div>
        <div class="nm">${esc(p.name)}</div>
        <div class="sub">${esc(p.class_name || '')}</div>
      </div>
      <div style="display:flex;gap:6px;flex-shrink:0;">
        <span class="pill orphan">${esc(t.marksSheet)}</span>
      </div>
    </div>`).join('');

  const dmcRows = dmcMatches.map(p => `
    <div class="list-row" style="cursor:pointer;" onclick="openDMCFromSearch()">
      <div>
        <div class="nm">${esc(p.name)}</div>
        <div class="sub">${esc(p.class_name || '')}${p.rollNo ? ' · ' + esc(p.rollNo) : ''}</div>
      </div>
      <div style="display:flex;gap:6px;flex-shrink:0;">
        <span class="pill free">${esc(t.dmc)}</span>
      </div>
    </div>`).join('');

  el.innerHTML = `<div class="list-card">${peopleRows}${msRows}${dmcRows}</div><div id="gs-archive-results" style="margin-top:10px;"></div>`;

  // Live in-memory matches above only cover people still loaded/uploaded this
  // session. Also query the permanent dmc_records archive so a certificate
  // issued years ago still turns up by name. Debounced + guarded against
  // stale results so a fast typer doesn't see an old query's results land late.
  clearTimeout(gsArchiveSearchTimer);
  if (q.length >= 3) {
    gsArchiveSearchTimer = setTimeout(() => searchDMCArchive(q), 350);
  }
}

let gsArchiveSearchTimer = null;
async function searchDMCArchive(q) {
  const box = document.getElementById('gs-archive-results');
  if (!box) return;
  const { data, error } = await sb.from('dmc_records')
    .select('id,student_name,class_name,academic_year,roll_no')
    .eq('owner_id', CURRENT_USER.id).ilike('student_name', `%${q}%`)
    .order('academic_year', { ascending: false }).limit(20);
  if (error || !data) return;
  const inp = document.getElementById('gs-input');
  if (!inp || normName(inp.value) !== q) return; // a newer search has since superseded this one
  if (!data.length) { box.innerHTML = ''; return; }
  box.innerHTML = `<div class="section-title" style="margin-top:0;">${esc(t.dmc || 'DMC')} — Purana Record (Archive)</div><div class="list-card">` +
    data.map(r => `
      <div class="list-row" style="cursor:pointer;" onclick="viewSavedDMCRecord('${r.id}')">
        <div>
          <div class="nm">${esc(r.student_name)}</div>
          <div class="sub">${esc(r.class_name || '')} · ${esc(r.academic_year || '')}${r.roll_no ? ' · Roll: ' + esc(r.roll_no) : ''}</div>
        </div>
        <span class="pill free">${esc(t.dmc || 'DMC')}</span>
      </div>`).join('') + `</div>`;
}

// Jump to the Marks Sheet tab with the matched student's class pre-selected.
function openMarksheetFromSearch(cls) {
  closeModal();
  msSelectedClass = cls;
  setTab('marksSheet');
}

// DMC results have no individual record to deep-link to (they're a batch preview),
// so just take the user to the Certificates tab where the loaded batch is shown.
function openDMCFromSearch() {
  closeModal();
  setTab('dmc');
}

// Combined view: shows a student's fee-ledger summary and admission-register info
// together, regardless of which tab they were found from.
function openFullRecord(studentId, registerId) {
  const s = studentId ? DATA.students.find(x => x.id === studentId) : null;
  const r = registerId ? DATA.admissionRegister.find(x => x.id === registerId) : null;
  if (!s && !r) return;
  const name = (s && s.name) || (r && r.student_name) || '';
  const father = (s && s.father_name) || (r && r.father_name) || '';

  let feeSection;
  if (s) {
    const entries = studentPayments(s.id);
    const totalPaidAllTime = entries.reduce((a, b) => a + Number(b.amount || 0), 0);
    const currentBalance = studentBalance(s.id);
    feeSection = `
      <h4 class="section-title" style="margin-top:0;">${esc(t.feeLedger)}</h4>
      <div style="font-size:12px;opacity:.7;margin-bottom:10px;display:flex;flex-wrap:wrap;gap:10px;">
        <span>${esc(t.className)}: ${esc(s.class_name || '')}</span>
        <span>${esc(t.monthlyFee)}: ₨${fmt(s.monthly_fee)}</span>
        <span>${esc(t.studentType)}: ${esc(typeLabel(s.student_type || 'paying'))}</span>
      </div>
      <div style="display:flex;gap:8px;margin-bottom:14px;">
        <div class="greenbox" style="flex:1;margin-bottom:0;"><div class="lbl">${esc(t.totalCollectedAllTime)}</div><div class="val">₨${fmt(totalPaidAllTime)}</div></div>
        <div class="greenbox" style="flex:1;margin-bottom:0;background:${currentBalance > 0 ? '#FBEAE5' : '#EAF2EC'};">
          <div class="lbl" style="color:${currentBalance > 0 ? 'var(--rust)' : 'var(--sage)'};">${esc(t.balanceCol)}</div>
          <div class="val" style="color:${currentBalance > 0 ? 'var(--rust)' : 'var(--sage)'};">₨${fmt(currentBalance)}</div>
        </div>
      </div>
      <button class="btn-ghost" style="width:100%;margin-bottom:6px;" onclick="closeModal(); openStudentDetail('${s.id}')">${esc(t.viewFeeLedger)} →</button>
    `;
  } else {
    feeSection = `<h4 class="section-title" style="margin-top:0;">${esc(t.feeLedger)}</h4><div class="empty" style="padding:20px;">${esc(t.notActiveStudent)}</div>`;
  }

  let regSection;
  if (r) {
    regSection = `
      <h4 class="section-title">${esc(t.registerInfo)}</h4>
      <div style="font-size:13px;line-height:2;">
        <div>${esc(t.serialNo)}: <b>${esc(r.serial_no || '—')}</b></div>
        <div>${esc(t.classAdmitted)}: <b>${esc(r.class_admitted || '—')}</b></div>
        <div>${esc(t.admissionDate)}: <b>${esc(fmtDate(r.admission_date) || '—')}</b></div>
        ${r.class_withdrawn ? `<div>${esc(t.classWithdrawn)}: <b>${esc(r.class_withdrawn)}</b></div>` : ''}
        ${r.withdrawal_date ? `<div>${esc(t.withdrawalDate)}: <b>${esc(fmtDate(r.withdrawal_date))}</b></div>` : ''}
        ${r.arrears_due ? `<div>${esc(t.arrearsDue)}: <b>₨${fmt(r.arrears_due)}</b></div>` : ''}
      </div>
      <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap;">
        <button class="btn-ghost" style="flex:1;" onclick="closeModal(); openEditAdmissionEntry('${r.id}')">${esc(t.viewRegisterEntry)}</button>
        <button class="btn-ghost" style="flex:1;" onclick="printAdmissionEntry('${r.id}')">🖨️ ${esc(t.printSlc)}</button>
        <button class="btn-ghost" style="flex:1;" onclick="printCharacterCertificate('${r.id}')">🖨️ ${esc(t.printCc)}</button>
      </div>
    `;
  } else {
    regSection = `<h4 class="section-title">${esc(t.registerInfo)}</h4><div class="empty" style="padding:20px;">${esc(t.notInRegister)}</div>`;
  }

  showModal(name, `
    <div style="font-size:12px;opacity:.7;margin-bottom:14px;">${esc(t.fatherName)}: ${esc(father || '')}</div>
    ${feeSection}
    ${regSection}
  `);
}

// Used only by search-as-you-type inputs (student/teacher/register search): a
// keystroke needs renderTab() to refresh the filtered list, but that rebuilds
// the input too and would otherwise close the mobile keyboard mid-word. This
// restores focus + cursor position on that ONE input only — unlike restoring
// focus after every renderTab() call (tab switches, saves, modal closes),
// which caused the keyboard to pop back open at the wrong times.
function reFocusAfterRender(inputId) {
  const el = document.getElementById(inputId);
  const selStart = el ? el.selectionStart : null;
  const selEnd = el ? el.selectionEnd : null;
  renderTab();
  const newEl = document.getElementById(inputId);
  if (newEl) {
    newEl.focus({ preventScroll: true });
    if (selStart != null && newEl.setSelectionRange) {
      try { newEl.setSelectionRange(selStart, selEnd); } catch (e) {}
    }
  }
}

// Keeps the page scroll and the picture-library scroll where they were when the KG paper
// builder re-renders (picking a picture, zooming, adding a question...).
function renderTab() {
  let keep = false;
  try { const m0 = document.getElementById('main'); keep = paperMode === 'kg' && TAB === 'papers' && !!(m0 && m0.querySelector('.paper-q-row, #kgLib, .card')); } catch (e) {}
  const lib = document.getElementById('kgLib'), ls = lib ? lib.scrollTop : 0, ws = window.scrollY || 0;
  const mEl = document.getElementById('main'), ms = mEl ? mEl.scrollTop : 0, aEl = document.getElementById('app'), as = aEl ? aEl.scrollTop : 0;
  if (keep && mEl) mEl.style.minHeight = mEl.offsetHeight + 'px';
  try { _renderTabInner(); }
  catch (e) {
    // One broken screen must never blank the whole app: log it and show a retry card.
    _logClientError('render:' + TAB, e);
    const m = document.getElementById('main');
    if (m) m.innerHTML = `<div class="card" style="margin:16px;text-align:center;"><div style="font-weight:700;margin-bottom:6px;">${esc(LANG === 'ur' ? 'یہ صفحہ لوڈ نہیں ہو سکا' : 'This screen could not load')}</div><div style="font-size:12px;opacity:.7;margin-bottom:12px;">${esc(String((e && e.message) || e).slice(0, 200))}</div><button class="btn-primary" onclick="renderTab()">${esc(LANG === 'ur' ? 'دوبارہ کوشش' : 'Try again')}</button></div>`;
    return;
  }
  if (!keep) return;
  try { pqScheduleSave(); } catch (e) {}
  const fix = () => { const l = document.getElementById('kgLib'); if (l && lib) l.scrollTop = ls;
    const m = document.getElementById('main'); if (m) m.scrollTop = ms; const a = document.getElementById('app'); if (a) a.scrollTop = as;
    window.scrollTo({ top: ws, left: 0, behavior: 'instant' }); };
  fix(); requestAnimationFrame(fix); setTimeout(() => { const m = document.getElementById('main'); if (m) m.style.minHeight = ''; }, 250);
}
function _renderTabInner() {
  const main = document.getElementById('main');
  _regBookCaptureScroll(); // remember horizontal scroll position before this rebuild wipes it
  if (TAB==='dashboard') main.innerHTML = tplDashboard();
  else if (TAB==='students') main.innerHTML = tplStudents();
  else if (TAB==='teachers') main.innerHTML = tplTeachers();
  else if (TAB==='finance') main.innerHTML = tplFinance();
  else if (TAB==='reports') main.innerHTML = tplReports();
  else if (TAB==='dmc') {
    main.innerHTML = tplDMC();
    renderDMCEditTable();
    restoreDMCUploadIfEmpty();
    loadDMCConfig().then(() => {
      if (TAB !== 'dmc' || !document.getElementById('dmc-school-name')) return;
      // Previously this replaced the *entire* tab (main.innerHTML = tplDMC())
      // once the network response landed, guarded only by a single check of
      // document.activeElement at that instant. That check closes the obvious
      // case (user already mid-typing) but not a fast tap that lands right
      // around when the response arrives: focus can end up on an element that
      // this rebuild is about to tear down and replace, which yanks the
      // keyboard closed right after it opens. Patching only the specific
      // fields that the config actually changes — and skipping any field the
      // user is currently focused on — never tears down input elements at
      // all, so there's no window where a tap can race a rebuild.
      applyDMCConfigToFields();
      renderDMCEditTable();
    });
  }
  else if (TAB==='marksSheet') { main.innerHTML = tplMarksSheet(); _regBookRestoreScroll(); }
  else if (TAB==='admissionRegister') { main.innerHTML = tplAdmissionRegister(); initRegBookScroll(); _regBookRestoreScroll(); }
  else if (TAB==='papers') main.innerHTML = tplPapers();
  else if (TAB==='teacherRegister') { main.innerHTML = tplTeacherRegister(); initRegBookScroll(); _regBookRestoreScroll(); }
  else if (TAB==='classLogins') main.innerHTML = tplClassLogins();
  else if (TAB==='timetable') {
    main.innerHTML = tplTimetable();
    _regBookRestoreScroll();
    if (ttStatus === 'idle') loadTimetableGrid();
  }
  else if (TAB==='datesheet') {
    main.innerHTML = tplDateSheet();
    // keep the grid's sideways scroll position through any redraw (it used to snap back to the start)
    _regBookRestoreScroll();
    requestAnimationFrame(_regBookRestoreScroll);
    // pulls the school logo/name used on the printed pages (once per session)
    if (!window.__dsCfgLoaded) { window.__dsCfgLoaded = true; Promise.resolve(loadDMCConfig()).catch(() => {}); }
  }
  else if (TAB==='notices') {
    // The form is NOT rebuilt if it is already on screen (same language): a background sync / 'online'
    // event used to wipe it and close the keyboard. Only the list underneath is refreshed.
    if (document.getElementById('notice-details') && main.dataset.noticeLang === LANG) { noticeLoad(); pmOwnerLoad(); updateAlertsBadge(); return; }
    main.dataset.noticeLang = LANG;
    main.innerHTML = tplNotices(); noticeInit(); pmOwnerLoad();
  }
  else if (TAB==='admin') { main.innerHTML = tplAdmin(); loadAdminLists(); return; }
  main.insertAdjacentHTML('beforeend', `<div class="notice">${esc(t.sharedNotice)}</div>`);
  main.insertAdjacentHTML('beforeend', `<div class="notice" style="margin-top:8px;font-size:10px;">${esc(t.copyrightNotice)}</div>`);
  updateAlertsBadge();
  pmOwnerBadgeRefresh();
}

// Keeps the 🔔 badge count in sync; safe to call anytime (no-ops if the
// bell isn't in the DOM yet, e.g. before login).
function updateAlertsBadge() {
  const badge = document.getElementById('alerts-bell-badge');
  if (!badge) return;
  const n = generateAlerts().length;
  badge.textContent = n > 0 ? (n > 9 ? '9+' : String(n)) : '';
  badge.style.display = n > 0 ? 'flex' : 'none';
}

// ---------------- Suggestions (for the school owner) ----------------
// Looks at the school's own live records (fees, dues, teacher salaries,
// student mix) and surfaces a short, plain-language list of things the
// owner may want to act on. Everything here is computed from data already
// in DATA/computeStats() — no network calls, nothing saved anywhere.
function generateSuggestions() {
  const s = computeStats();
  const cur = monthKey();
  const active = DATA.students.filter(x => x.status !== 'inactive');
  const list = [];

  // 1. Students seriously behind on fees (2+ months)
  const overdueCount = active.filter(x => isFeePaying(x) && monthsOverdue(x) >= 2).length;
  if (overdueCount > 0) {
    list.push({ icon:'⚠️',
      en:`${overdueCount} student${overdueCount>1?'s are':' is'} 2+ months behind on fees. Sending a reminder or reaching out to these families directly may help recover this faster.`,
      ur:`${overdueCount} طلبہ کی فیس 2 یا زیادہ ماہ سے واجب الادا ہے۔ ان خاندانوں کو یاد دہانی بھیجنے یا براہ راست رابطہ کرنے سے وصولی جلدی ہو سکتی ہے۔` });
  }

  // 2. All-time finances running at a deficit
  if (s.netBalance < 0) {
    list.push({ icon:'📉',
      en:`Your all-time net balance is currently in deficit (₨${fmt(Math.abs(s.netBalance))}). It may help to review recurring expenses or look into additional income sources.`,
      ur:`آپ کا مجموعی خالص بیلنس اس وقت خسارے میں ہے (₨${fmt(Math.abs(s.netBalance))})۔ بار بار ہونے والے اخراجات کا جائزہ لینا یا آمدنی کے اضافی ذرائع تلاش کرنا مفید ہو سکتا ہے۔` });
  }

  // 3. Low fee collection rate so far this month
  const totalDueThisMonth = s.feesCollectedThisMonth + s.feesDueThisMonth;
  if (totalDueThisMonth > 0) {
    const rate = s.feesCollectedThisMonth / totalDueThisMonth;
    if (rate < 0.6) {
      list.push({ icon:'💰',
        en:`Only ${Math.round(rate*100)}% of this month's fees have been collected so far. Sending reminders earlier in the month tends to improve collection.`,
        ur:`اس مہینے کی فیس کا صرف ${Math.round(rate*100)}% ہی اب تک وصول ہوا ہے۔ مہینے کے شروع میں یاد دہانی بھیجنے سے وصولی عموماً بہتر ہو جاتی ہے۔` });
    }
  }

  // 4. High share of Free/Orphan (non fee-paying) students
  const typedActive = s.payingCount + s.freeCount + s.orphanCount;
  if (typedActive > 0) {
    const freeRatio = (s.freeCount + s.orphanCount) / typedActive;
    if (freeRatio > 0.35) {
      list.push({ icon:'🤝',
        en:`${Math.round(freeRatio*100)}% of your active students are Free or Orphan (non fee-paying). Looking into donors or a sponsorship program could help support these seats.`,
        ur:`آپ کے فعال طلبہ میں سے ${Math.round(freeRatio*100)}% فری یا یتیم (غیر فیس ادا کرنے والے) ہیں۔ عطیہ دہندگان یا سپانسرشپ پروگرام تلاش کرنا ان نشستوں کی مدد کر سکتا ہے۔` });
    }
  }

  // 5. Teacher salaries still pending this month
  const unpaidTeachers = DATA.teachers.filter(tc => !teacherPayments(tc.id).some(p => p.month === cur));
  if (DATA.teachers.length > 0 && unpaidTeachers.length > 0) {
    list.push({ icon:'🧑‍🏫',
      en:`${unpaidTeachers.length} of ${DATA.teachers.length} teachers haven't been paid yet this month. Timely salary payments help with staff retention.`,
      ur:`${DATA.teachers.length} میں سے ${unpaidTeachers.length} اساتذہ کو اس مہینے تنخواہ ابھی تک ادا نہیں کی گئی۔ بروقت تنخواہ عملے کو برقرار رکھنے میں مددگار ہوتی ہے۔` });
  }

  // 6. Outstanding dues large relative to a normal month's collection
  if (s.totalDuesAllTime > 0 && s.feesCollectedThisMonth > 0 && s.totalDuesAllTime > s.feesCollectedThisMonth * 3) {
    list.push({ icon:'📋',
      en:`Total outstanding dues (₨${fmt(s.totalDuesAllTime)}) are more than 3× this month's collection. A structured fee-recovery plan could help bring this down.`,
      ur:`کل واجب الادا فیس (₨${fmt(s.totalDuesAllTime)}) اس مہینے کی وصولی سے 3 گنا سے زیادہ ہے۔ ایک منظم فیس وصولی منصوبہ اسے کم کرنے میں مدد دے سکتا ہے۔` });
  }

  return list;
}

// ---------------- Important Alerts (Fee dues + Teacher attendance misses) ----------------
// Purely additive: only reads from existing DATA/computeStats/monthsOverdue,
// writes nothing anywhere, and does not modify any existing function above.
// Surfaced via the 🔔 bell in the header and a banner on the Dashboard.
function generateAlerts() {
  const list = [];
  const today = todayISO();
  const now = new Date();

  // Fee alerts: every active fee-paying student currently overdue.
  const active = DATA.students.filter(x => x.status !== 'inactive');
  active.filter(s => isFeePaying(s)).forEach(s => {
    // Only alert if the LATEST recorded month's running balance is still due.
    // If earlier months had dues but the student has since caught up (their
    // most recent entry brings the running balance to 0 or below), this is
    // not overdue anymore — don't alert, even though older rows show old dues.
    const latestBalance = studentBalance(s.id);
    if (latestBalance <= 0) return;
    const m = monthsOverdue(s);
    if (m >= 1) {
      list.push({
        severity: m >= 2 ? 'high' : 'medium', icon: m >= 2 ? '🔴' : '🟠',
        en: `${s.name} — ${m} month${m > 1 ? 's' : ''} of fees overdue`,
        ur: `${s.name} — فیس ${m} ماہ سے واجب الادا ہے`,
        onclick: `openStudentDetail('${s.id}')`
      });
    }
  });

  // Teacher attendance: teachers send a "present" request
  // that the admin approves. After 9 AM show ONE summary alert (not one per teacher),
  // plus one alert if requests are waiting for approval.
  if (now.getHours() >= 9) {
    const missing = DATA.teachers.filter(tc => {
      const rec = DATA.teacherAttendance.find(a => String(a.teacher_id) === String(tc.id) && a.date === today);
      return !teacherHasMark(rec);
    }).length;
    if (missing > 0) {
      list.push({
        severity: 'medium', icon: '🕐',
        en: `${missing} teacher${missing > 1 ? 's have' : ' has'} no attendance marked today`,
        ur: `آج ${missing} اساتذہ کی حاضری نہیں لگی`,
        onclick: `openAttendanceHub()`
      });
    }
  }
  if (typeof SR_PENDING !== 'undefined' && SR_PENDING > 0) {
    list.push({
      severity: 'medium', icon: '🔔',
      en: `${SR_PENDING} teacher attendance request${SR_PENDING > 1 ? 's' : ''} waiting for your approval`,
      ur: `${SR_PENDING} اساتذہ کی حاضری کی درخواستیں منظوری کی منتظر ہیں`,
      onclick: `openStaffRequests()`
    });
  }

  list.sort((a, b) => (b.severity === 'high') - (a.severity === 'high'));
  return list;
}

function openAlertsModal() {
  const list = generateAlerts();
  const body = list.length
    ? list.map(a => `
        <div class="list-row" style="cursor:pointer;" onclick="closeModal(); ${a.onclick}">
          <div class="nm">${a.icon} ${esc(LANG === 'ur' ? a.ur : a.en)}</div>
        </div>`).join('')
    : `<div class="empty">${esc(LANG === 'ur' ? 'فی الحال کوئی اہم الرٹ نہیں۔' : 'No important alerts right now.')}</div>`;
  showModal(LANG === 'ur' ? 'اہم الرٹس' : 'Important Alerts', `<div class="list-card">${body}</div>`);
}

function tplSuggestions() {
  const list = generateSuggestions();
  const items = list.length
    ? list.map(x => `
        <div class="stat-card" style="display:flex;gap:10px;align-items:flex-start;margin-bottom:12px;">
          <div style="font-size:20px;line-height:1.3;">${x.icon}</div>
          <div style="font-size:13px;line-height:1.55;">${esc(LANG === 'ur' ? x.ur : x.en)}</div>
        </div>`).join('')
    : `<div class="stat-card" style="text-align:center;opacity:.65;font-size:13px;">${esc(t.suggestionsAllGood)}</div>`;

  return `
    <div style="padding-top:16px;">
      <div class="section-title" style="margin-top:0;">${esc(t.suggestionsTitle)}</div>
      <p style="font-size:12px;opacity:.65;margin:-4px 0 14px;">${esc(t.suggestionsDesc)}</p>
      ${items}

      <div class="section-title" style="margin-top:24px;">${esc(t.aiSuggestionsTitle)}</div>
      <p style="font-size:12px;opacity:.65;margin:-4px 0 14px;">${esc(t.aiSuggestionsDesc)}</p>
      <div id="ai-sugg-body"><div class="skel-line" style="width:90%;"></div><div class="skel-line" style="width:65%;"></div></div>
    </div>`;
}

// ---------------- AI Insights (Supabase Edge Function → Claude) ----------------
// A second, separate layer of suggestions on top of generateSuggestions()
// above: instead of fixed hand-written rules, this calls a Supabase Edge
// Function ("generate-ai-suggestions") which asks an AI model to look at
// this school's own aggregated stats and write a few fresh, specific
// suggestions. The Edge Function itself caches its result server-side and
// only calls the AI again after 8 hours (so this refreshes about 3
// times/day total, no matter how often the owner opens this tab — keeping
// AI usage/cost bounded across every school using the app). No student
// names or raw records are ever sent — only rounded-up counts/totals.
async function idbGetAiSuggestions() {
  const rows = await idbGetAll('ai_suggestions');
  return rows[0] || null;
}
async function idbSaveAiSuggestions(content, generatedAt) {
  await idbPutRow('ai_suggestions', { id: 'current', content, generatedAt });
}
function renderAiSuggestionsList(el, list, generatedAt, isStale) {
  if (!list || !list.length) { smoothSwapHtml(el, `<div class="stat-card" style="text-align:center;opacity:.65;font-size:13px;">${esc(t.suggestionsAllGood)}</div>`); return; }
  const timeStr = generatedAt ? new Date(generatedAt).toLocaleString() : '';
  const note = `<div style="font-size:11px;opacity:.6;margin-bottom:8px;">${esc(isStale ? t.aiSuggestionsCachedNote : t.aiSuggestionsUpdatedAt)} ${esc(timeStr)}</div>`;
  const items = list.map(x => `
    <div class="stat-card" style="display:flex;gap:10px;align-items:flex-start;margin-bottom:12px;">
      <div style="font-size:20px;line-height:1.3;">${esc(x.icon || '✨')}</div>
      <div style="font-size:13px;line-height:1.55;">${esc((LANG === 'ur' ? x.ur : x.en) || '')}</div>
    </div>`).join('');
  smoothSwapHtml(el, note + items);
}
async function loadAiSuggestions() {
  const el = document.getElementById('ai-sugg-body');
  if (!el) return;
  // No signal at all — show whatever AI insights were saved from the last
  // successful load instead of nothing, same offline-cache pattern used
  // everywhere else in this file (dmc_config, marks_sheet_data, etc.).
  if (!navigator.onLine) {
    const cached = await idbGetAiSuggestions();
    if (cached && cached.content && cached.content.length) renderAiSuggestionsList(el, cached.content, cached.generatedAt, true);
    else smoothSwapHtml(el, `<div class="stat-card" style="text-align:center;opacity:.65;font-size:13px;">${esc(t.aiSuggestionsOfflineNone)}</div>`);
    return;
  }
  try {
    const result = await withTimeout(sb.functions.invoke('generate-ai-suggestions', { body: { lang: LANG } }), 15000);
    const data = result && result.data;
    const error = result && result.error;
    if (error || !data || data.error || !data.content) {
      const cached = await idbGetAiSuggestions();
      if (cached && cached.content && cached.content.length) renderAiSuggestionsList(el, cached.content, cached.generatedAt, true);
      else smoothSwapHtml(el, `<div class="err">${esc(t.aiSuggestionsError)}</div>`);
      return;
    }
    await idbSaveAiSuggestions(data.content, data.generated_at);
    renderAiSuggestionsList(el, data.content, data.generated_at, false);
  } catch (e) {
    const cached = await idbGetAiSuggestions();
    if (cached && cached.content && cached.content.length) renderAiSuggestionsList(el, cached.content, cached.generatedAt, true);
    else smoothSwapHtml(el, `<div class="err">${esc(t.aiSuggestionsError)}</div>`);
  }
}

