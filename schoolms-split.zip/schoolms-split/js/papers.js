/* SchoolMS — papers.js — split from index.html (lines 10430-12257). Load order matters: see index.html */
// --------- Question Paper Generator ---------
// A manual builder for exam/test papers: fill in the header (class, subject,
// marks, time), add as many questions as needed across Section A's four
// question types plus Section B/C, then print. Questions are typed in fresh
// each time (or pasted in from content prepared elsewhere, e.g. from a
// textbook) — this tool only formats and prints, it does not store a
// reusable question bank.
// School name/logo default to the same dmcSchoolName/dmcLogo already set in
// Certificates, but are kept separately editable here (paperMeta) so a paper
// can use a different heading without touching the certificate settings.
let paperMeta = { school_name: '', logo: null, exam_name: '', class_name: '', subject: '', total_marks: '', time_allowed: '', exam_date: '' };
let paperMcqMarksEach = 1;
let paperMcqs = [ { no:1, q:'', options:['','','',''] } ];
let paperBlanks = [ { no:1, q:'' } ];
let paperTF = [ { no:1, q:'' } ];
let paperMatchA = [ '', '' ];
let paperMatchB = [ '', '' ];
let paperShort = [ { no:1, q:'', marks:'' } ];
let paperLong = [ { no:1, q:'', marks:'' } ];
// Free-typed instruction line shown under each section's title on the
// printed paper (e.g. "Choose the correct option" for MCQs). Optional —
// left blank the section just prints without one.
let paperInstructions = { mcq:'', blanks:'', tf:'', match:'', short:'', long:'' };
// Editable titles for Section A / B / C. Left blank they fall back to the
// default titles ("Section A — Objective Questions" etc.).
let paperSectionTitles = { a:'', b:'', c:'' };
const pqTitle = (k, def) => (paperSectionTitles[k] || '').trim() || def;
// Optional divider line after every 5th question in Section A (MCQs +
// Blanks + True/False counted together, in that print order), or in
// Section B (Short) / Section C (Long). Keyed 'a' | 'b' | 'c', then by group
// number (0 = the box after question 5 of that section, 1 = after #10...).
// Left blank it prints nothing; typed, it prints as its own centered line.
let paperBreaks = { a:[], b:[], c:[] };
// A single optional diagram/image printed once at the very end of the whole
// paper (not per-question) — mainly for Science papers that need one figure
// to label or refer to.
let paperEndImage = null;
let paperTables = [];

// ---- Question Paper draft auto-save (this device only, never Supabase) ----
// Every keystroke/change in the Papers tab is copied into localStorage, and
// the draft is restored on the next app start, so a refresh, a phone lock or
// a closed browser never loses a half-written paper. It is purely additive:
// it only reads/writes the paper* variables above and touches nothing else.
const PQ_DRAFT_KEY = 'pqDraft_v1';
let pqSaveTimer = null, pqReady = false;
function pqSnapshot(withImages) {
  const meta = Object.assign({}, paperMeta);
  if (!withImages || (typeof dmcLogo !== 'undefined' && meta.logo === dmcLogo)) meta.logo = null; // default logo is refilled automatically
  return { v:1, t:Date.now(), paperMeta:meta, paperMcqMarksEach, paperMcqs, paperBlanks, paperTF,
           paperMatchA, paperMatchB, paperShort, paperLong, paperInstructions, paperSectionTitles, paperBreaks,
           paperEndImage: withImages ? paperEndImage : null, paperMode, kgBlocks: [], paperTables };
}
function savePaperDraft() {
  if (!pqReady) return;
  try { localStorage.setItem(PQ_DRAFT_KEY, JSON.stringify(pqSnapshot(true))); }
  catch (e) { try { localStorage.setItem(PQ_DRAFT_KEY, JSON.stringify(pqSnapshot(false))); } catch (e2) {} } // storage full: keep the text at least
  try { kgIdbSave(); } catch (e3) {}
}
function pqScheduleSave() { clearTimeout(pqSaveTimer); pqSaveTimer = setTimeout(savePaperDraft, 300); }
function pqFlush() { clearTimeout(pqSaveTimer); savePaperDraft(); }
function loadPaperDraft() {
  let raw = null;
  try { raw = localStorage.getItem(PQ_DRAFT_KEY); } catch (e) {}
  if (!raw) { pqReady = true; return; }
  try {
    const d = JSON.parse(raw);
    const arr = (v, def) => (Array.isArray(v) && v.length ? v : def);
    if (d.paperMeta) paperMeta = Object.assign(paperMeta, d.paperMeta);
    if (d.paperMcqMarksEach != null) paperMcqMarksEach = d.paperMcqMarksEach;
    paperMcqs = arr(d.paperMcqs, paperMcqs);
    paperBlanks = arr(d.paperBlanks, paperBlanks);
    paperTF = arr(d.paperTF, paperTF);
    paperMatchA = arr(d.paperMatchA, paperMatchA);
    paperMatchB = arr(d.paperMatchB, paperMatchB);
    paperShort = arr(d.paperShort, paperShort);
    paperLong = arr(d.paperLong, paperLong);
    if (d.paperInstructions) paperInstructions = Object.assign(paperInstructions, d.paperInstructions);
    if (d.paperSectionTitles) paperSectionTitles = Object.assign(paperSectionTitles, d.paperSectionTitles);
    if (d.paperBreaks) paperBreaks = Object.assign(paperBreaks, d.paperBreaks);
    if (d.paperEndImage) paperEndImage = d.paperEndImage;
    if (d.paperMode) paperMode = d.paperMode;
    if (Array.isArray(d.kgBlocks)) kgBlocks = d.kgBlocks;
    if (Array.isArray(d.paperTables)) paperTables = d.paperTables;
    pqReady = true;
  } catch (e) {
    // unreadable draft: keep a copy instead of overwriting it
    try { localStorage.setItem(PQ_DRAFT_KEY + '_corrupt', raw); } catch (e2) {}
    pqReady = true;
  }
}
loadPaperDraft();

// ---- New Paper / restore previous paper ----
const PQ_BACKUP_KEY = 'pqBackup_v1';
function pqHasContent() {
  const m = paperMeta;
  return !!(m.exam_name || m.class_name || m.subject || m.total_marks || m.time_allowed || paperEndImage ||
    paperMcqs.some(x => x.q || (x.options||[]).some(Boolean)) || paperBlanks.some(x => x.q) || paperTF.some(x => x.q) ||
    paperMatchA.some(Boolean) || paperMatchB.some(Boolean) || paperShort.some(x => x.q) || paperLong.some(x => x.q) ||
    Object.values(paperInstructions).some(Boolean) || Object.values(paperSectionTitles).some(Boolean) ||
    Object.values(paperBreaks).some(arr => (arr||[]).some(Boolean)));
}
function pqStoreBackup() {
  try { localStorage.setItem(PQ_BACKUP_KEY, JSON.stringify(pqSnapshot(true))); }
  catch (e) { try { localStorage.setItem(PQ_BACKUP_KEY, JSON.stringify(pqSnapshot(false))); } catch (e2) {} }
}
function pqHasBackup() { try { return !!localStorage.getItem(PQ_BACKUP_KEY); } catch (e) { return false; } }
function pqResetPaper() {
  paperMeta = { school_name: paperMeta.school_name, logo: paperMeta.logo, exam_name: '', class_name: '', subject: '', total_marks: '', time_allowed: '', exam_date: '' };
  paperMcqMarksEach = 1;
  paperMcqs = [ { no:1, q:'', options:['','','',''] } ];
  paperBlanks = [ { no:1, q:'' } ];
  paperTF = [ { no:1, q:'' } ];
  paperMatchA = [ '', '' ];
  paperMatchB = [ '', '' ];
  paperShort = [ { no:1, q:'', marks:'' } ];
  paperLong = [ { no:1, q:'', marks:'' } ];
  paperInstructions = { mcq:'', blanks:'', tf:'', match:'', short:'', long:'' };
  paperSectionTitles = { a:'', b:'', c:'' };
  paperBreaks = { a:[], b:[], c:[] };
  paperEndImage = null;
  paperTables = [];
}
function newPaper() {
  const ur = LANG === 'ur';
  if (pqHasContent()) {
    if (!confirm(ur ? 'سب کچھ صاف کر کے نیا پرچہ شروع کریں؟ موجودہ پرچہ محفوظ رہے گا، آپ اسے واپس لا سکتے ہیں۔'
                    : 'Clear everything and start a new paper? The current paper is kept, so you can restore it.')) return;
    pqStoreBackup();
  }
  pqResetPaper();
  pqFlush();
  renderTab();
}
function restorePreviousPaper() {
  const ur = LANG === 'ur';
  let raw = null;
  try { raw = localStorage.getItem(PQ_BACKUP_KEY); } catch (e) {}
  if (!raw) return;
  if (pqHasContent() && !confirm(ur ? 'پچھلا پرچہ واپس لائیں؟ موجودہ پرچہ اس کی جگہ محفوظ ہو جائے گا۔'
                                    : 'Restore the previous paper? The current paper will be kept in its place.')) return;
  let d; try { d = JSON.parse(raw); } catch (e) { return; }
  const current = pqHasContent() ? JSON.stringify(pqSnapshot(true)) : null;
  pqResetPaper();
  const arr = (v, def) => (Array.isArray(v) && v.length ? v : def);
  if (d.paperMeta) paperMeta = Object.assign(paperMeta, d.paperMeta);
  if (d.paperMcqMarksEach != null) paperMcqMarksEach = d.paperMcqMarksEach;
  paperMcqs = arr(d.paperMcqs, paperMcqs); paperBlanks = arr(d.paperBlanks, paperBlanks); paperTF = arr(d.paperTF, paperTF);
  paperMatchA = arr(d.paperMatchA, paperMatchA); paperMatchB = arr(d.paperMatchB, paperMatchB);
  paperShort = arr(d.paperShort, paperShort); paperLong = arr(d.paperLong, paperLong);
  if (d.paperInstructions) paperInstructions = Object.assign(paperInstructions, d.paperInstructions);
  if (d.paperSectionTitles) paperSectionTitles = Object.assign(paperSectionTitles, d.paperSectionTitles);
  if (d.paperBreaks) paperBreaks = Object.assign(paperBreaks, d.paperBreaks);
  paperEndImage = d.paperEndImage || null;
  try { if (current) localStorage.setItem(PQ_BACKUP_KEY, current); else localStorage.removeItem(PQ_BACKUP_KEY); } catch (e) {}
  pqFlush();
  renderTab();
}
document.addEventListener('input', () => { try { if (TAB === 'papers') pqScheduleSave(); } catch (e) {} }, true);
document.addEventListener('change', () => { try { if (TAB === 'papers') pqScheduleSave(); } catch (e) {} }, true);
document.addEventListener('click', () => { try { if (TAB === 'papers') pqScheduleSave(); } catch (e) {} }, true); // add/remove question, image buttons
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') pqFlush(); });
window.addEventListener('pagehide', pqFlush);
window.addEventListener('beforeunload', pqFlush);

function ensurePaperMetaDefaults() {
  if (!paperMeta.school_name) paperMeta.school_name = dmcSchoolName || (CURRENT_PROFILE && CURRENT_PROFILE.school_name) || '';
  if (!paperMeta.logo) paperMeta.logo = dmcLogo || null;
  if (!paperMeta.exam_date) paperMeta.exam_date = todayISO();
}
function handlePaperLogoUpload(file) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => { paperMeta.logo = e.target.result; renderTab(); };
  reader.readAsDataURL(file);
}
function addPaperMcq() { paperMcqs.push({ no:paperMcqs.length+1, q:'', options:['','','',''] }); renderTab(); }
function removePaperMcq(i) { paperMcqs.splice(i,1); if (!paperMcqs.length) paperMcqs.push({no:1,q:'',options:['','','','']}); renderTab(); }
function addPaperBlank() { paperBlanks.push({ no:paperBlanks.length+1, q:'' }); renderTab(); }
function removePaperBlank(i) { paperBlanks.splice(i,1); if (!paperBlanks.length) paperBlanks.push({no:1,q:''}); renderTab(); }
function addPaperTF() { paperTF.push({ no:paperTF.length+1, q:'' }); renderTab(); }
function removePaperTF(i) { paperTF.splice(i,1); if (!paperTF.length) paperTF.push({no:1,q:''}); renderTab(); }
function addMatchA() { paperMatchA.push(''); renderTab(); }
function removeMatchA(i) { paperMatchA.splice(i,1); renderTab(); }
function addMatchB() { paperMatchB.push(''); renderTab(); }
function removeMatchB(i) { paperMatchB.splice(i,1); renderTab(); }
function addPaperShort() { paperShort.push({ no:paperShort.length+1, q:'', marks:'' }); renderTab(); }
function removePaperShort(i) { paperShort.splice(i,1); if (!paperShort.length) paperShort.push({no:1,q:'',marks:''}); renderTab(); }
function addPaperLong() { paperLong.push({ no:paperLong.length+1, q:'', marks:'' }); renderTab(); }
function removePaperLong(i) { paperLong.splice(i,1); if (!paperLong.length) paperLong.push({no:1,q:'',marks:''}); renderTab(); }
// Shared handler for the single end-of-paper image — reads the file as a
// data URL, strips its background (see removeImageBackground below), then
// embeds it directly in the printed paper with no server/storage round trip.
function handlePaperEndImageUpload(file) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    removeImageBackground(e.target.result, processed => { paperEndImage = processed; renderTab(); });
  };
  reader.readAsDataURL(file);
}
function removePaperEndImage() { paperEndImage = null; renderTab(); }

// Automatic background removal for uploaded diagrams: most textbook/scanned
// diagrams sit on a plain white (or near-white) page, so this samples the
// four corners of the image to find that background shade, then makes every
// pixel close to it fully transparent by editing the canvas alpha channel.
// This is a plain-canvas heuristic (no ML model, no network call — keeping
// the app fully self-contained/offline), so it works well for line diagrams
// and scanned pages on a plain background, but won't cleanly separate a
// busy or photographic background the way an AI cutout tool would.
function removeImageBackground(dataUrl, callback) {
  const img = new Image();
  img.onload = () => {
    try {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth; canvas.height = img.naturalHeight;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);
      const { width: w, height: h } = canvas;
      const imgData = ctx.getImageData(0, 0, w, h);
      const d = imgData.data;
      // Sample the four corners to estimate the background color.
      const corners = [0, (w-1)*4, (h-1)*w*4, ((h-1)*w + (w-1))*4];
      let br=0, bg=0, bb=0;
      corners.forEach(c => { br += d[c]; bg += d[c+1]; bb += d[c+2]; });
      br/=4; bg/=4; bb/=4;
      const threshold = 32; // max per-channel distance from the sampled background to treat as background
      for (let p = 0; p < d.length; p += 4) {
        const dr = d[p]-br, dg = d[p+1]-bg, db = d[p+2]-bb;
        if (Math.abs(dr) < threshold && Math.abs(dg) < threshold && Math.abs(db) < threshold) {
          d[p+3] = 0;
        }
      }
      ctx.putImageData(imgData, 0, 0);
      callback(canvas.toDataURL('image/png'));
    } catch (e) {
      callback(dataUrl); // e.g. a tainted/cross-origin canvas — fall back to the original image
    }
  };
  img.onerror = () => callback(dataUrl);
  img.src = dataUrl;
}

// Renders the optional break/divider box after the 5th, 10th, 15th... row of
// a section's list (see paperBreaks). Returns '' everywhere else, so it's
// safe to append to every row's markup unconditionally.
// Once a section reaches its 5th question, every question from there on
// (5th, 6th, 7th, 8th, 9th, ...) gets its own optional divider box right
// after it — not just every 5th one — so a user can drop a line wherever
// they want past that point (grp = i, one slot per row).
function pqBreakBox(section, i) {
  if (i + 1 < 5) return '';
  const grp = i;
  const val = (paperBreaks[section] && paperBreaks[section][grp]) || '';
  return `
    <div class="flexgap paper-q-row" style="align-items:center;background:#F3EEDD;border-radius:8px;padding:8px 10px;">
      <input dir="auto" style="flex:1;text-align:center;font-style:italic;background:transparent;border:1px dashed var(--line);" placeholder="${esc(t.paperBreakPh)}" value="${esc(val)}" oninput="pqSetBreak('${section}',${grp},this.value)">
    </div>`;
}
function pqSetBreak(section, grp, val) {
  if (!paperBreaks[section]) paperBreaks[section] = [];
  paperBreaks[section][grp] = val;
  pqScheduleSave();
}


// ---------- Nursery / KG paper mode ----------
let paperMode = 'std';
let kgBlocks = [];
const KG_TYPES = { trace:'✏️ Trace letters / numbers', missing:'🔤 Missing letters', picname:'🖼️ Write picture name', match:'🔗 Match pictures & names', count:'🔢 Count & write', colour:'🎨 Colour the picture', compare:'⚖️ Compare (big/small, long/short…)', mcq:'☑️ MCQs' };
function setPaperMode(m) {
  paperMode = m;
  if (m === 'kg' && !kgBlocks.length) {
    kgBlocks = [
      { type:'trace', title:'Trace the letters', items:[{txt:'A B C D E F'}] },
      { type:'missing', title:'Fill in the missing letters', items:[{txt:'A _ C'},{txt:'_ E F'}] },
      { type:'picname', title:'Write the name of the picture', items:[{img:null,txt:''},{img:null,txt:''},{img:null,txt:''}] },
      { type:'match', title:'Match the pictures with names', items:[{img:null,txt:''},{img:null,txt:''},{img:null,txt:''}] }
    ];
  }
  renderTab();
}
function kgAddBlock(sel) { const ty = sel.value; if (!ty) return;
  kgBlocks.push({ type:ty, title:'', items: (ty==='trace'||ty==='missing') ? [{txt:''}] : ty==='compare' ? [{pair:true,img:null,img2:null,txt:'',txt2:''}] : [{img:null,txt:''},{img:null,txt:''}] }); renderTab(); }
function kgDelBlock(i) { kgBlocks.splice(i,1); renderTab(); }
function kgMoveBlock(i,d) { const j=i+d; if (j<0||j>=kgBlocks.length) return; [kgBlocks[i],kgBlocks[j]]=[kgBlocks[j],kgBlocks[i]]; renderTab(); }
function kgAddItem(i) { kgBlocks[i].items.push(kgBlocks[i].type==='compare' ? {pair:true,img:null,img2:null,txt:'',txt2:''} : {img:null,txt:''}); renderTab(); }
function kgDelItem(i,j) { kgBlocks[i].items.splice(j,1); renderTab(); }
function kgItemImg(i,j,file,s) {
  if (!file) return;
  const r = new FileReader();
  r.onload = e => { const im = new Image(); im.onload = () => {
    const k = Math.min(1, 320/Math.max(im.width, im.height)); const c = document.createElement('canvas');
    c.width = Math.round(im.width*k); c.height = Math.round(im.height*k);
    c.getContext('2d').drawImage(im,0,0,c.width,c.height);
    kgBlocks[i].items[j][s==='R'?'img2':'img'] = c.toDataURL('image/png'); renderTab(); }; im.src = e.target.result; };
  r.readAsDataURL(file);
}
// ---------- Nursery / KG picture library + resizable pictures ----------
const KG_SHAPES = {
  circle:'<circle cx="50" cy="50" r="44"/>', square:'<rect x="8" y="8" width="84" height="84"/>', rectangle:'<rect x="4" y="22" width="92" height="56"/>',
  triangle:'<polygon points="50,8 94,90 6,90"/>', oval:'<ellipse cx="50" cy="50" rx="46" ry="30"/>', diamond:'<polygon points="50,4 92,50 50,96 8,50"/>',
  star:'<polygon points="50,6 61,38 95,38 67,58 78,92 50,71 22,92 33,58 5,38 39,38"/>', pentagon:'<polygon points="50,6 94,38 77,90 23,90 6,38"/>',
  hexagon:'<polygon points="27,8 73,8 96,50 73,92 27,92 4,50"/>', heart:'<path d="M50 88C10 56 6 30 26 18 40 10 50 22 50 30 50 22 60 10 74 18 94 30 90 56 50 88Z"/>',
  crescent:'<path d="M70 10A42 42 0 1 0 70 90 32 32 0 1 1 70 10Z"/>', semicircle:'<path d="M6 70A44 44 0 0 1 94 70Z"/>'
};
const KG_LIB = {
  animals:['🐶 Animals',['🐶 Dog','🐱 Cat','🐮 Cow','🐴 Horse','🐑 Sheep','🐐 Goat','🐘 Elephant','🦁 Lion','🐯 Tiger','🐵 Monkey','🐰 Rabbit','🐻 Bear','🦒 Giraffe','🐍 Snake','🐢 Turtle','🐟 Fish','🐦 Bird','🦆 Duck','🐔 Hen','🐫 Camel','🦓 Zebra','🐊 Crocodile','🦋 Butterfly','🐝 Bee']],
  fruits:['🍎 Fruits',['🍎 Apple','🍌 Banana','🍇 Grapes','🍊 Orange','🍉 Watermelon','🍓 Strawberry','🍍 Pineapple','🥭 Mango','🍐 Pear','🍒 Cherry','🍑 Peach','🍋 Lemon','🥥 Coconut','🍈 Melon','🥝 Kiwi']],
  veg:['🥕 Vegetables',['🥕 Carrot','🍅 Tomato','🥔 Potato','🧅 Onion','🥒 Cucumber','🌽 Corn','🥦 Broccoli','🍆 Brinjal','🌶️ Chilli','🧄 Garlic','🥬 Cabbage','🫑 Capsicum','🍄 Mushroom']],
  prof:['👨‍⚕️ Professions',['👨‍⚕️ Doctor','👩‍🏫 Teacher','👮 Police','👨‍🍳 Cook','👨‍🌾 Farmer','👨‍✈️ Pilot','👨‍🚒 Fireman','👷 Builder','👨‍🔧 Mechanic','🧑‍🎨 Artist','👨‍🚀 Astronaut','💂 Soldier','🧑‍⚖️ Judge']],
  colours:['🎨 Colours',['color:#e53935 Red','color:#1e88e5 Blue','color:#43a047 Green','color:#fdd835 Yellow','color:#fb8c00 Orange','color:#8e24aa Purple','color:#ec407a Pink','color:#6d4c41 Brown','color:#212121 Black','color:#ffffff White','color:#9e9e9e Grey','color:#4fc3f7 Sky blue']],
  shapes:['◼️ Shapes',Object.keys(KG_SHAPES).map(k => 'shape:' + k + ' ' + k.charAt(0).toUpperCase() + k.slice(1))],
  dress:['👕 Dresses',['👕 Shirt','👖 Pants','👗 Frock','🧢 Cap','🧦 Socks','👟 Shoes','🧥 Coat','🧣 Scarf','🧤 Gloves','👔 Tie','👒 Hat','🩳 Shorts','👜 Bag','🎒 School bag','🧕 Hijab']],
  flowers:['🌹 Flowers',['🌹 Rose','🌻 Sunflower','🌷 Tulip','🌼 Daisy','🪷 Lotus','🌺 Hibiscus','💐 Bouquet','🌸 Blossom']],
  vehicles:['🚗 Vehicles',['🚗 Car','🚌 Bus','🚲 Bicycle','✈️ Aeroplane','🚂 Train','🚢 Ship','🚁 Helicopter','🏍️ Bike','🚜 Tractor','🚑 Ambulance']],
  school:['✏️ School',['✏️ Pencil','📖 Book','🖊️ Pen','📏 Ruler','✂️ Scissors','🎒 Bag','🖍️ Crayons','🔔 Bell','⚽ Ball','🕌 Masjid']],
  people:['👨 People',['👨 Man','👩 Woman','👴 Old man','👵 Old woman','👦 Boy','👧 Girl','👶 Baby','🧔 Bearded man','👳 Man (turban)','🧕 Woman (hijab)','👨‍🦱 Curly-hair man','👩‍🦰 Red-hair woman','👨‍🦳 Grey-hair man','👩‍🦳 Grey-hair woman','🧑 Person','👪 Family','👸 Princess','🤴 Prince','🧒 Child','👱 Blond person']],
  food:['🍦 Food & Drinks',['🍦 Ice cream','🍵 Tea','☕ Coffee','🥛 Milk','🍞 Bread','🥚 Egg','🎂 Cake','🍕 Pizza','🍔 Burger','🍚 Rice','🧀 Cheese','🍯 Honey','🧃 Juice','💧 Water','🍪 Biscuit','🍫 Chocolate','🍬 Candy','🫓 Roti','🍗 Chicken','🍟 Fries','🍩 Doughnut','🥤 Cold drink','🍿 Popcorn','🥜 Peanuts']],
  home:['🏠 Home',['🏠 House','🪑 Chair','🛏️ Bed','🕐 Clock','💡 Bulb','🚪 Door','🔑 Key','🥄 Spoon','🍴 Fork','🍽️ Plate','🪟 Window','🛋️ Sofa','📺 TV','☎️ Phone','🧹 Broom','🪞 Mirror','🔦 Torch','☂️ Umbrella']],
  nature:['☀️ Nature',['☀️ Sun','🌙 Moon','⭐ Star','🌳 Tree','☁️ Cloud','🌧️ Rain','⛰️ Mountain','🌈 Rainbow','🔥 Fire','❄️ Snow','🌊 Wave','🍃 Leaf','🌍 Earth','⚡ Lightning']],
  body:['👁️ Body',['👁️ Eye','👂 Ear','👃 Nose','👄 Mouth','✋ Hand','🦶 Foot','🦷 Tooth','👅 Tongue','🦵 Leg','💪 Arm','🧠 Brain','🦴 Bone']]
};
const _st = (x, y, k, f) => `<polygon fill="${f}" transform="translate(${x} ${y}) scale(${k})" points="0,-10 2.9,-4 9.5,-3.1 4.7,1.5 5.9,8.1 0,5 -5.9,8.1 -4.7,1.5 -9.5,-3.1 -2.9,-4"/>`;
const _h = (a, b, c) => `<rect width="150" height="34" fill="${a}"/><rect y="33" width="150" height="34" fill="${b}"/><rect y="66" width="150" height="34" fill="${c}"/>`;
const _v = (a, b, c) => `<rect width="50" height="100" fill="${a}"/><rect x="50" width="50" height="100" fill="${b}"/><rect x="100" width="50" height="100" fill="${c}"/>`;
const KG_FLAGS = {
  pk:['Pakistan', '<rect width="150" height="100" fill="#01411c"/><rect width="37" height="100" fill="#fff"/><circle cx="95" cy="50" r="27" fill="#fff"/><circle cx="105" cy="44" r="24" fill="#01411c"/>' + _st(112, 38, 1.5, '#fff')],
  in:['India', _h('#f93', '#fff', '#138808') + '<circle cx="75" cy="50" r="11" fill="none" stroke="#008" stroke-width="2.5"/>'],
  sa:['Saudi Arabia', '<rect width="150" height="100" fill="#006c35"/><rect x="35" y="34" width="80" height="7" rx="3" fill="#fff"/><rect x="38" y="66" width="74" height="4" fill="#fff"/>'],
  tr:['Turkey', '<rect width="150" height="100" fill="#e30a17"/><circle cx="55" cy="50" r="24" fill="#fff"/><circle cx="62" cy="50" r="19" fill="#e30a17"/>' + _st(90, 50, 1.6, '#fff')],
  gb:['United Kingdom', '<rect width="150" height="100" fill="#012169"/><path d="M0 0L150 100M150 0L0 100" stroke="#fff" stroke-width="16"/><path d="M0 0L150 100M150 0L0 100" stroke="#c8102e" stroke-width="6"/><path d="M75 0V100M0 50H150" stroke="#fff" stroke-width="26"/><path d="M75 0V100M0 50H150" stroke="#c8102e" stroke-width="15"/>'],
  us:['USA', Array.from({ length: 13 }, (_, k) => `<rect y="${k * 100 / 13}" width="150" height="${100 / 13 + .3}" fill="${k % 2 ? '#fff' : '#b22234'}"/>`).join('') + '<rect width="66" height="54" fill="#3c3b6e"/>' + [0, 1, 2].map(c => [0, 1, 2, 3].map(r => _st(12 + c * 21, 10 + r * 13, .55, '#fff')).join('')).join('')],
  cn:['China', '<rect width="150" height="100" fill="#de2910"/>' + _st(25, 27, 3, '#ffde00') + _st(52, 10, 1, '#ffde00') + _st(62, 22, 1, '#ffde00') + _st(62, 36, 1, '#ffde00') + _st(52, 48, 1, '#ffde00')],
  jp:['Japan', '<rect width="150" height="100" fill="#fff"/><circle cx="75" cy="50" r="30" fill="#bc002d"/>'],
  bd:['Bangladesh', '<rect width="150" height="100" fill="#006a4e"/><circle cx="67" cy="50" r="28" fill="#f42a41"/>'],
  af:['Afghanistan', _v('#000', '#d32011', '#007a36')],
  ir:['Iran', _h('#239f40', '#fff', '#da0000')],
  ae:['UAE', _h('#00732f', '#fff', '#000') + '<rect width="38" height="100" fill="#f00"/>'],
  eg:['Egypt', _h('#ce1126', '#fff', '#000')],
  ps:['Palestine', _h('#000', '#fff', '#007a3d') + '<polygon points="0,0 55,50 0,100" fill="#ce1126"/>'],
  fr:['France', _v('#0055a4', '#fff', '#ef4135')],
  de:['Germany', _h('#000', '#dd0000', '#ffce00')],
  it:['Italy', _v('#009246', '#fff', '#ce2b37')],
  ru:['Russia', _h('#fff', '#0039a6', '#d52b1e')]
};
KG_LIB.flags = ['🏳️ Flags', Object.keys(KG_FLAGS).map(k => 'flag:' + k + ' ' + KG_FLAGS[k][0])];
const _note = (n, c1, c2) => `<rect x="1" y="1" width="148" height="68" rx="4" fill="${c1}" stroke="#222" stroke-width="2"/><rect x="6" y="6" width="138" height="58" rx="3" fill="none" stroke="${c2}" stroke-width="2"/><rect x="10" y="10" width="40" height="50" rx="3" fill="${c2}" opacity=".35"/><circle cx="30" cy="30" r="12" fill="${c2}" opacity=".6"/><path d="M12 60Q30 40 48 60Z" fill="${c2}" opacity=".6"/><text x="98" y="26" font-size="11" font-weight="700" text-anchor="middle" fill="#222" font-family="Arial,sans-serif">PAKISTAN</text><text x="98" y="52" font-size="24" font-weight="800" text-anchor="middle" fill="#111" font-family="Arial,sans-serif">Rs ${n}</text>`;
const _coin = (n, c1, c2) => `<circle cx="50" cy="50" r="46" fill="${c1}" stroke="#222" stroke-width="3"/><circle cx="50" cy="50" r="36" fill="none" stroke="${c2}" stroke-width="3"/><text x="50" y="62" font-size="36" font-weight="800" text-anchor="middle" fill="#222" font-family="Arial,sans-serif">${n}</text>`;
[[10, '#b9e0a5', '#3f8f2e'], [20, '#f6c68b', '#d9741c'], [50, '#d7b3e6', '#8e3fa8'], [100, '#f4a9a9', '#c62828'], [500, '#a8d8b0', '#1e7a3c'], [1000, '#a9c8ee', '#1e5aa8'], [5000, '#d9c39a', '#8a6a2b']]
  .forEach(a => { KG_FLAGS['n' + a[0]] = ['Rs ' + a[0] + ' note', _note(a[0], a[1], a[2]), '0 0 150 70']; });
[[1, '#cfd3d6', '#8a9096'], [2, '#cfd3d6', '#8a9096'], [5, '#e3c86a', '#a88a1d'], [10, '#e3c86a', '#a88a1d']]
  .forEach(a => { KG_FLAGS['c' + a[0]] = ['Rs ' + a[0] + ' coin', _coin(a[0], a[1], a[2]), '0 0 100 100']; });
KG_LIB.money = ['💵 Pakistani Money', ['n10', 'n20', 'n50', 'n100', 'n500', 'n1000', 'n5000', 'c1', 'c2', 'c5', 'c10'].map(k => 'flag:' + k + ' ' + KG_FLAGS[k][0])];
let kgLibOpen = -1, kgLibCatSel = 'animals';
const kgDef = type => type === 'colour' ? 150 : (type === 'count' ? 30 : 64);
function kgEntry(str) { const i = str.indexOf(' '); return [str.slice(0, i), str.slice(i + 1)]; }   // [code, name]
const _emo = {};
function emojiPng(e, z) { z = z || 512; const key = e + z; if (_emo[key]) return _emo[key]; const c = document.createElement('canvas'); c.width = c.height = z; const x = c.getContext('2d'); x.font = (z * .84) + "px 'Noto Color Emoji','Apple Color Emoji','Segoe UI Emoji',sans-serif"; x.textAlign = 'center'; x.fillText(e, z / 2, z * .79); return _emo[key] = c.toDataURL('image/png'); }
function kpic(it, cls, fit) {
  const w = it.w ? it.w + 'px' : '', h = it.h ? it.h + 'px' : '';
  const st = (it.w || it.h) ? ` style="${w ? 'width:' + w + ';' : ''}${h ? 'height:' + h + ';' : ''}max-width:none;object-fit:${fit || 'fill'};"` : '';
  const svgOpen = `<svg viewBox="0 0 100 100" preserveAspectRatio="none" class="${cls}"${(it.w || it.h) ? ` width="${it.w || it.h}" height="${it.h || it.w}" style="width:${it.w || it.h}px;height:${it.h || it.w}px;max-width:none;"` : ''}`;
  if (it.img) return `<img src="${it.img}" class="${cls}"${fit === 'contain' ? st.replace('object-fit:fill', 'object-fit:contain') : st}>`;
  const e = it.em || '';
  if (e.startsWith('shape:')) return `${svgOpen} fill="#fff" stroke="#222" stroke-width="4" stroke-linejoin="round">${KG_SHAPES[e.slice(6)] || ''}</svg>`;
  if (e.startsWith('color:')) return `${svgOpen}><rect x="4" y="4" width="92" height="92" rx="14" fill="${e.slice(6)}" stroke="#222" stroke-width="3"/></svg>`;
  if (e.startsWith('flag:')) { const f = KG_FLAGS[e.slice(5)], fw = it.w || it.h, fh = it.h || it.w; return `<svg viewBox="${f && f[2] || '0 0 150 100'}" preserveAspectRatio="xMidYMid meet" class="${cls}"${fw ? ` width="${fw}" height="${fh}" style="width:${fw}px;height:${fh}px;max-width:none;"` : ''}>${f ? f[1] : ''}${f && f[2] ? '' : '<rect width="150" height="100" fill="none" stroke="#222" stroke-width="3"/>'}</svg>`; }
  if (e) { const sz = (it.w || it.h) ? ` style="width:${it.w || it.h}px;height:${it.h || it.w}px;max-width:none;object-fit:contain;"` : ' style="object-fit:contain;"'; return `<img src="${emojiPng(e, (it.w && it.w <= 60 && (it.h || it.w) <= 60) ? 128 : 512)}" class="${cls}"${sz}>`; }
  return `<span class="${cls} kg-emptybox"></span>`;
}
function kgSize(i, j, k, v) { const it = kgBlocks[i].items[j], d = kgDef(kgBlocks[i].type); it.w = it.w || d; it.h = it.h || d; it[k] = +v; try { pqScheduleSave(); } catch (e) {} }
function kgPreset(i, j, f) { const it = kgBlocks[i].items[j], d = kgDef(kgBlocks[i].type); it.w = Math.round(d * f); it.h = Math.round(d * f); kgRefreshBlock(i); }

const kgSk = (s, k) => s === 'R' ? k + '2' : k;
function kgZoom(i, j, s, f) { const it = kgBlocks[i].items[j], d = kgDef(kgBlocks[i].type), a = kgSk(s,'w'), b = kgSk(s,'h');
  it[a] = Math.max(20, Math.min(400, Math.round((it[a] || d) * f))); it[b] = Math.max(20, Math.min(400, Math.round((it[b] || d) * f)));
  kgRefreshBlock(i); }
function kgSideSize(i, j, s, k, v) { const it = kgBlocks[i].items[j], a = kgSk(s,'w'), b = kgSk(s,'h'); it[a] = it[a] || 64; it[b] = it[b] || 64; it[kgSk(s,k)] = +v; try { pqScheduleSave(); } catch (e) {} }
function kgSideClear(i, j, s) { const it = kgBlocks[i].items[j]; it[kgSk(s,'img')] = null; it[kgSk(s,'em')] = null; try { pqScheduleSave(); } catch (e) {} renderTab(); }
let kgCmpT = null;
function kgCmpPick(cat, idx) { const t = kgCmpT; if (!t) return; const [code] = kgEntry(KG_LIB[cat][1][idx]), it = kgBlocks[t.i].items[t.j];
  it[kgSk(t.s,'em')] = code; it[kgSk(t.s,'img')] = null; if (!it[kgSk(t.s,'w')]) it[kgSk(t.s,'w')] = it[kgSk(t.s,'h')] = 64;
  kgCmpT = t.s === 'L' ? { i: t.i, j: t.j, s: 'R' } : null; kgRefreshBlock(t.i); }
function kgPairEditor(i, j, it) {
  const side = (s, lab) => { const sx = s === 'R' ? '2' : '', cw = it['w' + sx] || 64, ch = it['h' + sx] || 64, has = it['img' + sx] || it['em' + sx], on = kgCmpT && kgCmpT.i === i && kgCmpT.j === j && kgCmpT.s === s;
    return `<div style="flex:1;min-width:0;border:1px solid var(--line,#ddd);border-radius:10px;padding:6px;">
      <div style="font-size:11px;font-weight:700;margin-bottom:4px;">${lab}</div>
      <div style="display:flex;gap:4px;align-items:center;flex-wrap:wrap;">
        <span style="display:block;width:48px;height:48px;border:1px solid var(--line,#ddd);border-radius:8px;overflow:hidden;flex-shrink:0;">${has ? kpic({ img: it['img' + sx], em: it['em' + sx], w: 46, h: 46 }, '', 'contain') : ''}</span>
        <button class="${on ? 'btn-primary' : 'btn-ghost'}" style="padding:4px 8px;font-size:12px;" onclick="kgCmpT={i:${i},j:${j},s:'${s}'};renderTab()">📚</button>
        <label class="btn-ghost" style="padding:4px 8px;font-size:12px;cursor:pointer;">📷<input type="file" accept="image/*" style="display:none;" onchange="kgItemImg(${i},${j},this.files[0],'${s}')"></label>
        <button class="btn-ghost" style="padding:4px 8px;font-size:12px;" onclick="kgSideClear(${i},${j},'${s}')">🗑</button></div>
      <input dir="auto" style="width:100%;margin-top:6px;" placeholder="label (e.g. Big)" value="${esc(it['txt' + sx] || '')}" oninput="kgBlocks[${i}].items[${j}].txt${sx}=this.value">
      <div style="display:flex;align-items:center;gap:4px;margin-top:6px;font-size:11px;">
        <span>↔</span><input type="range" min="20" max="400" value="${cw}" style="flex:1;min-width:0;" oninput="kgSideSize(${i},${j},'${s}','w',this.value)">
        <span>↕</span><input type="range" min="20" max="400" value="${ch}" style="flex:1;min-width:0;" oninput="kgSideSize(${i},${j},'${s}','h',this.value)"></div>
      <div style="display:flex;gap:4px;margin-top:4px;"><button class="btn-ghost" style="padding:2px 8px;flex:1;" onclick="kgZoom(${i},${j},'${s}',0.85)">🔍－</button><button class="btn-ghost" style="padding:2px 8px;flex:1;" onclick="kgZoom(${i},${j},'${s}',1.2)">🔍＋</button></div></div>`; };
  return `<div class="paper-q-row" style="margin-bottom:10px;padding-bottom:10px;border-bottom:1px dashed var(--line,#ddd);">
    <div style="display:flex;gap:8px;align-items:flex-start;">${side('L', '⬅ Left picture')}${side('R', 'Right picture ➡')}<button class="btn-ghost" style="padding:6px 10px;" onclick="kgDelItem(${i},${j})">✕</button></div>
    ${kgCmpT && kgCmpT.i === i && kgCmpT.j === j ? `<div style="font-size:12px;margin-top:8px;">Picking for: <b>${kgCmpT.s === 'L' ? 'Left' : 'Right'}</b> <button class="btn-ghost" style="padding:2px 8px;" onclick="kgCmpT=null;renderTab()">Close</button></div>` + kgLibHtml(i, 'cmp') : ''}</div>`; }

// ---- Nursery/KG: phone storage (IndexedDB), New Paper, Previous Paper ----
const KG_DB = 'kgPapers', KG_ST = 'kv';
function kgDb() { return new Promise((res, rej) => { try { const r = indexedDB.open(KG_DB, 1); r.onupgradeneeded = () => r.result.createObjectStore(KG_ST); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); } catch (e) { rej(e); } }); }
function kgKvSet(k, v) { return kgDb().then(db => new Promise((res, rej) => { const tx = db.transaction(KG_ST, 'readwrite'); tx.objectStore(KG_ST).put(v, k); tx.oncomplete = () => res(true); tx.onerror = () => rej(tx.error); }))
  .catch(() => { try { localStorage.setItem('kgkv_' + k, JSON.stringify(v)); return true; } catch (e) { return false; } }); }
function kgKvGet(k) { return kgDb().then(db => new Promise((res, rej) => { const q = db.transaction(KG_ST).objectStore(KG_ST).get(k); q.onsuccess = () => res(q.result === undefined ? null : q.result); q.onerror = () => rej(q.error); }))
  .catch(() => { try { const r = localStorage.getItem('kgkv_' + k); return r ? JSON.parse(r) : null; } catch (e) { return null; } }); }
function kgKvDel(k) { return kgDb().then(db => new Promise((res) => { const tx = db.transaction(KG_ST, 'readwrite'); tx.objectStore(KG_ST).delete(k); tx.oncomplete = () => res(true); tx.onerror = () => res(false); }))
  .catch(() => { try { localStorage.removeItem('kgkv_' + k); } catch (e) {} return false; }); }
let kgReady = false, kgHasBackup = false;
const kgSnap = () => ({ t: Date.now(), paperMeta: Object.assign({}, paperMeta), kgBlocks: kgBlocks });
function kgIdbSave() { if (!kgReady || paperMode !== 'kg') return; return kgKvSet('draft', kgSnap()); }
Promise.all([kgKvGet('draft'), kgKvGet('backup')]).then(([d, b]) => {
  if (d && Array.isArray(d.kgBlocks) && d.kgBlocks.length) kgBlocks = d.kgBlocks;
  kgHasBackup = !!b; kgReady = true;
  try { if (TAB === 'papers' && paperMode === 'kg') renderTab(); } catch (e) {} });
window.addEventListener('pagehide', () => { try { pqFlush(); } catch (e) {} });
const kgItemHas = x => !!((x.txt || '').trim() || (x.txt2 || '').trim() || x.img || x.img2 || x.em || x.em2 || (x.qp || []).length || (x.op || []).some(a => a && a.length) || (x.o || []).some(Boolean));
function kgHasContent() { return kgBlocks.some(b => (b.title || '').trim() || b.items.some(kgItemHas)) || !!(paperMeta.exam_name || paperMeta.class_name || paperMeta.subject); }
function kgStarter() { return [
  { type:'trace', title:'Trace the letters', items:[{txt:'A B C D E F'}] },
  { type:'missing', title:'Fill in the missing letters', items:[{txt:'A _ C'},{txt:'_ E F'}] },
  { type:'picname', title:'Write the name of the picture', items:[{img:null,txt:''},{img:null,txt:''},{img:null,txt:''}] },
  { type:'match', title:'Match the pictures with names', items:[{img:null,txt:''},{img:null,txt:''},{img:null,txt:''}] } ]; }
async function kgNewPaper() {
  const ur = LANG === 'ur';
  if (kgHasContent()) {
    if (!confirm(ur ? 'سب کچھ صاف کر کے نیا پرچہ شروع کریں؟ موجودہ پرچہ محفوظ رہے گا، آپ اسے واپس لا سکتے ہیں۔' : 'Clear everything and start a new paper? The current paper is kept, so you can restore it.')) return;
    await kgKvSet('backup', kgSnap()); kgHasBackup = true;
  }
  kgBlocks = kgStarter(); kgLibOpen = -1; kgLibT = null; kgCmpT = null;
  paperMeta = { school_name: paperMeta.school_name, logo: paperMeta.logo, exam_name: '', class_name: '', subject: '', total_marks: '', time_allowed: '', exam_date: '' };
  pqFlush(); renderTab(); }
async function kgRestorePrevious() {
  const ur = LANG === 'ur', b = await kgKvGet('backup'); if (!b || !Array.isArray(b.kgBlocks)) return;
  if (kgHasContent() && !confirm(ur ? 'پچھلا پرچہ واپس لائیں؟ موجودہ پرچہ اس کی جگہ محفوظ ہو جائے گا۔' : 'Restore the previous paper? The current paper will be kept in its place.')) return;
  const cur = kgHasContent() ? kgSnap() : null;
  kgBlocks = b.kgBlocks; if (b.paperMeta) paperMeta = Object.assign({}, paperMeta, b.paperMeta);
  kgLibOpen = -1; kgLibT = null; kgCmpT = null;
  if (cur) { await kgKvSet('backup', cur); kgHasBackup = true; } else { await kgKvDel('backup'); kgHasBackup = false; }
  pqFlush(); renderTab(); }
// re-draw only one question block (keeps the page and library exactly where they are)
function kgRefreshBlock(i) { const el = document.getElementById('kgb-' + i); if (!el || !kgBlocks[i]) { renderTab(); return; }
  const lib = document.getElementById('kgLib'), st = lib ? lib.scrollTop : 0, ws = window.scrollY || 0;
  el.innerHTML = kgBlockHtml(kgBlocks[i], i);
  const l2 = document.getElementById('kgLib'); if (l2) l2.scrollTop = st;
  window.scrollTo({ top: ws, left: 0, behavior: 'instant' });
  try { pqScheduleSave(); } catch (e) {} }

// ---- Import a paper from a PDF / photo (both paper modes) ----
const PQ_PDFJS = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.min.js', PQ_PDFJS_W = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.worker.min.js', PQ_TESS = 'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js';
const pqLibP = {};
function pqLoadScript(src) { return pqLibP[src] || (pqLibP[src] = new Promise((res, rej) => { const e = document.createElement('script'); e.src = src; e.onload = res; e.onerror = () => { delete pqLibP[src]; rej(new Error('Internet needed to load PDF reader')); }; document.head.appendChild(e); })); }
function pqImpMsg(t, ms) { let d = document.getElementById('pqImpMsg'); if (!d) { d = document.createElement('div'); d.id = 'pqImpMsg'; d.style.cssText = 'position:fixed;left:50%;bottom:90px;transform:translateX(-50%);background:#222;color:#fff;padding:10px 16px;border-radius:12px;z-index:99999;font-size:14px;max-width:90%;text-align:center;'; document.body.appendChild(d); }
  d.textContent = t; d.style.display = ''; clearTimeout(d._t); if (ms) d._t = setTimeout(() => { d.style.display = 'none'; }, ms); }
const pqNorm = l => String(l || '').replace(/[٠-٩]/g, c => c.charCodeAt(0) - 0x0660).replace(/[۰-۹]/g, c => c.charCodeAt(0) - 0x06F0).replace(/\s+/g, ' ').trim();
function pqLines(items) { const rows = []; items.forEach(it => { if (!it.str) return; const y = it.transform[5], x = it.transform[4]; let r = rows.find(r => Math.abs(r.y - y) < 3); if (!r) rows.push(r = { y, it: [] }); r.it.push({ x, s: it.str }); });
  return rows.sort((a, b) => b.y - a.y).map(r => { const rtl = /[\u0600-\u06FF]/.test(r.it.map(i => i.s).join('')); r.it.sort((a, b) => rtl ? b.x - a.x : a.x - b.x); return r.it.map(i => i.s).join(' '); }); }
async function pqOcr(canvas, n, total) { await pqLoadScript(PQ_TESS);
  const r = await Tesseract.recognize(canvas, LANG === 'ur' ? 'eng+urd' : 'eng', { logger: m => { if (m.status === 'recognizing text') pqImpMsg('🔎 Reading page ' + n + '/' + total + ' … ' + Math.round(m.progress * 100) + '%'); } });
  return r.data.text.split('\n'); }
async function pqImgCanvas(file) { const url = URL.createObjectURL(file); const im = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('Cannot open image')); i.src = url; });
  const c = document.createElement('canvas'), k = Math.min(1, 2200 / Math.max(im.width, im.height)); c.width = im.width * k; c.height = im.height * k; c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); URL.revokeObjectURL(url); return c; }
function pqMeta(lines) { const m = {}, h = lines.slice(0, 14).join('\n'), cl = v => v.replace(/\s*(subject|total|time|date|class|marks?)\b.*$/i, '').trim(), g = re => { const x = h.match(re); return x ? x[1].trim() : ''; };
  const tm = g(/total\s*marks?\s*[:\-]?\s*(\d+)/i), tl = cl(g(/time(?:\s*allowed)?\s*[:\-]?\s*([^\n]{1,30})/i)), c = cl(g(/class\s*[:\-]?\s*([^\n]{1,20})/i)), sb = cl(g(/subject\s*[:\-]?\s*([^\n]{1,30})/i)), ex = lines.slice(0, 6).find(l => /exam|test|term|paper/i.test(l));
  if (tm) m.total_marks = tm; if (tl) m.time_allowed = tl; if (c) m.class_name = c; if (sb) m.subject = sb; if (ex) m.exam_name = ex; return m; }
function pqParseStd(lines) {
  const o = { mcq: [], blank: [], tf: [], short: [], long: [], meta: pqMeta(lines) };
  const secOf = l => /true\s*[\/&]?\s*(or)?\s*false/i.test(l) ? 'tf' : /multiple\s*choice|\bmcqs?\b|correct (answer|option)/i.test(l) ? 'mcq' : /blanks?\b/i.test(l) ? 'blank' : /short/i.test(l) ? 'short' : /long|detail/i.test(l) ? 'long' : null;
  const qRe = /^\s*(?:Q\.?\s*)?(\d{1,3})\s*[.):\-]\s*(.+)/i, mkRe = /\(\s*(\d+)\s*(?:marks?)?\s*\)\s*$/i, tfRe = /\(\s*true\s*\/?\s*false\s*\)/i;
  let sec = 'mcq', cur = null;
  const flush = () => { if (!cur) return; const raw = cur.t.replace(/\s+/g, ' ').trim(); cur = null; if (!raw) return;
    const parts = raw.split(/(?:^|\s)\(?[a-dA-D][.)]\s+/), mk = raw.match(mkRe), t = raw.replace(mkRe, '').trim();
    if (parts.length >= 3) { const op = parts.slice(1, 5).map(x => x.trim()); while (op.length < 4) op.push(''); o.mcq.push({ q: parts[0].trim(), o: op }); }
    else if (sec === 'tf' || tfRe.test(raw)) o.tf.push({ q: t.replace(tfRe, '').trim() });
    else if (sec === 'blank' || /_{2,}|…|\.{4,}/.test(raw)) o.blank.push({ q: t });
    else (sec === 'long' ? o.long : o.short).push({ q: t, m: mk ? mk[1] : '' }); };
  lines.forEach(l => { const sc = secOf(l), q = l.match(qRe);
    if (sc && l.length < 110 && !/_{3,}|\?\s*$/.test(l) && (/^\s*(section|part|q\.?\s*\d)/i.test(l) || !q)) { flush(); sec = sc; return; }
    if (q) { flush(); cur = { t: q[2] }; } else if (cur) cur.t += ' ' + l; });
  flush(); return o; }
function pqParseKg(lines) {
  const ty = t => /trace/i.test(t) ? 'trace' : /match|join/i.test(t) ? 'match' : /colou?r/i.test(t) ? 'colour' : /count/i.test(t) ? 'count' : /big|small|tall|short|compar|more|less/i.test(t) ? 'compare' : /missing|fill/i.test(t) ? 'missing' : /name|picture/i.test(t) ? 'picname' : /choose|circle|tick|select/i.test(t) ? 'mcq' : 'missing';
  const hRe = /^\s*(?:Q\.?\s*)?(\d{1,2})\s*[.):\-]\s*(.+)/i, out = []; let cur = null;
  lines.forEach(l => { const h = l.match(hRe); if (h) { cur = { title: h[2].replace(/\(\s*\d+\s*(?:marks?)?\s*\)\s*$/i, '').trim(), type: ty(h[2]), lines: [] }; out.push(cur); } else if (cur) cur.lines.push(l); });
  if (!out.length) out.push({ title: 'Imported', type: 'missing', lines: lines.slice() });
  return out.map(c => { const L = c.lines.filter(x => x.length < 60).slice(0, 12), T = c.type;
    const items = (T === 'trace' || T === 'missing') ? (L.length ? L.map(x => ({ txt: x })) : [{ txt: '' }])
      : T === 'compare' ? (L.length ? L : ['']).map(x => ({ pair: true, img: null, img2: null, txt: x, txt2: '' }))
      : T === 'mcq' ? [{ img: null, txt: '' }, { img: null, txt: '' }]
      : (L.length ? L : ['', '', '']).map(x => ({ img: null, txt: T === 'count' ? (x.match(/\d+/) || [''])[0] : x }));
    return { type: T, title: c.title, items }; }); }
function pqApplyStd(lines) { const o = pqParseStd(lines), arr = (a, d) => a.length ? a : d;
  paperMcqs = arr(o.mcq.map((x, i) => ({ no: i + 1, q: x.q, options: x.o })), [{ no: 1, q: '', options: ['', '', '', ''] }]);
  paperBlanks = arr(o.blank.map((x, i) => ({ no: i + 1, q: x.q })), [{ no: 1, q: '' }]);
  paperTF = arr(o.tf.map((x, i) => ({ no: i + 1, q: x.q })), [{ no: 1, q: '' }]);
  paperShort = arr(o.short.map((x, i) => ({ no: i + 1, q: x.q, marks: x.m })), [{ no: 1, q: '', marks: '' }]);
  paperLong = arr(o.long.map((x, i) => ({ no: i + 1, q: x.q, marks: x.m })), [{ no: 1, q: '', marks: '' }]);
  Object.assign(paperMeta, o.meta); return o.mcq.length + o.blank.length + o.tf.length + o.short.length + o.long.length; }
function pqApplyKg(lines) { kgBlocks = pqParseKg(lines); kgLibOpen = -1; kgLibT = null; kgCmpT = null; Object.assign(paperMeta, pqMeta(lines)); return kgBlocks.length; }
async function pqImportFile(file) {
  if (!file) return;
  const ur = LANG === 'ur', kg = paperMode === 'kg', has = kg ? kgHasContent() : pqHasContent();
  if (has && !confirm(ur ? 'موجودہ پرچہ بدل جائے گا (وہ "پچھلا پرچہ" میں محفوظ رہے گا)۔ جاری رکھیں؟' : 'This replaces the current paper (it is kept under Previous Paper). Continue?')) return;
  try {
    pqImpMsg('⏳ Opening file…'); let lines = [];
    if (file.type === 'application/pdf' || /\.pdf$/i.test(file.name)) {
      await pqLoadScript(PQ_PDFJS); pdfjsLib.GlobalWorkerOptions.workerSrc = PQ_PDFJS_W;
      const pdf = await pdfjsLib.getDocument({ data: await file.arrayBuffer() }).promise;
      for (let n = 1; n <= pdf.numPages; n++) { pqImpMsg('📄 Page ' + n + '/' + pdf.numPages);
        const page = await pdf.getPage(n); let pl = pqLines((await page.getTextContent()).items);
        if (pl.join('').trim().length < 20) { const vp = page.getViewport({ scale: 2 }), c = document.createElement('canvas'); c.width = vp.width; c.height = vp.height;
          await page.render({ canvasContext: c.getContext('2d'), viewport: vp }).promise; pl = await pqOcr(c, n, pdf.numPages); }
        lines = lines.concat(pl); }
    } else lines = await pqOcr(await pqImgCanvas(file), 1, 1);
    lines = lines.map(pqNorm).filter(Boolean);
    if (!lines.length) { pqImpMsg('❌ No text found in the file', 4000); return; }
    if (has) { if (kg) { await kgKvSet('backup', kgSnap()); kgHasBackup = true; } else pqStoreBackup(); }
    const n = kg ? pqApplyKg(lines) : pqApplyStd(lines);
    pqFlush(); renderTab(); pqImpMsg('✅ ' + n + (kg ? ' question blocks' : ' questions') + ' imported — please check and edit', 5000);
  } catch (e) { pqImpMsg('❌ ' + ((e && e.message) || e), 6000); } }
const pqImportBtn = () => `<label class="btn-ghost" style="display:block;width:100%;margin-top:10px;text-align:center;cursor:pointer;box-sizing:border-box;">📄 ${LANG==='ur' ? 'PDF / تصویر سے پرچہ لائیں' : 'Import paper from PDF / photo'}<input type="file" accept="application/pdf,image/*" style="display:none;" onchange="pqImportFile(this.files[0]);this.value=''"></label>`;
const KG_SETS = { cap:'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split(''), low:'abcdefghijklmnopqrstuvwxyz'.split(''),
  ur:'ا ب پ ت ٹ ث ج چ ح خ د ڈ ذ ر ڑ ز ژ س ش ص ض ط ظ ع غ ف ق ک گ ل م ن و ہ ھ ء ی ے'.split(' '),
  num:Array.from({length:20}, (_, k) => '' + (k + 1)), urnum:'۱ ۲ ۳ ۴ ۵ ۶ ۷ ۸ ۹ ۱۰ ۱۱ ۱۲ ۱۳ ۱۴ ۱۵ ۱۶ ۱۷ ۱۸ ۱۹ ۲۰'.split(' ') };
function kgFill(i, k) { const b = kgBlocks[i], a = KG_SETS[k].slice(), n = k === 'ur' ? 8 : 6;
  if (b.type === 'missing') for (let j = 1; j < a.length; j += 3) a[j] = '_';
  const rows = []; for (let j = 0; j < a.length; j += n) rows.push({ txt: a.slice(j, j + n).join(' ') });
  b.items = rows; try { pqScheduleSave(); } catch (e) {} renderTab(); }
function kgOpt(i, j, k, v) { const it = kgBlocks[i].items[j]; it.o = it.o || ['', '', '', '']; it.o[k] = v; try { pqScheduleSave(); } catch (e) {} }
function kgBrk(i, j) { const it = kgBlocks[i].items[j]; it.brk = !it.brk; renderTab(); }
let kgLibT = null;
function kgSlot(i, j, s) { const it = kgBlocks[i].items[j];
  if (!it.qp) { it.qp = (it.em || it.img) ? [{ em: it.em, img: it.img, w: it.w, h: it.h }] : []; delete it.em; delete it.img; }
  if (!it.op) it.op = [[], [], [], []];
  return s === 'q' ? it.qp : it.op[s]; }
function kgMcqPick(cat, idx) { const t = kgLibT; if (!t) return; const [code] = kgEntry(KG_LIB[cat][1][idx]), b = t.s === 'q' ? 64 : 48;
  kgSlot(t.i, t.j, t.s).push({ em: code, w: b, h: b });
  const pn = document.getElementById('kgLib'), st = pn ? pn.scrollTop : 0;
  try { pqScheduleSave(); } catch (e) {} kgRefreshBlock(t.i); }
function kgPicSz(i, j, s, k, f, base) { const pp = kgSlot(i, j, s)[k]; pp.w = pp.h = Math.round(base * f); try { pqScheduleSave(); } catch (e) {} }
function kgPicDel(i, j, s, k) { kgSlot(i, j, s).splice(k, 1); renderTab(); }
function kgSlotImg(i, j, s, files) { const b = s === 'q' ? 64 : 48;
  [...files].forEach(file => { const r = new FileReader(); r.onload = e => { const im = new Image(); im.onload = () => {
    const k = Math.min(1, 320 / Math.max(im.width, im.height)), c = document.createElement('canvas'); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
    c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); kgSlot(i, j, s).push({ img: c.toDataURL('image/png'), w: b, h: b }); renderTab(); }; im.src = e.target.result; }; r.readAsDataURL(file); }); }
function kgMcqEditor(i, j, it) {
  kgSlot(i, j, 'q');
  const slotHtml = (s, label) => { const arr = kgSlot(i, j, s), base = s === 'q' ? 64 : 48;
    return `<div style="margin-top:6px;display:flex;gap:6px;flex-wrap:wrap;align-items:center;">${label}${arr.map((pp, k) => { const cur = pp.w ? pp.w / base : 1;
      return `<span style="display:inline-flex;flex-direction:column;align-items:center;gap:2px;border:1px solid var(--line,#ddd);border-radius:8px;padding:2px;"><span style="display:block;width:40px;height:40px;">${kpic({ ...pp, w: 38, h: 38 }, '', 'contain')}</span><span style="display:flex;gap:2px;"><select style="font-size:10px;padding:0;" onchange="kgPicSz(${i},${j},'${s}',${k},this.value,${base})">${[['.6', 'S'], ['1', 'M'], ['1.6', 'L'], ['2.2', 'XL'], ['3.2', 'XXL']].map(o => `<option value="${o[0]}"${Math.abs(cur - o[0]) < .15 ? ' selected' : ''}>${o[1]}</option>`).join('')}</select><button class="btn-ghost" style="padding:0 5px;font-size:11px;" onclick="kgPicDel(${i},${j},'${s}',${k})">✕</button></span></span>`; }).join('')}<button class="${kgLibT && kgLibT.i === i && kgLibT.j === j && kgLibT.s === s ? 'btn-primary' : 'btn-ghost'}" style="padding:4px 8px;font-size:12px;" onclick="kgLibT={i:${i},j:${j},s:'${s}'};renderTab()">＋ Picture</button><label class="btn-ghost" style="padding:4px 8px;font-size:12px;cursor:pointer;">📷<input type="file" accept="image/*" multiple style="display:none;" onchange="kgSlotImg(${i},${j},'${s}',this.files)"></label></div>`; };
  return `<div class="paper-q-row" style="margin-bottom:10px;padding-bottom:10px;border-bottom:1px dashed var(--line,#ddd);">
    <div class="flexgap" style="align-items:center;"><input dir="auto" style="flex:1;" placeholder="Question" value="${esc(it.txt||'')}" oninput="kgBlocks[${i}].items[${j}].txt=this.value"><button class="btn-ghost" style="padding:6px 10px;" onclick="kgDelItem(${i},${j})">✕</button></div>
    ${slotHtml('q', '<b style="font-size:11px;">Question</b>')}
    ${'abcd'.split('').map((l, k) => `<div style="margin-top:8px;"><input dir="auto" style="width:100%;" placeholder="(${l}) option" value="${esc((it.o||[])[k]||'')}" oninput="kgOpt(${i},${j},${k},this.value)">${slotHtml(k, '<b style="font-size:11px;">(' + l + ')</b>')}</div>`).join('')}
    ${kgLibT && kgLibT.i === i && kgLibT.j === j ? `<div style="font-size:12px;margin-top:8px;">Picking for: <b>${kgLibT.s === 'q' ? 'Question' : 'option (' + 'abcd'[kgLibT.s] + ')'}</b> — tap as many pictures as you want <button class="btn-ghost" style="padding:2px 8px;" onclick="kgLibT=null;renderTab()">Done</button></div>` + kgLibHtml(i, true) : ''}
  </div>`; }
function kgLibToggle(i) { kgLibOpen = kgLibOpen === i ? -1 : i; renderTab(); }
function kgLibCat(c) { kgLibCatSel = c; renderTab(); }
function kgLibPick(i, cat, idx) {
  const b = kgBlocks[i], [code, name] = kgEntry(KG_LIB[cat][1][idx]), pn = document.getElementById('kgLib'), st = pn ? pn.scrollTop : 0;
  let it = b.items.find(x => !x.img && !x.em && !(x.txt || '').trim());
  if (!it) { it = { img: null, txt: '' }; b.items.push(it); }
  it.em = code; if (b.type === 'match') it.txt = name;
  try { pqScheduleSave(); } catch (e) {}
  kgRefreshBlock(i);
}
function kgLibHtml(i, t) {
  return `<div id="kgLib" style="border:1px solid var(--line,#ddd);border-radius:12px;padding:8px;margin-top:8px;max-height:340px;overflow:auto;">${Object.keys(KG_LIB).map(c => `<div style="font-size:12px;font-weight:700;margin:8px 0 4px;">${KG_LIB[c][0]}</div><div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;">${KG_LIB[c][1].map((str, idx) => { const [code, name] = kgEntry(str); return `<button class="btn-ghost" style="padding:6px 2px;display:flex;flex-direction:column;align-items:center;gap:2px;" onclick="${t === 'cmp' ? `kgCmpPick('${c}',${idx})` : t ? `kgMcqPick('${c}',${idx})` : `kgLibPick(${i},'${c}',${idx})`}"><span style="display:block;width:38px;height:38px;">${kpic({ em: code, w: 38, h: 38 }, '')}</span><span style="font-size:9px;line-height:1.1;">${name}</span></button>`; }).join('')}</div>`).join('')}</div>`;
}
function kgBlockHtml(b,i) {
    const txtOnly = b.type==='trace' || b.type==='missing';
    const ph = { trace:'e.g. A B C D E F', missing:'e.g. A _ C', picname:'answer (optional)', match:'name (e.g. Apple)', count:'number (e.g. 3)', colour:'', compare:'label (e.g. Big) — optional', mcq:'Question' }[b.type];
    let body;
    if (txtOnly) {
      body = `<textarea rows="3" style="width:100%;" placeholder="${ph} — one line per row" oninput="kgBlocks[${i}].items=this.value.split('\\n').map(x=>({txt:x}))">${esc(b.items.map(x=>x.txt).join('\n'))}</textarea><div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px;">${[['cap','A–Z'],['low','a–z'],['ur','اردو حروف'],['num','1–20'],['urnum','۱–۲۰']].map(f => `<button class="btn-ghost" style="padding:4px 10px;font-size:12px;" onclick="kgFill(${i},'${f[0]}')">${f[1]}</button>`).join('')}</div>`;
    } else {
      body = b.items.map((it,j) => { const d = kgDef(b.type), cw = it.w || d, ch = it.h || d; if (b.type === 'mcq') return kgMcqEditor(i, j, it); if (b.type === 'compare' && it.pair) return kgPairEditor(i, j, it);
        return `<div class="paper-q-row" style="margin-bottom:8px;padding-bottom:8px;border-bottom:1px dashed var(--line,#ddd);">
        <div class="flexgap" style="align-items:center;">
          <label style="cursor:pointer;flex-shrink:0;">${(it.img || it.em) ? `<span style="display:block;width:48px;height:48px;border:1px solid var(--line,#ddd);border-radius:8px;overflow:hidden;">${kpic({ ...it, w: 46, h: 46 }, '', 'contain')}</span>` : `<div style="width:48px;height:48px;border:1px dashed var(--line,#ddd);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:20px;">📷</div>`}
            <input type="file" accept="image/*" style="display:none;" onchange="kgItemImg(${i},${j},this.files[0])"></label>
          ${b.type==='colour' ? '<span style="flex:1;font-size:12px;opacity:.6;">picture</span>' : `<input style="flex:1;" placeholder="${ph}" value="${esc(it.txt||'')}" oninput="kgBlocks[${i}].items[${j}].txt=this.value">`}
          <button class="btn-ghost" style="padding:6px 10px;" onclick="kgDelItem(${i},${j})">✕</button></div>
        ${b.type==='mcq' ? `<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:6px;">${'abcd'.split('').map((l,k) => `<input dir="auto" placeholder="(${l}) option" value="${esc((it.o||[])[k]||'')}" oninput="kgOpt(${i},${j},${k},this.value)">`).join('')}</div>` : ''}<div style="display:flex;align-items:center;gap:6px;margin-top:6px;font-size:11px;">
          <span title="Width">↔</span><input type="range" min="20" max="400" value="${cw}" style="flex:1;min-width:0;" oninput="kgSize(${i},${j},'w',this.value)">
          <span title="Height">↕</span><input type="range" min="20" max="400" value="${ch}" style="flex:1;min-width:0;" oninput="kgSize(${i},${j},'h',this.value)">
          <button class="btn-ghost" style="padding:2px 8px;" onclick="kgPreset(${i},${j},0.6)">S</button><button class="btn-ghost" style="padding:2px 8px;" onclick="kgPreset(${i},${j},1)">M</button><button class="btn-ghost" style="padding:2px 8px;" onclick="kgPreset(${i},${j},1.7)">L</button><button class="btn-ghost" style="padding:2px 8px;" onclick="kgZoom(${i},${j},'',0.85)">🔍－</button><button class="btn-ghost" style="padding:2px 8px;" onclick="kgZoom(${i},${j},'',1.2)">🔍＋</button>${b.type==='compare' ? `<button class="${it.brk?'btn-primary':'btn-ghost'}" style="padding:2px 8px;" title="Start a new row here" onclick="kgBrk(${i},${j})">↵</button>` : ''}</div></div>`; }).join('')
        + `<div class="flexgap" style="margin-top:6px;"><button class="btn-ghost" style="flex:1;" onclick="kgAddItem(${i})">＋ Add</button>${(b.type==='mcq'||b.type==='compare') ? '' : `<button class="${kgLibOpen===i?'btn-primary':'btn-ghost'}" style="flex:1;" onclick="kgLibToggle(${i})">📚 Library</button>`}</div>` + (kgLibOpen === i && b.type !== 'mcq' ? kgLibHtml(i) : '');
    }
    return `<div class="card" style="margin-bottom:14px;">
      <div class="flexgap" style="align-items:center;margin-bottom:8px;">
        <b style="font-size:12px;flex:1;">${esc(KG_TYPES[b.type])}</b>
        <button class="btn-ghost" style="padding:4px 8px;" onclick="kgMoveBlock(${i},-1)">↑</button>
        <button class="btn-ghost" style="padding:4px 8px;" onclick="kgMoveBlock(${i},1)">↓</button>
        <button class="btn-ghost" style="padding:4px 8px;" onclick="kgDelBlock(${i})">✕</button></div>
      <input dir="auto" style="width:100%;font-weight:600;margin-bottom:8px;" placeholder="Question heading" value="${esc(b.title)}" oninput="kgBlocks[${i}].title=this.value">
      ${body}</div>`;
}
function tplKgBuilder() {
  const blocks = kgBlocks.map((b,i) => `<div id="kgb-${i}">${kgBlockHtml(b,i)}</div>`).join('');
  return blocks + `<div class="card" style="margin-bottom:14px;"><select style="width:100%;padding:8px;" onchange="kgAddBlock(this)"><option value="">＋ Add a new question type…</option>${Object.keys(KG_TYPES).map(k=>`<option value="${k}">${esc(KG_TYPES[k])}</option>`).join('')}</select></div>
    <button class="btn-primary" style="width:100%;" onclick="printQuestionPaper()">🖨️ ${esc(t.print)}</button>
    ${pqImportBtn()}<div class="flexgap" style="margin-top:10px;"><button class="btn-ghost" style="flex:1;" onclick="kgNewPaper()">🆕 ${LANG==='ur' ? 'نیا پرچہ' : 'New Paper'}</button>${kgHasBackup ? `<button class="btn-ghost" style="flex:1;" onclick="kgRestorePrevious()">↩️ ${LANG==='ur' ? 'پچھلا پرچہ' : 'Previous Paper'}</button>` : ''}</div>`;
}

// ---------- Math symbols palette ----------
let symTarget = null;
const TT='\u0640'; // tatweel: gives a base letter to show a lone diacritic on a button
const SYM_TABS = [
  { id:'math', label:'Σ  Math', groups:[
    ['Basic','× ÷ ± ≠ ≤ ≥ ≈ ∞ ° % ‰'],
    ['Powers','² ³ √ ∛ π'],
    ['Power letters','ᵃ ᵇ ᶜ ᵈ ᵉ ᶠ ᵍ ʰ ⁱ ʲ ᵏ ˡ ᵐ ⁿ ᵒ ᵖ ʳ ˢ ᵗ ᵘ ᵛ ʷ ˣ ʸ ᶻ'],
    ['Power numbers','⁰ ¹ ² ³ ⁴ ⁵ ⁶ ⁷ ⁸ ⁹ ⁺ ⁻ ⁽ ⁾'],
    ['Subscript','₀ ₁ ₂ ₃ ₄ ₅ ₆ ₇ ₈ ₉ ₐ ₙ ₘ ₓ'],
    ['Fractions','½ ⅓ ¼ ¾ ⅔ ⅕ ⅛'],
    ['Geometry','∠ △ □ ⊥ ∥ ≅ ∼ ∴ ∵ ⌒'],
    ['Sets','∈ ∉ ∪ ∩ ⊂ ⊆ ∅ ℕ ℤ ℚ ℝ'],
    ['Greek (small)','α β γ δ ε ζ η θ ι κ λ μ ν ξ ο π ρ σ τ υ φ χ ψ ω'],
    ['Greek (capital)','Γ Δ Θ Λ Ξ Π Σ Φ Ψ Ω'],
    ['Arrows','→ ← ↔ ⇒ ⇔ ↑ ↓']
  ]},
  { id:'sum', label:'▦ Sum', custom:true, groups:[] },
  { id:'serial', label:'№ Serial', custom:true, groups:[] },
  { id:'aerab', label:'اعراب', ur:true, groups:[
    ['زبر، زیر، پیش', [TT+'\u064E',TT+'\u0650',TT+'\u064F'], 'mark'],
    ['تشدید، جزم', [TT+'\u0651',TT+'\u0652'], 'mark'],
    ['تنوین', [TT+'\u064B',TT+'\u064D',TT+'\u064C'], 'mark'],
    ['تشدید کے ساتھ', [TT+'\u0651\u064E',TT+'\u0651\u0650',TT+'\u0651\u064F'], 'mark'],
    ['کھڑی زبر، کھڑا زیر، الٹا پیش', [TT+'\u0670',TT+'\u0656',TT+'\u0657'], 'mark'],
    ['مد، ہمزہ', [TT+'\u0653',TT+'\u0654',TT+'\u0655'], 'mark'],
    ['قرآنی علامات', ['\u06D6','\u06D7','\u06DA','\u06D8','\u06D9','\u06DB','\u06DC','\u06E2','\u06E3','\u06DE','\u06E9','\uFD3E','\uFD3F'], 'plain']
  ]},
  { id:'urdu', label:'اردو', ur:true, groups:[
    ['دعائیہ کلمات', ['ﷺ','صلی اللہ علیہ وسلم','رضی اللہ عنہ','رضی اللہ عنہا','رضی اللہ عنہم','رضی اللہ عنہما','علیہ السلام','علیہا السلام','علیہم السلام','رحمۃ اللہ علیہ','رحمہا اللہ','جل جلالہ','عز و جل','سبحانہ و تعالیٰ','ﷲ','﷽'], 'phrase'],
    ['علامات', ['۔','،','؟','؛','«','»','٪','٫','ـ'], 'plain'],
    ['خاص حروف', ['ے','ں','ھ','ٹ','ڈ','ڑ','گ','چ','پ','ژ','ۃ','ء','ئ','ؤ','أ','آ','إ','ۓ','ۂ','ۃ'], 'plain'],
    ['ابتدائی شکل (حرف کا شروع)', 'ب پ ت ٹ ث ج چ ح خ س ش ص ض ط ظ ع غ ف ق ک گ ل م ن ہ ھ ی ئ'.split(' ').map(c => c + '\u200D'), 'plain'],
    ['درمیانی شکل (حرف کا بیچ)', 'ب پ ت ٹ ث ج چ ح خ س ش ص ض ط ظ ع غ ف ق ک گ ل م ن ہ ھ ی ئ'.split(' ').map(c => '\u200D' + c + '\u200D'), 'plain'],
    ['آخری شکل (حرف کا آخر)', 'ا ب پ ت ٹ ث ج چ ح خ د ڈ ذ ر ڑ ز ژ س ش ص ض ط ظ ع غ ف ق ک گ ل م ن ں و ہ ھ ی ے'.split(' ').map(c => '\u200D' + c), 'plain'],
    ['ہندسے', ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'], 'plain']
  ]}
];
let symTab = 'math';
document.addEventListener('focusin', e => {
  const el = e.target;
  if ((el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && (!el.type || el.type === 'text'))) && !el.closest('#symBar')) symTarget = el;
});
// The palette lives outside #main so re-renders of the tab can never close it.
function symSync() {
  let bar = document.getElementById('symBar');
  if (!bar) { bar = document.createElement('div'); bar.id = 'symBar'; bar.innerHTML = symBarHtml(); document.body.appendChild(bar); }
  bar.style.display = (typeof TAB !== 'undefined' && TAB === 'papers') ? '' : 'none';
}
{ const _rt = renderTab; renderTab = function () { const r = _rt.apply(this, arguments); try { symSync(); } catch (e) {} return r; }; }
function symToggle() { const b = document.getElementById('symBox'); if (b) b.style.display = b.style.display === 'none' ? 'block' : 'none'; }
function symInsert(ch, phrase) {
  const hint = document.getElementById('symHint');
  const el = symTarget;
  if (!el || !document.body.contains(el)) { if (hint) hint.style.color = '#d33'; return; }
  if (hint) hint.style.color = '';
  const a = el.selectionStart ?? el.value.length, b = el.selectionEnd ?? a;
  if (phrase) { const prev = el.value.slice(0, a).slice(-1); ch = (prev && !/\s/.test(prev) ? ' ' : '') + ch + ' '; }
  el.value = el.value.slice(0, a) + ch + el.value.slice(b);
  el.focus(); el.selectionStart = el.selectionEnd = a + ch.length;
  el.dispatchEvent(new Event('input', { bubbles: true }));
}
function symTabSet(id) {
  symTab = id;
  document.querySelectorAll('#symBar [data-tab]').forEach(e => e.classList.toggle('on', e.dataset.tab === id));
  document.querySelectorAll('#symBar [data-pane]').forEach(e => e.style.display = e.dataset.pane === id ? 'block' : 'none');
}
function symBarHtml() {
  const chip = (c, kind, ur) => `<button type="button" class="symchip${kind==='phrase'?' wide':''}${kind==='mark'?' mk':''}${ur?' ur':''}" data-c="${c}" onclick="symInsert(this.dataset.c,${kind==='phrase'})">${c}</button>`;
  const panes = SYM_TABS.map(tb => `<div data-pane="${tb.id}" style="display:${tb.id===symTab?'block':'none'};">${tb.custom ? (tb.id === 'sum' ? symSumHtml() : symSerialHtml()) : ''}${tb.groups.map(g => {
    const items = Array.isArray(g[1]) ? g[1] : g[1].split(' ');
    return `<div class="symgt${tb.ur?' ur':''}">${g[0]}</div><div class="symrow${tb.ur?' rtl':''}">${items.map(c => chip(c, g[2], tb.ur)).join('')}</div>`;
  }).join('')}</div>`).join('');
  return `<div style="position:fixed;right:12px;bottom:84px;z-index:50;max-width:calc(100vw - 24px);" onmousedown="if(!event.target.closest('input,select'))event.preventDefault()">
    <div id="symBox" style="display:none;margin-bottom:10px;width:318px;max-width:100%;background:var(--card,#fff);border:1px solid var(--line,#d9d2c0);border-radius:20px;box-shadow:0 14px 40px rgba(20,30,50,.28);overflow:hidden;">
      <div class="symtabs">${SYM_TABS.map(tb => `<button type="button" data-tab="${tb.id}" class="symtab${tb.id===symTab?' on':''}${tb.ur?' ur':''}" onclick="symTabSet('${tb.id}')">${tb.label}</button>`).join('')}<button type="button" class="symx" onclick="symToggle()">✕</button></div>
      <div id="symHint">Pehle question box par tap karein, phir chunein</div>
      <div class="symbody">${panes}</div>
    </div>
    <div style="text-align:right;"><button type="button" class="btn-primary" style="border-radius:50%;width:52px;height:52px;font-size:22px;padding:0;box-shadow:0 6px 18px rgba(0,0,0,.3);" onclick="symToggle()">Σ</button></div>
  </div>`;
}

function tplPapers() {
  const html = tplPapersStd();
  const tg = `<div style="padding-top:16px;"><div class="flexgap">
    <button class="${paperMode==='std'?'btn-primary':'btn-ghost'}" style="flex:1;" onclick="setPaperMode('std')">📝 Standard</button>
    <button class="${paperMode==='kg'?'btn-primary':'btn-ghost'}" style="flex:1;" onclick="setPaperMode('kg')">🧸 Nursery / KG</button></div></div>`;
  if (paperMode !== 'kg') return tg + html;
  return tg + html.split('<!--PQ_HDR_END-->')[0] + tplKgBuilder() + '</div>';
}
function kgBodyHtml() {
  const kimg = (x, cls) => kpic(x, cls);
  const ur = t => /[\u0600-\u06FF]/.test(t || '');
  return kgBlocks.map((b,n) => {
    const its = b.items.filter(x => (b.type==='trace'||b.type==='missing') ? (x.txt||'').trim() : true);
    if (!its.length) return '';
    let body = '';
    if (b.type==='trace') body = its.map(x => `<div class="kg-trace${ur(x.txt)?' kg-ur':''}"${ur(x.txt)?' dir="rtl"':''}>${pqEsc(x.txt)}</div>`).join('');
    else if (b.type==='missing') body = `<div class="kg-missing${its.some(x=>ur(x.txt))?' kg-ur':''}"${its.some(x=>ur(x.txt))?' dir="rtl"':''}>${its.map(x => `<span>${pqEsc(x.txt).replace(/_+/g,'<i class="kg-gap"></i>')}</span>`).join('')}</div>`;
    else if (b.type==='picname') body = `<div class="kg-grid">${its.map(x => `<div class="kg-cell">${kimg(x,'kg-pic')}<div class="kg-line"></div></div>`).join('')}</div>`;
    else if (b.type==='colour') body = `<div class="kg-grid kg-big">${its.map(x => kimg(x,'kg-pic-big')).join('')}</div>`;
    else if (b.type==='count') body = its.map(x => { const c = Math.max(0, Math.min(10, parseInt(x.txt)||0)); return `<div class="kg-count">${Array(c||3).fill(kimg(x,'kg-pic-sm')).join('')}<span class="kg-eq">= ____</span></div>`; }).join('');
    else if (b.type==='compare') { const rows = [[]]; its.forEach(x => { if (x.brk && rows[rows.length-1].length) rows.push([]); rows[rows.length-1].push(x); });
      const cell = (x, sx) => { const o = { img: x['img' + sx], em: x['em' + sx], w: x['w' + sx], h: x['h' + sx] }; return `<div class="kg-cmpc">${kimg(o,'kg-pic')}<i class="kg-cbox"></i><div class="kg-clab" dir="auto">${pqEsc(x['txt' + sx]||'')}</div></div>`; };
      body = rows.map(r => `<div class="kg-cmp">${r.map(x => x.pair ? `<div class="kg-cmpp">${cell(x,'')}${cell(x,'2')}</div>` : cell(x,'')).join('')}</div>`).join(''); }
    else if (b.type==='mcq') body = its.map((x,i) => { const p = (x.txt||'').split('|').map(z => z.trim()), q = p.shift(), pics = a => (a||[]).map(pp => kpic(pp,'kg-pic','contain')).join(''), qp = x.qp || ((x.em||x.img) ? [x] : []);
      return `<div class="kg-mcq"><div class="kg-mq" dir="auto">${i+1}. ${pqEsc(q)}</div><div class="kg-mpics">${pics(qp)}</div><div class="kg-mo">${['a','b','c','d'].map((l,k) => `<span class="kg-mopt"><span dir="auto">(${l}) ${pqEsc((x.o||p)[k]||'')}</span><span class="kg-mpics">${pics((x.op||[])[k])}</span></span>`).join('')}</div></div>`; }).join('');
    else if (b.type==='match') {
      const m = its.length, right = its.map((x,i) => its[(i+1)%m]);
      body = `<div class="kg-match">${its.map((x,i) => `<div class="kg-mrow"><div>${kimg(x,'kg-pic')}</div><i class="kg-dot"></i><span class="kg-mid"></span><i class="kg-dot"></i><div class="kg-mname">${pqEsc(right[i].txt||'')}</div></div>`).join('')}</div>`;
    }
    return `<div class="pq-section kg-sec"><div class="pq-section-title" dir="auto">Q${n+1}. ${pqEsc(b.title)}</div>${body}</div>`;
  }).join('');
}


// ---------- Tables (word meanings, opposites, singular/plural, ...) ----------
function pqTouch() { try { pqScheduleSave(); } catch (e) {} }
const PQ_POS = { top:'Before the objective section (MCQs…)', preShort:'Before Short Questions', postShort:'After Short Questions (before Long)', end:'After Long Questions (end)' };
function pqTblStyle(tb) { return tb.numStyle || (tb.nums === false ? 'none' : '1'); }
function pqAddTable() {
  paperTables.push({ title:'', pos:'end', numStyle:'1', cols:['',''], rows:[0,1,2,3,4].map(() => ['','']) });
  pqTouch(); renderTab();
}
function pqDupTable(i) { paperTables.splice(i+1, 0, JSON.parse(JSON.stringify(paperTables[i]))); pqTouch(); renderTab(); }
function pqDelTable(i) { paperTables.splice(i,1); pqTouch(); renderTab(); }
function pqAddRow(i) { const tb = paperTables[i]; tb.rows.push(tb.cols.map(() => '')); pqTouch(); renderTab(); }
function pqDelRow(i,r) { paperTables[i].rows.splice(r,1); pqTouch(); renderTab(); }
function pqAddCol(i) { const tb = paperTables[i]; if (tb.cols.length >= 6) return; tb.cols.push(''); tb.rows.forEach(r => r.push('')); pqTouch(); renderTab(); }
function pqDelCol(i) { const tb = paperTables[i]; if (tb.cols.length <= 1) return; tb.cols.pop(); tb.rows.forEach(r => r.pop()); pqTouch(); renderTab(); }
function tplPqTables() {
  const cards = paperTables.map((tb,i) => {
    const g = `display:grid;grid-template-columns:repeat(${tb.cols.length},1fr) 34px;gap:6px;margin-bottom:6px;`;
    return `<div style="border:1px solid var(--line,#ddd);border-radius:12px;padding:10px;margin-bottom:10px;">
      <div style="font-size:11px;font-weight:700;opacity:.6;margin-bottom:4px;">Table ${i+1}</div>
      <input dir="auto" style="width:100%;font-weight:600;margin-bottom:8px;" placeholder="Question heading (optional)" value="${esc(tb.title)}" oninput="paperTables[${i}].title=this.value">
      <select style="width:100%;padding:8px;margin-bottom:8px;" onchange="paperTables[${i}].pos=this.value">${Object.keys(PQ_POS).map(k => `<option value="${k}"${(tb.pos||'end')===k?' selected':''}>📍 ${PQ_POS[k]}</option>`).join('')}</select>
      <div style="${g}">${tb.cols.map((c,k) => `<input dir="auto" style="font-weight:700;" placeholder="Column heading" value="${esc(c)}" oninput="paperTables[${i}].cols[${k}]=this.value">`).join('')}<span></span></div>
      ${tb.rows.map((r,ri) => `<div style="${g}">${r.map((c,k) => `<input dir="auto" placeholder="blank = student writes" value="${esc(c)}" oninput="paperTables[${i}].rows[${ri}][${k}]=this.value">`).join('')}<button class="btn-ghost" style="padding:0;" onclick="pqDelRow(${i},${ri})">✕</button></div>`).join('')}
      <select style="width:100%;padding:8px;margin:6px 0;" onchange="paperTables[${i}].numStyle=this.value">${[['none','No serial numbers'],...PQ_SN_STYLES.map(x => [x[0],'Serial: ' + x[1]])].map(o => `<option value="${o[0]}"${pqTblStyle(tb)===o[0]?' selected':''}>${o[1]}</option>`).join('')}</select>
      <div class="flexgap" style="flex-wrap:wrap;">
        <button class="btn-ghost" onclick="pqAddRow(${i})">＋ Row</button>
        <button class="btn-ghost" onclick="pqAddCol(${i})">＋ Column</button>
        <button class="btn-ghost" onclick="pqDelCol(${i})">－ Column</button>
        <button class="btn-ghost" onclick="pqDupTable(${i})">⧉ Duplicate</button>
        <button class="btn-ghost" onclick="pqDelTable(${i})">🗑️ Delete</button>
      </div></div>`;
  }).join('');
  return `<div class="card" style="margin-bottom:14px;">
    <b style="font-size:13px;display:block;margin-bottom:4px;">Tables</b>
    <div style="font-size:11px;opacity:.6;margin-bottom:8px;">Make any table you need and name it yourself. Fill the cells you want printed; leave a cell empty for the student to write. Choose where it prints.</div>
    ${cards}
    <button class="btn-ghost" style="width:100%;" onclick="pqAddTable()">＋ Add Table</button></div>`;
}
function pqTablesHtml(pos) {
  return paperTables.filter(tb => (tb.pos || 'end') === pos).map(tb => {
    const rows = tb.rows.filter(r => r.some(c => (c || '').trim()));
    if (!rows.length) return '';
    const ns = pqTblStyle(tb), nums = ns !== 'none', hasHead = tb.cols.some(c => (c || '').trim());
    return `<div class="pq-section">${(tb.title||'').trim() ? `<div class="pq-instruction" dir="auto">${esc(tb.title)}</div>` : ''}
      <table class="pq-table">${hasHead ? `<thead><tr>${nums ? '<th class="pq-no">#</th>' : ''}${tb.cols.map(c => `<th dir="auto">${esc(c||'')}</th>`).join('')}</tr></thead>` : ''}
      <tbody>${rows.map((r,i) => `<tr>${nums ? `<td class="pq-no">${pqSerialText(ns, i+1)}</td>` : ''}${r.map(c => `<td dir="auto">${pqEsc(c||'')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
  }).join('');
}


// ---------- Serial numbers: {#} 1) 2) 3) · {#a} a) b) · {#A} · {#i} · {#I} · {#۱} · {#ا} (restart in every question) ----------
const PQ_SN_STYLES = [['1','1  2  3'],['a','a  b  c'],['A','A  B  C'],['i','i  ii  iii'],['I','I  II  III'],['\u06F1','\u06F1  \u06F2  \u06F3'],['\u0627','الف  ب  ج']];
const PQ_UR_ALPHA = ['الف','ب','ج','د','ہ','و','ز','ح','ط','ی','ک','ل','م','ن','س','ع','ف','ق','ر','ش'];
function pqRoman(n) { const m = [[10,'x'],[9,'ix'],[5,'v'],[4,'iv'],[1,'i']]; let r = ''; m.forEach(([v,c]) => { while (n >= v) { r += c; n -= v; } }); return r; }
function pqSerialText(k, n) {
  if (k === 'a') return String.fromCharCode(96 + ((n - 1) % 26) + 1);
  if (k === 'A') return String.fromCharCode(64 + ((n - 1) % 26) + 1);
  if (k === 'i') return pqRoman(n);
  if (k === 'I') return pqRoman(n).toUpperCase();
  if (k === '\u06F1') return String(n).replace(/\d/g, d => String.fromCharCode(0x06F0 + Number(d)));
  if (k === '\u0627') return PQ_UR_ALPHA[(n - 1) % PQ_UR_ALPHA.length];
  return String(n);
}

// ---------- Column sums: {{345+128}} prints as a vertical addition/subtraction/multiplication ----------
// Optional place-value boxes: {{345+128|pv}} (Th H T O) or {{345+128|pvf}} (Ones Tens Hundreds ...)
const PQ_PV_SHORT = ['O','T','H','Th','TTh','HTh','M','TM'];
const PQ_PV_FULL  = ['Ones','Tens','Hundreds','Thousands','Ten Thousands','Hundred Thousands','Millions','Ten Millions'];
function pqColSumHtml(expr) {
  let ans = '', e = String(expr), flag = '';
  const bar = e.lastIndexOf('|');
  if (bar >= 0) { flag = e.slice(bar + 1).trim(); e = e.slice(0, bar); }
  const eq = e.indexOf('=');
  if (eq >= 0) { ans = e.slice(eq + 1).trim(); e = e.slice(0, eq); }
  const parts = e.split(/([+\u2212\u00d7*]|-)/);
  const nums = [], ops = [];
  parts.forEach((x, i) => { if (i % 2 === 0) { if (x.trim()) nums.push(x.trim()); } else ops.push(x); });
  if (nums.length < 2 || !ops.length) return esc('{{' + expr + '}}');
  const op = ops[0] === '-' ? '\u2212' : (ops[0] === '*' ? '\u00d7' : ops[0]);
  const clean = v => String(v).replace(/[<>&]/g, '');
  // place-value chart (only when the teacher asked for it and every number is a whole number)
  if ((flag === 'pv' || flag === 'pvf') && nums.every(n => /^\d+$/.test(n)) && /^\d*$/.test(ans)) {
    const lens = nums.map(n => n.length), mx = Math.max(...lens, ans.length);
    let L = op === '+' ? mx + 1 : (op === '\u00d7' ? Math.max(mx, lens[0] + lens[1]) : mx);
    L = Math.min(8, Math.max(2, L));
    const names = flag === 'pvf' ? PQ_PV_FULL : PQ_PV_SHORT;
    const cells = str => { const d = str.padStart(L, ' ').slice(-L); return Array.from(d).map(c => `<td>${c.trim()}</td>`).join(''); };
    const head = Array.from({ length: L }, (_, i) => `<th>${names[L - 1 - i]}</th>`).join('');
    return `<table class="pq-pvt${flag === 'pvf' ? ' full' : ''}" dir="ltr"><thead><tr><th class="op"></th>${head}</tr></thead><tbody>${nums.map((n, i) => `<tr><td class="op">${i === nums.length - 1 ? op : ''}</td>${cells(n)}</tr>`).join('')}<tr class="res"><td class="op"></td>${cells(ans)}</tr></tbody></table>`;
  }
  return `<span class="pq-col" dir="ltr">${nums.map((n, i) => `<span class="r">${i === nums.length - 1 ? `<i>${op}</i>` : ''}${clean(n)}</span>`).join('')}<span class="ln"></span><span class="r ans">${ans ? clean(ans) : '&nbsp;'}</span></span>`;
}
function symSumVals() {
  const g = id => ((document.getElementById(id) || {}).value || '').trim();
  const pvOn = !!(document.getElementById('sumPV') || {}).checked;
  return { op: g('sumOp') || '+', nums: [g('sumA'), g('sumB'), g('sumC'), g('sumD')].filter(Boolean), pv: pvOn ? (g('sumPVS') || 'pv') : '' };
}
function symSumExpr(v) { return v.nums.join(v.op) + (v.pv ? '|' + v.pv : ''); }
function symSumPrev() {
  const v = symSumVals(), el = document.getElementById('sumPrev');
  const box = document.getElementById('sumPVS'); if (box) box.style.display = v.pv ? '' : 'none';
  if (el) el.innerHTML = v.nums.length >= 2 ? pqColSumHtml(symSumExpr(v)) : '<span style="opacity:.5;font-size:12px;">Numbers likhein…</span>';
}
function symSumInsert() {
  const v = symSumVals();
  if (v.nums.length < 2) return;
  const sn = ((document.getElementById('sumSN') || {}).value || '');
  symInsert((sn ? '{#' + (sn === '1' ? '' : sn) + '} ' : '') + '{{' + symSumExpr(v) + '}}', true);
}
function symSerialHtml() {
  return `<div class="symgt">Serial number (har jagah lag sakta hai)</div>
    <div class="symrow">${PQ_SN_STYLES.map(x => `<button type="button" dir="ltr" class="symchip wide${x[0]==='\u0627'||x[0]==='\u06F1'?' ur':''}" data-c="{#${x[0]==='1'?'':x[0]}}" onclick="symInsert(this.dataset.c,true)">${x[1].split('  ').map(v => v + ')').join('  ')}</button>`).join('')}</div>
    <div style="font-size:11px;opacity:.7;margin-top:10px;line-height:1.6;">Chip dabane par us jagah <b>{#}</b> jaisa nishan lagta hai. Print me wo agla number ban jata hai, aur har sawal me dobara 1 (ya a, i…) se shuru hota hai. Jitni baar chahein likhein, jaise:<br><b>{#} {{345+128}} &nbsp; {#} {{45+67}} &nbsp; {#} {{90-38}}</b><br>Ye MCQ, True/False, Blanks, Short, Long aur Table ke cells sab me chalta hai. Sawal ka apna number upar ke number wale box me kuch bhi (1, a, i, ۱) likh sakte hain.</div>`;
}
function symSumHtml() {
  const inp = (id, ph) => `<input id="${id}" inputmode="decimal" placeholder="${ph}" oninput="symSumPrev()" style="width:100%;min-width:0;text-align:right;font-family:'Courier New',monospace;font-size:16px;padding:8px;">`;
  return `<div class="symgt">Column sum (upar neeche jama / minus / zarb)</div>
    <div style="display:grid;grid-template-columns:1fr 64px;gap:6px;margin-bottom:8px;">
      <div style="display:grid;gap:6px;">${inp('sumA','1st number, e.g. 345')}${inp('sumB','2nd number, e.g. 128')}${inp('sumC','3rd (optional)')}${inp('sumD','4th (optional)')}</div>
      <select id="sumOp" onchange="symSumPrev()" style="font-size:24px;text-align:center;border-radius:10px;height:44px;"><option value="+">+</option><option value="\u2212">\u2212</option><option value="\u00d7">\u00d7</option></select>
    </div>
    <select id="sumSN" style="width:100%;padding:8px;margin-bottom:8px;"><option value="">Serial number: none</option>${PQ_SN_STYLES.map(x => `<option value="${x[0]}">Serial: ${x[1]}</option>`).join('')}</select>
    <label style="display:flex;align-items:center;gap:8px;font-size:13px;margin-bottom:6px;"><input type="checkbox" id="sumPV" onchange="symSumPrev()"> Ones / Tens / Hundreds… labels (optional)</label>
    <select id="sumPVS" onchange="symSumPrev()" style="display:none;width:100%;padding:8px;margin-bottom:8px;"><option value="pv">Short: Th  H  T  O</option><option value="pvf">Full: Thousands  Hundreds  Tens  Ones</option></select>
    <div id="sumPrev" style="background:#fff;color:#111;border:1px dashed var(--line,#ccc);border-radius:12px;padding:8px 12px;min-height:90px;margin-bottom:8px;overflow-x:auto;"><span style="opacity:.5;font-size:12px;">Numbers likhein…</span></div>
    <button type="button" class="btn-primary" style="width:100%;" onclick="symSumInsert()">＋ Question me lagayein</button>
    <div style="font-size:11px;opacity:.65;margin-top:8px;line-height:1.5;">Ye MCQ, True/False, Blanks, Short aur Long sab me chalta hai. Aap seedha <b>{{345+128}}</b> bhi likh sakte hain. Jawab dikhana ho to <b>{{345+128=473}}</b>. Labels ke sath: <b>{{345+128|pv}}</b> ya <b>{{345+128|pvf}}</b>. Checkbox na lagayein to labels print nahi hote.</div>`;
}

function tplPapersStd() {
  ensurePaperMetaDefaults();

  const mcqRows = paperMcqs.map((m,i) => `
    <div class="paper-q-row">
      <div class="flexgap" style="align-items:flex-start;">
        <input type="number" value="${esc(m.no)}" oninput="paperMcqs[${i}].no=this.value" style="width:40px;flex-shrink:0;padding:6px;">
        <textarea rows="1" style="flex:1;" placeholder="${esc(t.mcqType)}..." oninput="paperMcqs[${i}].q=this.value">${esc(m.q)}</textarea>
        <button class="btn-ghost" style="padding:6px 10px;" onclick="removePaperMcq(${i})">✕</button>
      </div>
      <div class="row2" style="margin-top:6px;">
        ${m.options.map((o,oi) => `<input placeholder="${String.fromCharCode(97+oi)}) option" value="${esc(o)}" oninput="paperMcqs[${i}].options[${oi}]=this.value">`).join('')}
      </div>
    </div>${pqBreakBox('a', i)}`).join('');

  // offset lets Blanks and True/False continue the SAME running count of
  // Section A questions that MCQs started, so the "every 5th question" box
  // lands after the 5th question overall in the section, not per sub-type.
  const simpleRows = (list, addFn, delFn, ph, offset=0) => list.map((it,i) => {
    const arrName = delFn.startsWith('removePaperBlank') ? 'paperBlanks' : 'paperTF';
    return `
    <div class="flexgap paper-q-row" style="align-items:flex-start;">
      <input type="number" value="${esc(it.no)}" oninput="${arrName}[${i}].no=this.value" style="width:40px;flex-shrink:0;padding:6px;">
      <textarea rows="1" style="flex:1;" placeholder="${esc(ph)}..." oninput="${arrName}[${i}].q=this.value">${esc(it.q)}</textarea>
      <button class="btn-ghost" style="padding:6px 10px;" onclick="${delFn}(${i})">✕</button>
    </div>${pqBreakBox('a', offset + i)}`;
  }).join('');

  // Long Questions no longer carries a per-question image — a single
  // optional image is attached once, at the very end of the whole paper
  // (see the "end image" card below), since a diagram is rarely needed and
  // only for some subjects (e.g. Science).
  const marksRows = (list, arrName, section) => list.map((it,i) => `
    <div class="paper-q-row">
      <div class="flexgap" style="align-items:flex-start;">
        <input type="number" value="${esc(it.no)}" oninput="${arrName}[${i}].no=this.value" style="width:40px;flex-shrink:0;padding:6px;">
        <textarea rows="1" style="flex:1;" placeholder="${esc(t.paperSubject)}..." oninput="${arrName}[${i}].q=this.value">${esc(it.q)}</textarea>
        <input style="width:70px;" type="number" placeholder="${esc(t.marks)}" value="${esc(it.marks)}" oninput="${arrName}[${i}].marks=this.value">
        <button class="btn-ghost" style="padding:6px 10px;" onclick="removePaper${arrName==='paperShort'?'Short':'Long'}(${i})">✕</button>
      </div>
    </div>${pqBreakBox(section, i)}`).join('');

  const matchRows = (list, letterStyle, addFn, removeFn) => list.map((v,i) => `
    <div class="flexgap paper-q-row" style="align-items:center;">
      <span style="font-size:12px;opacity:.6;width:18px;">${letterStyle==='num' ? (i+1)+'.' : String.fromCharCode(97+i)+')'}</span>
      <input style="flex:1;" value="${esc(v)}" oninput="paperMatch${letterStyle==='num'?'A':'B'}[${i}]=this.value">
      <button class="btn-ghost" style="padding:6px 10px;" onclick="${removeFn}(${i})">✕</button>
    </div>`).join('');

  return `<div style="padding-top:16px;">
    <div class="section-title">${NAV_ICONS.papers}${esc(t.papers)}</div>
    <div class="notice" style="margin-bottom:12px;">${esc(t.paperPreviewNote)}</div>

    <div class="card" style="margin-bottom:14px;">
      <div class="flexgap" style="align-items:center;margin-top:0;">
        <label style="cursor:pointer;flex-shrink:0;">
          ${paperMeta.logo ? `<img src="${paperMeta.logo}" style="width:48px;height:48px;object-fit:contain;border-radius:8px;border:1px solid var(--line);">` : `<div style="width:48px;height:48px;border-radius:8px;border:1px dashed var(--line);display:flex;align-items:center;justify-content:center;font-size:10px;opacity:.6;text-align:center;">${esc(t.logo||'Logo')}</div>`}
          <input type="file" accept="image/*" style="display:none;" onchange="handlePaperLogoUpload(this.files[0])">
        </label>
        <input style="flex:1;font-weight:600;" value="${esc(paperMeta.school_name)}" oninput="paperMeta.school_name=this.value">
      </div>
      <div class="row2" style="margin-top:10px;">
        <label><span>${esc(t.paperExamName)}</span>
          <input list="paper-exam-name-list" value="${esc(paperMeta.exam_name)}" oninput="paperMeta.exam_name=this.value" placeholder="${esc(t.paperExamName)}">
          <datalist id="paper-exam-name-list">
            <option value="Monthly Test">
            <option value="1st Term Exam">
            <option value="Mid Term Exam">
            <option value="Final Term Exam">
          </datalist>
        </label>
        <label><span>${esc(t.paperClass)}</span><input value="${esc(paperMeta.class_name)}" oninput="paperMeta.class_name=this.value"></label>
      </div>
      <div class="row2">
        <label><span>${esc(t.paperSubject)}</span><input value="${esc(paperMeta.subject)}" oninput="paperMeta.subject=this.value"></label>
        <label><span>${esc(t.paperTotalMarks)}</span><input type="number" value="${esc(paperMeta.total_marks)}" oninput="paperMeta.total_marks=this.value"></label>
      </div>
      <div class="row2">
        <label><span>${esc(t.paperTime)}</span><input placeholder="e.g. 2 hours" value="${esc(paperMeta.time_allowed)}" oninput="paperMeta.time_allowed=this.value"></label>
        <label><span>${esc(t.paperDate)}</span><input type="date" value="${esc(paperMeta.exam_date)}" oninput="paperMeta.exam_date=this.value"></label>
      </div>
    </div>

    <!--PQ_HDR_END-->
    <div class="section-title" style="font-size:14px;margin-bottom:8px;"><input dir="auto" style="width:100%;font-size:14px;font-weight:600;" placeholder="${esc(t.mcqSection)}" value="${esc(paperSectionTitles.a)}" oninput="paperSectionTitles.a=this.value"></div>

    <div class="card" style="margin-bottom:14px;">
      <div class="flexgap" style="justify-content:space-between;align-items:center;margin-bottom:8px;">
        <b style="font-size:13px;">${esc(t.mcqType)}</b>
        <label style="margin:0;display:flex;align-items:center;gap:6px;font-size:12px;"><span>${esc(t.marksEach)}</span><input type="number" style="width:60px;" value="${paperMcqMarksEach}" oninput="paperMcqMarksEach=this.value"></label>
      </div>
      <input dir="auto" style="width:100%;font-size:12px;font-style:italic;margin-bottom:8px;" placeholder="${esc(t.instructionPh)}" value="${esc(paperInstructions.mcq)}" oninput="paperInstructions.mcq=this.value">
      ${mcqRows}
      <button class="btn-ghost" style="margin-top:6px;" onclick="addPaperMcq()">${esc(t.addQuestion)}</button>
    </div>

    <div class="card" style="margin-bottom:14px;">
      <b style="font-size:13px;display:block;margin-bottom:8px;">${esc(t.blanksType)}</b>
      <input dir="auto" style="width:100%;font-size:12px;font-style:italic;margin-bottom:8px;" placeholder="${esc(t.instructionPh)}" value="${esc(paperInstructions.blanks)}" oninput="paperInstructions.blanks=this.value">
      ${simpleRows(paperBlanks, 'addPaperBlank', 'removePaperBlank', t.blanksType, paperMcqs.length)}
      <button class="btn-ghost" style="margin-top:6px;" onclick="addPaperBlank()">${esc(t.addQuestion)}</button>
    </div>

    <div class="card" style="margin-bottom:14px;">
      <b style="font-size:13px;display:block;margin-bottom:8px;">${esc(t.tfType)}</b>
      <input dir="auto" style="width:100%;font-size:12px;font-style:italic;margin-bottom:8px;" placeholder="${esc(t.instructionPh)}" value="${esc(paperInstructions.tf)}" oninput="paperInstructions.tf=this.value">
      ${simpleRows(paperTF, 'addPaperTF', 'removePaperTF', t.tfType, paperMcqs.length + paperBlanks.length)}
      <button class="btn-ghost" style="margin-top:6px;" onclick="addPaperTF()">${esc(t.addQuestion)}</button>
    </div>

    <div class="card" style="margin-bottom:14px;">
      <b style="font-size:13px;display:block;margin-bottom:8px;">${esc(t.matchType)}</b>
      <input dir="auto" style="width:100%;font-size:12px;font-style:italic;margin-bottom:8px;" placeholder="${esc(t.instructionPh)}" value="${esc(paperInstructions.match)}" oninput="paperInstructions.match=this.value">
      <div class="row2">
        <div>
          <div style="font-size:11px;opacity:.6;margin-bottom:4px;">Column A</div>
          ${matchRows(paperMatchA, 'num', 'addMatchA', 'removeMatchA')}
          <button class="btn-ghost" style="margin-top:4px;" onclick="addMatchA()">${esc(t.addQuestion)}</button>
        </div>
        <div>
          <div style="font-size:11px;opacity:.6;margin-bottom:4px;">Column B</div>
          ${matchRows(paperMatchB, 'alpha', 'addMatchB', 'removeMatchB')}
          <button class="btn-ghost" style="margin-top:4px;" onclick="addMatchB()">${esc(t.addQuestion)}</button>
        </div>
      </div>
    </div>

    <div class="card" style="margin-bottom:14px;">
      <div style="margin-bottom:8px;"><input dir="auto" style="width:100%;font-size:14px;font-weight:600;" placeholder="${esc(t.shortSection)}" value="${esc(paperSectionTitles.b)}" oninput="paperSectionTitles.b=this.value"></div>
      <input dir="auto" style="width:100%;font-size:12px;font-style:italic;margin-bottom:8px;" placeholder="${esc(t.instructionPh)}" value="${esc(paperInstructions.short)}" oninput="paperInstructions.short=this.value">
      ${marksRows(paperShort, 'paperShort', 'b')}
      <button class="btn-ghost" style="margin-top:6px;" onclick="addPaperShort()">${esc(t.addQuestion)}</button>
    </div>

    <div class="card" style="margin-bottom:14px;">
      <div style="margin-bottom:8px;"><input dir="auto" style="width:100%;font-size:14px;font-weight:600;" placeholder="${esc(t.longSection)}" value="${esc(paperSectionTitles.c)}" oninput="paperSectionTitles.c=this.value"></div>
      <input dir="auto" style="width:100%;font-size:12px;font-style:italic;margin-bottom:8px;" placeholder="${esc(t.instructionPh)}" value="${esc(paperInstructions.long)}" oninput="paperInstructions.long=this.value">
      ${marksRows(paperLong, 'paperLong', 'c')}
      <button class="btn-ghost" style="margin-top:6px;" onclick="addPaperLong()">${esc(t.addQuestion)}</button>
    </div>

    ${tplPqTables()}
    <div class="card" style="margin-bottom:14px;">
      <b style="font-size:13px;display:block;margin-bottom:4px;">${esc(t.paperEndImageLabel)}</b>
      <div style="font-size:11px;opacity:.6;margin-bottom:8px;">${esc(t.paperEndImageHint)}</div>
      <div class="flexgap" style="align-items:center;">
        ${paperEndImage ? `<img src="${paperEndImage}" style="width:44px;height:44px;object-fit:cover;border-radius:6px;border:1px solid var(--line);background:repeating-conic-gradient(#ddd 0% 25%, #fff 0% 50%) 50%/10px 10px;">` : ''}
        <label class="btn-ghost" style="cursor:pointer;font-size:12px;padding:6px 10px;">${esc(t.addImage)}<input type="file" accept="image/*" style="display:none;" onchange="handlePaperEndImageUpload(this.files[0])"></label>
        ${paperEndImage ? `<button class="btn-ghost" style="font-size:12px;padding:6px 10px;" onclick="removePaperEndImage()">${esc(t.removeImage)}</button>` : ''}
      </div>
    </div>

    <button class="btn-primary" style="width:100%;" onclick="printQuestionPaper()">🖨️ ${esc(t.print)}</button>
    ${pqImportBtn()}
    <div class="flexgap" style="margin-top:10px;">
      <button class="btn-ghost" style="flex:1;" onclick="newPaper()">🆕 ${LANG==='ur' ? 'نیا پرچہ' : 'New Paper'}</button>
      ${pqHasBackup() ? `<button class="btn-ghost" style="flex:1;" onclick="restorePreviousPaper()">↩️ ${LANG==='ur' ? 'پچھلا پرچہ' : 'Previous Paper'}</button>` : ''}
    </div>
  </div>`;
}

// Formats paperMeta.exam_date (stored as plain YYYY-MM-DD from the <input
// type="date">) into a readable printed date, e.g. "28 Sep 2026". Falls back
// to an em dash if no date is set, same convention as the other paper fields.
function formatPaperDate(isoDate) {
  if (!isoDate) return '—';
  const [y, m, d] = isoDate.split('-').map(Number);
  if (!y || !m || !d) return '—';
  return new Date(y, m - 1, d).toLocaleDateString(LANG === 'ur' ? 'ur-PK' : 'en-GB', { day:'numeric', month:'short', year:'numeric' });
}

// Printed-paper text: like esc(), but turns superscript characters (10⁻¹⁹) and
// ^ notation (10^-19) into real <sup> so the exponent never shows as an empty
// box when the print font has no glyph for the superscript minus sign.
const PQ_SUP = {'⁰':'0','¹':'1','²':'2','³':'3','⁴':'4','⁵':'5','⁶':'6','⁷':'7','⁸':'8','⁹':'9','⁻':'\u2212','⁺':'+'};
const pqEsc = s => esc(s)
  .replace(/[⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁺]+/g, m => '<sup>' + Array.from(m).map(c => PQ_SUP[c]).join('') + '</sup>')
  .replace(/\^([-\u2212+]?\d+)/g, (m, d) => '<sup>' + d.replace('-', '\u2212') + '</sup>')
  // [[word]] -> underlined word (for "underline the word" style questions)
  .replace(/\[\[(.+?)\]\]/g, '<u>$1</u>')
  // {#} {#a} {#i} ... -> auto serial numbers (counter restarts for every question text)
  .replace(/\{#([1aAiI\u06F1\u0627]?)\}/g, (() => { const c = {}; return (m, k) => { k = k || '1'; c[k] = (c[k] || 0) + 1; return `<span class="pq-sn" dir="ltr">${pqSerialText(k, c[k])})</span>`; }; })())
  // {{345+128}} -> vertical column sum (works in every question type)
  .replace(/\{\{([^{}]{1,80})\}\}/g, (m, e) => pqColSumHtml(e));

function printQuestionPaper() {
  const validMcqs = paperMcqs.filter(m => m.q.trim());
  const validBlanks = paperBlanks.filter(b => b.q.trim());
  const validTF = paperTF.filter(x => x.q.trim());
  const validMatchA = paperMatchA.filter(v => v.trim());
  const validMatchB = paperMatchB.filter(v => v.trim());
  const validShort = paperShort.filter(s => s.q.trim());
  const validLong = paperLong.filter(l => l.q.trim());
  const letters = ['a','b','c','d'];

  // Same optional divider box the builder offers after every question from
  // the 5th one onward (see pqBreakBox / paperBreaks) — printed only when
  // the user actually typed something into that row's box.
  const pqBreakLine = (section, i) => {
    if (i + 1 < 5) return '';
    const grp = i;
    const val = ((paperBreaks[section] || [])[grp] || '').trim();
    return val ? `<div class="pq-break" dir="auto">${pqEsc(val)}</div>` : '';
  };

  const mcqHtml = validMcqs.length ? `
    <div class="pq-sub">
      <div class="pq-marks" style="margin-bottom:6px;">(${paperMcqMarksEach} ${LANG==='ur'?'نمبر فی سوال':'mark(s) each'})</div>
      ${paperInstructions.mcq.trim() ? `<div class="pq-instruction" dir="auto">${esc(paperInstructions.mcq)}</div>` : ''}
      ${validMcqs.map((m,i) => { const d = qDir(m.q); const opts = m.options.map((o,oi)=> o.trim() ? `<span>(${letters[oi]}) ${pqEsc(o)}</span>` : '').join(''); return `
        <div class="pq-q" dir="${d}">
          <div class="pq-q-text"><b>${esc(m.no||i+1)}.</b> ${pqEsc(m.q)}</div>${opts ? `<div class="pq-options">${opts}</div>` : ''}
        </div>${pqBreakLine('a', i)}`; }).join('')}
    </div>` : '';

  const blanksHtml = validBlanks.length ? `
    <div class="pq-sub">
      ${paperInstructions.blanks.trim() ? `<div class="pq-instruction" dir="auto">${esc(paperInstructions.blanks)}</div>` : ''}
      <div class="pq-2col">${validBlanks.map((b,i) => `<div class="pq-q"><div class="pq-q-text" dir="auto"><b>${esc(b.no||i+1)}.</b> ${pqEsc(b.q)}</div></div>${pqBreakLine('a', validMcqs.length + i)}`).join('')}</div>
    </div>` : '';

  const tfHtml = validTF.length ? `
    <div class="pq-sub">
      ${paperInstructions.tf.trim() ? `<div class="pq-instruction" dir="auto">${esc(paperInstructions.tf)}</div>` : ''}
      ${validTF.map((x,i) => `<div class="pq-q"><div class="pq-q-text" dir="auto"><b>${esc(x.no||i+1)}.</b> ${pqEsc(x.q)} <span class="pq-tf">( &nbsp;True&nbsp; / &nbsp;False&nbsp; )</span></div></div>${pqBreakLine('a', validMcqs.length + validBlanks.length + i)}`).join('')}
    </div>` : '';

  const matchHtml = (validMatchA.length && validMatchB.length) ? `
    <div class="pq-sub">
      ${paperInstructions.match.trim() ? `<div class="pq-instruction" dir="auto">${esc(paperInstructions.match)}</div>` : ''}
      <div class="pq-match">
        <div class="pq-match-col">${validMatchA.map((v,i) => `<div dir="auto">${i+1}. ${pqEsc(v)}</div>`).join('')}</div>
        <div class="pq-match-col">${validMatchB.map((v,i) => `<div dir="auto">${String.fromCharCode(97+i)}) ${pqEsc(v)}</div>`).join('')}</div>
      </div>
    </div>` : '';

  const section = (title, list, instruction, key) => list.length ? `
    <div class="pq-section">
      <div class="pq-section-title">${esc(title)}</div>
      ${instruction && instruction.trim() ? `<div class="pq-instruction" dir="auto">${esc(instruction)}</div>` : ''}
      <div class="pq-2col">${list.map((it,i) => `
        <div class="pq-q">
          <div class="pq-q-text" dir="auto"><b>${esc(it.no||i+1)}.</b> ${pqEsc(it.q)} ${it.marks ? `<span class="pq-marks">[${esc(it.marks)}]</span>` : ''}</div>
        </div>${key ? pqBreakLine(key, i) : ''}`).join('')}</div>
    </div>` : '';

  const sectionAHtml = (mcqHtml || blanksHtml || tfHtml || matchHtml) ? `
    <div class="pq-section">
      <div class="pq-section-title">${esc(pqTitle('a', t.mcqSection))}</div>
      ${mcqHtml}${blanksHtml}${tfHtml}${matchHtml}
    </div>` : '';

  document.getElementById('print-area').innerHTML = `
    <div class="qpaper-print" id="qpaper-print-el">
      <div class="qp-head">
        <div class="qp-head-row">
          <div class="qp-side qp-side-left">${esc(t.paperTime)}: ${esc(paperMeta.time_allowed||'—')}<br>${esc(t.paperDate)}: ${esc(formatPaperDate(paperMeta.exam_date))}</div>
          <div class="qp-center">
            ${paperMeta.logo ? `<img src="${paperMeta.logo}" class="qp-logo">` : ''}
            <div class="qp-school">${esc(paperMeta.school_name || 'School')}</div>
            <div class="qp-examname">${esc(paperMeta.exam_name || (LANG==='ur'?'سوالیہ پرچہ':'Question Paper'))}</div>
            <div class="qp-subject">${esc(paperMeta.subject||'')}</div>
            <div class="qp-classline">${esc(t.paperClass)}: ${esc(paperMeta.class_name||'—')}</div>
          </div>
          <div class="qp-side qp-side-right">${esc(t.paperTotalMarks)}: ${esc(paperMeta.total_marks||'—')}</div>
        </div>
        <div class="qp-name-line">${esc(t.studentNameLbl||'Name')}: ______________________&nbsp;&nbsp;&nbsp; ${LANG==='ur'?'رول نمبر':'Roll No.'}: __________</div>
      </div>
      ${paperMode==='kg' ? kgBodyHtml() : `${pqTablesHtml('top')}${sectionAHtml}
      ${pqTablesHtml('preShort')}${section(pqTitle('b', t.shortSection), validShort, paperInstructions.short, 'b')}
      ${pqTablesHtml('postShort')}${section(pqTitle('c', t.longSection), validLong, paperInstructions.long, 'c')}
      ${pqTablesHtml('end')}`}
      ${paperEndImage ? `<div class="pq-end-img-wrap"><img src="${paperEndImage}" class="pq-end-img"></div>` : ''}
    </div>`;
  // The paper is forced onto exactly one A4 page via fitAndSpacePaper, which
  // first stretches or tightens the line/section spacing (a short paper gets
  // spread out to cover the sheet, a long one gets tightened to fit) and
  // only falls back to shrinking with CSS `zoom` (not `transform` — see that
  // function's comment for why transform doesn't work here) if it's still
  // too tall even at minimum spacing.
  const printEl = document.getElementById('qpaper-print-el');
  const imgs = printEl ? Array.from(printEl.querySelectorAll('img')) : [];
  const imgsReady = Promise.all(imgs.map(img => img.complete ? Promise.resolve() : new Promise(res => { img.onload = res; img.onerror = res; })));
  // Web fonts (Noto Nastaliq Urdu / Inter) only start downloading once the text
  // is actually laid out, and #print-area is display:none until print. So show
  // it off-screen first, force-load the fonts, wait for them, and only THEN
  // measure — otherwise the height is measured with fallback fonts and the
  // spacing comes out wrong (squashed lines / half-empty page).
  const warmFonts = () => {
    const box = document.getElementById('print-area');
    const keep = box.getAttribute('style');
    box.style.cssText = 'display:block;position:fixed;left:-99999px;top:0;width:194mm;';
    const sample = printEl ? printEl.textContent.slice(0, 400) : '';
    const loads = (document.fonts && document.fonts.load) ? [
      document.fonts.load('16px "Noto Nastaliq Urdu"', sample),
      document.fonts.load('700 16px "Noto Nastaliq Urdu"', sample),
      document.fonts.load('16px Inter', sample),
      document.fonts.load('700 16px Inter', sample)
    ].map(p => p.catch(()=>{})) : [];
    const fontsReady = (document.fonts && document.fonts.ready) ? document.fonts.ready.catch(()=>{}) : Promise.resolve();
    const timeout = new Promise(res => setTimeout(res, 4000)); // never hang if offline
    return Promise.race([Promise.all([...loads, fontsReady]), timeout]).then(() => {
      if (keep == null) box.removeAttribute('style'); else box.setAttribute('style', keep);
      return new Promise(res => requestAnimationFrame(() => res()));
    });
  };
  imgsReady.then(warmFonts).then(() => {
    // 0.93 = aim for 93% of the page height, never 100%: the print engine's
    // own page break can differ from the on-screen measurement by a few px,
    // and filling the sheet exactly is what pushed the last question onto a
    // 2nd page.
    fitAndSpacePaper('qpaper-print-el', 8, 0.85);
    fitAndSpacePaper('qpaper-print-el', 8, 0.85); // second pass = refine once fonts/layout have settled
    printAsA4(8);
  });
}

// Adjusts the printed paper's spacing so a short paper stretches to cover the
// whole A4 sheet and a long one tightens up to still fit on one page — done
// via a --pq-space CSS variable (see the .qpaper-print rules) that scales
// line-height and the gaps between sections/questions, NOT font-size, so
// text stays fully readable either way. Only if a paper is so long that
// even the minimum spacing still overflows does this fall back to a small
// CSS `zoom` shrink (not `transform` — transform only changes paint, not the
// box's contribution to layout, so the print engine's page-break calculation
// would still see the full height and spill onto a 2nd page even though it
// looks smaller; `zoom` actually shrinks the box in layout terms). The
// element sits inside #print-area, which is normally display:none (only
// shown under @media print) — both are briefly forced visible off-screen
// here to measure the real rendered height, then handed back to the print
// CSS to display for real.
function fitAndSpacePaper(elId, marginMm, safety) {
  const el = document.getElementById(elId);
  const container = document.getElementById('print-area');
  if (!el || !container) return;
  marginMm = marginMm == null ? 8 : marginMm;
  const usableWidthMm = 210 - marginMm * 2;
  const usableHeightMm = 297 - marginMm * 2;

  // Probe real px-per-mm on this device/zoom level using a throwaway element.
  const probe = document.createElement('div');
  probe.style.cssText = `position:fixed;visibility:hidden;height:${usableHeightMm}mm;width:0;`;
  document.body.appendChild(probe);
  const limitPx = probe.getBoundingClientRect().height * (safety && safety > 0 && safety <= 1 ? safety : 1);
  probe.remove();

  const prev = { display: container.style.display, position: container.style.position, left: container.style.left, top: container.style.top, width: container.style.width };
  container.style.display = 'block';
  container.style.position = 'fixed';
  container.style.left = '-99999px';
  container.style.top = '0';
  container.style.width = usableWidthMm + 'mm';

  const prevElDisplay = el.style.display;
  el.style.display = 'block';
  el.style.zoom = 1;
  el.style.setProperty('--pq-space', 1);
  el.style.height = 'auto';

  const baselineHeight = el.scrollHeight;

  // How far spacing can stretch (short paper, fill the sheet) or shrink
  // (long paper, help it fit) before it starts looking wrong.
  const MIN_SPACE = 1;
  const MAX_SPACE = 2.4;
  let space = baselineHeight > 0 ? (limitPx / baselineHeight) : 1;
  space = Math.max(MIN_SPACE, Math.min(MAX_SPACE, space));
  el.style.setProperty('--pq-space', space);

  // Spacing isn't perfectly linear with height (the header/logo/images don't
  // scale with --pq-space), so nudge once more toward the target if the
  // first pass landed noticeably off.
  const afterFirstPass = el.scrollHeight;
  if (afterFirstPass > 0 && Math.abs(afterFirstPass - limitPx) > limitPx * 0.03) {
    const nudged = space * (limitPx / afterFirstPass);
    space = Math.max(MIN_SPACE, Math.min(MAX_SPACE, nudged));
    el.style.setProperty('--pq-space', space);
  }

  // Safety net: a paper so long that even MIN_SPACE still overflows the page
  // gets a small zoom-out on top, same as before — just now only kicking in
  // after spacing has already done most of the work.
  const finalHeight = el.scrollHeight;
  const MIN_ZOOM = 0.45;
  const zoomScale = finalHeight > limitPx ? Math.max(MIN_ZOOM, limitPx / finalHeight) : 1;
  el.style.zoom = zoomScale < 1 ? zoomScale : 1;

  el.style.display = prevElDisplay;

  container.style.display = prev.display;
  container.style.position = prev.position;
  container.style.left = prev.left;
  container.style.top = prev.top;
  container.style.width = prev.width;
  // Both el.style.zoom and the --pq-space custom property are intentionally
  // left in place — that's what makes them apply when @media print later
  // shows this element for real.
}



// Temporarily overrides the page orientation for a single print job (the wide
// ledger table needs landscape while every other print — receipts, SLC,
// character certificate — should stay portrait), then removes the override
// right after so later prints aren't affected.
function printWithOrientation(orientation) {
  const styleEl = document.createElement('style');
  styleEl.id = 'print-orientation-override';
  styleEl.textContent = `@media print { @page{ size:${orientation}; margin:8mm; } }`;
  document.head.appendChild(styleEl);
  const cleanup = () => { styleEl.remove(); window.removeEventListener('afterprint', cleanup); };
  window.addEventListener('afterprint', cleanup);
  window.print();
  setTimeout(cleanup, 3000); // fallback in case afterprint doesn't fire
}

// Forces the page size to A4 portrait for a single print job regardless of
// whatever paper size the device/printer driver defaults to (e.g. "Letter"
// on some Android/Chrome print dialogs). The SLC and Character Certificate
// are laid out to exact A4-minus-10mm-margin dimensions (190mm x 277mm), so
// without this override a different default paper size makes the
// certificate taller than the printable area and spill onto a second page.
function printAsA4(marginMm) {
  const styleEl = document.createElement('style');
  styleEl.id = 'print-pagesize-override';
  styleEl.textContent = `@media print { @page{ size:A4 portrait; margin:${marginMm || 10}mm; } }`;
  document.head.appendChild(styleEl);
  const cleanup = () => { styleEl.remove(); window.removeEventListener('afterprint', cleanup); };
  window.addEventListener('afterprint', cleanup);
  window.print();
  setTimeout(cleanup, 3000);
}

// Forces a narrow, receipt-roll page size (default 80mm wide, height auto)
// for a single print job — used for the thermal-style vouchers/receipts so
// they print as a slim POS strip instead of a full A4 sheet.
function printAsThermal(widthMm) {
  const styleEl = document.createElement('style');
  styleEl.id = 'print-thermal-override';
  styleEl.textContent = `@media print { @page{ size:${widthMm || 80}mm auto; margin:2mm; } }`;
  document.head.appendChild(styleEl);
  const cleanup = () => { styleEl.remove(); window.removeEventListener('afterprint', cleanup); };
  window.addEventListener('afterprint', cleanup);
  window.print();
  setTimeout(cleanup, 3000);
}

// Fills the Admission Register's attendance_possible/attendance_actual
// fields from the actual daily attendance recorded via the Class Portal
// (student_attendance table) for the student linked in this form, over the
// date range from their admission date to their withdrawal date (or today
// if still enrolled). Both counted in the same units as attendanceDaysCount()
// (AM+PM each = 1, so a full day is 2) so the two numbers stay comparable.
// Explicit button, not automatic on load, so it never silently overwrites a
// value someone entered by hand.
async function calcAdmissionAttendance() {
  const studentId = document.getElementById('ar-student-link').value;
  const msgEl = document.getElementById('ar-attendance-calc-msg');
  if (!studentId) { if (msgEl) msgEl.textContent = LANG==='ur' ? 'پہلے طالب علم منتخب کریں' : 'Link a student first'; return; }
  const start = dateVal('ar-admission-date') || todayISO();
  const end = dateVal('ar-withdrawal-date', null) || todayISO();
  const monthStart = monthStartISO();
  // This month: day-by-day rows from the cache already in memory.
  let actual = attendanceDaysCount(DATA.studentAttendance.filter(r => r.student_id === studentId && r.date >= start && r.date <= end));
  // Earlier months: totals (rolled up) + any rows not rolled up yet. Needs internet.
  if (start < monthStart) {
    try {
      const oldRows = await fetchAll(() => sb.from('student_attendance').select('status_am,status_pm,date')
        .eq('student_id', studentId).gte('date', start).lt('date', monthStart).lte('date', end));
      if (oldRows.error) throw oldRows.error;
      actual += attendanceDaysCount(oldRows.data || []);
      const tot = await fetchAll(() => sb.from('student_attendance_totals').select('present_days')
        .eq('student_id', studentId).gte('session_start', sessionStartISO(start)).lte('session_start', end));
      if (tot.error && !/does not exist|schema cache|PGRST205|42P01/i.test((tot.error.message || '') + (tot.error.code || ''))) throw tot.error;
      (tot.data || []).forEach(r => { actual += (r.present_days || 0); });
    } catch (e) {
      if (msgEl) msgEl.textContent = '✗ ' + (e && e.message ? e.message : 'internet?');
      return;
    }
  }
  let possible = 0;
  for (let d = new Date(start + 'T00:00:00'); d <= new Date(end + 'T00:00:00'); d.setDate(d.getDate() + 1)) {
    if (!isHoliday(localISO(d))) possible += 2;
  }
  document.getElementById('ar-attendance-possible').value = possible;
  document.getElementById('ar-attendance-actual').value = actual;
  if (msgEl) msgEl.textContent = '✓';
}

function admissionEntryForm(r) {
  r = r || {};
  const cols = [
    [t.serialNo, `<input class="cell-input" id="ar-serial" type="number" value="${esc(r.serial_no||'')}">`],
    [t.admissionDate, `<input class="cell-input" id="ar-admission-date" type="date" value="${esc(r.admission_date||todayISO())}">`],
    [t.studentName, `<input class="cell-input" id="ar-name" value="${esc(r.student_name||'')}">`],
    [t.studentNameUr, `<input class="cell-input" id="ar-name-ur" dir="rtl" value="${esc(r.student_name_ur||'')}">`],
    [t.dobFigures, `<input class="cell-input" id="ar-dob-figures" type="date" value="${esc(r.dob_figures||'')}">`],
    [t.dobWords, `<input class="cell-input" id="ar-dob-words" value="${esc(r.dob_words||'')}">`],
    [t.fatherName, `<input class="cell-input" id="ar-father" value="${esc(r.father_name||'')}">`],
    [t.fatherNameUr, `<input class="cell-input" id="ar-father-ur" dir="rtl" value="${esc(r.father_name_ur||'')}">`],
    [t.casteTribe, `<input class="cell-input" id="ar-caste" value="${esc(r.caste_tribe||'')}">`],
    [t.casteTribeUr, `<input class="cell-input" id="ar-caste-ur" dir="rtl" value="${esc(r.caste_tribe_ur||'')}">`],
    [t.occupation, `<input class="cell-input" id="ar-occupation" value="${esc(r.occupation||'')}">`],
    [t.residence, `<input class="cell-input" id="ar-residence" value="${esc(r.residence||'')}">`],
    [t.residenceUr, `<input class="cell-input" id="ar-residence-ur" dir="rtl" value="${esc(r.residence_ur||'')}">`],
    [t.classAdmitted, `<select class="cell-input" id="ar-class-admitted">${CLASS_OPTIONS.map(c=>`<option ${r.class_admitted===c?'selected':''}>${c}</option>`).join('')}</select>`],
    [t.linkStudent, `<select class="cell-input" id="ar-student-link"><option value="">${esc(t.linkStudentNone)}</option>${DATA.students.map(s=>`<option value="${s.id}" ${r.student_id===s.id?'selected':''}>${esc(s.name)}${s.roll_no?' (#'+esc(s.roll_no)+')':''}</option>`).join('')}</select>`],
    [t.arrearsDue, `<input class="cell-input" id="ar-arrears" type="number" value="${esc(r.arrears_due||0)}">`],
    [t.classWithdrawn, `<select class="cell-input" id="ar-class-withdrawn"><option value="">—</option>${CLASS_OPTIONS.map(c=>`<option ${r.class_withdrawn===c?'selected':''}>${c}</option>`).join('')}</select>`],
    [t.withdrawalDate, `<input class="cell-input" id="ar-withdrawal-date" type="date" value="${esc(r.withdrawal_date||'')}">`],
    [t.highMiddleSlcNo, `<input class="cell-input" id="ar-hm-slc-no" value="${esc(r.high_middle_slc_no||'')}">`],
    [t.bise, `<input class="cell-input" id="ar-bise" value="${esc(r.bise_enrolment_no||'')}">`],
    [t.slcIssueDateField, `<input class="cell-input" id="ar-slc-issue-date" type="date" value="${esc(r.slc_issue_date||'')}">`],
    [t.attendancePossible, `<input class="cell-input" id="ar-attendance-possible" value="${esc(r.attendance_possible||'')}">`],
    [t.attendanceActual, `<input class="cell-input" id="ar-attendance-actual" value="${esc(r.attendance_actual||'')}">`],
    ['', `<button type="button" class="btn-ghost" style="white-space:nowrap;" onclick="calcAdmissionAttendance()" title="${LANG==='ur'?'کلاس پورٹل کی حاضری سے حساب لگائیں':'Calculate from Class Portal attendance'}">🔄</button><div id="ar-attendance-calc-msg" style="font-size:10px;opacity:.7;"></div>`],
    [t.schoolFundReport, `<input class="cell-input" id="ar-school-fund" value="${esc(r.school_fund_report||'')}">`],
    [t.conduct, `<input class="cell-input" id="ar-conduct" value="${esc(r.conduct||'')}">`],
    [t.remarks, `<input class="cell-input" id="ar-remarks" value="${esc(r.remarks||'')}">`],
  ];
  return `
    <div class="regbook-screen-wrap" style="margin-bottom:14px;">
      <table class="regbook-screen">
        <thead><tr>${cols.map(c => `<th>${esc(c[0])}</th>`).join('')}</tr></thead>
        <tbody><tr>${cols.map(c => `<td class="input-cell">${c[1]}</td>`).join('')}</tr></tbody>
      </table>
    </div>`;
}

function openAddAdmissionEntry() {
  showModal(t.addRegisterEntry, `
    ${admissionEntryForm()}
    <div class="flexgap">
      <button class="btn-ghost" onclick="closeModal()">${esc(t.cancel)}</button>
      <button class="btn-primary" style="flex:1" onclick="guardedSubmit(this, submitAddAdmissionEntry)">${esc(t.save)}</button>
    </div>
  `);
}

function readAdmissionForm() {
  return {
    serial_no: document.getElementById('ar-serial').value ? Number(document.getElementById('ar-serial').value) : null,
    admission_date: dateVal('ar-admission-date'),
    student_name: document.getElementById('ar-name').value.trim(),
    student_name_ur: document.getElementById('ar-name-ur').value.trim() || null,
    dob_figures: dateVal('ar-dob-figures', ''),
    dob_words: document.getElementById('ar-dob-words').value.trim(),
    father_name: document.getElementById('ar-father').value.trim(),
    father_name_ur: document.getElementById('ar-father-ur').value.trim() || null,
    caste_tribe: document.getElementById('ar-caste').value.trim(),
    caste_tribe_ur: document.getElementById('ar-caste-ur').value.trim() || null,
    occupation: document.getElementById('ar-occupation').value.trim(),
    residence: document.getElementById('ar-residence').value.trim(),
    residence_ur: document.getElementById('ar-residence-ur').value.trim() || null,
    class_admitted: document.getElementById('ar-class-admitted').value,
    student_id: document.getElementById('ar-student-link').value || null,
    arrears_due: Number(document.getElementById('ar-arrears').value || 0),
    class_withdrawn: document.getElementById('ar-class-withdrawn').value || null,
    withdrawal_date: dateVal('ar-withdrawal-date', null),
    high_middle_slc_no: document.getElementById('ar-hm-slc-no').value.trim(),
    bise_enrolment_no: document.getElementById('ar-bise').value.trim(),
    slc_issue_date: dateVal('ar-slc-issue-date', null),
    attendance_possible: document.getElementById('ar-attendance-possible').value.trim(),
    attendance_actual: document.getElementById('ar-attendance-actual').value.trim(),
    school_fund_report: document.getElementById('ar-school-fund').value.trim(),
    conduct: document.getElementById('ar-conduct').value.trim(),
    remarks: document.getElementById('ar-remarks').value.trim(),
  };
}

async function submitAddAdmissionEntry() {
  const entry = readAdmissionForm();
  if (!entry.student_name) return;
  entry.parent_pin = String(Math.floor(100000 + Math.random() * 900000));
  const payload = { id: crypto.randomUUID ? crypto.randomUUID() : `local-${Date.now()}`, owner_id: CURRENT_USER.id, ...entry };
  // Offline-aware: a brand-new register entry, so there's nothing on the
  // server yet to conflict with — safe to just insert once back online.
  const { queued, error } = await offlineWrite({
    table: 'admission_register', action: 'insert', payload, id: payload.id, baseRow: null,
    run: () => sb.from('admission_register').insert(payload),
    optimisticApply: () => { DATA.admissionRegister.push(payload); idbPutRow('admission_register', payload); }
  });
  if (!queued && reportSaveError(error)) return;
  closeModal(); if (!queued) await loadAllData(); renderTab();
}

function openEditAdmissionEntry(id) {
  const r = DATA.admissionRegister.find(x => x.id === id);
  if (!r) return;
  const codeBox = r.parent_pin ? `
    <div style="background:var(--surface2);border-radius:8px;padding:10px 12px;margin-bottom:12px;font-size:13px;">
      <b>${esc(t.parentCode)}:</b> ${esc(CURRENT_PROFILE.school_code || '—')} / ${esc(r.serial_no || '—')} / ${esc(r.parent_pin)}
      ${!CURRENT_PROFILE.school_code ? `<div style="color:var(--rust);margin-top:4px;">${esc(t.parentSchoolCodeMissing)}</div>` : ''}
    </div>` : `
    <div style="background:var(--surface2);border-radius:8px;padding:10px 12px;margin-bottom:12px;font-size:13px;">
      <span style="opacity:.7;">${esc(t.parentCodeNone)}</span>
      <button type="button" class="btn-ghost" style="margin-top:6px;width:100%;" onclick="generateParentPinForEntry('${id}')">${esc(t.parentGenerateCode)}</button>
    </div>`;
  showModal(r.student_name || t.editRegisterEntry, `
    ${codeBox}
    ${admissionEntryForm(r)}
    <div class="flexgap" style="flex-wrap:wrap;">
      <button class="btn-ghost" style="color:var(--rust);border-color:var(--rust);" onclick="confirmDelete('admissionEntry','${id}')">${esc(t.delete)}</button>
      <button class="btn-ghost" onclick="printAdmissionEntry('${id}')">🖨️ ${esc(t.print)}</button>
      <button class="btn-ghost" onclick="printCharacterCertificate('${id}')">🖨️ ${esc(t.printCc)}</button>
      <button class="btn-primary" style="flex:1" onclick="guardedSubmit(this, ()=>submitEditAdmissionEntry('${id}'))">${esc(t.save)}</button>
    </div>
  `);
}

// Backfills a Parent PIN for an admission-register entry created before the
// Parent Portal feature existed — new entries already get one automatically
// (see submitAddAdmissionEntry), this just covers the older ones on demand.
async function generateParentPinForEntry(id) {
  const pin = String(Math.floor(100000 + Math.random() * 900000));
  const { error } = await sb.from('admission_register').update({ parent_pin: pin }).eq('id', id);
  if (reportSaveError(error)) return;
  await loadAllData();
  openEditAdmissionEntry(id); // re-open so the new code box shows immediately
}

// Prints a single admission-register entry as a clean one-record sheet — used
// from the search bar's print button when a search narrows the list to one match.
async function printSingleAdmissionEntry(id) {
  const r = DATA.admissionRegister.find(x => x.id === id);
  if (!r) return;
  await loadDMCConfig(); // pulls the editable school logo saved under Certificates (DMC) config
  const dash = '—';
  const rows = [
    [t.admissionDate, fmtDate(r.admission_date)],
    [t.serialNo, r.serial_no],
    [t.studentName, r.student_name],
    [t.dobLabel, [r.dob_words, fmtDate(r.dob_figures)].filter(Boolean).join(' — ')],
    [t.fatherName, r.father_name],
    [t.casteTribe, r.caste_tribe],
    [t.occupation, r.occupation],
    [t.residence, r.residence],
    [t.classAdmitted, r.class_admitted],
    [t.arrearsDue, Number(r.arrears_due||0) ? '₨'+fmt(r.arrears_due) : dash],
    [t.classWithdrawn, r.class_withdrawn],
    [t.withdrawalDate, fmtDate(r.withdrawal_date)],
    [t.remarks, r.remarks],
  ];
  const rowsHtml = rows.map(([label, val]) => `
    <div style="display:flex;border-bottom:1px dashed #E7E0CE;padding:8px 4px;">
      <div style="width:170px;flex-shrink:0;font-weight:700;color:#0F2740;font-size:13px;">${esc(label)}</div>
      <div style="flex:1;font-size:13px;color:#1C2530;">${esc(val || dash)}</div>
    </div>`).join('');

  document.getElementById('print-area').innerHTML = `
    <div class="slc-print" style="max-width:640px;">
      <span class="slc-corner tl">❧</span>
      <span class="slc-corner tr">❧</span>
      <span class="slc-corner bl">❧</span>
      <span class="slc-corner br">❧</span>
      <div class="slc-inner">
        ${dmcLogo ? `<div class="slc-watermark"><img src="${dmcLogo}" alt=""></div>` : ''}
        <div class="slc-content">
          <div class="slc-head">
            ${dmcLogo ? `<img class="slc-logo" src="${dmcLogo}" alt="School Logo">` : ''}
            <div class="eyebrow">${esc(t.headOfInstitution)}</div>
            <div class="slc-name-wrap"><span class="flourish">✦</span><h2>${esc(CURRENT_PROFILE.school_name || 'School')}</h2><span class="flourish">✦</span></div>
            <div class="slc-title-wrap">
              <span class="rule"></span>
              <span class="slc-title">${esc(t.admissionRegister)}</span>
              <span class="rule r"></span>
            </div>
          </div>
          <div style="margin-top:16px;">${rowsHtml}</div>
        </div>
      </div>
    </div>`;
  window.print();
}

// Prints a single admission entry as a formal School Leaving Certificate (SLC).
// The certificate is written as a narrative paragraph (not a bare field list),
// with every actual record value (names, dates, numbers) bolded within the
// otherwise italic certificate text so they stand out at a glance.
function rec(val, dash) {
  // Wraps a record value in a bold span; falls back to a plain dash if empty.
  return val ? `<b class="rec">${esc(val)}</b>` : `<b class="rec">${esc(dash)}</b>`;
}

function slcParagraphEn(r, dash) {
  const rel = 'S/O, D/O';
  return `
    This is to certify that ${rec(r.student_name, dash)} ${rel} ${rec(r.father_name, dash)},
    resident of ${rec(r.residence, dash)}, bearing Serial No. ${rec(r.serial_no, dash)} in the
    Admission &amp; Withdrawal Register of this institution, was admitted on ${rec(fmtDate(r.admission_date), dash)}
    in Class ${rec(r.class_admitted, dash)}. As per the register, his/her date of birth is
    ${rec(r.dob_words, dash)} (${rec(fmtDate(r.dob_figures), dash)}), and he/she was struck off the rolls
    on ${rec(fmtDate(r.withdrawal_date), dash)}. During the period of study, his/her conduct remained
    ${rec(r.conduct || 'Good', dash)}. This certificate is issued at his/her request for whatever purpose it may serve.
  `;
}

function slcParagraphUr(r, dash) {
  const rel = 'ولد، بنتِ';
  return `
    یہ تصدیق کی جاتی ہے کہ ${rec(r.student_name_ur || r.student_name, dash)} ${rel} ${rec(r.father_name_ur || r.father_name, dash)}،
    ساکن ${rec(r.residence_ur || r.residence, dash)}، جو اس ادارے کے داخلہ و اخراج رجسٹر میں سیریل نمبر
    ${rec(r.serial_no, dash)} پر درج ہے، کو تاریخ ${rec(fmtDate(r.admission_date), dash)} کو جماعت
    ${rec(classNameUrdu(r.class_admitted), dash)} میں داخل کیا گیا تھا۔ رجسٹر کے مطابق موصوف/موصوفہ کی تاریخ پیدائش
    ${rec(r.dob_words, dash)} (${rec(fmtDate(r.dob_figures), dash)}) ہے، اور وہ تاریخ ${rec(fmtDate(r.withdrawal_date), dash)}
    کو رجسٹر سے خارج کیے گئے۔ زیرِ تعلیم رہنے کی مدت کے دوران اخلاق ${rec(r.conduct || 'اچھا', dash)} رہا۔
    یہ سرٹیفکیٹ ان کی درخواست پر، جہاں ضرورت ہو استعمال کے لیے، جاری کیا جاتا ہے۔
  `;
}

async function printAdmissionEntry(id) {
  const r = DATA.admissionRegister.find(x => x.id === id);
  if (!r) return;
  await loadDMCConfig(); // pulls the editable school logo saved under Certificates (DMC) config
  const dash = '—';
  const paragraph = (LANG === 'ur') ? slcParagraphUr(r, dash) : slcParagraphEn(r, dash);

  document.getElementById('print-area').innerHTML = `
    <div class="slc-print">
      <span class="slc-corner tl">❧</span>
      <span class="slc-corner tr">❧</span>
      <span class="slc-corner bl">❧</span>
      <span class="slc-corner br">❧</span>
      <div class="slc-inner">
        ${dmcLogo ? `<div class="slc-watermark"><img src="${dmcLogo}" alt=""></div>` : ''}
        <div class="slc-content">
        <div class="slc-head">
          ${dmcLogo ? `<img class="slc-logo" src="${dmcLogo}" alt="School Logo">` : ''}
          <div class="eyebrow">${esc(t.headOfInstitution)}</div>
          <div class="slc-name-wrap"><span class="flourish">✦</span><h2>${esc((LANG === 'ur' ? schoolNameUrdu() : CURRENT_PROFILE.school_name) || 'School')}</h2><span class="flourish">✦</span></div>
          <div class="slc-title-wrap">
            <span class="rule"></span>
            <span class="slc-title">${esc(t.slcTitle)}</span>
            <span class="rule r"></span>
          </div>
        </div>
        <div class="slc-meta">
          <span><b>${esc(t.slcNo)}:</b> ${esc(r.serial_no || dash)}</span>
          <span><b>${esc(t.slcIssueDate)}:</b> ${esc(fmtDate(r.slc_issue_date || todayISO()))}</span>
        </div>
        <div class="slc-meta" style="margin-top:6px;flex-wrap:wrap;gap:8px;">
          <span><b>${esc(t.highMiddleSlcNo)}:</b> ${esc(r.high_middle_slc_no || dash)}</span>
          <span><b>${esc(t.bise)}:</b> ${esc(r.bise_enrolment_no || dash)}</span>
        </div>
        <div class="slc-body">${paragraph}</div>
        <div class="slc-meta" style="margin-top:14px;flex-wrap:wrap;gap:8px;">
          <span><b>${esc(t.attendancePossible)}:</b> ${esc(r.attendance_possible || dash)}</span>
          <span><b>${esc(t.attendanceActual)}:</b> ${esc(r.attendance_actual || dash)}</span>
        </div>
        <div class="slc-remarks">${esc(t.schoolFundReport)}: <b class="rec">${esc(r.school_fund_report || dash)}</b></div>
        <div class="slc-foot">
          <div class="box seal"><div class="line"></div>${esc(t.officialSeal)}</div>
          <div class="box"><div class="line"></div>${esc(t.headOfInstitution)}</div>
        </div>
        </div>
      </div>
    </div>`;
  printAsA4();
  logCertificateIssued('SLC', r.student_name, r.class_withdrawn || r.class_admitted, r.id);
}

// Character Certificate — narrative paragraph (same record-value-in-bold treatment
// as the SLC) but focused purely on conduct/character rather than admission &
// withdrawal, and usable for currently-enrolled as well as left students.
// CLASS_OPTIONS is a fixed dropdown, so unlike free-text names/addresses this can
// be translated automatically — no manual Urdu entry needed for class names.
const CLASS_NAME_UR = {
  'Nursery':'نرسری', 'KG':'کے جی', '1st':'اول', '2nd':'دوم', '3rd':'سوم', '4th':'چہارم',
  '5th':'پنجم', '6th':'ششم', '7th':'ہفتم', '8th':'ہشتم', '9th':'نہم', '10th':'دہم',
  '11th':'گیارہویں', '12th':'بارہویں'
};
function classNameUrdu(c) { return CLASS_NAME_UR[c] || c; }

function ccParagraphEn(r, dash) {
  const rel = 'S/O, D/O';
  const studyLine = r.class_withdrawn
    ? `and remained on the rolls of this institution up to Class ${rec(r.class_withdrawn, dash)}, from which he/she was struck off on ${rec(fmtDate(r.withdrawal_date), dash)}`
    : `and is currently studying in Class ${rec(r.class_admitted, dash)} at this institution`;
  return `
    This is to certify that ${rec(r.student_name, dash)} ${rel} ${rec(r.father_name, dash)},
    Caste/Tribe ${rec(r.caste_tribe, dash)}, resident of ${rec(r.residence, dash)}, bearing
    Serial No. ${rec(r.serial_no, dash)} in the Admission &amp; Withdrawal Register of this institution,
    was admitted on ${rec(fmtDate(r.admission_date), dash)} in Class ${rec(r.class_admitted, dash)}, ${studyLine}.
    During the entire period of his/her stay at this institution, his/her character and conduct
    remained ${rec(r.conduct || 'Good', dash)}, and he/she was never found involved in any activity
    prejudicial to the discipline or moral atmosphere of the institution. This certificate is issued
    on his/her request for whatever purpose it may serve.
  `;
}

function ccParagraphUr(r, dash) {
  const rel = 'ولد، بنتِ';
  const studyLine = r.class_withdrawn
    ? `اور اس ادارے میں جماعت ${rec(classNameUrdu(r.class_withdrawn), dash)} تک زیرِ تعلیم رہے، اور تاریخ ${rec(fmtDate(r.withdrawal_date), dash)} کو رجسٹر سے خارج ہوئے`
    : `اور فی الحال اس ادارے میں جماعت ${rec(classNameUrdu(r.class_admitted), dash)} میں زیرِ تعلیم ہیں`;
  return `
    یہ تصدیق کی جاتی ہے کہ ${rec(r.student_name_ur || r.student_name, dash)} ${rel} ${rec(r.father_name_ur || r.father_name, dash)}،
    ذات/قبیلہ ${rec(r.caste_tribe_ur || r.caste_tribe, dash)}، ساکن ${rec(r.residence_ur || r.residence, dash)}، جو اس ادارے کے داخلہ و اخراج
    رجسٹر میں سیریل نمبر ${rec(r.serial_no, dash)} پر درج ہے، کو تاریخ ${rec(fmtDate(r.admission_date), dash)}
    کو جماعت ${rec(classNameUrdu(r.class_admitted), dash)} میں داخل کیا گیا تھا، ${studyLine}۔ اس ادارے میں قیام کے پورے
    عرصے کے دوران موصوف/موصوفہ کا اخلاق و کردار ${rec(r.conduct || 'اچھا', dash)} رہا، اور وہ کبھی بھی
    ادارے کے نظم و ضبط یا اخلاقی ماحول کے منافی کسی سرگرمی میں ملوث نہیں پائے گئے۔ یہ سرٹیفکیٹ ان کی
    درخواست پر، جہاں ضرورت ہو استعمال کے لیے، جاری کیا جاتا ہے۔
  `;
}

// Prints a full-page Character Certificate for an admission-register entry —
// deliberately more spacious than the SLC (larger type, taller line-height,
// generous margins) so the certificate fills the page the way a formal
// character certificate is expected to.
async function printCharacterCertificate(id) {
  const r = DATA.admissionRegister.find(x => x.id === id);
  if (!r) return;
  await loadDMCConfig(); // pulls the editable school logo saved under Certificates (DMC) config
  const dash = '—';
  const paragraph = (LANG === 'ur') ? ccParagraphUr(r, dash) : ccParagraphEn(r, dash);

  document.getElementById('print-area').innerHTML = `
    <div class="cc-print">
      <span class="cc-corner tl">❧</span>
      <span class="cc-corner tr">❧</span>
      <span class="cc-corner bl">❧</span>
      <span class="cc-corner br">❧</span>
      <div class="cc-inner">
        ${dmcLogo ? `<div class="cc-watermark"><img src="${dmcLogo}" alt=""></div>` : ''}
        <div class="cc-content">
          <div class="cc-head">
            ${dmcLogo ? `<img class="cc-logo" src="${dmcLogo}" alt="School Logo">` : ''}
            <div class="eyebrow">${esc(t.headOfInstitution)}</div>
            <div class="cc-name-wrap"><span class="flourish">✦</span><h2>${esc((LANG === 'ur' ? schoolNameUrdu() : CURRENT_PROFILE.school_name) || 'School')}</h2><span class="flourish">✦</span></div>
            <div class="cc-title-wrap">
              <span class="rule"></span>
              <span class="cc-title">${esc(t.ccTitle)}</span>
              <span class="rule r"></span>
            </div>
          </div>
          <div class="cc-meta">
            <span><b>${esc(t.ccNo)}:</b> ${esc(r.serial_no || dash)}</span>
            <span><b>${esc(t.ccIssueDate)}:</b> ${esc(fmtDate(todayISO()))}</span>
          </div>
          <div class="cc-body">${paragraph}</div>
          <div class="cc-quote">${esc(dmcQuote || (LANG === 'ur' ? 'تعلیم مستقبل روشن بنانے کی کنجی ہے۔' : 'Character is the foundation on which a bright future is built.'))}</div>
          <div class="cc-foot">
            <div class="box seal"><div class="line"></div>${esc(t.officialSeal)}</div>
            <div class="box"><div class="line"></div>${esc(t.headOfInstitution)}</div>
          </div>
        </div>
      </div>
    </div>`;
  printAsA4();
  logCertificateIssued('Character Certificate', r.student_name, r.class_admitted, r.id);
}

async function submitEditAdmissionEntry(id) {
  const entry = readAdmissionForm();
  if (!entry.student_name) return;
  const baseRow = DATA.admissionRegister.find(x => x.id === id) || null;
  // Offline-aware: applied to the local cache immediately and queued —
  // syncs automatically once back online (with a conflict prompt if another
  // device changed this same entry meanwhile).
  const { queued, error } = await offlineWrite({
    table: 'admission_register', action: 'update', payload: entry, id, baseRow,
    run: () => sb.from('admission_register').update(entry).eq('id', id),
    optimisticApply: () => {
      const idx = DATA.admissionRegister.findIndex(x => x.id === id);
      if (idx >= 0) { DATA.admissionRegister[idx] = { ...DATA.admissionRegister[idx], ...entry }; idbPutRow('admission_register', DATA.admissionRegister[idx]); }
    }
  });
  if (!queued && reportSaveError(error)) return;
  closeModal(); if (!queued) await loadAllData(); renderTab();
}


function showModal(title, bodyHtml) {
  document.getElementById('modal-root').innerHTML = `
    <div class="modal-bg" onclick="if(event.target===this)closeModal()">
      <div class="modal">
        <div class="modal-head"><h3>${esc(title)}</h3><button onclick="closeModal()">✕</button></div>
        ${bodyHtml}
      </div>
    </div>`;
  // No-op unless this modal happens to contain a .regbook-screen-wrap (e.g.
  // the Admission Register's Add/Edit form) — see initRegBookScroll().
  initRegBookScroll();
}
function closeModal() { document.getElementById('modal-root').innerHTML = ''; }

function confirmDelete(kind, id) {
  showModal(t.delete, `
    <p style="font-size:14px;">${esc(t.confirmDelete)}</p>
    <div class="flexgap">
      <button class="btn-ghost" onclick="closeModal()">${esc(t.no)}</button>
      <button class="btn-primary" style="flex:1;background:var(--rust);" onclick="doDelete('${kind}','${id}')">${esc(t.yes)}</button>
    </div>
  `);
}
async function doDelete(kind, id) {
  // Delete dependent ledger rows first so a missing FK-cascade rule on the
  // database can't silently block the delete or leave orphaned payment records.
  let err = null;
  if (kind==='student') {
    // Offline-aware: queues the student's fee_payments deletes and the
    // student delete itself; all applied to the local cache immediately.
    const relatedPayments = DATA.feePayments.filter(x => x.student_id === id);
    for (const fp of relatedPayments) {
      const r1 = await offlineWrite({
        table: 'fee_payments', action: 'delete', payload: null, id: fp.id, baseRow: fp,
        run: () => sb.from('fee_payments').delete().eq('id', fp.id),
        optimisticApply: () => { DATA.feePayments = DATA.feePayments.filter(x => x.id !== fp.id); idbDeleteRow('fee_payments', fp.id); }
      });
      if (!r1.queued && r1.error) err = r1.error;
    }
    const baseStudent = DATA.students.find(x => x.id === id) || null;
    const r2 = await offlineWrite({
      table: 'students', action: 'delete', payload: null, id, baseRow: baseStudent,
      run: () => sb.from('students').delete().eq('id', id),
      optimisticApply: () => { DATA.students = DATA.students.filter(x => x.id !== id); idbDeleteRow('students', id); }
    });
    if (!r2.queued && r2.error) err = r2.error;
  }
  if (kind==='teacher') {
    // Offline-aware: queues the teacher's salary_payments + attendance deletes
    // and the teacher delete itself; all applied to the local cache immediately
    // (mirrors the student/fee_payments cascade above).
    const relatedSalary = DATA.salaryPayments.filter(x => x.teacher_id === id);
    for (const sp of relatedSalary) {
      const r1 = await offlineWrite({
        table: 'salary_payments', action: 'delete', payload: null, id: sp.id, baseRow: sp,
        run: () => sb.from('salary_payments').delete().eq('id', sp.id),
        optimisticApply: () => { DATA.salaryPayments = DATA.salaryPayments.filter(x => x.id !== sp.id); idbDeleteRow('salary_payments', sp.id); }
      });
      if (!r1.queued && r1.error) err = r1.error;
    }
    const relatedAttendance = DATA.teacherAttendance.filter(x => x.teacher_id === id);
    for (const ta of relatedAttendance) {
      const r1b = await offlineWrite({
        table: 'teacher_attendance', action: 'delete', payload: null, id: ta.id, baseRow: ta,
        run: () => sb.from('teacher_attendance').delete().eq('id', ta.id),
        optimisticApply: () => { DATA.teacherAttendance = DATA.teacherAttendance.filter(x => x.id !== ta.id); idbDeleteRow('teacher_attendance', ta.id); }
      });
      if (!r1b.queued && r1b.error) err = r1b.error;
    }
    const baseTeacher = DATA.teachers.find(x => x.id === id) || null;
    const r2 = await offlineWrite({
      table: 'teachers', action: 'delete', payload: null, id, baseRow: baseTeacher,
      run: () => sb.from('teachers').delete().eq('id', id),
      optimisticApply: () => { DATA.teachers = DATA.teachers.filter(x => x.id !== id); idbDeleteRow('teachers', id); }
    });
    if (!r2.queued && r2.error) err = r2.error;
  }
  if (kind==='admissionEntry') {
    // Offline-aware, same as the student/teacher deletes above.
    const baseRow = DATA.admissionRegister.find(x => x.id === id) || null;
    const r1 = await offlineWrite({
      table: 'admission_register', action: 'delete', payload: null, id, baseRow,
      run: () => sb.from('admission_register').delete().eq('id', id),
      optimisticApply: () => { DATA.admissionRegister = DATA.admissionRegister.filter(x => x.id !== id); idbDeleteRow('admission_register', id); }
    });
    if (!r1.queued && r1.error) err = r1.error;
  }
  if (kind==='whitelistEmail') {
    const r1 = await sb.from('whitelist_emails').delete().eq('email', id);
    if (r1.error) err = r1.error;
  }
  if (kind==='classLogin') {
    const r1 = await sb.from('class_logins').delete().eq('id', id);
    if (r1.error) err = r1.error;
  }
  closeModal(); await loadAllData(); renderTab();
  if (err) alert((LANG==='ur' ? 'حذف کرنے میں خرابی: ' : 'Delete failed: ') + err.message);
}

