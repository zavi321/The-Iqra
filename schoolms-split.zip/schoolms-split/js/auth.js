/* SchoolMS — auth.js — split from index.html (lines 2349-2866). Load order matters: see index.html */
// ---------------- Boot / session ----------------
function renderForgotPassword() {
  renderAuthShell(`
    <h2>${esc(t.forgotPasswordTitle)}</h2>
    <p class="desc">${esc(t.forgotPasswordDesc)}</p>
    <label><span>${esc(t.email)}</span><input id="fp-email" type="email" autocomplete="email" onkeydown="if(event.key==='Enter')submitForgotPassword()"></label>
    <div id="auth-msg"></div>
    <button class="btn-primary" id="fp-btn" onclick="submitForgotPassword()">${esc(t.sendResetLink)}</button>
    <div class="switch-line"><a onclick="renderLogIn()">${esc(t.backToLogin)}</a></div>
  `);
}

async function submitForgotPassword() {
  const email = document.getElementById('fp-email').value.trim();
  const msg = document.getElementById('auth-msg');
  const btn = document.getElementById('fp-btn');
  msg.innerHTML = '';
  if (!email) return;
  btn.disabled = true;
  const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin });
  btn.disabled = false;
  // Always show a success-style message even on error, so this screen can't be used
  // to probe which emails have accounts (Supabase itself does this by default too).
  msg.innerHTML = `<div class="ok"><div style="margin-bottom:8px;">${esc(t.resetLinkSentTitle)}</div><div>${esc(t.resetLinkSentDesc)}</div></div>`;
}

function renderSetNewPassword() {
  renderAuthShell(`
    <h2>${esc(t.newPasswordTitle)}</h2>
    <p class="desc">${esc(t.newPasswordDesc)}</p>
    <label><span>${esc(t.password)}</span><input id="np-pw" type="password" autocomplete="new-password"></label>
    <label><span>${esc(t.confirmPassword)}</span><input id="np-pw2" type="password" autocomplete="new-password" onkeydown="if(event.key==='Enter')submitSetNewPassword()"></label>
    <div id="auth-msg"></div>
    <button class="btn-primary" id="np-btn" onclick="submitSetNewPassword()">${esc(t.setNewPassword)}</button>
  `);
}

async function submitSetNewPassword() {
  const pw = document.getElementById('np-pw').value;
  const pw2 = document.getElementById('np-pw2').value;
  const msg = document.getElementById('auth-msg');
  const btn = document.getElementById('np-btn');
  msg.innerHTML = '';
  if (pw.length < 6) { msg.innerHTML = `<div class="err">${esc(t.passwordTooShort)}</div>`; return; }
  if (pw !== pw2) { msg.innerHTML = `<div class="err">${esc(t.passwordMismatch)}</div>`; return; }
  btn.disabled = true;
  const { error } = await sb.auth.updateUser({ password: pw });
  btn.disabled = false;
  if (error) { msg.innerHTML = `<div class="err">${esc(error.message)}</div>`; return; }
  msg.innerHTML = `<div class="ok"><div style="margin-bottom:8px;">${esc(t.passwordUpdatedTitle)}</div><div>${esc(t.passwordUpdatedDesc)}</div></div>`;
  await sb.auth.signOut();
  setTimeout(renderLogIn, 1800);
}

function renderForgotEmail() {
  renderAuthShell(`
    <h2>${esc(t.forgotEmailTitle)}</h2>
    <p class="desc">${esc(t.forgotEmailDesc)}</p>
    <a class="btn-primary" style="display:block;text-align:center;text-decoration:none;margin-top:10px;" href="${smsUriFromDigits(OWNER_WHATSAPP_NUMBER, 'Hi, I forgot which email my school account is registered under. My school name is: ')}" rel="noopener">${esc(t.contactOnWhatsApp)}</a>
    <div class="switch-line"><a onclick="renderLogIn()">${esc(t.backToLogin)}</a></div>
  `);
}

// Chrome (and most Android browsers) treat IndexedDB/localStorage for a
// site like this as "best-effort" storage unless the origin is granted
// persistent storage — meaning the OS can silently wipe it under storage
// pressure (low disk space, the site not opened in a while, etc.) with zero
// warning to the user. That wipe is indistinguishable from a real bug: the
// exact same "shows data online, everything turns to 0 once offline"
// symptom, except here the offline cache itself was erased by the browser,
// not by anything in this app's own code. Requesting persistence here (every
// boot, it's harmless to repeat) tells the browser this data matters and
// should be protected the same way an installed app's storage is. It can
// still be silently refused on some browsers/devices, so this reduces the
// problem but cannot promise it will never happen again — encourage the
// school to "Add to Home Screen" too, since installed PWAs get persistence
// far more reliably than a plain browser tab.
async function ensurePersistentStorage() {
  try {
    if (!(navigator.storage && navigator.storage.persist)) return;
    const already = navigator.storage.persisted ? await navigator.storage.persisted() : false;
    if (!already) await navigator.storage.persist();
  } catch (e) { console.error('ensurePersistentStorage failed', e); }
}

async function boot() {
  ensurePersistentStorage(); // fire-and-forget — never blocks boot on this
  document.body.className = LANG === 'ur' ? 'ur' : '';

  // A parent visiting ?parent=1 lands on a public, no-login lookup page — they
  // enter School Code + Roll No. + PIN, verified server-side via a Postgres
  // RPC (see parent_portal_lookup) so no table data is ever exposed directly.
  const parentPortal = new URLSearchParams(window.location.search).get('parent');
  if (parentPortal) { renderParentPortal(); return; }

  // A teacher using the shared class device lands here with ?class=1 — a
  // public, no-real-login page. They enter School Code + the class's Login
  // ID + Password, verified server-side each time via class_login_verify (and
  // again on every attendance/marks write), so this device never holds a
  // Supabase Auth session of its own. See class_attendance_marks_migration.sql.
  const classPortal = new URLSearchParams(window.location.search).get('class');
  if (classPortal) { renderClassPortalEntry(); return; }

  // A teacher using the shared Diary device lands here with ?diary=1 — one
  // school-wide login (separate from the per-class Attendance login above),
  // verified server-side via diary_login_verify (and again on every entry
  // write via diary_add_entry). See diary_migration.sql.
  const diaryPortal = new URLSearchParams(window.location.search).get('diary');
  if (diaryPortal) { renderDiaryPortalEntry(); return; }


  let handledAsRecovery = false;
  sb.auth.onAuthStateChange((event) => {
    if (event === 'PASSWORD_RECOVERY') {
      handledAsRecovery = true;
      renderSetNewPassword();
    }
  });

  // Racing this against a timeout (like every other network call in this
  // file) matters here specifically because the access token can be expired
  // by the time the app is reopened: getSession() then tries to refresh it
  // over the network, which simply hangs/fails when offline or on a weak
  // signal, instead of falling back to the still-valid cached data below.
  //
  // Unlike the Postgrest table queries elsewhere in this file (which always
  // resolve with { data, error } even on failure), Supabase's AUTH client can
  // actually reject/throw when a network-dependent token refresh fails (e.g.
  // fully offline). withTimeout() only races a timeout — it never catches a
  // rejection — so that throw was propagating straight out of this line,
  // uncaught, and killing the entire boot() function before it ever reached
  // the "offline → use last logged-in account" fallback a few lines below.
  // The result: the loading screen froze forever and NOTHING rendered at all
  // while offline — not the app, not even the login screen or Settings —
  // which is the real "everything disappears offline" bug. Wrapping it here
  // turns that crash into the same recoverable failure as a timeout.
  let sessionResult;
  try {
    sessionResult = await withTimeout(sb.auth.getSession(), 6000);
  } catch (e) {
    sessionResult = { data: null, error: e };
  }
  const session = sessionResult && sessionResult.data && sessionResult.data.session;
  const sessionCheckFailed = !session && !!(sessionResult && sessionResult.error);
  // Give the PASSWORD_RECOVERY listener a tick to fire first if this load came from a reset-link click.
  await new Promise(r => setTimeout(r, 50));
  if (handledAsRecovery) { document.getElementById('loading').classList.add('hidden'); return; }

  if (session && session.user) {
    CURRENT_USER = session.user;
    await afterLogin(); // hides #loading itself once data has actually arrived
  } else if (!navigator.onLine || sessionCheckFailed) {
    // Couldn't get a definitive session from the server (offline, or the
    // check itself timed out/errored) — fall back to whichever account last
    // logged in successfully on this device, if any, and let afterLogin()'s
    // existing cached-profile/cached-data fallbacks take it from there. A
    // clean "no session" answer from a reachable server (not this branch)
    // still goes to the normal login screen below.
    let lastUid = null;
    try { lastUid = localStorage.getItem(LAST_UID_KEY); } catch (e) {}
    if (lastUid) {
      CURRENT_USER = { id: lastUid };
      await afterLogin();
    } else {
      document.getElementById('loading').classList.add('hidden');
      renderLogIn();
    }
  } else {
    document.getElementById('loading').classList.add('hidden');
    renderLogIn();
  }
}

async function afterLogin() {
  try { localStorage.setItem(LAST_UID_KEY, CURRENT_USER.id); } catch (e) {}
  const PROFILE_CACHE_KEY = 'sms_cached_profile_' + CURRENT_USER.id;
  const { data: prof, error: profErr } = await withTimeout(sb.from('profiles').select('*').eq('id', CURRENT_USER.id).maybeSingle());
  if (prof) {
    CURRENT_PROFILE = prof;
    try { localStorage.setItem(PROFILE_CACHE_KEY, JSON.stringify(prof)); } catch (e) {}
  } else {
    // Fetch failed or timed out (weak/fake-online connection) — fall back to
    // whatever profile was cached from the last successful login instead of
    // hanging here or showing a placeholder school name.
    let cached = null;
    try { cached = JSON.parse(localStorage.getItem(PROFILE_CACHE_KEY) || 'null'); } catch (e) {}
    CURRENT_PROFILE = cached || { school_name: 'My School' };
  }
  // If this account signed up with a phone number but it hasn't landed on the
  // profile row yet (e.g. they had to verify via OTP before their first login), sync it now.
  const metaPhone = CURRENT_USER.user_metadata && CURRENT_USER.user_metadata.phone;
  if (metaPhone && !CURRENT_PROFILE.phone && navigator.onLine) {
    await sb.from('profiles').update({ phone: metaPhone }).eq('id', CURRENT_USER.id);
    CURRENT_PROFILE.phone = metaPhone;
  }

  // Monthly-plan schools get locked out 3 days after their paid_until date until
  // a payment is confirmed (see SUBSCRIPTION LOCK block below). Admin/owner
  // account and lifetime-plan schools are never locked. Skipped entirely with
  // no signal — fails open, same as a network error during the check itself.
  const locked = navigator.onLine ? await checkSubscriptionLock() : false;
  if (locked) {
    document.getElementById('loading').classList.add('hidden');
    renderRenewalLock();
    return;
  }

  const loadingEl = document.getElementById('loading');
  if (loadingEl) loadingEl.textContent = t.loadingData || 'Loading your data…';
  await loadAllData();
  document.getElementById('loading').classList.add('hidden');
  renderApp();
  startStaffReqPolling();
  maybeRunExamRecordsCleanup(); // fire-and-forget safety net (see function below)
}

// ============================================================================
// SUBSCRIPTION LOCK — monthly-plan schools must pay by their paid_until date;
// a 3-day grace period is added on top before access is actually blocked.
// Lifetime-plan schools and the admin/owner account are never checked.
// Payment is confirmed automatically: the school submits their EasyPaisa TRX
// ID (submitTrxId), and a server-side Edge Function matches it against the
// SMS forwarded from the owner's phone, extending `paid_until` — no manual
// action needed on a match. See subscription_migration.sql + sms-webhook.
// ============================================================================
let SUBSCRIPTION_INFO = null;

async function checkSubscriptionLock() {
  if (CURRENT_PROFILE.is_admin) return false;
  const { data: sub, error } = await withTimeout(sb.from('subscriptions').select('*').eq('school_id', CURRENT_USER.id).maybeSingle());
  if (error) { console.error('Subscription check failed:', error.message); return false; } // fail open, never lock out on a network/query error
  SUBSCRIPTION_INFO = sub;
  if (!sub || sub.plan_type === 'lifetime') return false;
  if (sub.status === 'suspended') return true;
  if (!sub.paid_until) return false; // no due date set yet — admin hasn't started billing this school
  const graceEnd = new Date(sub.paid_until + 'T00:00:00');
  graceEnd.setDate(graceEnd.getDate() + 3);
  return new Date() > graceEnd;
}

function renderRenewalLock() {
  document.getElementById('app').classList.add('hidden');
  const price = SUBSCRIPTION_INFO ? SUBSCRIPTION_INFO.monthly_price : 0;
  document.getElementById('auth-root').innerHTML = `
    <div class="auth-wrap">
      <div class="auth-box">
        <div class="auth-brand">${esc(t.appName)}</div>
        <div class="auth-card">
          <h2>${esc(t.renewalLockedTitle)}</h2>
          <p class="desc">${esc(t.renewalLockedDesc)} <b>₨${fmt(price)}</b> ${esc(t.renewalToNumber)} <b>${esc(OWNER_WHATSAPP_NUMBER)}</b></p>
          <label><span>${esc(t.trxIdLabel)}</span><input id="trx-input" onkeydown="if(event.key==='Enter')submitTrxId()"></label>
          <div id="trx-msg"></div>
          <button class="btn-primary" id="trx-btn" onclick="guardedSubmit(this, submitTrxId)">${esc(t.submitTrxButton)}</button>
          <button class="btn-ghost" style="width:100%;margin-top:10px;" onclick="recheckSubscription()">${esc(t.checkAgainButton)}</button>
          <div class="switch-line"><a onclick="logOut()">${esc(t.logOut)}</a></div>
        </div>
      </div>
    </div>`;
}

async function submitTrxId() {
  const input = document.getElementById('trx-input');
  const msg = document.getElementById('trx-msg');
  const trx = input.value.trim();
  if (!trx) return;
  const { error } = await sb.from('payment_submissions').insert({ school_id: CURRENT_USER.id, trx_id: trx });
  if (error) { msg.innerHTML = `<div class="err">${esc(error.message)}</div>`; return; }
  msg.innerHTML = `<div class="ok">${esc(t.trxSubmittedMsg)}</div>`;
  input.value = '';
}

async function recheckSubscription() {
  const locked = await checkSubscriptionLock();
  if (locked) { renderRenewalLock(); } else { afterLogin(); }
}

// Deletes DMC records and marks sheets older than 2 years, and fully-paid
// (no dues) fee ledgers for academic years that have already ended. The real
// schedule is a pair of Supabase pg_cron jobs that run daily on the server
// regardless of whether anyone opens the app — this is only a fallback so
// cleanup still happens on the next login if those server jobs were ever
// missed/unavailable. Guarded to run at most once per calendar day per browser.
function maybeRunExamRecordsCleanup() {
  const todayStr = todayISO();
  if (localStorage.getItem('examRecordsCleanupRanOn') === todayStr) return;
  localStorage.setItem('examRecordsCleanupRanOn', todayStr);
  sb.rpc('cleanup_old_exam_records').then(({ error }) => {
    if (error) console.error('Exam records cleanup failed:', error.message);
  });
  sb.rpc('cleanup_cleared_fee_records').then(({ error }) => {
    if (error) console.error('Fee records cleanup failed:', error.message);
  });
}

// ---------------- Teacher attendance requests (principal approves) ----------------
let SR_PENDING = 0, SR_TIMER = null;
function srPaintBadges() {
  document.querySelectorAll('.sr-badge').forEach(el => { el.textContent = SR_PENDING; el.style.display = SR_PENDING ? '' : 'none'; });
}
// Head-only count query (no rows downloaded) — a few hundred bytes per check, and only while the app is visible.
async function refreshStaffReqCount() {
  if (!CURRENT_USER || document.hidden || !navigator.onLine) return;
  const { count, error } = await sb.from('staff_att_requests').select('id', { count: 'exact', head: true })
    .eq('owner_id', CURRENT_USER.id).eq('status', 'pending');
  if (error) return;
  const prev = SR_PENDING; SR_PENDING = count || 0; srPaintBadges();
  if (SR_PENDING > prev) { try { if (navigator.vibrate) navigator.vibrate(200); } catch (e) {} }
}
function startStaffReqPolling() {
  clearInterval(SR_TIMER);
  refreshStaffReqCount();
  SR_TIMER = setInterval(refreshStaffReqCount, 90000);
}
async function openStaffRequests() {
  showModal(qt('Teacher Requests', 'اساتذہ کی درخواستیں'), `<div id="sr-body" style="padding:10px 0;opacity:.6;text-align:center;">…</div>`);
  await renderStaffRequests();
}
async function renderStaffRequests() {
  const body = document.getElementById('sr-body');
  if (!body) return;
  if (!navigator.onLine) { body.innerHTML = `<div class="err">${esc(qt('You are offline. Requests can be approved only when online.', 'آپ آف لائن ہیں۔ منظوری صرف آن لائن ہو سکتی ہے۔'))}</div>`; return; }
  const { data, error } = await sb.from('staff_att_requests')
    .select('id,teacher_id,att_date,kind,session,requested_at,received_at')
    .eq('owner_id', CURRENT_USER.id).eq('status', 'pending').order('requested_at');
  if (error) { body.innerHTML = `<div class="err">${esc(error.message)}</div>`; return; }
  SR_PENDING = (data || []).length; srPaintBadges();
  if (!data.length) { body.innerHTML = `<div style="padding:14px;text-align:center;font-size:13px;opacity:.6;">${esc(qt('No pending requests.', 'کوئی درخواست باقی نہیں۔'))}</div>`; return; }
  const fmtT = iso => new Date(iso).toLocaleTimeString(LANG === 'ur' ? 'ur-PK' : 'en-PK', { hour: '2-digit', minute: '2-digit' });
  const today = todayISO();
  body.innerHTML = data.map(r => {
    const tc = DATA.teachers.find(x => String(x.id) === String(r.teacher_id));
    const kindTxt = r.kind === 'present' ? t.present : r.kind === 'leave' ? t.leave : t.sick;
    const sessTxt = r.session === 'am' ? ' · ' + t.morning : r.session === 'pm' ? ' · ' + t.afternoon : '';
    const late = Math.abs(new Date(r.received_at) - new Date(r.requested_at)) > 2 * 60000;
    const dateTxt = r.att_date !== today ? ` · ${esc(r.att_date)}` : '';
    return `<div class="ledger-row" style="flex-direction:column;align-items:stretch;gap:8px;">
      <div>
        <div style="font-size:14px;font-weight:600;">${esc(tc ? tc.name : '—')}</div>
        <div style="font-size:12px;opacity:.75;">${esc(kindTxt)}${esc(sessTxt)}${dateTxt}</div>
        <div style="font-size:11px;opacity:.6;">${esc(qt('Requested', 'درخواست'))}: ${esc(fmtT(r.requested_at))}${late ? ` · ${esc(qt('received', 'موصول'))} ${esc(fmtT(r.received_at))}` : ''}</div>
      </div>
      <div style="display:flex;gap:8px;">
        <button class="btn-primary" style="flex:1;padding:8px;" onclick="decideStaffReq('${r.id}','approved')">${esc(qt('Approve', 'منظور'))}</button>
        <button class="btn-ghost" style="flex:1;padding:8px;" onclick="decideStaffReq('${r.id}','denied')">${esc(qt('Deny', 'مسترد'))}</button>
      </div>
    </div>`;
  }).join('');
}
async function decideStaffReq(id, decision) {
  if (!navigator.onLine) { alert(qt('You are offline.', 'آپ آف لائن ہیں۔')); return; }
  const { data: r, error: e0 } = await sb.from('staff_att_requests').select('*').eq('id', id).eq('owner_id', CURRENT_USER.id).maybeSingle();
  if (e0 || !r || r.status !== 'pending') { await renderStaffRequests(); return; }
  if (decision === 'approved') {
    const tc = DATA.teachers.find(x => String(x.id) === String(r.teacher_id));
    if (!tc) { alert(qt('This teacher no longer exists.', 'یہ استاد اب موجود نہیں۔')); return; }
    // Read the live row so a session already approved earlier today is never overwritten.
    const { data: ex } = await sb.from('teacher_attendance').select('*').eq('teacher_id', tc.id).eq('date', r.att_date).maybeSingle();
    let am = ex ? ex.status_am : null, pm = ex ? ex.status_pm : null;
    if (r.kind === 'present') { if (r.session === 'am') am = 'present'; else pm = 'present'; }
    else { am = r.kind; pm = r.kind; }
    const payload = {
      id: ex ? ex.id : (crypto.randomUUID ? crypto.randomUUID() : `local-${Date.now()}`),
      owner_id: CURRENT_USER.id, teacher_id: tc.id, date: r.att_date,
      status_am: am || null, status_pm: pm || null, status: deriveDayStatus(am, pm)
    };
    const { error: e1 } = await sb.from('teacher_attendance').upsert(payload, { onConflict: 'teacher_id,date' });
    if (reportSaveError(e1)) return;
    const idx = DATA.teacherAttendance.findIndex(x => String(x.teacher_id) === String(tc.id) && x.date === r.att_date);
    if (idx >= 0) DATA.teacherAttendance[idx] = { ...DATA.teacherAttendance[idx], ...payload }; else DATA.teacherAttendance.push(payload);
    try { idbPutRow('teacher_attendance', payload); } catch (e) {}
  }
  const { error: e2 } = await sb.from('staff_att_requests').update({ status: decision, decided_at: new Date().toISOString() })
    .eq('id', id).eq('owner_id', CURRENT_USER.id);
  if (reportSaveError(e2)) return;
  await renderStaffRequests();
}

// ---------------- Auth screens ----------------
function renderAuthShell(inner) {
  document.getElementById('app').classList.add('hidden');
  document.getElementById('auth-root').innerHTML = `
    <div class="auth-wrap">
      <div class="auth-box">
        <div class="auth-brand">${esc(t.appName)}</div>
        <div class="auth-card">${inner}</div>
        <div style="text-align:center;opacity:.35;font-size:10px;margin-top:10px;">build v-kbfix-4</div>
      </div>
    </div>`;
}

function renderLogIn() {
  renderAuthShell(`
    <div style="text-align:${LANG==='ur'?'right':'left'};margin-bottom:8px;">
      <button class="lang-mini" onclick="toggleLangAuth(false)">${esc(t.langToggle)}</button>
    </div>
    <h2>${esc(t.logInTitle)}</h2>
    <p class="desc">${esc(t.logInDesc)}</p>
    <label><span>${esc(t.email)}</span><input id="li-email" type="email" autocomplete="email"></label>
    <label><span>${esc(t.password)}</span><input id="li-pw" type="password" autocomplete="current-password" onkeydown="if(event.key==='Enter')submitLogIn()"></label>
    <div style="display:flex;justify-content:space-between;margin:-6px 0 10px;font-size:12px;">
      <a onclick="renderForgotPassword()" style="cursor:pointer;">${esc(t.forgotPassword)}</a>
      <a onclick="renderForgotEmail()" style="cursor:pointer;">${esc(t.forgotEmail)}</a>
    </div>
    <div id="auth-msg"></div>
    <button class="btn-primary" id="li-btn" onclick="submitLogIn()">${esc(t.logIn)}</button>
    <div class="switch-line">${esc(t.noAccount)} <a onclick="renderSignUp()">${esc(t.signUp)}</a></div>
  `);
}

function renderSignUp() {
  renderAuthShell(`
    <div style="text-align:${LANG==='ur'?'right':'left'};margin-bottom:8px;">
      <button class="lang-mini" onclick="toggleLangAuth(true)">${esc(t.langToggle)}</button>
    </div>
    <h2>${esc(t.signUpTitle)}</h2>
    <p class="desc">${esc(t.signUpDesc)}</p>
    <label><span>${esc(t.schoolName)}</span><input id="su-school"></label>
    <label><span>${esc(t.email)}</span><input id="su-email" type="email" autocomplete="email"></label>
    <label><span>${esc(t.phoneNumber)}</span><input id="su-phone" type="tel" autocomplete="tel" placeholder="03XXXXXXXXX"></label>
    <label><span>${esc(t.password)}</span><input id="su-pw" type="password" autocomplete="new-password"></label>
    <label><span>${esc(t.confirmPassword)}</span><input id="su-pw2" type="password" autocomplete="new-password" onkeydown="if(event.key==='Enter')submitSignUp()"></label>
    <div id="auth-msg"></div>
    <button class="btn-primary" id="su-btn" onclick="submitSignUp()">${esc(t.signUp)}</button>
    <div class="switch-line">${esc(t.haveAccount)} <a onclick="renderLogIn()">${esc(t.logIn)}</a></div>
    <p style="font-size:10px;text-align:center;opacity:.5;margin-top:14px;line-height:1.5;">${esc(t.copyrightNotice)}</p>
  `);
}

function toggleLangAuth(isSignUp) {
  LANG = LANG === 'en' ? 'ur' : 'en';
  localStorage.setItem('sms_lang', LANG);
  t = T[LANG];
  document.body.className = LANG === 'ur' ? 'ur' : '';
  isSignUp ? renderSignUp() : renderLogIn();
}

async function submitSignUp() {
  const school = document.getElementById('su-school').value.trim();
  const email = document.getElementById('su-email').value.trim();
  const phone = document.getElementById('su-phone').value.trim();
  const pw = document.getElementById('su-pw').value;
  const pw2 = document.getElementById('su-pw2').value;
  const msg = document.getElementById('auth-msg');
  const btn = document.getElementById('su-btn');
  msg.innerHTML = '';
  if (!school || !email) { msg.innerHTML = `<div class="err">${esc(t.schoolName)} / ${esc(t.email)} ${LANG==='ur'?'لازمی ہے':'required'}</div>`; return; }
  if (pw.length < 6) { msg.innerHTML = `<div class="err">${esc(t.passwordTooShort)}</div>`; return; }
  if (pw !== pw2) { msg.innerHTML = `<div class="err">${esc(t.passwordMismatch)}</div>`; return; }
  btn.disabled = true;

  // Only owner-whitelisted emails may sign up. Anyone else is sent to
  // WhatsApp to arrange registration first.
  const { data: allowed, error: wErr } = await sb.rpc('is_email_whitelisted', { check_email: email });
  if (wErr) { btn.disabled = false; msg.innerHTML = `<div class="err">${esc(wErr.message)}</div>`; return; }
  if (!allowed) {
    btn.disabled = false;
    const smsLink = smsUriFromDigits(OWNER_WHATSAPP_NUMBER, 'Hi, I want to register my school: ' + school);
    msg.innerHTML = `
      <div class="err">
        <div style="margin-bottom:8px;">${esc(t.notWhitelistedTitle)}</div>
        <div style="margin-bottom:10px;">${esc(t.notWhitelistedDesc)}</div>
        <a class="btn-primary" style="display:block;text-align:center;text-decoration:none;" href="${smsLink}" rel="noopener">${esc(t.contactOnWhatsApp)}</a>
      </div>`;
    return;
  }

  const { data, error } = await sb.auth.signUp({
    email, password: pw,
    options: { data: { school_name: school, phone } }
  });
  btn.disabled = false;
  if (error) { msg.innerHTML = `<div class="err">${esc(error.message)}</div>`; return; }

  if (data.session) {
    // Email confirmation is off on this project — logs straight in.
    CURRENT_USER = data.user;
    // Best-effort: also store the phone number directly on the profile row now
    // that we have an authenticated session (RLS allows updating our own row).
    if (phone) await sb.from('profiles').update({ phone }).eq('id', CURRENT_USER.id);
    await afterLogin();
    return;
  }

  // Normal path: Supabase sent a confirmation code to their email.
  // Mark the whitelist entry so the admin sees it's awaiting OTP.
  await sb.rpc('mark_signup_attempted', { check_email: email });
  const smsLink2 = smsUriFromDigits(OWNER_WHATSAPP_NUMBER, 'Hi, my school is ' + school + ' (' + email + '). My verification code is: ');
  msg.innerHTML = `
    <div class="ok">
      <div style="margin-bottom:8px;">${esc(t.signUpPendingTitle)}</div>
      <div style="margin-bottom:10px;">${esc(t.signUpPendingDesc)}</div>
      <a class="btn-primary" style="display:block;text-align:center;text-decoration:none;" href="${smsLink2}" rel="noopener">${esc(t.contactOnWhatsApp)}</a>
    </div>`;
}

async function submitLogIn() {
  const email = document.getElementById('li-email').value.trim();
  const pw = document.getElementById('li-pw').value;
  const msg = document.getElementById('auth-msg');
  const btn = document.getElementById('li-btn');
  msg.innerHTML = '';
  btn.disabled = true;
  const { data, error } = await sb.auth.signInWithPassword({ email, password: pw });
  btn.disabled = false;
  if (error) { msg.innerHTML = `<div class="err">${esc(error.message)}</div>`; return; }
  CURRENT_USER = data.user;
  await afterLogin();
}

async function logOut() {
  await sb.auth.signOut();
  try { localStorage.removeItem(LAST_UID_KEY); } catch (e) {}
  CURRENT_USER = null; CURRENT_PROFILE = null;
  DATA = { students:[], feePayments:[], teachers:[], salaryPayments:[], transactions:[], admissionRegister:[], teacherAttendance:[], holidays:[], classLogins:[], studentAttendance:[] };
  document.getElementById('app').classList.add('hidden');
  renderLogIn();
}

