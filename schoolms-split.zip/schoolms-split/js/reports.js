/* SchoolMS — reports.js — split from index.html (lines 7947-8104). Load order matters: see index.html */
// ---------------- Reports ----------------
function tplReports() {
  const s = computeStats();
  const perClass = {};
  DATA.students.filter(x=>x.status!=='inactive').forEach(st=>{
    const cls = st.class_name || '—';
    if (!perClass[cls]) perClass[cls] = {count:0, collected:0, dues:0};
    perClass[cls].count++;
    perClass[cls].collected += studentPayments(st.id).reduce((a,b)=>a+Number(b.amount),0);
    if (isFeePaying(st)) perClass[cls].dues += Math.max(0, studentBalance(st.id));
  });
  const rows = [
    [t.totalCollectedAllTime, s.totalCollectedAllTime, 'amt-pos'],
    [t.totalSalariesAllTime, s.totalSalariesAllTime, 'amt-neg'],
    [t.totalOtherIncomeAllTime, s.totalOtherIncomeAllTime, 'amt-pos'],
    [t.totalOtherExpenseAllTime, s.totalOtherExpenseAllTime, 'amt-neg'],
  ];
  return `
    <div style="padding-top:16px;">
      <div class="section-title" style="margin-top:0;display:flex;justify-content:space-between;align-items:center;">
        <span>${esc(t.summaryReport)}</span>
        <button onclick="printReport()" style="border:none;background:var(--navy);color:var(--gold-soft);border-radius:8px;padding:5px 12px;font-size:11px;font-weight:600;">🖨️ ${esc(t.print)}</button>
      </div>
      <div class="list-card">
        ${rows.map(([l,v,cls])=>`<div class="list-row"><span style="font-size:13px;">${esc(l)}</span><span class="${cls}">₨${fmt(v)}</span></div>`).join('')}
      </div>
      <div class="section-title">${esc(t.studentType)}</div>
      <div class="list-card">
        <div class="list-row"><span style="font-size:13px;">${esc(t.feePaying)}</span><span>${s.payingCount}</span></div>
        <div class="list-row"><span style="font-size:13px;">${esc(t.free)}</span><span>${s.freeCount}</span></div>
        <div class="list-row"><span style="font-size:13px;">${esc(t.orphan)}</span><span>${s.orphanCount}</span></div>
      </div>
      <div class="section-title">${esc(t.perClassBreakdown)}</div>
      <div class="list-card">
        ${Object.keys(perClass).length===0 ? `<div style="padding:16px;text-align:center;opacity:.5;font-size:13px;">—</div>` :
          Object.entries(perClass).map(([cls,d])=>`
            <div class="list-row">
              <span style="font-size:13px;font-weight:500;">${esc(cls)} <span style="font-size:11px;opacity:.5;">(${d.count})</span></span>
              <span style="display:flex;flex-direction:column;align-items:flex-end;gap:2px;">
                <span class="amt-pos">₨${fmt(d.collected)}</span>
                ${d.dues>0 ? `<span class="amt-neg" style="font-size:11px;">₨${fmt(d.dues)} ${esc(t.due)}</span>` : ''}
              </span>
            </div>`).join('')}
      </div>
      <div class="section-title" style="display:flex;justify-content:space-between;align-items:center;">
        <span>${esc(t.defaultersReport)}</span>
        <button onclick="printDefaultersReport()" style="border:none;background:var(--navy);color:var(--gold-soft);border-radius:8px;padding:5px 12px;font-size:11px;font-weight:600;">🖨️ ${esc(t.print)}</button>
      </div>
      <div class="list-card">
        ${(() => {
          const defaulters = DATA.students
            .filter(x => x.status!=='inactive' && isFeePaying(x) && studentBalance(x.id) > 0)
            .sort((a,b) => studentBalance(b.id) - studentBalance(a.id));
          if (defaulters.length === 0) return `<div style="padding:16px;text-align:center;opacity:.5;font-size:13px;">—</div>`;
          return defaulters.map(x => `
            <div class="list-row" style="cursor:pointer;" onclick="setTab('students'); openStudentDetail('${x.id}')">
              <span style="font-size:13px;">${esc(x.name)} <span style="font-size:11px;opacity:.5;">(${esc(x.class_name||'—')})</span></span>
              <span class="amt-neg">₨${fmt(studentBalance(x.id))}</span>
            </div>`).join('');
        })()}
      </div>
    </div>`;
}

function printDefaultersReport() {
  const defaulters = DATA.students
    .filter(x => x.status!=='inactive' && isFeePaying(x) && studentBalance(x.id) > 0)
    .sort((a,b) => studentBalance(b.id) - studentBalance(a.id));
  const total = defaulters.reduce((a,b) => a + studentBalance(b.id), 0);
  const rows = defaulters.map((x,i) => `
    <tr>
      <td>${i+1}</td>
      <td>${esc(x.name)}</td>
      <td>${esc(x.father_name||'—')}</td>
      <td>${esc(x.class_name||'—')}</td>
      <td style="text-align:right;">₨${fmt(studentBalance(x.id))}</td>
    </tr>`).join('');

  document.getElementById('print-area').innerHTML = `
    <div class="ledger-print">
      <h2>${esc(CURRENT_PROFILE.school_name || 'School')}</h2>
      <div class="sub">${esc(t.defaultersReport)} — ${esc(fmtDate(todayISO()))}</div>
      <table>
        <thead><tr><th>#</th><th>${esc(t.studentName)}</th><th>${esc(t.fatherName)}</th><th>${esc(t.className)}</th><th>${esc(t.balanceCol)}</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="foot" style="text-align:left;margin-top:14px;font-weight:700;">${esc(t.total)}: ₨${fmt(total)}</div>
    </div>`;
  window.print();
}

function printReport() {
  const s = computeStats();
  const perClass = {};
  DATA.students.filter(x=>x.status!=='inactive').forEach(st=>{
    const cls = st.class_name || '—';
    if (!perClass[cls]) perClass[cls] = {count:0, collected:0, dues:0};
    perClass[cls].count++;
    perClass[cls].collected += studentPayments(st.id).reduce((a,b)=>a+Number(b.amount),0);
    if (isFeePaying(st)) perClass[cls].dues += Math.max(0, studentBalance(st.id));
  });
  const summaryRows = [
    [t.totalCollectedAllTime, s.totalCollectedAllTime],
    [t.totalSalariesAllTime, s.totalSalariesAllTime],
    [t.totalOtherIncomeAllTime, s.totalOtherIncomeAllTime],
    [t.totalOtherExpenseAllTime, s.totalOtherExpenseAllTime],
  ].map(([l,v])=>`<tr><td class="lbl">${esc(l)}</td><td style="text-align:right;">₨${fmt(v)}</td></tr>`).join('');

  const typeRows = `
    <tr><td class="lbl">${esc(t.feePaying)}</td><td style="text-align:right;">${s.payingCount}</td></tr>
    <tr><td class="lbl">${esc(t.free)}</td><td style="text-align:right;">${s.freeCount}</td></tr>
    <tr><td class="lbl">${esc(t.orphan)}</td><td style="text-align:right;">${s.orphanCount}</td></tr>`;

  const classRowsHtml = Object.keys(perClass).length===0
    ? `<tr><td colspan="4" style="text-align:center;opacity:.6;">—</td></tr>`
    : Object.entries(perClass).map(([cls,d])=>`
        <tr>
          <td>${esc(cls)}</td>
          <td style="text-align:right;">${d.count}</td>
          <td style="text-align:right;">₨${fmt(d.collected)}</td>
          <td style="text-align:right;">${d.dues>0 ? '₨'+fmt(d.dues) : '—'}</td>
        </tr>`).join('');

  document.getElementById('print-area').innerHTML = `
    <div class="receipt-box" style="max-width:100%;">
      <h2>${esc(CURRENT_PROFILE.school_name || 'School')}</h2>
      <div class="sub">${esc(t.summaryReport)} — ${esc(fmtDate(todayISO()))}</div>
      <table><tbody>${summaryRows}</tbody></table>
      <div style="margin-top:16px;font-weight:700;font-size:13px;color:#0F2740;">${esc(t.studentType)}</div>
      <table><tbody>${typeRows}</tbody></table>
      <div style="margin-top:16px;font-weight:700;font-size:13px;color:#0F2740;">${esc(t.perClassBreakdown)}</div>
      <table style="width:100%;border-collapse:collapse;">
        <thead><tr>
          <th style="text-align:left;padding:6px 4px;border-bottom:2px solid #0F2740;font-size:11px;">Class</th>
          <th style="text-align:right;padding:6px 4px;border-bottom:2px solid #0F2740;font-size:11px;">#</th>
          <th style="text-align:right;padding:6px 4px;border-bottom:2px solid #0F2740;font-size:11px;">Collected</th>
          <th style="text-align:right;padding:6px 4px;border-bottom:2px solid #0F2740;font-size:11px;">${esc(t.due)}</th>
        </tr></thead>
        <tbody style="font-size:12px;">${classRowsHtml}</tbody>
      </table>
      <div class="foot">${esc(CURRENT_PROFILE.school_name || '')} — Principal Signature: ____________________</div>
    </div>`;
  window.print();
}

// Tapping a Recent Activity row opens that person's full record
function openActivityHistory(kind, refId) {
  if (kind === 'fee') { setTab('students'); openStudentDetail(refId); return; }
  if (kind === 'salary') { setTab('teachers'); openTeacherDetail(refId); return; }
  const x = DATA.transactions.find(tx => tx.id === refId);
  if (!x) return;
  showModal(x.description||'—', `
    <div class="list-row"><span style="font-size:13px;opacity:.65;">${esc(t.dateCol)}</span><span style="font-size:13px;">${esc(fmtDate(x.txn_date)||'')}</span></div>
    <div class="list-row"><span style="font-size:13px;opacity:.65;">${esc(t.amount)}</span><span class="${x.type==='income'?'amt-pos':'amt-neg'}">${x.type==='income'?'+':'−'}₨${fmt(x.amount)}</span></div>
    <button class="btn-ghost" style="width:100%;margin-top:14px;" onclick="printTxnVoucher('${x.id}')">🖨️ ${esc(t.print)}</button>
  `);
}

