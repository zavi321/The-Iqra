/* SchoolMS — settings.js — split from index.html (lines 4026-4751). Load order matters: see index.html */
// ---------------- Admin Panel (owner only) ----------------
function tplAdmin() {
  if (!CURRENT_PROFILE || !CURRENT_PROFILE.is_admin) {
    return `<div class="notice">${esc(t.notAdmin)}</div>`;
  }
  return `
    <h2>${esc(t.adminPanel)}</h2>

    <div class="card" style="margin-bottom:16px;">
      <h3 style="margin-top:0;">${esc(t.addSchoolEmail)}</h3>
      <label><span>${esc(t.email)}</span><input id="wl-email" type="email" placeholder="${esc(t.schoolEmailPlaceholder)}"></label>
      <div id="wl-add-msg"></div>
      <button class="btn-primary" onclick="guardedSubmit(this, submitAddWhitelist)">${esc(t.addToWhitelist)}</button>
    </div>

    <div class="card" style="margin-bottom:16px;">
      <h3 style="margin-top:0;">${esc(t.confirmOtpTitle)}</h3>
      <p class="desc" style="margin-top:0;">${esc(t.confirmOtpDesc)}</p>
    </div>

    <div id="admin-lists">
      <div class="card">
        <h3 style="margin-top:0;">${esc(t.whitelistedSchools)}</h3>
        <div id="wl-list"><div class="skel-line" style="width:60%;"></div><div class="skel-line" style="width:40%;"></div></div>
      </div>
    </div>
  `;
}

// The admin lists load over the network (and can take a few seconds on a
// slow connection). Rendering the real card structure immediately (header,
// border, spacing all present from the first paint) and only ever swapping
// the small shimmer inside the list div for its real content — rather than
// hiding a whole block and revealing it later — keeps this from causing a
// sudden page-height jump ("wobble") once the school directory loads in.
async function loadAdminLists() {
  await loadWhitelist();
}

// Loads every school's subscription row (creating a sensible default in the
// UI for schools that don't have one yet) plus the pending-payment queue.
// Approving a pending payment here is the manual fallback for when the
// SMS-forwarding auto-match (see sms-webhook) hasn't caught it yet.
async function loadSubscriptionsAdmin() {
  const el = document.getElementById('sub-list');
  const pendEl = document.getElementById('pending-list');
  if (!el && !pendEl) return;
  const [{ data: profs, error: e1 }, { data: subs, error: e2 }, { data: pending, error: e3 }] = await Promise.all([
    fetchAll(() => sb.from('profiles').select('id,school_name,school_code').eq('is_admin', false).order('school_name')),
    fetchAll(() => sb.from('subscriptions').select('*')),
    fetchAll(() => sb.from('payment_submissions').select('*').eq('status', 'pending').order('submitted_at', { ascending: false }))
  ]);
  // Profiles feed both cards (names + the school list), so if that query
  // itself fails, neither card can render — show the error in both.
  if (e1) {
    if (el) el.innerHTML = `<div class="err">${esc(e1.message)}</div>`;
    if (pendEl) pendEl.innerHTML = `<div class="err">${esc(e1.message)}</div>`;
    return;
  }

  const nameOf = id => { const p = (profs||[]).find(x => x.id === id); return p ? (p.school_name || p.school_code || id) : id; };

  // Subscriptions and pending-payments are otherwise independent queries —
  // one failing (e.g. a missing/renamed table) must not leave the other
  // card stuck on its loading placeholder forever.
  if (el) {
    if (e2) {
      el.innerHTML = `<div class="err">${esc(e2.message)}</div>`;
    } else {
      const subMap = {};
      (subs || []).forEach(s => { subMap[s.school_id] = s; });
      el.innerHTML = !profs || !profs.length ? `<div class="empty">${esc(t.noWhitelistYet)}</div>` : profs.map(p => {
        const s = subMap[p.id] || { plan_type: 'monthly', monthly_price: 0, paid_until: '' };
        return `
        <div class="card" style="margin-bottom:10px;">
          <div class="nm">${esc(p.school_name || '—')} <span style="opacity:.5;font-size:11px;">(${esc(p.school_code || '—')})</span></div>
          <label><span>${esc(t.planType)}</span>
            <select id="plan-${p.id}">
              <option value="monthly" ${s.plan_type === 'monthly' ? 'selected' : ''}>${esc(t.monthlyPlan)}</option>
              <option value="lifetime" ${s.plan_type === 'lifetime' ? 'selected' : ''}>${esc(t.lifetimePlan)}</option>
            </select>
          </label>
          <label><span>${esc(t.monthlyPrice)}</span><input id="price-${p.id}" type="number" value="${s.monthly_price || 0}"></label>
          <label><span>${esc(t.paidUntil)}</span><input id="paiduntil-${p.id}" type="date" value="${s.paid_until || ''}"></label>
          <button class="btn-primary" style="width:100%;" onclick="guardedSubmit(this, () => saveSubscription('${p.id}'))">${esc(t.save)}</button>
        </div>`;
      }).join('');
    }
  }

  if (pendEl) {
    if (e3) {
      pendEl.innerHTML = `<div class="err">${esc(e3.message)}</div>`;
    } else {
      pendEl.innerHTML = !pending || !pending.length ? `<div class="notice">${esc(t.noPendingPayments)}</div>` :
        pending.map(row => `
        <div class="list-row">
          <div><div class="nm">${esc(nameOf(row.school_id))}</div><div class="sub">${esc(t.trxIdLabel)}: ${esc(row.trx_id)} · ${esc(t.submittedOn)} ${esc(fmtDate(row.submitted_at))}</div></div>
          <button class="btn-primary" style="width:auto;padding:6px 10px;white-space:nowrap;" onclick="guardedSubmit(this, () => approvePending('${row.id}','${row.school_id}'))">${esc(t.approve)}</button>
        </div>`).join('');
    }
  }
}

async function saveSubscription(schoolId) {
  const plan_type = document.getElementById('plan-' + schoolId).value;
  const monthly_price = Number(document.getElementById('price-' + schoolId).value || 0);
  const paid_until = document.getElementById('paiduntil-' + schoolId).value || null;
  // onConflict:'school_id' is required here — without it, Postgrest upserts
  // against the table's primary key (id), which this payload never includes,
  // so every "Save" silently INSERTED a brand-new row instead of updating the
  // existing one. Old duplicate rows then made the reloaded list flicker
  // back to stale values. .select() lets us confirm a row actually came back
  // instead of trusting a null `error` alone (RLS can block a write with no
  // error at all — 0 rows affected, nothing thrown).
  const { data, error } = await sb.from('subscriptions')
    .upsert({ school_id: schoolId, plan_type, monthly_price, paid_until, status: 'active', updated_at: new Date().toISOString() }, { onConflict: 'school_id' })
    .select();
  if (reportSaveError(error)) return;
  if (!data || !data.length) { reportSaveError({ message: LANG === 'ur' ? 'اجازت نہیں ملی — کوئی ریکارڈ محفوظ نہیں ہوا (RLS چیک کریں)۔' : 'No row was saved — likely blocked by a database permission (RLS) rule.' }); return; }
  loadSubscriptionsAdmin();
}

// Manual fallback: extends paid_until by 30 days from whichever is later —
// today, or the school's current paid_until (so early/extra payments stack
// forward instead of being wasted) — same rule the sms-webhook uses.
async function approvePending(submissionId, schoolId) {
  const { data: sub } = await sb.from('subscriptions').select('*').eq('school_id', schoolId).maybeSingle();
  const today = new Date();
  const base = (sub && sub.paid_until && new Date(sub.paid_until + 'T00:00:00') > today) ? new Date(sub.paid_until + 'T00:00:00') : today;
  base.setDate(base.getDate() + 30);
  // Same onConflict fix as saveSubscription — without it this also silently
  // inserted a duplicate row per approval instead of extending the real one.
  const { data, error } = await sb.from('subscriptions')
    .upsert({ school_id: schoolId, plan_type: sub ? sub.plan_type : 'monthly', monthly_price: sub ? sub.monthly_price : 0,
      paid_until: localISO(base), status: 'active', updated_at: new Date().toISOString() }, { onConflict: 'school_id' })
    .select();
  if (reportSaveError(error)) return;
  if (!data || !data.length) { reportSaveError({ message: LANG === 'ur' ? 'اجازت نہیں ملی — کوئی ریکارڈ محفوظ نہیں ہوا (RLS چیک کریں)۔' : 'No row was saved — likely blocked by a database permission (RLS) rule.' }); return; }
  const { data: payData, error: payErr } = await sb.from('payment_submissions').update({ status: 'verified', verified_at: new Date().toISOString() }).eq('id', submissionId).select();
  if (reportSaveError(payErr)) return;
  if (!payData || !payData.length) { reportSaveError({ message: LANG === 'ur' ? 'ادائیگی کا ریکارڈ اپ ڈیٹ نہیں ہوا (اجازت کا مسئلہ)۔' : 'Payment record was not updated (permission issue).' }); return; }
  loadSubscriptionsAdmin();
}

// Smoothly grows/shrinks a container from whatever height it's currently
// showing (e.g. the 2-line loading shimmer) to whatever height the real
// content actually needs, instead of snapping to it instantly. An instant
// snap is exactly what reads as the page "wobbling" — a skeleton guessing
// 2 lines and the real list turning out to have 15 rows (or vice versa)
// is a sudden, jarring jump either way; animating it makes it read as
// content settling in rather than the page jerking around.
function smoothSwapHtml(el, newHtml) {
  const startHeight = el.offsetHeight;
  el.innerHTML = newHtml;
  const endHeight = el.scrollHeight;
  el.style.overflow = 'hidden';
  el.style.maxHeight = startHeight + 'px';
  // Force the browser to register the starting height before changing it,
  // or the transition below has nothing to animate from.
  void el.offsetHeight;
  el.style.transition = 'max-height .25s ease';
  el.style.maxHeight = endHeight + 'px';
  setTimeout(() => {
    el.style.maxHeight = '';
    el.style.overflow = '';
    el.style.transition = '';
  }, 260);
}

async function loadWhitelist() {
  const el = document.getElementById('wl-list');
  if (!el) return;
  // withTimeout is required here — on a weak/unstable connection a plain
  // await never resolves, so the skeleton shimmer (see .skel-line) is left
  // running forever instead of ever being swapped for real content or an
  // error. That reads as the panel "wobbling" nonstop with nothing ever
  // loading, saving, or deleting.
  const { data, error } = await withTimeout(fetchAll(() => sb.from('whitelist_emails').select('*').order('created_at', { ascending: false })));
  if (error) { smoothSwapHtml(el, `<div class="err">${esc(error.message)}</div>`); return; }
  if (!data || !data.length) { smoothSwapHtml(el, `<div class="notice">${esc(t.noWhitelistYet)}</div>`); return; }
  const statusLabel = s => s==='verified' ? t.statusVerified : s==='signup_attempted' ? t.statusAttempted : t.statusWhitelisted;
  const statusColor = s => s==='verified' ? '#1a7f37' : s==='signup_attempted' ? '#b8860b' : '#666';
  smoothSwapHtml(el, data.map(row => `
    <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;padding:10px 0;border-bottom:1px solid var(--line);">
      <span style="word-break:break-all;flex:1;">${esc(row.email)}</span>
      ${row.status === 'signup_attempted'
        ? `<button style="font-size:11px;padding:6px 10px;white-space:nowrap;" class="btn-primary" onclick="markWhitelistVerified('${esc(row.email).replace(/'/g,"\\'")}')">${esc(t.markVerified)}</button>`
        : `<span style="font-size:11px;font-weight:600;color:${statusColor(row.status)};white-space:nowrap;">${esc(statusLabel(row.status))}</span>`
      }
      <button title="${esc(t.delete)}" style="flex-shrink:0;background:none;border:none;color:var(--rust);font-size:16px;cursor:pointer;padding:4px;" onclick="confirmDelete('whitelistEmail','${esc(row.email).replace(/'/g,"\\'")}')">🗑️</button>
    </div>`).join(''));
}

async function markWhitelistVerified(email) {
  const { data, error } = await withTimeout(sb.from('whitelist_emails').update({ status: 'verified', verified_at: new Date().toISOString() }).eq('email', email).select());
  if (reportSaveError(error)) return;
  if (!data || !data.length) { reportSaveError({ message: LANG === 'ur' ? 'اجازت نہیں ملی — تصدیق محفوظ نہیں ہوئی۔' : 'No row was updated — likely blocked by a database permission (RLS) rule.' }); return; }
  loadWhitelist();
}

async function submitAddWhitelist() {
  const email = document.getElementById('wl-email').value.trim();
  const msg = document.getElementById('wl-add-msg');
  msg.innerHTML = '';
  if (!email) return;
  const { data, error } = await withTimeout(sb.from('whitelist_emails').insert({ email, added_by: CURRENT_USER.id }).select());
  if (error) { msg.innerHTML = `<div class="err">${esc(error.message)}</div>`; return; }
  if (!data || !data.length) { msg.innerHTML = `<div class="err">${esc(LANG === 'ur' ? 'اجازت نہیں ملی — ای میل محفوظ نہیں ہوا۔' : 'No row was saved — likely blocked by a database permission (RLS) rule.')}</div>`; return; }
  msg.innerHTML = `<div class="ok">${esc(t.emailAdded)}</div>`;
  document.getElementById('wl-email').value = '';
  loadWhitelist();
}



// ---------------- Settings (school name, password, logout) ----------------
// Opens an ID card generator tool inside the app's own modal (iframe),
// instead of a separate full browser tab — keeps the user inside the app.
function openIdCardTool(file, title) {
  showModal(title, `
    <iframe src="${file}" style="width:100%;height:75vh;border:none;border-radius:10px;background:#fff;"></iframe>
  `);
}

function openSettings() {
  showModal(t.settings, `
    <label><span>${esc(t.changeSchoolName)}</span><input id="set-school" value="${esc(CURRENT_PROFILE.school_name||'')}"></label>
    <label><span>${esc(t.changeSchoolNameUr)}</span><input id="set-school-ur" dir="rtl" value="${esc(CURRENT_PROFILE.school_name_ur||'')}"></label>
    <label><span>${esc(t.changePassword)}</span><input id="set-pw" type="password" autocomplete="new-password"></label>
    <div id="set-msg"></div>
    <button class="btn-primary" onclick="submitSettings()">${esc(t.saveSettings)}</button>
    <div style="margin-top:18px;padding-top:16px;border-top:1px solid var(--line);">
      <label><span>${esc(t.parentSchoolCode)}</span>
        <div style="display:flex;gap:8px;">
          <input id="set-school-code" value="${esc(CURRENT_PROFILE.school_code||'')}" placeholder="e.g., MRT01" style="text-transform:uppercase;flex:1;">
          <button type="button" class="btn-ghost" style="white-space:nowrap;" onclick="generateSchoolCode()">${esc(t.generate)}</button>
        </div>
      </label>
      <p style="font-size:11px;opacity:.6;margin:4px 0 8px;">${esc(t.parentSchoolCodeHint)}</p>
      <div id="set-code-msg"></div>
      <button class="btn-primary" style="width:100%;" onclick="saveSchoolCode()">${esc(t.saveSettings)}</button>
    </div>
    <div style="margin-top:18px;padding-top:16px;border-top:1px solid var(--line);">
      <label><span>${esc(t.diaryPasswordLabel)}</span><input id="set-diary-pw" type="password" autocomplete="off" value="" placeholder="New password (min 6 characters)"></label>
      <p style="font-size:11px;opacity:.6;margin:4px 0 8px;">${esc(t.diaryPasswordHint)}</p>
      <div id="set-diary-msg"></div>
      <button class="btn-primary" style="width:100%;" onclick="saveDiaryPassword()">${esc(t.saveSettings)}</button>
    </div>
    <div style="margin-top:18px;padding-top:16px;border-top:1px solid var(--line);">
      <p style="font-size:11px;opacity:.6;margin:0 0 8px;">${esc(t.exportHint)}</p>
      <button class="btn-ghost" style="width:100%;margin-bottom:8px;" onclick="exportBackup()">⬇ ${esc(t.exportBackup)}</button>
      <button class="btn-ghost" style="width:100%;" onclick="exportFullBackupJSON()">🗄 ${LANG==='ur' ? 'مکمل بیک اپ (بحالی کے لیے)' : 'Full Backup (for Restore)'}</button>
      <p style="font-size:11px;opacity:.55;margin:8px 0 6px;">${LANG==='ur' ? 'یہ فائل بعد میں تمام ڈیٹا واپس لانے کے لیے استعمال ہو سکتی ہے۔' : 'Keep this file safe — it can bring all your data back later, exactly as it was.'}</p>
      <input type="file" id="restore-file-input" accept="application/json" style="display:none;" onchange="handleRestoreFileSelected(this)">
      <button class="btn-ghost" style="width:100%;" onclick="document.getElementById('restore-file-input').click()">⤴ ${LANG==='ur' ? 'بیک اپ سے بحال کریں' : 'Restore from Backup'}</button>
      <div id="restore-msg" style="margin-top:8px;"></div>
    </div>
    <div style="margin-top:18px;padding-top:16px;border-top:1px solid var(--line);">
      <button class="btn-ghost" style="width:100%;" onclick="openActivityLog()">📋 ${LANG==='ur' ? 'سرگرمی لاگ دیکھیں' : 'View Activity Log'}</button>
    </div>
    <div style="margin-top:18px;padding-top:16px;border-top:1px solid var(--line);">
      <p style="font-size:11px;opacity:.6;margin:0 0 8px;">${LANG==='ur' ? 'آئی ڈی کارڈز پرنٹ کریں' : 'Print ID Cards'}</p>
      <button class="btn-ghost" style="width:100%;margin-bottom:8px;" onclick="openIdCardTool('id-card-generator.html', ${LANG==='ur' ? "'طالب علم آئی ڈی کارڈ'" : "'Student ID Card Generator'"})">🪪 ${LANG==='ur' ? 'طالب علم آئی ڈی کارڈ' : 'Student ID Card Generator'}</button>
      <button class="btn-ghost" style="width:100%;" onclick="openIdCardTool('teacher-id-card-generator.html', ${LANG==='ur' ? "'اساتذہ آئی ڈی کارڈ'" : "'Teacher ID Card Generator'"})">🪪 ${LANG==='ur' ? 'اساتذہ آئی ڈی کارڈ' : 'Teacher ID Card Generator'}</button>
    </div>
    <div style="margin-top:18px;padding-top:16px;border-top:1px solid var(--line);">
      <p style="font-size:11px;opacity:.6;margin:0 0 8px;">${LANG==='ur' ? 'آف لائن مسئلے کی تشخیص کے لیے (جیسے ڈیش بورڈ 0 دکھانا)' : 'For diagnosing offline issues (e.g. dashboard showing 0)'}</p>
      <button class="btn-ghost" style="width:100%;" onclick="showStorageDiagnostics()">🔍 ${LANG==='ur' ? 'اسٹوریج کی تشخیص' : 'Storage Diagnostics'}</button>
    </div>
    <div style="margin-top:18px;padding-top:16px;border-top:1px solid var(--line);">
      <p style="font-size:11px;opacity:.6;margin:0 0 8px;">${esc(t.clearCacheHint)}</p>
      <div id="clear-cache-msg"></div>
      <button class="btn-ghost" style="width:100%;" onclick="clearAppCache()">🧹 ${esc(t.clearCache)}</button>
    </div>
    <div style="margin-top:16px;"><button class="btn-ghost danger" onclick="logOut()">${esc(t.logOut)}</button></div>
  `);
}

// Self-contained, on-phone diagnostic report — no PC/remote-debugging
// needed. Shows exactly what's actually persisted on THIS device right now
// (IndexedDB row counts, localStorage snapshot, Cache Storage, whether the
// browser granted "persistent storage", and how the app is being run) so
// the offline-shows-zero bug can be diagnosed from a screenshot alone.
async function showStorageDiagnostics() {
  showModal(LANG==='ur' ? 'اسٹوریج کی تشخیص' : 'Storage Diagnostics', `<div id="diag-body" style="font-size:12px;white-space:pre-wrap;font-family:monospace;line-height:1.6;">${LANG==='ur' ? 'لوڈ ہو رہا ہے...' : 'Loading…'}</div>
    <button class="btn-ghost" style="width:100%;margin-top:12px;" onclick="copyDiagnostics()">📋 ${LANG==='ur' ? 'کاپی کریں' : 'Copy'}</button>`);
  const lines = [];
  lines.push('=== School MS Storage Diagnostics ===');
  lines.push('Time: ' + new Date().toLocaleString());
  lines.push('navigator.onLine: ' + navigator.onLine);
  lines.push('User agent: ' + navigator.userAgent);
  lines.push('Display mode: ' + (window.matchMedia('(display-mode: standalone)').matches ? 'standalone (installed PWA)' : 'browser tab'));
  lines.push('SW controller active: ' + !!(navigator.serviceWorker && navigator.serviceWorker.controller));
  try {
    if (navigator.storage && navigator.storage.persisted) {
      lines.push('Storage persisted (protected from auto-eviction): ' + await navigator.storage.persisted());
    } else {
      lines.push('Storage persisted: not supported by this browser/webview');
    }
  } catch (e) { lines.push('Storage persisted: error — ' + e.message); }
  try {
    if (navigator.storage && navigator.storage.estimate) {
      const est = await navigator.storage.estimate();
      lines.push(`Storage usage: ${Math.round((est.usage||0)/1024)} KB of ${Math.round((est.quota||0)/1024/1024)} MB quota`);
    } else {
      lines.push('Storage estimate: not supported by this browser/webview');
    }
  } catch (e) { lines.push('Storage estimate: error — ' + e.message); }
  lines.push('');
  lines.push('--- IndexedDB (' + IDB_NAME + ') ---');
  try {
    const counts = await Promise.all(READ_CACHE_TABLES.map(tbl => idbGetAll(tbl)));
    READ_CACHE_TABLES.forEach((tbl, i) => lines.push(tbl + ': ' + counts[i].length + ' rows'));
    lines.push('TOTAL: ' + counts.reduce((a, c) => a + c.length, 0) + ' rows');
  } catch (e) { lines.push('IndexedDB read failed: ' + e.message); }
  lines.push('');
  lines.push('--- localStorage snapshot backup ---');
  try {
    const snap = loadOfflineSnapshot();
    if (!snap) {
      lines.push('No snapshot found for this account on this device.');
    } else {
      const snapRows = (snap.students||[]).length + (snap.feePayments||[]).length + (snap.teachers||[]).length +
        (snap.salaryPayments||[]).length + (snap.transactions||[]).length;
      lines.push('Snapshot found — saved ' + (snap.savedAt ? new Date(snap.savedAt).toLocaleString() : 'unknown time'));
      lines.push('students: ' + (snap.students||[]).length + ', fee_payments: ' + (snap.feePayments||[]).length + ', teachers: ' + (snap.teachers||[]).length + ', salary_payments: ' + (snap.salaryPayments||[]).length + ', transactions: ' + (snap.transactions||[]).length);
    }
  } catch (e) { lines.push('localStorage read failed: ' + e.message); }
  lines.push('');
  lines.push('--- Cache Storage (app shell / sw.js) ---');
  try {
    if (window.caches) {
      const keys = await caches.keys();
      for (const k of keys) {
        const c = await caches.open(k);
        const reqs = await c.keys();
        lines.push(k + ': ' + reqs.length + ' cached files');
      }
    } else {
      lines.push('Cache Storage API not available');
    }
  } catch (e) { lines.push('Cache Storage read failed: ' + e.message); }
  lines.push('');
  lines.push('Live DATA in memory right now: students ' + DATA.students.length + ', fee_payments ' + DATA.feePayments.length + ', teachers ' + DATA.teachers.length);
  lines.push('CACHE_UNAVAILABLE flag: ' + CACHE_UNAVAILABLE);
  const el = document.getElementById('diag-body');
  if (el) el.textContent = lines.join('\n');
  window._diagText = lines.join('\n');
}
// User-facing "Clear App Cache" (Settings screen). Wipes only locally
// cached copies of data (IndexedDB read-cache tables, the localStorage
// backup snapshot, and the Cache Storage used by the service worker for
// app-shell files), then reloads — so the browser/app is forced to fetch
// the newest deployed index.html/sw.js instead of an old cached one.
// Deliberately does NOT touch: the Supabase auth session (user stays
// logged in), the chosen language, or — most importantly — sync_queue,
// which holds any offline edits not yet pushed to the server. If that
// queue is non-empty we refuse and tell the user to reconnect first,
// since deleting the IndexedDB database would silently discard that
// unsynced work.
async function clearAppCache() {
  const msg = document.getElementById('clear-cache-msg');
  let pending = 0;
  try { pending = (await idbGetAll('sync_queue')).length; } catch (e) {}
  if (pending > 0) {
    if (msg) msg.innerHTML = `<div class="err">${esc(t.clearCachePending)}</div>`;
    return;
  }
  if (!confirm(t.clearCacheConfirm)) return;
  if (msg) msg.innerHTML = `<div class="ok">${esc(t.clearCacheWorking)}</div>`;

  // 1. Delete the IndexedDB database (closing any open connection first,
  // otherwise deleteDatabase() stalls waiting for it to close).
  try {
    if (_idbPromise) { try { (await _idbPromise).close(); } catch (e) {} }
    _idbPromise = null;
    await new Promise((resolve) => {
      const req = indexedDB.deleteDatabase(IDB_NAME);
      req.onsuccess = () => resolve();
      req.onerror = () => resolve();
      req.onblocked = () => resolve();
    });
  } catch (e) {}

  // 2. Clear the localStorage read-cache copies (offline snapshot + cached
  // profile), but leave sms_lang and the Supabase auth token alone.
  try {
    const toRemove = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && (k.startsWith(OFFLINE_SNAPSHOT_KEY) || k.startsWith('sms_cached_profile_') || k === 'examRecordsCleanupRanOn')) {
        toRemove.push(k);
      }
    }
    toRemove.forEach(k => localStorage.removeItem(k));
  } catch (e) {}

  // 3. Clear the Cache Storage API entries the service worker uses for the
  // app shell (HTML/CSS/JS), so the next load fetches fresh files.
  try {
    if (window.caches) {
      const keys = await caches.keys();
      await Promise.all(keys.map(k => caches.delete(k)));
    }
  } catch (e) {}

  // 4. Unregister the service worker itself so it re-installs fresh on
  // reload, picking up the newest sw.js instead of an old cached copy.
  try {
    if (navigator.serviceWorker) {
      const regs = await navigator.serviceWorker.getRegistrations();
      await Promise.all(regs.map(r => r.unregister()));
    }
  } catch (e) {}

  // 5. A plain reload() can still be answered by the browser's own normal
  // HTTP cache (separate from Cache Storage above) if the server sent a
  // cache-control header allowing it — that's the "online cache" a script
  // can't force-clear directly. Reloading to a URL with a fresh, unique
  // query string sidesteps that: the browser treats it as a different
  // resource and is forced to fetch it from the network instead of disk.
  const bustUrl = location.pathname + '?_cachebust=' + Date.now();
  location.replace(bustUrl);
}

function copyDiagnostics() {
  if (!window._diagText) return;
  navigator.clipboard.writeText(window._diagText).then(() => {
    const btn = event.target;
    const old = btn.textContent;
    btn.textContent = LANG==='ur' ? '✓ کاپی ہو گیا' : '✓ Copied';
    setTimeout(() => { btn.textContent = old; }, 1500);
  }).catch(() => {});
}

function generateSchoolCode() {
  const base = (CURRENT_PROFILE.school_name || 'SCH').replace(/[^a-zA-Z]/g, '').toUpperCase().slice(0, 4) || 'SCH';
  const rand = Math.floor(10 + Math.random() * 90);
  document.getElementById('set-school-code').value = base + rand;
}

async function saveSchoolCode() {
  const codeMsg = document.getElementById('set-code-msg');
  let code = document.getElementById('set-school-code').value.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (!code) { codeMsg.innerHTML = `<div class="err">${esc(t.parentSchoolCodeRequired)}</div>`; return; }
  const { error } = await sb.from('profiles').update({ school_code: code }).eq('id', CURRENT_USER.id);
  if (error) {
    codeMsg.innerHTML = `<div class="err">${error.code === '23505' ? esc(t.parentSchoolCodeTaken) : esc(friendlyErrorMsg(error))}</div>`;
    return;
  }
  CURRENT_PROFILE.school_code = code;
  codeMsg.innerHTML = `<div class="ok">${esc(t.saved)}</div>`;
}

async function saveDiaryPassword() {
  const msg = document.getElementById('set-diary-msg');
  const pw = document.getElementById('set-diary-pw').value.trim();
  if (!pw || pw.length < 6) { msg.innerHTML = `<div class="err">${esc(t.diaryPasswordRequired)} (min 6)</div>`; return; }
  const { error } = await sb.from('profiles').update({ diary_password: pw }).eq('id', CURRENT_USER.id);
  if (error) { msg.innerHTML = `<div class="err">${esc(friendlyErrorMsg(error))}</div>`; return; }
  try { const { data: dp } = await sb.from('profiles').select('diary_password').eq('id', CURRENT_USER.id).single(); if (dp) CURRENT_PROFILE.diary_password = dp.diary_password; } catch(e) {}
  document.getElementById('set-diary-pw').value = '';
  msg.innerHTML = `<div class="ok">${esc(t.saved)}</div>`;
}

// Generic activity-log entry not tied to one of the ACTIVITY_LOG_TABLES rows
// above (e.g. "downloaded a backup", "restored a backup") — same best-effort,
// never-throws behavior as logActivity().
function logCustomActivity(description, action) {
  if (!navigator.onLine || !CURRENT_USER) return;
  try {
    sb.from('activity_log').insert({
      owner_id: CURRENT_USER.id, actor_email: CURRENT_USER.email || null,
      action: action || 'other', table_name: 'backup', description
    }).then(() => {}).catch(() => {});
  } catch (e) { /* never let logging break the actual action */ }
}

async function openActivityLog() {
  showModal(LANG === 'ur' ? 'سرگرمی لاگ' : 'Activity Log', `<div id="activity-log-body" style="font-size:13px;opacity:.7;">${LANG === 'ur' ? 'لوڈ ہو رہا ہے…' : 'Loading…'}</div>`);
  const { data, error } = await sb.from('activity_log').select('*')
    .eq('owner_id', CURRENT_USER.id).order('created_at', { ascending: false }).limit(200);
  const body = document.getElementById('activity-log-body');
  if (!body) return; // modal was closed before this resolved
  if (error) {
    body.innerHTML = `<p style="font-size:13px;opacity:.7;">${LANG === 'ur'
      ? 'سرگرمی لاگ ابھی سیٹ اپ نہیں ہوا۔ فائل کے شروع میں CONFIG کے قریب دیا گیا SQL، Supabase میں ایک بار چلائیں۔'
      : "Activity Log isn't set up yet — run the one-time SQL near CONFIG at the top of this file in your Supabase SQL editor, then try again."}</p>`;
    return;
  }
  if (!data || !data.length) {
    body.innerHTML = `<p style="font-size:13px;opacity:.6;">${LANG === 'ur' ? 'ابھی تک کوئی سرگرمی ریکارڈ نہیں ہوئی۔' : 'No activity recorded yet.'}</p>`;
    return;
  }
  body.innerHTML = `<div style="max-height:60vh;overflow-y:auto;">${data.map(r => `
    <div style="padding:9px 0;border-bottom:1px solid var(--line);">
      <div style="font-size:13px;">${esc(r.description)}</div>
      <div style="font-size:11px;opacity:.55;margin-top:2px;">${esc(r.actor_email || '')}${r.actor_email ? ' · ' : ''}${new Date(r.created_at).toLocaleString(LANG === 'ur' ? 'ur-PK' : 'en-US')}</div>
    </div>`).join('')}</div>`;
}

// ---------------- Full Backup (JSON) & Restore ----------------
// exportBackup() below (Excel) is a human-readable report — great for
// printing/sharing, but lossy (rounded to display columns, no row IDs), so
// it can't safely be fed back in. This JSON export keeps every raw row from
// every table, IDs included, so it can be restored later without guesswork.
function exportFullBackupJSON() {
  const payload = {
    version: 1,
    exported_at: new Date().toISOString(),
    school_name: CURRENT_PROFILE.school_name || '',
    profile: {
      school_name: CURRENT_PROFILE.school_name || null,
      school_name_ur: CURRENT_PROFILE.school_name_ur || null,
      school_code: CURRENT_PROFILE.school_code || null,
      diary_password: CURRENT_PROFILE.diary_password || null
    },
    data: {
      students: DATA.students, fee_payments: DATA.feePayments, teachers: DATA.teachers,
      salary_payments: DATA.salaryPayments, transactions: DATA.transactions,
      admission_register: DATA.admissionRegister, teacher_attendance: DATA.teacherAttendance,
      holidays: DATA.holidays, class_logins: DATA.classLogins, student_attendance: DATA.studentAttendance
    }
  };
  const blob = new Blob([JSON.stringify(payload)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const schoolPart = (CURRENT_PROFILE.school_name || 'school').replace(/[^a-z0-9]+/gi, '_');
  a.href = url; a.download = `${schoolPart}_full_backup_${fmtDate(todayISO())}.json`;
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
  logCustomActivity('Downloaded a full backup', 'export');
}

// Holds the parsed backup while the user reviews the summary and confirms —
// kept in memory only (never inlined into an onclick attribute), since a
// backup can be many thousands of rows.
let PENDING_RESTORE_DATA = null;
async function handleRestoreFileSelected(input) {
  const file = input.files && input.files[0];
  input.value = ''; // so picking the same file again later still fires 'change'
  if (!file) return;
  const msg = document.getElementById('restore-msg');
  msg.innerHTML = `<div style="font-size:12px;opacity:.7;">${LANG === 'ur' ? 'فائل پڑھی جا رہی ہے…' : 'Reading file…'}</div>`;
  let parsed;
  try { parsed = JSON.parse(await file.text()); } catch (e) { parsed = null; }
  if (!parsed || typeof parsed.data !== 'object') {
    msg.innerHTML = `<div class="err">${LANG === 'ur' ? 'یہ ایک درست بیک اپ فائل نہیں ہے۔' : 'This does not look like a valid backup file.'}</div>`;
    return;
  }
  PENDING_RESTORE_DATA = parsed;
  const counts = Object.entries(parsed.data)
    .map(([k, v]) => `${k.replace(/_/g, ' ')}: ${Array.isArray(v) ? v.length : 0}`).join(' · ');
  msg.innerHTML = `
    <div style="font-size:12px;background:var(--surface2);padding:10px;border-radius:8px;">
      <div style="margin-bottom:8px;">${LANG === 'ur' ? 'اس بیک اپ میں شامل ہے' : 'This backup contains'}: ${esc(counts)}</div>
      <div style="margin-bottom:10px;opacity:.7;">${LANG === 'ur'
        ? 'بحالی سے موجودہ ریکارڈ نہیں مٹیں گے — صرف شامل یا اپڈیٹ ہوں گے۔'
        : 'Restoring will not delete any current records — it only adds new ones and updates matching ones by ID.'}</div>
      <button class="btn-primary" style="width:100%;" onclick="confirmRestoreBackup()">${LANG === 'ur' ? 'تصدیق کریں اور بحال کریں' : 'Confirm & Restore'}</button>
    </div>`;
}
async function confirmRestoreBackup() {
  const parsed = PENDING_RESTORE_DATA;
  const msg = document.getElementById('restore-msg');
  if (!parsed) return;
  msg.innerHTML = `<div style="font-size:12px;opacity:.7;">${LANG === 'ur' ? 'بحال کیا جا رہا ہے…' : 'Restoring…'}</div>`;
  const TABLES = ['students', 'fee_payments', 'teachers', 'salary_payments', 'transactions',
    'admission_register', 'teacher_attendance', 'holidays', 'class_logins', 'student_attendance'];
  const failed = [];
  for (const key of TABLES) {
    const rows = parsed.data[key];
    if (!Array.isArray(rows) || !rows.length) continue;
    // Force ownership onto the account currently restoring — protects against
    // a backup that was shared between schools, or restored onto a new login.
    const scoped = rows.map(r => ({ ...r, owner_id: CURRENT_USER.id }));
    // Chunked so a large school's full history doesn't hit Supabase's
    // per-request row/size limits in one go.
    for (let i = 0; i < scoped.length; i += 500) {
      const { error } = await sb.from(key).upsert(scoped.slice(i, i + 500), { onConflict: 'id' });
      if (error) { failed.push(key); break; }
    }
  }
  PENDING_RESTORE_DATA = null;
  await loadAllData(); renderTab();
  if (failed.length) {
    msg.innerHTML = `<div class="err">${(LANG === 'ur' ? 'کچھ حصے بحال نہیں ہو سکے: ' : 'Some parts could not be restored: ') + esc(failed.join(', '))}</div>`;
  } else {
    msg.innerHTML = `<div class="ok">${LANG === 'ur' ? 'بحالی مکمل ہو گئی۔' : 'Restore complete.'}</div>`;
    logCustomActivity('Restored data from a backup file', 'restore');
  }
}

function exportBackup() {
  const wb = XLSX.utils.book_new();
  const addSheet = (name, rows) => {
    const ws = XLSX.utils.json_to_sheet(rows.length ? rows : [{}]);
    // Size the sheet to exactly the columns that exist — no blank/hidden extra columns
    const numCols = rows.length ? Object.keys(rows[0]).length : 1;
    ws['!cols'] = Array.from({ length: numCols }, () => ({ wch: 14 }));
    // Bold the header row (row 1)
    for (let c = 0; c < numCols; c++) {
      const addr = XLSX.utils.encode_cell({ r: 0, c });
      if (ws[addr]) ws[addr].s = { font: { bold: true } };
    }
    XLSX.utils.book_append_sheet(wb, ws, name);
  };
  const classRank = (cls) => {
    const i = CLASS_OPTIONS.indexOf(cls);
    return i === -1 ? CLASS_OPTIONS.length : i; // unknown/blank class names sort last
  };
  const sortedStudents = DATA.students.slice().sort((a, b) => {
    const r = classRank(a.class_name) - classRank(b.class_name);
    if (r !== 0) return r;
    return (a.name || '').localeCompare(b.name || ''); // same class → alphabetical by name
  });
  addSheet('Students', sortedStudents.map(s=>({
    Name:s.name, Father:s.father_name, Class:s.class_name, Type:typeLabel(s.student_type||'paying'),
    Admission:fmtDate(s.admission_date), Contact:s.contact, MonthlyFee:s.monthly_fee, Status:s.status,
    CurrentBalance: studentBalance(s.id)
  })));
  // Per-student fee ledger sheets — mirrors the school's printed fee card format exactly:
  // 12 fixed rows (February through January) with columns
  // Month | Last Balance | School Fee | Sports Fund | Admission Fee | Annual Exam Fee | Total Dues | Total Paid | Balance | Receipt No | Date | Signature
  const CARD_MONTH_ORDER = [2,3,4,5,6,7,8,9,10,11,12,1]; // Feb..Jan, same order as the printed card
  const usedSheetNames = new Set(['Students','Teachers','Salary Payments','Other Transactions','Summary']);
  DATA.students.slice().sort((a, b) => {
    const r = classRank(a.class_name) - classRank(b.class_name);
    if (r !== 0) return r;
    return (a.name || '').localeCompare(b.name || '');
  }).forEach(s => {
    const entries = studentPayments(s.id);
    const entryByMonth = {};
    entries.forEach(e => { entryByMonth[e.month] = e; });

    // Figure out which calendar year February starts in for this student's card
    // (admission year if known, else the earliest recorded entry, else the current year)
    let startYear;
    if (s.admission_date) startYear = new Date(s.admission_date).getFullYear();
    else if (entries.length) startYear = Math.min(...entries.map(e => Number(e.month.split('-')[0])));
    else startYear = new Date().getFullYear();

    const monthKeys = CARD_MONTH_ORDER.map(m => {
      const y = m >= 2 ? startYear : startYear + 1; // January rolls into the next calendar year
      return `${y}-${String(m).padStart(2,'0')}`;
    });

    let running = 0;
    const ledgerRows = monthKeys.map(mk => {
      const e = entryByMonth[mk];
      const lastBalance = running;
      if (!e) {
        // No entry recorded yet for this month — row stays blank like the physical card, balance carries forward
        running = lastBalance;
        return {
          Month: monthLabel(mk), 'Last Balance': lastBalance, 'School Fee': '', 'Sports Fund': '',
          'Admission Fee': '', 'Annual Exam Fee': '', 'Other Fee': '', 'Total Dues': lastBalance, 'Total Paid': '',
          'Balance': lastBalance, 'Receipt No': '', Date: '', Signature: ''
        };
      }
      const totalDues = lastBalance + Number(e.school_fee||0) + Number(e.sports_fund||0) + Number(e.admission_fee||0) + Number(e.exam_fee||0) + Number(e.other_fee||0);
      const totalPaid = Number(e.amount||0);
      const balance = money2(totalDues - totalPaid);
      running = balance;
      return {
        Month: monthLabel(mk), 'Last Balance': lastBalance, 'School Fee': Number(e.school_fee||0),
        'Sports Fund': Number(e.sports_fund||0), 'Admission Fee': Number(e.admission_fee||0), 'Annual Exam Fee': Number(e.exam_fee||0),
        'Other Fee': Number(e.other_fee||0), 'Total Dues': totalDues, 'Total Paid': totalPaid, 'Balance': balance,
        'Receipt No': e.receipt_no||'', Date: fmtDate(e.pay_date)||'', Signature: ''
      };
    });
    // Build a safe, unique Excel sheet name (max 31 chars, no illegal characters)
    let base = (s.name||'Student').replace(/[\\/*?:\[\]]/g,'').trim().slice(0,28) || 'Student';
    let sheetName = base, i = 2;
    while (usedSheetNames.has(sheetName)) { sheetName = `${base.slice(0,26)}_${i++}`; }
    usedSheetNames.add(sheetName);
    addSheet(sheetName, ledgerRows);
  });
  addSheet('Teachers', DATA.teachers.map(tc=>({
    Name:tc.name, Subject:tc.subject, MonthlySalary:tc.monthly_salary, JoinDate:fmtDate(tc.join_date)
  })));
  addSheet('Salary Payments', DATA.salaryPayments.map(p=>{
    const tc = DATA.teachers.find(x=>x.id===p.teacher_id);
    return { Teacher: tc?tc.name:p.teacher_id, Month:p.month, Amount:p.amount, Date:fmtDate(p.pay_date) };
  }));
  addSheet('Other Transactions', DATA.transactions.map(x=>({
    Type:x.type, Category:x.category, Description:x.description, Amount:x.amount, Date:fmtDate(x.txn_date)
  })));
  const s = computeStats();
  addSheet('Summary', [{
    TotalFeesCollected:s.totalCollectedAllTime, TotalSalariesPaid:s.totalSalariesAllTime,
    TotalOtherIncome:s.totalOtherIncomeAllTime, TotalOtherExpense:s.totalOtherExpenseAllTime,
    NetBalance:s.netBalance, ExportedOn:fmtDate(todayISO())
  }]);
  const schoolPart = (CURRENT_PROFILE.school_name||'school').replace(/[^a-z0-9]+/gi,'_');
  XLSX.writeFile(wb, `${schoolPart}_backup_${fmtDate(todayISO())}.xlsx`, { cellStyles: true });
}

async function submitSettings() {
  const schoolName = document.getElementById('set-school').value.trim();
  const schoolNameUr = document.getElementById('set-school-ur').value.trim();
  const newPw = document.getElementById('set-pw').value;
  const msg = document.getElementById('set-msg');
  msg.innerHTML = '';
  if (newPw && newPw.length < 6) { msg.innerHTML = `<div class="err">${esc(t.passwordTooShort)}</div>`; return; }

  if (schoolName && schoolName !== CURRENT_PROFILE.school_name) {
    const { error } = await sb.from('profiles').update({ school_name: schoolName }).eq('id', CURRENT_USER.id);
    if (error) { msg.innerHTML = `<div class="err">${esc(friendlyErrorMsg(error))}</div>`; return; }
    CURRENT_PROFILE.school_name = schoolName;
  }
  if (schoolNameUr !== (CURRENT_PROFILE.school_name_ur || '')) {
    const { error } = await sb.from('profiles').update({ school_name_ur: schoolNameUr || null }).eq('id', CURRENT_USER.id);
    if (error) { msg.innerHTML = `<div class="err">${esc(friendlyErrorMsg(error))}</div>`; return; }
    CURRENT_PROFILE.school_name_ur = schoolNameUr;
  }
  if (newPw) {
    const { error } = await sb.auth.updateUser({ password: newPw });
    if (error) { msg.innerHTML = `<div class="err">${esc(friendlyErrorMsg(error))}</div>`; return; }
  }
  msg.innerHTML = `<div class="ok">${esc(t.settingsSaved)}</div>`;
  document.querySelector('header .eyebrow').textContent = CURRENT_PROFILE.school_name;
  setTimeout(closeModal, 800);
}

