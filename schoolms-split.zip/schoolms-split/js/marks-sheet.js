/* SchoolMS — marks-sheet.js — split from index.html (lines 9462-10429). Load order matters: see index.html */
// --------- MARKS SHEET (Independent - separate from Students database) ---------
let msClasses = ['Nursery', 'KG', '1st', '2nd', '3rd']; // independent class list
let msStudents = {}; // {className: [{id, name}, ...]}
let msSubjects = []; // independent subject list
let msMarksData = {}; // {className: {studentId: {subject: marks}}}
let msSelectedClass = '';
let msNewStudentName = '';
let msLoaded = false;
let msSaveTimer = null;
// Which academic year's sheet is currently loaded. Each year gets its own row
// in marks_sheet_data (owner_id + academic_year together are unique), so
// switching years never overwrites a previous year's marks.
let msAcademicYear = '';
let msLoadedYear = null; // the year msStudents/msMarksData currently reflect
let msYearsList = [];    // years this school has previously saved, for the dropdown

// ---- Device-only storage (same idea as the Question Paper draft) ----
// The Marks Sheet is kept on this device: localStorage is written synchronously on
// every change (so nothing is lost on refresh / app switch / closing the browser),
// with an IndexedDB copy as a second backup. Nothing is sent to Supabase, and
// nothing here is touched by "Clear cache" except the IndexedDB backup copy.
let msSubjectTotals = {}; // {subjectName: maximum marks}
function msLocalKey() { return 'msLocal_v1_' + ((typeof CURRENT_USER !== 'undefined' && CURRENT_USER && CURRENT_USER.id) || 'x'); }
function msLocalRead() {
  try { const o = JSON.parse(localStorage.getItem(msLocalKey()) || 'null'); if (o && o.years) return o; } catch (e) {}
  return { years: {}, lastYear: '' };
}
function msSubjectMax(name) { const n = Number(msSubjectTotals[name]); return n > 0 ? n : 100; }

async function loadMarksSheetYearsList() {
  const set = new Set(Object.keys(msLocalRead().years));
  try { (await idbGetAll('marks_sheet_data')).forEach(r => { if (r && r.academic_year) set.add(r.academic_year); }); } catch (e) {}
  msYearsList = Array.from(set).filter(Boolean).sort().reverse();
}

async function loadMarksSheetData() {
  if (msLoaded && msLoadedYear === msAcademicYear) return;
  msLoaded = true;
  try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist(); } catch (e) {}
  const db = msLocalRead();
  if (!msAcademicYear) msAcademicYear = db.lastYear || Object.keys(db.years).sort().reverse()[0] || dmcAcademicSession || '';
  const yearKey = msAcademicYear || 'Unspecified';
  msLoadedYear = msAcademicYear;
  // Synchronous: no await before the data is applied, so a save can never run
  // against empty defaults and overwrite what is stored.
  let row = db.years[yearKey];
  applyMarksSheetData(row);
  loadMarksSheetYearsList();
  if (!row) {
    // Nothing in localStorage for this year: look for an older IndexedDB copy once.
    try {
      const cached = await idbGetAll('marks_sheet_data');
      const old = cached.find(r => r.id === yearKey);
      if (old && msLoadedYear === msAcademicYear && !(msStudents && Object.keys(msStudents).length)) {
        applyMarksSheetData(old);
        saveMarksSheetData();
        if (TAB === 'marksSheet') renderTab();
      }
    } catch (e) {}
  }
}

// Applies a loaded marks-sheet row (from Supabase or the local cache) to the
// working globals. `row` is undefined/null when nothing has been saved yet
// for this year, in which case the sheet starts blank rather than showing
// whatever a previously-loaded year left in memory.
function applyMarksSheetData(row) {
  if (row) {
    msClasses = row.classes && row.classes.length ? row.classes : msClasses;
    msSubjects = row.subjects || [];
    msSubjectTotals = row.totals || {};
    msStudents = row.students || {};
    msMarksData = row.marks || {};
  } else {
    msSubjects = []; msSubjectTotals = {}; msStudents = {}; msMarksData = {};
  }
}

// Switches the working year (e.g. moving to a new session, or looking back at
// an old one) and reloads that year's own data from the database.
function changeMarksSheetYear(year) {
  msAcademicYear = year || '';
  msLoadedYear = null; // force loadMarksSheetData() to actually refetch
  loadMarksSheetData().then(() => {
    if (TAB !== 'marksSheet') return;
    const main = document.getElementById('main');
    const active = document.activeElement;
    if (active && main && main.contains(active) && (active.tagName === 'INPUT' || active.tagName === 'SELECT' || active.tagName === 'TEXTAREA')) return;
    renderTab();
  });
}

// Local cache write happens IMMEDIATELY (not debounced) — so an edit is never
// lost even if the tab/app is backgrounded (app switched, notification panel
// pulled down, screen locked, etc.) a moment after typing. Only the network
// call to Supabase is debounced, to avoid spamming the server on every keystroke.
let msFlushPending = null; // kept for compatibility; saving is now immediate and local
let msSaveWarned = false;
function msWarnSaveFailed() {
  if (msSaveWarned) return; // one warning per problem, not one per keystroke
  msSaveWarned = true;
  alert('⚠️ Marks is phone mein save nahi ho sake (phone ki jagah bhar gayi ho ya browser ne roka ho). Jo abhi likha hai wo kho sakta hai. Abhi "Backup" dabakar file mein save kar lein, aur phone ki jagah khali karein.');
}
// Backup: every year's data in one .json file; Restore puts it back (device-only, no server).
function msBackupDownload() {
  try {
    saveMarksSheetData();
    const db = msLocalRead();
    const blob = new Blob([JSON.stringify({ app: 'SchoolMS-MarksSheet', version: 1, exported_at: new Date().toISOString(), lastYear: db.lastYear, years: db.years })], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'marks-sheet-backup-' + todayISO() + '.json';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  } catch (e) { alert('Backup nahi ban saka: ' + (e && e.message || e)); }
}
function msRestoreFromFile(input) {
  const f = input.files && input.files[0];
  if (!f) return;
  const r = new FileReader();
  r.onload = () => {
    try {
      const o = JSON.parse(r.result);
      if (!o || o.app !== 'SchoolMS-MarksSheet' || !o.years || typeof o.years !== 'object') throw new Error('bad file');
      const names = Object.keys(o.years).filter(y => {
        const row = o.years[y];
        return row && typeof row === 'object' && Array.isArray(row.subjects) && row.students && typeof row.students === 'object' && row.marks && typeof row.marks === 'object';
      });
      if (!names.length) throw new Error('empty');
      if (!confirm(names.length + ' saal ka data wapis lagana hai?\n(' + names.join(', ') + ')\nIsi naam ke saal ka maujooda data is file se badal jayega.')) return;
      saveMarksSheetData(); // keep whatever is on screen right now before merging
      const db = msLocalRead();
      names.forEach(y => { db.years[y] = o.years[y]; });
      const show = (o.lastYear && names.includes(o.lastYear)) ? o.lastYear : names[0];
      db.lastYear = show;
      localStorage.setItem(msLocalKey(), JSON.stringify(db));
      msLoaded = false; msLoadedYear = null; msAcademicYear = show;
      renderTab();
      alert('Backup wapis laga diya gaya.');
    } catch (e) { alert('Ye sahi backup file nahi lagti, ya data save nahi ho saka.'); }
    input.value = '';
  };
  r.readAsText(f);
}
function saveMarksSheetData() {
  // Never write before this year's data has been loaded (would overwrite it with empty defaults).
  if (!msLoaded || msLoadedYear !== msAcademicYear) return;
  const yearKey = msAcademicYear || 'Unspecified';
  const row = { classes: msClasses, subjects: msSubjects, totals: msSubjectTotals, students: msStudents, marks: msMarksData, updated_at: new Date().toISOString() };
  const db = msLocalRead();
  db.years[yearKey] = row;
  db.lastYear = msAcademicYear;
  try { localStorage.setItem(msLocalKey(), JSON.stringify(db)); msSaveWarned = false; }
  catch (e) { console.error('Marks sheet could not be saved on this device:', e); msWarnSaveFailed(); }
  // Second copy in IndexedDB (best effort, device only).
  try { idbPutRow('marks_sheet_data', { id: yearKey, academic_year: yearKey, ...row }); } catch (e) {}
  if (msAcademicYear && !msYearsList.includes(msAcademicYear)) msYearsList = [msAcademicYear, ...msYearsList];
}
// Save once more whenever the app is hidden or closed (harmless: it writes the same state).
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') { try { saveMarksSheetData(); } catch (e) {} } });
window.addEventListener('pagehide', () => { try { saveMarksSheetData(); } catch (e) {} });

// ---- Total / Grade / Position helpers (Marks Sheet + Teacher Portal) ----
// Position: highest total = 1. Equal totals share a position and the next
// position follows without a gap (1, 1, 2 - NOT 1, 1, 3). A student with no
// marks entered yet gets null (shown as a dash).
function msComputeRanks(totals) {
  const valid = [...new Set(totals.filter(x => x !== null))].sort((a, b) => b - a);
  return totals.map(x => x === null ? null : valid.indexOf(x) + 1);
}
// Max = sum of each subject's own total marks (default 100 for subjects added before totals existed).
function msSummaryForClass(cls) {
  const studs = msStudents[cls] || [];
  const md = msMarksData[cls] || {};
  const totals = studs.map(st => {
    const row = md[st.id] || {};
    let any = false, tot = 0;
    msSubjects.forEach(sj => { const v = row[sj]; if (v !== undefined && v !== null && v !== '') { any = true; tot += Number(v) || 0; } });
    return any ? tot : null;
  });
  const ranks = msComputeRanks(totals);
  const max = msSubjects.reduce((sum, sj) => sum + msSubjectMax(sj), 0);
  return studs.map((st, i) => ({
    total: totals[i], max,
    grade: (totals[i] === null || !max) ? '' : dmcGradeFor(totals[i] / max * 100),
    pos: ranks[i]
  }));
}
// Updates the Total / Grade / Position cells in place while marks are typed,
// without re-rendering the tab (a re-render would close the keyboard).
function msRefreshSummary() {
  if (!msSelectedClass) return;
  const sum = msSummaryForClass(msSelectedClass);
  const studs = msStudents[msSelectedClass] || [];
  const cells = document.querySelectorAll('[data-ms-sid]');
  studs.forEach((st, i) => {
    cells.forEach(el => {
      if (el.dataset.msSid !== String(st.id)) return;
      const k = el.dataset.ms;
      el.textContent = k === 'tot' ? (sum[i].total === null ? '—' : sum[i].total + '/' + sum[i].max)
        : k === 'grade' ? (sum[i].grade || '—')
        : (sum[i].pos === null ? '—' : sum[i].pos);
    });
  });
}

function tplMarksSheet() {
  if (!msLoaded) {
    // Previously this returned a bare "Loading..." placeholder (no inputs at
    // all) and swapped in the *entire* real form via renderTab() once the
    // network call finished — typically well under a second later. A tap
    // landing right in that window races the swap: the finger goes down on
    // the placeholder, but by the time the tap resolves, the real form
    // (with real inputs) has replaced it underneath, which can open then
    // immediately close the keyboard. Rendering the real form immediately
    // (with whatever's currently in memory — empty defaults, the first
    // time) means the inputs a user might tap are on the page from the very
    // first paint, so there's nothing for a fast tap to race against; the
    // fetch below just fills them in a moment later.
    msLoaded = true;
    loadMarksSheetData().then(() => {
      if (TAB !== 'marksSheet') return;
      const main = document.getElementById('main');
      const active = document.activeElement;
      if (active && main && main.contains(active) && (active.tagName === 'INPUT' || active.tagName === 'SELECT' || active.tagName === 'TEXTAREA')) return;
      renderTab();
    });
  }
  if (!msSelectedClass && msClasses.length) msSelectedClass = msClasses[0];
  
  const classStudents = msStudents[msSelectedClass] || [];
  
  let tableHtml = '';
  if (classStudents.length > 0) {
    const msSum = msSummaryForClass(msSelectedClass);
    tableHtml = `
      <div class="ms-scroll-wrap" style="overflow-x:auto;margin-bottom:16px;direction:ltr;-webkit-overflow-scrolling:touch;"><table style="width:100%;border-collapse:collapse;font-size:19px;">
        <thead>
          <tr style="background:#0F2740;color:#fff;position:sticky;top:0;">
            <th style="padding:8px;text-align:left;min-width:150px;position:sticky;left:0;z-index:3;background:#0F2740;box-shadow:2px 0 0 #C9A227;">Student Name</th>
            <th style="padding:8px;text-align:left;min-width:150px;">Father Name</th>
            ${msSubjects.map(s => `<th style="padding:10px;text-align:center;min-width:100px;">${esc(s)}<div style="font-size:12px;font-weight:400;opacity:.8;">/ ${msSubjectMax(s)}</div></th>`).join('')}
            <th style="padding:8px;text-align:center;min-width:70px;">Total</th>
            <th style="padding:8px;text-align:center;min-width:50px;">Grade</th>
            <th style="padding:8px;text-align:center;min-width:60px;">Position</th>
            <th style="padding:8px;text-align:center;min-width:60px;">Action</th>
          </tr>
        </thead>
        <tbody>
    `;
    
    classStudents.forEach((student, idx) => {
      if (!msMarksData[msSelectedClass]) msMarksData[msSelectedClass] = {};
      if (!msMarksData[msSelectedClass][student.id]) msMarksData[msSelectedClass][student.id] = {};
      
      tableHtml += `<tr style="border-bottom:1px solid #ddd;">
        <td style="padding:10px;text-align:left;font-weight:600;position:sticky;left:0;z-index:2;background:#fff;box-shadow:2px 0 0 #ddd;">${esc(student.name)}</td>
        <td style="padding:4px;"><input type="text" autocomplete="off" value="${esc(student.fatherName||'')}" placeholder="Father Name" style="width:100%;padding:9px;font-size:19px;border:1px solid #ccc;" oninput="msStudents['${msSelectedClass}'][${idx}].fatherName=this.value;saveMarksSheetData();" onchange="msStudents['${msSelectedClass}'][${idx}].fatherName=this.value;saveMarksSheetData();"></td>
        ${msSubjects.map(subj => {
          const val = msMarksData[msSelectedClass][student.id][subj] || '';
          return `<td style="padding:4px;"><input type="number" inputmode="decimal" min="0" max="${msSubjectMax(subj)}" autocomplete="off" value="${val}" placeholder="—" style="width:100%;text-align:center;padding:9px;font-size:19px;border:1px solid #ccc;" oninput="msMarksData['${msSelectedClass}']['${student.id}']['${subj}']=this.value;saveMarksSheetData();msRefreshSummary();" onchange="msMarksData['${msSelectedClass}']['${student.id}']['${subj}']=this.value;saveMarksSheetData();msRefreshSummary();"></td>`;
        }).join('')}
        <td style="padding:8px;text-align:center;font-weight:600;" data-ms="tot" data-ms-sid="${esc(student.id)}">${msSum[idx].total === null ? '—' : msSum[idx].total + '/' + msSum[idx].max}</td>
        <td style="padding:8px;text-align:center;font-weight:600;" data-ms="grade" data-ms-sid="${esc(student.id)}">${msSum[idx].grade || '—'}</td>
        <td style="padding:8px;text-align:center;font-weight:600;" data-ms="pos" data-ms-sid="${esc(student.id)}">${msSum[idx].pos === null ? '—' : msSum[idx].pos}</td>
        <td style="padding:4px;text-align:center;"><button class="btn-ghost" style="padding:0;font-size:11px;" onclick="removeMarksSheetStudent('${msSelectedClass}', ${idx})">✕</button></td>
      </tr>`;
    });
    
    tableHtml += `</tbody></table></div>`;
  }
  
  return `
    <h2>📋 Marks Sheet (Independent)</h2>

    <div class="card">
      <h3 style="margin-top:0;">Academic Year</h3>
      <p style="font-size:11px;opacity:.6;">Har saal ka data alag save hota hai — is se purana saal overwrite nahi hoga. Naya saal shuru karne ke liye yahan naya year likhein (jaise 2026-2027).</p>
      <div style="display:flex;gap:6px;">
        <input type="text" id="ms-year" list="ms-years-list" value="${esc(msAcademicYear)}" placeholder="e.g., 2025-2026" style="flex:1;" onchange="changeMarksSheetYear(this.value)">
        <datalist id="ms-years-list">${msYearsList.map(y => `<option value="${esc(y)}">`).join('')}</datalist>
      </div>
      ${msYearsList.length ? `<p style="font-size:11px;opacity:.5;margin:6px 0 0;">Purane saal: ${msYearsList.map(esc).join(', ')}</p>` : ''}
    </div>

    <div class="card">
      <h3 style="margin-top:0;">Backup</h3>
      <p style="font-size:11px;opacity:.6;">Ye sheet sirf is phone mein save hoti hai. Kabhi kabhi (khaas kar naya phone lene ya browser saaf karne se pehle) Backup dabakar file save kar lein. Restore se wohi file wapis laga sakte hain.</p>
      <div style="display:flex;gap:6px;flex-wrap:wrap;">
        <button class="btn-ghost" onclick="msBackupDownload()">⬇ Backup</button>
        <button class="btn-ghost" onclick="document.getElementById('ms-restore-file').click()">⬆ Restore</button>
        <input type="file" id="ms-restore-file" accept=".json,application/json" style="display:none" onchange="msRestoreFromFile(this)">
      </div>
    </div>

    <div class="card">
      <h3 style="margin-top:0;">Classes</h3>
      <p style="font-size:11px;opacity:.6;">Add or remove classes</p>
      <div style="display:flex;gap:6px;margin-bottom:8px;">
        <input type="text" id="ms-new-class" autocomplete="off" placeholder="Class Name (e.g., 1st, 2nd)" style="flex:1;">
        <button class="btn-ghost" onclick="addMarksSheetClass()">+ Add</button>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px;">
        ${msClasses.map((c, i) => `
          <div style="background:#F0EBDA;padding:6px 10px;border-radius:6px;font-size:12px;display:flex;align-items:center;gap:6px;">
            <button style="background:none;border:none;padding:0;cursor:pointer;font-weight:${c===msSelectedClass?'bold':'normal'};color:${c===msSelectedClass?'#0F2740':'inherit'};" onclick="msSelectedClass='${c}';renderTab();">${esc(c)}</button>
            <button class="btn-ghost" style="padding:0;font-size:10px;opacity:.6;" onclick="removeMarksSheetClass(${i})">✕</button>
          </div>
        `).join('')}
      </div>
    </div>

    <div class="card">
      <h3 style="margin-top:0;">Subjects</h3>
      <p style="font-size:11px;opacity:.6;">Add or remove subjects for this marks sheet</p>
      <div style="display:flex;gap:6px;margin-bottom:8px;">
        <input type="text" id="ms-new-subject" autocomplete="off" placeholder="Subject Name (e.g., Urdu, Math)" style="flex:1;min-width:0;">
        <input type="number" id="ms-new-subject-total" autocomplete="off" inputmode="numeric" min="1" value="100" placeholder="Total" title="Total marks" style="width:86px;">
        <button class="btn-ghost" onclick="addMarksSheetSubject()">+ Add</button>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:6px;">
        ${msSubjects.map((s, i) => `
          <div style="background:#F0EBDA;padding:6px 10px;border-radius:6px;font-size:12px;display:flex;align-items:center;gap:6px;">
            ${esc(s)}
            <span style="opacity:.7;">/</span><input type="number" inputmode="numeric" min="1" value="${msSubjectMax(s)}" title="Total marks" style="width:62px;padding:3px 4px;font-size:13px;" onchange="msSubjectTotals[msSubjects[${i}]]=(Number(this.value)>0?Number(this.value):100);saveMarksSheetData();renderTab();">
            <button class="btn-ghost" style="padding:0;font-size:10px;opacity:.6;" onclick="msSubjects.splice(${i},1);saveMarksSheetData();renderTab();">✕</button>
          </div>
        `).join('')}
      </div>
    </div>

    ${msSelectedClass ? `
    <div class="card">
      <h3 style="margin-top:0;">Class: ${esc(msSelectedClass)}</h3>
      <p style="font-size:11px;opacity:.6;">Add students and enter marks</p>
      
      <div style="display:flex;gap:6px;margin-bottom:12px;">
        <input type="text" id="ms-student-input" autocomplete="off" placeholder="Student Name" style="flex:1;">
        <input type="text" id="ms-father-input" autocomplete="off" placeholder="Father Name (optional)" style="flex:1;">
        <button class="btn-ghost" onclick="addMarksSheetStudent()">+ Add Student</button>
      </div>
      
      ${classStudents.length ? tableHtml : '<p style="opacity:.5;text-align:center;padding:20px;">No students yet. Add a student above.</p>'}
      
      ${classStudents.length && msSubjects.length ? `
        <button class="btn-ghost" onclick="printMarksSheet('${msSelectedClass}')">🖨️ Print</button>
        <button class="btn-ghost" onclick="exportMarksSheetExcel('${msSelectedClass}')">📊 Export to Excel</button>
      ` : ''}
    </div>
    ` : ''}
  `;
}

function addMarksSheetClass() {
  const input = document.getElementById('ms-new-class');
  const cls = input.value.trim();
  if (!cls) return;
  if (!msClasses.includes(cls)) {
    msClasses.push(cls);
    msStudents[cls] = [];
    msMarksData[cls] = {};
    msSelectedClass = cls;
  }
  input.value = '';
  saveMarksSheetData();
  renderTab();
}

function removeMarksSheetClass(idx) {
  const cls = msClasses[idx];
  msClasses.splice(idx, 1);
  delete msStudents[cls];
  delete msMarksData[cls];
  if (msSelectedClass === cls) msSelectedClass = msClasses[0] || '';
  saveMarksSheetData();
  renderTab();
}

function addMarksSheetSubject() {
  const input = document.getElementById('ms-new-subject');
  const totalInput = document.getElementById('ms-new-subject-total');
  const subj = input.value.trim();
  if (!subj) return;
  const tot = Number(totalInput && totalInput.value);
  if (!msSubjects.includes(subj)) {
    msSubjects.push(subj);
  }
  msSubjectTotals[subj] = tot > 0 ? tot : 100;
  input.value = '';
  saveMarksSheetData();
  renderTab();
}

function addMarksSheetStudent() {
  const input = document.getElementById('ms-student-input');
  const fatherInput = document.getElementById('ms-father-input');
  const name = input.value.trim();
  const fatherName = fatherInput ? fatherInput.value.trim() : '';
  if (!name || !msSelectedClass) return;
  
  if (!msStudents[msSelectedClass]) msStudents[msSelectedClass] = [];
  if (!msMarksData[msSelectedClass]) msMarksData[msSelectedClass] = {};
  
  const id = Math.random().toString(36).substr(2, 9);
  msStudents[msSelectedClass].push({id, name, fatherName});
  msMarksData[msSelectedClass][id] = {};
  
  input.value = '';
  if (fatherInput) fatherInput.value = '';
  saveMarksSheetData();
  renderTab();
}

function removeMarksSheetStudent(cls, idx) {
  const student = msStudents[cls][idx];
  msStudents[cls].splice(idx, 1);
  delete msMarksData[cls][student.id];
  saveMarksSheetData();
  renderTab();
}

function exportMarksSheetExcel(className) {
  const classStudents = msStudents[className] || [];
  if (!classStudents.length || !msSubjects.length) return;

  const msSum = msSummaryForClass(className);
  const showFather = classStudents.some(st => (st.fatherName || '').trim());
  const rows = classStudents.map((student, si) => {
    const row = { 'Student Name': student.name };
    if (showFather) row['Father Name'] = student.fatherName || '';
    let total = 0;
    msSubjects.forEach(subj => {
      const val = (msMarksData[className] && msMarksData[className][student.id] && msMarksData[className][student.id][subj]) || '';
      row[subj] = val === '' ? '' : Number(val);
      total += Number(val) || 0;
    });
    row['Total'] = total;
    row['Grade'] = msSum[si].grade;
    row['Position'] = msSum[si].pos === null ? '' : msSum[si].pos;
    return row;
  });

  const ws = XLSX.utils.json_to_sheet(rows);
  // Bold header row
  const headerRange = XLSX.utils.decode_range(ws['!ref']);
  for (let c = headerRange.s.c; c <= headerRange.e.c; c++) {
    const addr = XLSX.utils.encode_cell({ r: 0, c });
    if (ws[addr]) ws[addr].s = { font: { bold: true } };
  }
  ws['!cols'] = [{ wch: 24 }, ...(showFather ? [{ wch: 24 }] : []), ...msSubjects.map(() => ({ wch: 12 })), { wch: 10 }, { wch: 8 }, { wch: 10 }];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, className.slice(0, 31) || 'Marks Sheet');

  const schoolPart = (CURRENT_PROFILE?.school_name || 'School').replace(/[^a-zA-Z0-9]/g, '_');
  XLSX.writeFile(wb, `${schoolPart}_MarksSheet_${className}_${fmtDate(todayISO())}.xlsx`, { cellStyles: true });
}

function printMarksSheet(className) {
  const classStudents = msStudents[className] || [];
  const msSum = msSummaryForClass(className);
  const showFather = classStudents.some(st => (st.fatherName || '').trim());
  const printCols = msSubjects.length;
  const printLandscape = printCols > 8;
  // Font picked from the number of columns. table-layout:fixed + width:100%
  // means the table can never be wider than the paper, so the browser never
  // "shrink-to-fits" it (that shrink is what left a big blank gap at the
  // bottom of page 1 while the rest of the students went to page 2).
  const printFont = printCols <= 4 ? 16 : printCols <= 6 ? 15 : printCols <= 8 ? 14 : printCols <= 10 ? 12 : 11;
  // Rows have a FIXED height, so how many fit on a page is exact. Page 1 is
  // filled completely before anything goes to page 2. Usable height is kept
  // slightly under the real A4/Letter value so both paper sizes fit.
  const rowMm = 8;
  const usableMm = printLandscape ? 190 : 260;
  const headMm = 24, theadMm = 10;
  const firstRows = Math.max(1, Math.floor((usableMm - headMm - theadMm) / rowMm));
  const nextRows = Math.max(1, Math.floor((usableMm - theadMm) / rowMm));

  const theadHtml = `
        <thead>
          <tr style="height:${theadMm}mm;">
            <th style="width:${showFather ? 20 : 26}%;">Student Name</th>
            ${showFather ? '<th style="width:20%;">Father Name</th>' : ''}
            ${msSubjects.map(s => `<th>${esc(s)}</th>`).join('')}
            <th style="width:11%;">Total</th>
            <th style="width:7%;">Grade</th>
            <th style="width:9%;">Position</th>
          </tr>
        </thead>`;
  const rowHtml = (student, si) => `
            <tr style="height:${rowMm}mm;">
              <td class="nm">${esc(student.name)}</td>
              ${showFather ? `<td class="nm">${esc(student.fatherName||'—')}</td>` : ''}
              ${msSubjects.map(subj => `<td class="c">${msMarksData[className] && msMarksData[className][student.id] && msMarksData[className][student.id][subj] ? msMarksData[className][student.id][subj] : '—'}</td>`).join('')}
              <td class="c b">${msSum[si].total === null ? '—' : msSum[si].total + '/' + msSum[si].max}</td>
              <td class="c b">${msSum[si].grade || '—'}</td>
              <td class="c b">${msSum[si].pos === null ? '—' : msSum[si].pos}</td>
            </tr>`;

  // Split the students into page-sized chunks.
  const chunks = [];
  let idx = 0;
  while (idx < classStudents.length || chunks.length === 0) {
    const n = chunks.length === 0 ? firstRows : nextRows;
    chunks.push(classStudents.slice(idx, idx + n).map((st, k) => rowHtml(st, idx + k)).join(''));
    idx += n;
    if (idx >= classStudents.length) break;
  }

  const headerHtml = `
      <div class="header">
        <div class="school-name">${esc(CURRENT_PROFILE?.school_name || 'School Name')}</div>
        <div class="class-name">Marks Sheet - ${esc(className)}</div>
      </div>`;
  const pagesHtml = chunks.map((rows, i) => `
      <div class="pg" style="${i < chunks.length - 1 ? 'page-break-after:always;break-after:page;' : ''}">
        ${i === 0 ? headerHtml : ''}
        <table>${theadHtml}
          <tbody>${rows}</tbody>
        </table>
      </div>`).join('');

  let html = `
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <style>
        @page { size: A4 ${printLandscape ? 'landscape' : 'portrait'}; margin: 8mm; }
        * { -webkit-print-color-adjust: exact; print-color-adjust: exact; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; }
        .header { height: ${headMm}mm; text-align: center; border-bottom: 3px solid #0F2740; padding-bottom: 6px; margin-bottom: 4mm; overflow: hidden; }
        .school-name { font-size: ${printFont + 8}px; font-weight: bold; color: #0F2740; }
        .class-name { font-size: ${printFont}px; color: #444; margin-top: 4px; }
        table { width: 100%; table-layout: fixed; border-collapse: collapse; background: white; }
        th { background: #0F2740; color: white; padding: 0 3px; text-align: center; font-weight: bold; font-size: ${printFont - 1}px; border: 1.5px solid #0F2740; overflow: hidden; }
        td { padding: 0 4px; font-size: ${printFont}px; border: 1.5px solid #888; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
        td.nm { text-align: left; }
        td.c { text-align: center; }
        td.b { font-weight: bold; }
        tr { page-break-inside: avoid; break-inside: avoid; }
      </style>
    </head>
    <body>${pagesHtml}
    </body>
    </html>
  `;
  
  const printWindow = window.open('', '', 'height=900,width=1000');
  printWindow.document.write(html);
  printWindow.document.close();
  printWindow.focus();
  setTimeout(() => printWindow.print(), 500);
}

function tplAdmissionRegister() {
  const subnav = `
    <div class="type-filter" style="margin-bottom:12px;">
      <button class="${registerSubTab==='dashboard'?'on':''}" onclick="setRegisterSubTab('dashboard')">${esc(t.registerDashboard)}</button>
      <button class="${registerSubTab==='admitted'?'on':''}" onclick="setRegisterSubTab('admitted')">${esc(t.registerAdmitted)}</button>
      <button class="${registerSubTab==='slc'?'on':''}" onclick="setRegisterSubTab('slc')">${esc(t.registerSlc)}</button>
    </div>`;
  const body = registerSubTab === 'dashboard' ? tplRegisterDashboard() : tplRegisterList();
  return `<div style="padding-top:16px;">
    <div class="reg-book">
      <div class="reg-book-title">${NAV_ICONS.admissionRegister}${esc(t.admissionRegister)}</div>
      ${subnav}${body}
    </div>
  </div>`;
}

function tplRegisterDashboard() {
  const all = DATA.admissionRegister;
  const admittedCount = all.filter(r => !r.withdrawal_date).length;
  const slcCount = all.filter(r => !!r.withdrawal_date).length;
  const totalArrears = all.filter(r => !r.withdrawal_date).reduce((a,b) => a + Number(b.arrears_due||0), 0);
  const allSorted = all.slice().sort((a,b) => Number(a.serial_no||0) - Number(b.serial_no||0));

  return `
    <div class="notice" style="margin-bottom:12px;">${esc(t.admissionRegisterDesc)}</div>
    <div class="stat-grid">
      <div class="stat-card"><div class="lbl">${esc(t.registerAdmitted)}</div><div class="val">${admittedCount}</div></div>
      <div class="stat-card"><div class="lbl">${esc(t.registerSlc)}</div><div class="val">${slcCount}</div></div>
      <div class="stat-card"><div class="lbl">${esc(t.arrearsDue)}</div><div class="val" style="color:var(--rust);font-size:18px;">₨${fmt(totalArrears)}</div></div>
      <div class="stat-card"><div class="lbl">${esc(t.serialNo)} (${esc(t.all)})</div><div class="val">${all.length}</div></div>
    </div>
    <div style="display:flex;align-items:center;justify-content:space-between;margin:20px 0 8px;">
      <div class="section-title" style="margin:0;">${esc(t.admissionRegister)}</div>
      <button class="icon-btn" style="width:34px;height:34px;" onclick="openAddAdmissionEntry()">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#E4C765" stroke-width="2.5"><path d="M12 5v14M5 12h14"/></svg>
      </button>
    </div>
    ${registerLedgerTableHtml(allSorted)}
    ${REGISTER_SELECTED.size > 0 ? `
    <div class="flexgap" style="margin-top:10px;">
      <button class="btn-primary" style="flex:1;background:var(--sage);" onclick="printSelectedAdmissionEntries()">
        🖨️ ${esc(t.printSelected||'Print Selected')} (${REGISTER_SELECTED.size})
      </button>
      <button class="btn-ghost" onclick="clearRegisterSelection()">✕ ${esc(t.clear||'Clear')}</button>
    </div>` : ''}`;
}

// Shared ledger-book table renderer: same column order as the physical bound
// Admission & Withdrawal Register page, so every saved entry appears as a row
// on the same "page" (used by both the Dashboard's full-book view and the
// Admitted/SLC list view) instead of one-at-a-time cards.
function registerLedgerTableHtml(rows) {
  const dobText = r => {
    const parts = [r.dob_words, fmtDate(r.dob_figures)].filter(Boolean);
    return parts.length ? esc(parts.join(' — ')) : '—';
  };
  const headCols = [
    '', t.admissionDate, t.serialNo, t.studentName, t.dobLabel, t.fatherName,
    t.casteTribe, t.occupation, t.residence, t.classAdmitted, t.arrearsDue,
    t.classWithdrawn, t.withdrawalDate, t.remarks, ''
  ];
  const SPINE_AFTER = 5; // after Father's Name column, matching the book's fold

  const dataRow = r => `
    <tr onclick="openEditAdmissionEntry('${r.id}')">
      <td class="act" onclick="event.stopPropagation();"><input type="checkbox" ${REGISTER_SELECTED.has(r.id)?'checked':''} onchange="toggleRegisterSelect('${r.id}')"></td>
      <td>${esc(fmtDate(r.admission_date)||'—')}</td>
      <td>${esc(r.serial_no||'—')}</td>
      <td class="mo">${esc(r.student_name||'—')}</td>
      <td>${dobText(r)}</td>
      <td class="rb-spine">${esc(r.father_name||'—')}</td>
      <td>${esc(r.caste_tribe||'—')}</td>
      <td>${esc(r.occupation||'—')}</td>
      <td>${esc(r.residence||'—')}</td>
      <td>${esc(r.class_admitted||'—')}</td>
      <td class="${Number(r.arrears_due||0) ? 'due' : ''}">${Number(r.arrears_due||0) ? '₨'+fmt(r.arrears_due) : '—'}</td>
      <td>${esc(r.class_withdrawn||'—')}</td>
      <td>${esc(fmtDate(r.withdrawal_date)||'—')}</td>
      <td>${esc(r.remarks||'—')}</td>
      <td class="act">${r.withdrawal_date ? `<span class="print-btn" title="${esc(t.print)}" onclick="event.stopPropagation(); printAdmissionEntry('${r.id}')">🖨️</span>` : ''}<span class="print-btn" title="${esc(t.printCc)}" onclick="event.stopPropagation(); printCharacterCertificate('${r.id}')">📜</span></td>
    </tr>`;

  if (rows.length === 0) return `<div class="empty">${esc(t.noRegisterEntries)}</div>`;
  return `
    <div class="regbook-scroll-track">
      <div class="regbook-scroll-thumb">↔</div>
    </div>
    <div class="regbook-screen-wrap">
      <table class="regbook-screen">
        <thead><tr>${headCols.map((c,i) => `<th${i===SPINE_AFTER?' class="rb-spine"':''}>${esc(c)}</th>`).join('')}</tr></thead>
        <tbody>${rows.map(dataRow).join('')}</tbody>
      </table>
    </div>`;
}

// Single draggable handle (a small drag-to-scroll slider), added as a
// hands-on alternative to dragging the table itself directly — this gives a
// dedicated, always-reliable control even on a device/browser combo where
// the table's own drag-scroll still misbehaves. The handle's width reflects
// how much of the table is visible, and its position mirrors scroll
// progress; dragging it (mouse or touch) drives the table's scrollLeft.
function initRegBookSliders() {
  document.querySelectorAll('.regbook-scroll-track').forEach(track => {
    const wrap = track.nextElementSibling;
    const thumb = track.querySelector('.regbook-scroll-thumb');
    if (!wrap || !thumb || !wrap.classList.contains('regbook-screen-wrap')) return;

    const sync = () => {
      const trackW = track.clientWidth;
      const maxScroll = wrap.scrollWidth - wrap.clientWidth;
      if (maxScroll <= 0) { thumb.style.width = trackW + 'px'; thumb.style.left = '0px'; return; }
      const thumbW = Math.max(40, trackW * (wrap.clientWidth / wrap.scrollWidth));
      const maxThumbLeft = trackW - thumbW;
      const ratio = wrap.scrollLeft / maxScroll;
      thumb.style.width = thumbW + 'px';
      thumb.style.left = (ratio * maxThumbLeft) + 'px';
    };
    sync();
    if (!wrap._sliderScrollBound) { wrap._sliderScrollBound = true; wrap.addEventListener('scroll', sync); }
    if (thumb._dragBound) return; // don't double-bind on re-render
    thumb._dragBound = true;

    const startDrag = (clientX) => ({
      startX: clientX, startThumbLeft: thumb.offsetLeft,
      maxThumbLeft: track.clientWidth - thumb.offsetWidth,
      maxScroll: wrap.scrollWidth - wrap.clientWidth
    });
    const moveDrag = (state, clientX) => {
      if (!state || state.maxThumbLeft <= 0) return;
      const dx = clientX - state.startX;
      const newLeft = Math.min(state.maxThumbLeft, Math.max(0, state.startThumbLeft + dx));
      thumb.style.left = newLeft + 'px';
      wrap.scrollLeft = (newLeft / state.maxThumbLeft) * state.maxScroll;
    };

    let pState = null, pPointerId = null;
    thumb.addEventListener('pointerdown', (e) => {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      pPointerId = e.pointerId;
      pState = startDrag(e.clientX);
      try { thumb.setPointerCapture(pPointerId); } catch (err) {}
    });
    thumb.addEventListener('pointermove', (e) => {
      if (pState === null || e.pointerId !== pPointerId) return;
      e.preventDefault();
      moveDrag(pState, e.clientX);
    });
    const endThumbDrag = (e) => {
      if (e.pointerId !== pPointerId) return;
      pState = null;
      try { thumb.releasePointerCapture(pPointerId); } catch (err) {}
    };
    thumb.addEventListener('pointerup', endThumbDrag);
    thumb.addEventListener('pointercancel', endThumbDrag);
  });
}

// Manual drag-scroll fallback for the ledger-book table(s) — both the
// read-only list view and the wide input-form table inside the Add/Edit
// modal use the same .regbook-screen-wrap class. Native overflow-x:auto +
// touch scrolling on this element was not engaging on some devices/WebViews
// (Pointer Events alone did not fix it either), so this drives scrollLeft
// directly from raw touch/mouse movement instead of relying on the
// browser's own touch-scroll handling for this element. Direction is
// detected on the first few pixels of movement: a mostly-vertical drag is
// left alone so the page still scrolls normally; only a mostly-horizontal
// drag is taken over and animated via scrollLeft. Purely additive — mouse
// wheel/shift-scroll and any already-working native scroll are untouched.
// Batches manual vertical scrolling (used below while a horizontal-scroll
// table is being drag-panned) into once-per-animation-frame instead of
// calling window.scrollBy() synchronously on every single touchmove event
// (which can fire 60+ times/sec) — that per-event call was the cause of the
// vertical scroll feeling jerky/stuttery ("atak atak kar") instead of
// smooth. Multiple touchmove deltas arriving within the same frame are
// summed and applied together.
let _regBookScrollRAF = null;
let _regBookPendingDY = 0;
function _regBookFlushVerticalScroll() {
  _regBookScrollRAF = null;
  if (_regBookPendingDY !== 0) {
    window.scrollBy(0, _regBookPendingDY);
    _regBookPendingDY = 0;
  }
}

// Drag-to-scroll for the ledger tables, built on Pointer Events instead of
// separate touch + mouse handlers. Touch and mouse used to be handled by two
// completely independent listener sets on the same element; some Android
// WebViews then replay a finished touch drag as a synthetic "ghost" mouse
// sequence (mousedown -> mousemove -> mouseup), sometimes over a second
// later, which re-ran a *second* independent drag on top of the
// already-touch-scrolled table — that's what looked like the table
// "scrolling correctly, then snapping back to the start" a moment later.
// Pointer Events collapse touch/mouse/pen into a single event stream (each
// physical interaction fires pointerdown/move/up exactly once, regardless of
// input type), so that whole class of duplicate-drag bug can't occur.
// setPointerCapture also pins all subsequent events for this interaction to
// this element even if the finger drifts, which is more reliable than raw
// touch events against a browser's own edge/back-swipe gesture recognizer.
// Root cause of "scroll ho jata hai lekin wapas ajata hai" (scrolls, then
// snaps straight back): on a weak/flaky mobile connection, the browser's
// 'online' event (or a background sync finishing) can fire literally while
// the user is mid-drag. That redraw is correctly *deferred* while
// _regBookDragActive is true (see safeRenderTab above) — but the moment the
// drag ends, that deferred redraw fires immediately (pendingRenderOnDragEnd),
// which tears down and rebuilds the table from scratch. A freshly rebuilt
// .regbook-screen-wrap/.reg-drag-wrap always starts at scrollLeft 0, so the
// horizontal position the user just dragged to is thrown away right as they
// let go — looks exactly like "scrolls, then snaps back", in either
// direction, every time a redraw happens to land right after a drag.
// Capturing scrollLeft immediately before any renderTab() rebuild and
// re-applying it right after the table (and its drag-scroll bindings) are
// rebuilt keeps the user's scroll position through any redraw, deferred or not.
let _regBookScrollPositions = {};
function _regBookCaptureScroll() {
  document.querySelectorAll('.regbook-screen-wrap, .reg-drag-wrap, .tt-scroll-wrap, .ms-scroll-wrap').forEach((wrap, i) => {
    _regBookScrollPositions[wrap.className + '_' + i] = wrap.scrollLeft;
  });
}
function _regBookRestoreScroll() {
  document.querySelectorAll('.regbook-screen-wrap, .reg-drag-wrap, .tt-scroll-wrap, .ms-scroll-wrap').forEach((wrap, i) => {
    const key = wrap.className + '_' + i;
    if (_regBookScrollPositions[key]) wrap.scrollLeft = _regBookScrollPositions[key];
  });
}

function initRegBookScroll() {
  document.querySelectorAll('.regbook-screen-wrap, .reg-drag-wrap').forEach(wrap => {
    if (wrap._dragScrollBound) return; // don't double-bind on re-render
    wrap._dragScrollBound = true;

    let active = false, pointerId = null, moved = false;
    let startX = 0, startY = 0, lastX = 0, lastY = 0;
    const THRESH = 6;

    wrap.addEventListener('pointerdown', (e) => {
      const tag = (e.target && e.target.tagName) || '';
      if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') return; // let normal focus/click happen on editable cells
      if (e.pointerType === 'mouse' && e.button !== 0) return; // only primary mouse button
      active = true; moved = false; pointerId = e.pointerId;
      _regBookDragActive = true;
      startX = lastX = e.clientX; startY = lastY = e.clientY;
      try { wrap.setPointerCapture(pointerId); } catch (err) {}
      wrap.classList.add('rb-dragging');
    });

    wrap.addEventListener('pointermove', (e) => {
      if (!active || e.pointerId !== pointerId) return;
      const totalDX = e.clientX - startX, totalDY = e.clientY - startY;
      if (!moved && Math.abs(totalDX) < THRESH && Math.abs(totalDY) < THRESH) return;
      // Both axes are driven every frame from the raw pointer delta since the
      // *previous* move, instead of picking one axis up front from the first
      // couple of pixels and locking to it for the whole drag — a swipe that
      // starts even slightly diagonal (very common) used to get stuck reading
      // as "vertical" for its entire duration, so horizontal drag looked
      // completely dead no matter how far left/right the finger kept moving.
      e.preventDefault();
      moved = true;
      const dx = e.clientX - lastX, dy = e.clientY - lastY;
      lastX = e.clientX; lastY = e.clientY;
      // Whichever axis moved more THIS frame wins; the smaller one is dropped
      // rather than also applied, so a mostly-horizontal swipe never leaks
      // into a page-wide vertical shift (and vice versa for a real vertical
      // swipe started on the table).
      if (Math.abs(dx) >= Math.abs(dy)) {
        wrap.scrollLeft -= dx;
      } else {
        _regBookPendingDY += -dy; // manual vertical scroll since native pan is disabled here (touch-action:none)
        if (_regBookScrollRAF === null) _regBookScrollRAF = requestAnimationFrame(_regBookFlushVerticalScroll);
      }
    });

    const endDrag = (e) => {
      if (!active || e.pointerId !== pointerId) return;
      active = false;
      _regBookDragActive = false;
      if (pendingRenderOnDragEnd) {
        pendingRenderOnDragEnd = false;
        // Let the drag/click handling below finish first, then redraw with
        // whatever data arrived while the redraw was held off.
        setTimeout(() => { if (TAB) renderTab(); }, 0);
      }
      wrap.classList.remove('rb-dragging');
      try { wrap.releasePointerCapture(pointerId); } catch (err) {}
      // Swallow the click that follows a real drag so it doesn't fall through
      // to an attendance/row cell underneath and toggle it — that accidental
      // toggle used to trigger a re-render that reset scrollLeft to 0, which
      // is what made the table look like it randomly snapped back mid-scroll.
      if (moved) wrap.addEventListener('click', (ev) => ev.stopPropagation(), { once: true, capture: true });
    };
    wrap.addEventListener('pointerup', endDrag);
    wrap.addEventListener('pointercancel', endDrag);
  });
  initRegBookSliders();
}

function tplRegisterList() {
  const full = filteredRegisterList();
  const totalPages = Math.max(1, Math.ceil(full.length / REGISTER_PAGE_SIZE));
  if (registerPage > totalPages) registerPage = totalPages;
  const start = (registerPage - 1) * REGISTER_PAGE_SIZE;
  const list = full.slice(start, start + REGISTER_PAGE_SIZE);

  const pager = full.length === 0 ? '' : `
    <div class="flexgap" style="align-items:center;margin-top:12px;">
      <button class="btn-ghost" ${registerPage<=1?'disabled':''} onclick="setRegisterPage(${registerPage-1})">‹ ${esc(t.previous||'Prev')}</button>
      <span style="font-size:12px;opacity:.65;white-space:nowrap;">${registerPage} / ${totalPages}</span>
      <button class="btn-ghost" ${registerPage>=totalPages?'disabled':''} onclick="setRegisterPage(${registerPage+1})">${esc(t.next||'Next')} ›</button>
    </div>
    <button class="btn-primary" style="width:100%;margin-top:10px;" onclick="printAdmissionRegisterPage(${registerPage})">
      🖨️ ${esc(t.printThisPage||'Print this page')} (${list.length})
    </button>
    ${REGISTER_SELECTED.size > 0 ? `
    <div class="flexgap" style="margin-top:10px;">
      <button class="btn-primary" style="flex:1;background:var(--sage);" onclick="printSelectedAdmissionEntries()">
        🖨️ ${esc(t.printSelected||'Print Selected')} (${REGISTER_SELECTED.size})
      </button>
      <button class="btn-ghost" onclick="clearRegisterSelection()">✕ ${esc(t.clear||'Clear')}</button>
    </div>` : ''}`;

  return `
    <div class="searchbar">
      <input id="register-search-input" placeholder="${esc(t.searchRegister)}" value="${esc(registerSearch)}" oninput="setRegisterSearch(this.value)">
      <button class="icon-btn" title="${esc(t.searchRegister)}" onclick="setRegisterSearch(document.getElementById('register-search-input').value)">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#E4C765" stroke-width="2.5"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.35-4.35"/></svg>
      </button>
      ${registerSearch.trim() && full.length===1 ? `<button class="icon-btn" title="${esc(t.print)}" onclick="printSingleAdmissionEntry('${full[0].id}')">🖨️</button>` : ''}
      <button class="icon-btn" onclick="openAddAdmissionEntry()">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#E4C765" stroke-width="2.5"><path d="M12 5v14M5 12h14"/></svg>
      </button>
    </div>
    ${registerLedgerTableHtml(list)}${list.length ? pager : ''}`;
}

// Prints one page (up to 30 rows) of the register as a single ledger-style table,
// matching the columns/layout of the physical Admission & Withdrawal Register book.
function printAdmissionRegisterPage(page) {
  const full = filteredRegisterList();
  const start = (page - 1) * REGISTER_PAGE_SIZE;
  const rows = full.slice(start, start + REGISTER_PAGE_SIZE);
  if (rows.length === 0) return;
  printAdmissionEntriesLedger(rows, `Page ${page}`, true);
}

// Prints exactly the rows the user has ticked in the Admission Register, in any
// combination and regardless of which search/page they were checked on — sorted
// by serial number so the printed sheet still reads in register order.
function printSelectedAdmissionEntries() {
  if (REGISTER_SELECTED.size === 0) return;
  const rows = DATA.admissionRegister
    .filter(r => REGISTER_SELECTED.has(r.id))
    .sort((a,b) => Number(a.serial_no||0) - Number(b.serial_no||0));
  if (rows.length === 0) return;
  printAdmissionEntriesLedger(rows, `${t.printSelected||'Selected'} (${rows.length})`, false);
}

// Shared ledger-style print builder used by both the page print and the
// selected-rows print. padToPageSize adds blank ruled rows up to
// REGISTER_PAGE_SIZE (matching the physical book's page), which only makes
// sense for a single register page — a selected-rows printout is left
// unpadded since it isn't one physical page.
function printAdmissionEntriesLedger(rows, subtitle, padToPageSize) {
  const headCols = [
    t.admissionDate, t.serialNo, t.studentName, t.dobLabel, t.fatherName,
    t.casteTribe, t.occupation, t.residence, t.classAdmitted, t.arrearsDue,
    t.classWithdrawn, t.withdrawalDate, t.remarks
  ];
  const SPINE_AFTER = 5; // book fold falls after Father's Name (5th column)
  const headerHtml = headCols.map((c,i) => `<th${i===SPINE_AFTER?' class="rb-spine"':''}>${esc(c)}</th>`).join('');

  const dobText = r => {
    const parts = [fmtDate(r.dob_figures), r.dob_words].filter(Boolean);
    return parts.length ? esc(parts.join(' — ')) : '—';
  };
  const dataRow = r => `
    <tr>
      <td>${esc(fmtDate(r.admission_date)||'—')}</td>
      <td>${esc(r.serial_no||'—')}</td>
      <td>${esc(r.student_name||'—')}</td>
      <td>${dobText(r)}</td>
      <td>${esc(r.father_name||'—')}</td>
      <td class="rb-spine">${esc(r.caste_tribe||'—')}</td>
      <td>${esc(r.occupation||'—')}</td>
      <td>${esc(r.residence||'—')}</td>
      <td>${esc(r.class_admitted||'—')}</td>
      <td>${Number(r.arrears_due||0) ? '₨'+fmt(r.arrears_due) : '—'}</td>
      <td>${esc(r.class_withdrawn||'—')}</td>
      <td>${esc(fmtDate(r.withdrawal_date)||'—')}</td>
      <td>${esc(r.remarks||'—')}</td>
    </tr>`;
  const blankRow = `<tr>${headCols.map((_,i)=>`<td${i===SPINE_AFTER?' class="rb-spine"':''}>&nbsp;</td>`).join('')}</tr>`;
  const bodyRows = rows.map(dataRow).join('') + (padToPageSize ? blankRow.repeat(Math.max(0, REGISTER_PAGE_SIZE - rows.length)) : '');

  document.getElementById('print-area').innerHTML = `
    <div class="regbook-print">
      <div class="rb-head">
        <h2>${esc(t.admissionRegister)}</h2>
        <span class="rb-of">${LANG==='ur' ? 'کے' : 'of the'}</span>
        <span class="rb-school">${esc(CURRENT_PROFILE.school_name || 'School')}</span>
      </div>
      <div class="rb-meta">${esc(subtitle)} &nbsp;·&nbsp; ${esc(fmtDate(todayISO()))}</div>
      <table>
        <thead><tr>${headerHtml}</tr></thead>
        <tbody>${bodyRows}</tbody>
      </table>
      <div class="foot">
        <div class="note">Note: The age entries should be recorded in words and figures, and any change in sub entries should be attested.</div>
        <div class="sign">${esc(t.headOfInstitution || 'Head of the Institution')}</div>
      </div>
    </div>`;
  printWithOrientation('landscape');
}

