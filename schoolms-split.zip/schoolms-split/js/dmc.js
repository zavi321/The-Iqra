/* SchoolMS — dmc.js — split from index.html (lines 8452-9461). Load order matters: see index.html */
// --------- DMC (Detail Marks Certificate) Generator ---------
let dmcResults = []; // temporary storage for uploaded results
let certLogCache = null; // cache of recently-issued certificates (DMC / SLC / Character Certificate)

// Records that a certificate was issued (fire-and-forget — a logging failure
// should never block the actual print). Shared by DMC, SLC, and Character
// Certificate print flows so all three show up in one combined history.
async function logCertificateIssued(certType, studentName, className, refId) {
  try {
    await sb.from('certificate_log').insert({
      owner_id: CURRENT_USER.id, cert_type: certType,
      student_name: studentName || null, class_name: className || null, ref_id: refId || null
    });
  } catch (e) { /* non-critical */ }
}
async function loadCertificateLog() {
  const { data, error } = await sb.from('certificate_log').select('*')
    .eq('owner_id', CURRENT_USER.id).order('issued_at', { ascending: false }).limit(30);
  if (!error) certLogCache = data || [];
}
let dmcLogo = null; // base64 logo image
let dmcSchoolName = 'SCHOOL NAME'; // editable school name for certificates
let dmcTagline = ''; // optional motto shown under the school name
let dmcAcademicSession = ''; // optional e.g. "2025-2026"
let dmcQuote = ''; // optional footer quote — falls back to a language-appropriate default at print time if left blank
let dmcBatchSection = ''; // shared section for this batch, applied to all certificates
let dmcBatchDateOfIssue = todayISO(); // shared date of issue for this batch, applied to all certificates
let dmcSelectedClass = ''; // persisted copy of the "Select Class" dropdown value, so a background
                            // re-render (e.g. once loadDMCConfig() resolves) doesn't reset it to blank
let dmcLastUploadMsg = ''; // persisted copy of the "Loaded N students" / error message shown after
                            // an Excel upload, so a background re-render doesn't make it disappear

// Editable certificate colors (the layout itself is fixed — only the colors
// are customizable per school).
let dmcDesign = {
  certTitle: 'DETAIL MARKS CERTIFICATE',
  primaryColor: '#0F2740', // navy — header banner, table header, borders
  accentColor: '#0F2740',  // navy — border trim, session pill, accents
  bgColor: '#FAF6EC',      // cream — certificate background
  bgImage: '',             // optional background picture (data URL); '' = none
  bgImageOpacity: 0.25,    // 0.05 - 1
  bgImageFit: 'cover',     // 'cover' | 'contain'
  showPosition: true,      // "Position in class" summary block
  showStamp: true,         // dashed "SCHOOL STAMP" circle in footer
  teacherLabel: 'CLASS TEACHER SIGNATURE',
  principalLabel: 'PRINCIPAL SIGNATURE'
};

// Lighten a #rrggbb hex color by `pct` (0-1) toward white — used to derive the
// soft highlight shade (e.g. table's TOTAL row) from just the one accent color
// the school picks, instead of needing a second color input for it.
function lightenColor(hex, pct) {
  const h = (hex || '#C9A227').replace('#', '');
  const num = parseInt(h.length === 3 ? h.split('').map(c => c + c).join('') : h, 16);
  const r = (num >> 16) & 255, g = (num >> 8) & 255, b = num & 255;
  const mix = c => Math.round(c + (255 - c) * pct);
  return `#${[mix(r), mix(g), mix(b)].map(v => v.toString(16).padStart(2, '0')).join('')}`;
}

function tplDMC() {
  return `
    <h2>📜 Detail Marks Certificate (DMC)</h2>

    <div class="card">
      <h3 style="margin-top:0;">School Configuration for DMC</h3>
      <p style="font-size:11px;opacity:.6;">Set your school logo and name for certificates. The certificate's background and accent (trim) colors are generated automatically to match your logo.</p>
      
      <label>
        <span>School Logo (Upload Image)</span>
        <input type="file" id="dmc-logo-input" accept="image/*" onchange="handleDMCLogoUpload(this.files[0])">
      </label>
      <div id="dmc-logo-preview">${dmcLogoPreviewHtml()}</div>
      <p style="font-size:11px;opacity:.6;margin-top:-4px;">The certificate's background and trim colors are generated automatically from your logo's own colors.</p>

      <label>
        <span>School Name (for DMC)</span>
        <input type="text" id="dmc-school-name" autocomplete="off" value="${esc(dmcSchoolName)}" placeholder="e.g., ISLAMIA SCHOOL & COLLEGE MARTUNG" onchange="dmcSchoolName=this.value; saveDMCConfig();">
      </label>
      <label>
        <span>Tagline (optional)</span>
        <input type="text" id="dmc-tagline" autocomplete="off" value="${esc(dmcTagline)}" placeholder="e.g., Nurturing Knowledge, Building Character" onchange="dmcTagline=this.value; saveDMCConfig();">
      </label>
      <label>
        <span>Academic Session (optional)</span>
        <input type="text" id="dmc-session" autocomplete="off" value="${esc(dmcAcademicSession)}" placeholder="e.g., 2025-2026" onchange="dmcAcademicSession=this.value; saveDMCConfig();">
      </label>
      <label style="margin-bottom:0;">
        <span>Footer Quote (optional)</span>
        <input type="text" id="dmc-quote" autocomplete="off" value="${esc(dmcQuote)}" placeholder="e.g., Education is the key to a bright future." onchange="dmcQuote=this.value; saveDMCConfig();">
      </label>
    </div>

    <div class="card">
      <h3 style="margin-top:0;">Class</h3>
      <p style="font-size:12px;opacity:.7;">Select which class this batch of certificates is for. This is used for every certificate in this upload — unless the Excel file itself has its own "Class" column, in which case that overrides it per row.</p>
      <div style="margin-bottom:0;">
        <label for="dmc-class" style="display:block;font-size:12px;font-weight:500;opacity:.7;margin-bottom:4px;">Class</label>
        <input type="text" id="dmc-class" autocomplete="off" value="${esc(dmcSelectedClass)}" placeholder="e.g., 5th" oninput="selectDMCClass(this.value)">
      </div>
    </div>

    <div class="card">
      <h3 style="margin-top:0;">Upload Result List (Excel)</h3>
      <p style="font-size:12px;opacity:.7;">Upload an Excel file with columns: Student Name, Father Name, Roll No, Section, Subject1 Marks, Subject2 Marks, etc. (A "Class" column is optional if you've selected a class above.)</p>
      <label style="margin-bottom:0;">
        <span>Select Excel File</span>
        <input type="file" id="dmc-file-input" accept=".xlsx,.xls,.csv" onchange="handleDMCExcelUpload(this.files[0])">
      </label>
      <div id="dmc-upload-msg" style="margin-top:8px;font-size:12px;">${dmcLastUploadMsg}</div>
    </div>

    <div class="card">
      <h3 style="margin-top:0;">Section & Date of Issue</h3>
      <p style="font-size:12px;opacity:.7;">These apply to every certificate in this batch.</p>
      <label>
        <span>Section</span>
        <input type="text" id="dmc-batch-section" autocomplete="off" value="${esc(dmcBatchSection)}" placeholder="e.g., A" onchange="dmcBatchSection=this.value;">
      </label>
      <label style="margin-bottom:0;">
        <span>Date of Issue</span>
        <input type="date" id="dmc-batch-date" value="${esc(dmcBatchDateOfIssue || todayISO())}" onchange="dmcBatchDateOfIssue=this.value;">
      </label>
    </div>

    <div class="card">
      <h3 style="margin-top:0;">Certificate Background <span style="font-size:12px;font-weight:400;opacity:.6;">(optional)</span></h3>
      <div id="dmc-bg-box">${dmcBgBoxHtml()}</div>
    </div>

    <div class="card">
      <h3 style="margin-top:0;">Subjects & Total Marks</h3>
      <p style="font-size:12px;opacity:.7;">Har subject ke saath uske total marks likhein. Naya subject yahin se add kar sakte hain, aur Excel se aaye subjects ke total marks bhi badal sakte hain.</p>
      <div id="dmc-subjects-box"></div>
    </div>

    <div class="card">
      <h3 style="margin-top:0;">Review & Edit Students</h3>
      <p style="font-size:12px;opacity:.7;">Print se pehle har student ka Name, Roll No. ya marks theek karein. Jo Excel mein nahi tha ya ghalat aaya, yahin sahi ho jayega.</p>
      <div id="dmc-edit-table"></div>
    </div>

    <div class="card">
      <h3 style="margin-top:0;">Preview & Generate DMC</h3>
      <div id="dmc-preview"></div>
      <div style="margin-top:12px;display:flex;gap:6px;">
        <button class="btn-ghost" onclick="generateDMCPreview()">Preview Certificates</button>
        <button class="btn-ghost" onclick="printAllDMC()">Print All</button>
      </div>
    </div>
  `;
}

function selectDMCClass(cls) {
  dmcSelectedClass = cls;
  // If results are already loaded and their rows have no per-row class of
  // their own (i.e. the Excel file didn't specify one), keep them in sync.
  dmcResults.forEach(r => { if (!r.classFromExcel) r.class = cls; });
}

let dmcSubjects = []; // {name: 'Urdu', total: 100}
let dmcConfigLoaded = false;

function dmcLogoPreviewHtml() {
  return dmcLogo ? `<div style="margin-bottom:12px;"><img src="${dmcLogo}" style="max-height:80px;max-width:150px;border-radius:4px;"></div>` : '';
}

// Pushes the current dmcSchoolName/dmcTagline/etc. globals into the already-
// rendered DMC tab's DOM, field by field, instead of tearing the whole tab
// down and rebuilding it. Used once loadDMCConfig() resolves, so a config
// arriving late over the network can never race a tap-to-focus on one of
// these fields (which a full main.innerHTML rebuild used to do — see the
// comment at the call site in renderTab()). Any field the user is currently
// typing into is left alone so their in-progress edit is never overwritten.
function applyDMCConfigToFields() {
  const setIfNotFocused = (id, val) => {
    const el = document.getElementById(id);
    if (el && document.activeElement !== el) el.value = val;
  };
  setIfNotFocused('dmc-school-name', dmcSchoolName);
  setIfNotFocused('dmc-tagline', dmcTagline);
  setIfNotFocused('dmc-session', dmcAcademicSession);
  setIfNotFocused('dmc-quote', dmcQuote);
  const logoBox = document.getElementById('dmc-logo-preview');
  if (logoBox) logoBox.innerHTML = dmcLogoPreviewHtml();
}

// Applies a loaded DMC config object (from Supabase or the offline cache)
// onto the in-memory settings used by the certificate generator.
function applyDMCConfig(data) {
  if (!data) return;
  if (data.subjects) dmcSubjects = data.subjects;
  if (data.school_name) dmcSchoolName = data.school_name;
  if (data.logo) dmcLogo = data.logo;
  if (data.tagline) dmcTagline = data.tagline;
  if (data.academic_session) dmcAcademicSession = data.academic_session;
  if (data.quote) dmcQuote = data.quote;
  // Merge onto the defaults rather than replacing, so a school that saved
  // their design before a new toggle was added still gets that toggle's
  // default instead of `undefined`.
  if (data.design) dmcDesign = { ...dmcDesign, ...data.design };
}

async function loadDMCConfig() {
  if (dmcConfigLoaded) return;
  // No signal at all — skip straight to the local cache so the Certificates
  // tab still comes up with the school's logo/name/subjects, and certificates
  // can be generated and printed with zero internet.
  if (!navigator.onLine) {
    const cached = await idbGetAll('dmc_config');
    applyDMCConfig(cached[0]);
    return; // not marked "loaded" — will fetch properly once back online
  }
  const { data, error } = await withTimeout(
    sb.from('dmc_config').select('*').eq('owner_id', CURRENT_USER.id).maybeSingle()
  );
  if (error) {
    // Network hiccup — fall back to whatever was cached from the last
    // successful load instead of leaving the certificate blank.
    const cached = await idbGetAll('dmc_config');
    applyDMCConfig(cached[0]);
    return;
  }
  dmcConfigLoaded = true;
  if (!data) return;
  applyDMCConfig(data);
  await idbPutRow('dmc_config', { id: 'main', ...data });
}

// Snapshots the currently-uploaded DMC batch (student rows + marks + which
// class/section/date it's for) to IndexedDB, so it survives a page reload or
// opening the app with no signal — mirrors the same on-demand cache pattern
// as dmc_config, just for the upload itself instead of the school's settings.
async function saveDMCUpload() {
  await idbPutRow('dmc_upload', {
    id: 'main', results: dmcResults, selectedClass: dmcSelectedClass,
    section: dmcBatchSection, dateOfIssue: dmcBatchDateOfIssue
  });
}
// Restores the last-cached DMC batch when the tab opens with nothing in
// memory yet (fresh reload) — so offline (or a slow/flaky connection) still
// shows the previously uploaded results instead of an empty upload screen.
async function restoreDMCUploadIfEmpty() {
  if (dmcResults.length) return;
  const cached = await idbGetAll('dmc_upload');
  const row = cached[0];
  if (!row || !row.results || !row.results.length) return;
  dmcResults = row.results;
  dmcSelectedClass = row.selectedClass || '';
  dmcBatchSection = row.section || '';
  dmcBatchDateOfIssue = row.dateOfIssue || '';
  renderDMCEditTable();
  const clsSel = document.getElementById('dmc-class-select');
  if (clsSel) clsSel.value = dmcSelectedClass;
  const msgEl = document.getElementById('dmc-upload-msg');
  if (msgEl) msgEl.innerHTML = `✓ Loaded ${dmcResults.length} students (from last saved upload)`;
}

async function saveDMCConfig() {
  const payload = {
    owner_id: CURRENT_USER.id, subjects: dmcSubjects, school_name: dmcSchoolName, logo: dmcLogo,
    tagline: dmcTagline, academic_session: dmcAcademicSession, quote: dmcQuote, design: dmcDesign,
    updated_at: new Date().toISOString()
  };
  // Cache locally right away — so certificates use the latest settings even
  // if the device goes offline before this reaches the server.
  await idbPutRow('dmc_config', { id: 'main', ...payload });
  const { error } = await sb.from('dmc_config').upsert(payload);
  if (error && !isNetworkError(error)) console.error('DMC config save failed:', error.message);
}

// Re-renders the (already-generated) certificate preview after a design
// tweak, so a school editing colors/labels sees the result immediately
// instead of having to click "Preview Certificates" again.
function renderDMCPreviewIfOpen() {
  if (dmcResults.length > 0 && document.getElementById('dmc-preview')) generateDMCPreview();
}

// ---- Certificate Background (optional picture + colour, all editable) ----
function dmcBgBoxHtml() {
  const d = dmcDesign;
  const has = !!d.bgImage;
  const op = Math.round((d.bgImageOpacity == null ? 0.25 : d.bgImageOpacity) * 100);
  return `
    <label style="display:block;margin-bottom:10px;">
      <span style="display:block;font-size:12px;font-weight:500;opacity:.7;margin-bottom:4px;">Background picture (optional)</span>
      <input type="file" accept="image/*" onchange="handleDMCBgUpload(this.files[0])">
    </label>
    ${has ? `
      <div style="margin-bottom:10px;"><img src="${d.bgImage}" style="max-height:90px;max-width:100%;border-radius:6px;border:1px solid var(--line);"></div>
      <label style="display:block;margin-bottom:10px;font-size:12px;">
        <span style="opacity:.7;">Picture ki dhundhlahat (opacity): <b id="dmc-bg-op-val">${op}%</b></span>
        <input type="range" min="5" max="100" value="${op}" style="width:100%;" oninput="setDMCBgOpacity(this.value)">
      </label>
      <label style="display:block;margin-bottom:10px;font-size:12px;">
        <span style="opacity:.7;">Picture ka size</span>
        <select onchange="setDMCBgFit(this.value)">
          <option value="cover" ${d.bgImageFit !== 'contain' ? 'selected' : ''}>Poora certificate dhake (cover)</option>
          <option value="contain" ${d.bgImageFit === 'contain' ? 'selected' : ''}>Beech mein, poori picture (contain)</option>
        </select>
      </label>
      <button class="btn-ghost" onclick="removeDMCBg()">✕ Picture hatayein</button>
    ` : '<p style="font-size:12px;opacity:.55;margin:0 0 10px;">Abhi koi background picture nahi lagi. Certificate sirf rang ke saath print hoga.</p>'}
    <label style="display:flex;align-items:center;gap:10px;margin-top:12px;font-size:12px;">
      <span style="opacity:.7;">Background ka rang</span>
      <input type="color" value="${esc(d.bgColor || '#FAF6EC')}" onchange="setDMCBgColor(this.value)" style="width:48px;height:32px;padding:0;">
    </label>`;
}
function refreshDMCBgBox() {
  const box = document.getElementById('dmc-bg-box');
  if (box) box.innerHTML = dmcBgBoxHtml();
}
function handleDMCBgUpload(file) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    // Shrink big photos first so the saved settings stay small.
    const img = new Image();
    img.onload = () => {
      const max = 1400;
      const k = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      dmcDesign.bgImage = c.toDataURL('image/jpeg', 0.82);
      saveDMCConfig();
      refreshDMCBgBox();
      renderDMCPreviewIfOpen();
    };
    img.onerror = () => alert('Yeh picture khul nahi saki, doosri try karein');
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
}
function setDMCBgOpacity(v) {
  dmcDesign.bgImageOpacity = Math.min(1, Math.max(0.05, Number(v) / 100));
  const el = document.getElementById('dmc-bg-op-val'); if (el) el.textContent = Math.round(v) + '%';
  saveDMCConfig();
  renderDMCPreviewIfOpen();
}
function setDMCBgFit(v) {
  dmcDesign.bgImageFit = v === 'contain' ? 'contain' : 'cover';
  saveDMCConfig();
  renderDMCPreviewIfOpen();
}
function setDMCBgColor(v) {
  dmcDesign.bgColor = v;
  saveDMCConfig();
  renderDMCPreviewIfOpen();
}
function removeDMCBg() {
  dmcDesign.bgImage = '';
  saveDMCConfig();
  refreshDMCBgBox();
  renderDMCPreviewIfOpen();
}

// ---- Subjects & Total Marks (manual add / edit / remove) ----
function renderDMCSubjects() {
  const box = document.getElementById('dmc-subjects-box');
  if (!box) return;
  const a = document.activeElement;
  if (a && box.contains(a) && (a.tagName === 'INPUT')) return; // never rebuild while typing
  const rows = dmcSubjects.map((sub, j) => `
    <div style="display:flex;align-items:center;gap:8px;border-bottom:1px solid var(--line);padding:8px 0;">
      <input type="text" autocomplete="off" style="flex:1;min-width:0;" value="${esc(sub.name)}" placeholder="Subject" onchange="renameDMCSubject(${j}, this.value)">
      <input type="number" inputmode="numeric" min="1" style="width:80px;flex-shrink:0;" value="${esc(sub.total)}" placeholder="Total" onchange="updateDMCSubjectTotal(${j}, this.value)">
      <button class="btn-ghost" style="flex-shrink:0;" onclick="removeDMCSubject(${j})">✕</button>
    </div>`).join('');
  box.innerHTML = (rows || '<p style="font-size:12px;opacity:.5;">Abhi koi subject nahi hai. Neeche se add karein ya Excel upload karein.</p>') + `
    <div style="display:flex;align-items:center;gap:8px;margin-top:12px;">
      <input type="text" id="dmc-new-subj-name" autocomplete="off" style="flex:1;min-width:0;" placeholder="Subject name">
      <input type="number" id="dmc-new-subj-total" inputmode="numeric" min="1" style="width:80px;flex-shrink:0;" placeholder="Total">
      <button class="btn-ghost" style="flex-shrink:0;" onclick="addDMCSubject()">+ Add</button>
    </div>`;
}
function dmcSubjectsChanged() {
  saveDMCConfig();
  saveDMCUpload();
  renderDMCEditTable();
  renderDMCPreviewIfOpen();
}
function addDMCSubject() {
  const nameEl = document.getElementById('dmc-new-subj-name');
  const totalEl = document.getElementById('dmc-new-subj-total');
  const name = (nameEl.value || '').trim();
  const total = Number(totalEl.value);
  if (!name) { alert('Subject ka naam likhein'); return; }
  if (!total || total <= 0) { alert('Is subject ke total marks likhein'); return; }
  if (dmcSubjects.some(x => x.name.toLowerCase() === name.toLowerCase())) { alert('Yeh subject pehle se maujood hai'); return; }
  dmcSubjects.push({ name, total });
  dmcResults.forEach(r => { r.marks = r.marks || {}; if (r.marks[name] === undefined) r.marks[name] = 0; });
  nameEl.value = ''; totalEl.value = '';
  renderDMCSubjects();
  dmcSubjectsChanged();
}
function updateDMCSubjectTotal(j, v) {
  const total = Number(v);
  if (!total || total <= 0) { alert('Total marks 0 se zyada hone chahiye'); renderDMCSubjects(); return; }
  dmcSubjects[j].total = total;
  dmcSubjectsChanged();
}
function renameDMCSubject(j, v) {
  const name = (v || '').trim();
  const old = dmcSubjects[j].name;
  if (!name || name === old) { renderDMCSubjects(); return; }
  if (dmcSubjects.some((x, k) => k !== j && x.name.toLowerCase() === name.toLowerCase())) { alert('Yeh naam pehle se maujood hai'); renderDMCSubjects(); return; }
  dmcSubjects[j].name = name;
  dmcResults.forEach(r => { if (r.marks && old in r.marks) { r.marks[name] = r.marks[old]; delete r.marks[old]; } });
  dmcSubjectsChanged();
}
function removeDMCSubject(j) {
  const sub = dmcSubjects[j];
  if (!confirm(`"${sub.name}" ko hata dein? Is subject ke saare marks bhi hat jayenge.`)) return;
  dmcResults.forEach(r => { if (r.marks) delete r.marks[sub.name]; });
  dmcSubjects.splice(j, 1);
  renderDMCSubjects();
  dmcSubjectsChanged();
}
function setDMCMark(i, j, v) {
  const r = dmcResults[i];
  r.marks = r.marks || {};
  r.marks[dmcSubjects[j].name] = Number(v) || 0;
  saveDMCUpload();
}

function renderDMCEditTable() {
  renderDMCSubjects();
  const container = document.getElementById('dmc-edit-table');
  if (!container) return;
  // Same protection as applyDMCConfigToFields(): never blow away a row the
  // user is actively typing into (Student Name / Roll No.) — this container
  // gets rebuilt from a few different places (Excel upload, config load),
  // and any of them landing mid-keystroke used to be able to reproduce the
  // exact same "keyboard closes on tap" symptom for these two fields.
  const active = document.activeElement;
  if (active && container.contains(active) && (active.tagName === 'INPUT' || active.tagName === 'SELECT' || active.tagName === 'TEXTAREA')) return;
  if (dmcResults.length === 0) { container.innerHTML = `<p style="font-size:12px;opacity:.5;">Upload a result list above to edit roll numbers.</p>`; return; }
  container.innerHTML = dmcResults.map((r, i) => `
    <div style="display:flex;align-items:center;gap:10px;border-bottom:1px solid var(--line);padding:8px 0;">
      <div style="width:22px;font-size:13px;color:var(--ink);flex-shrink:0;">${r.serialNo}.</div>
      <input type="text" autocomplete="off" style="flex:1;" value="${esc(r.studentName)}" placeholder="Student Name" oninput="dmcResults[${i}].studentName=this.value;saveDMCUpload();">
      <input type="text" autocomplete="off" style="width:110px;flex-shrink:0;" value="${esc(r.rollNo)}" placeholder="Roll No." oninput="dmcResults[${i}].rollNo=this.value;saveDMCUpload();">
    </div>
    ${dmcSubjects.length ? `<div style="display:flex;flex-wrap:wrap;gap:8px;padding:6px 0 10px 32px;border-bottom:1px solid var(--line);">${dmcSubjects.map((sub, j) => `
      <label style="display:flex;flex-direction:column;font-size:11px;opacity:.85;">
        <span>${esc(sub.name)} /${esc(sub.total)}</span>
        <input type="number" inputmode="decimal" min="0" max="${esc(sub.total)}" style="width:70px;" value="${esc((r.marks && r.marks[sub.name] !== undefined) ? r.marks[sub.name] : '')}" oninput="setDMCMark(${i},${j},this.value)">
      </label>`).join('')}</div>` : ''}
  `).join('');
}

function handleDMCExcelUpload(file) {
  if (!file) return;
  const selectedClass = dmcSelectedClass;
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const data = new Uint8Array(e.target.result);
      const wb = XLSX.read(data, {type: 'array'});
      const ws = wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws);

      dmcResults = rows.map((r, idx) => {
        const excelClass = r['Class'] || r['جماعت'] || '';
        return {
          serialNo: idx + 1,
          studentName: r['Student Name'] || r['Name'] || r['Student'] || '',
          fatherName: r['Father Name'] || r["Father's Name"] || r['Father'] || r['S/O'] || r['Walid'] || '',
          rollNo: r['Roll No'] || r['Roll No.'] || r['Roll Number'] || r['Roll'] || '',
          class: excelClass || selectedClass || '',
          classFromExcel: !!excelClass, // if true, onDMCClassChange() won't overwrite this row later
          marks: {} // will be filled from other columns
        };
      });

      // Every remaining column is a subject; its total marks are read
      // straight from the column header itself (e.g. "Urdu/75", "Math/100")
      // instead of a separate manual Subject Configuration step — dmcSubjects
      // is fully rebuilt from the Excel headers on every upload.
      // Blank-header columns (XLSX names these "__EMPTY", "__EMPTY_1", etc.)
      // and any pre-existing summary column already in the sheet (Total,
      // Grand Total, Percentage, Result, Position, Grade, Remarks...) are
      // skipped — those aren't per-subject marks, and the certificate
      // computes its own total/percentage from the real subjects anyway, so
      // including them would double it up.
      const nonMarkCols = ['Student Name','Name','Student','Class','جماعت','Father Name',"Father's Name",'Father','S/O','Walid','Roll No','Roll No.','Roll Number','Roll','Section','سیکشن','Date of Issue','Issue Date'];
      const skipWords = ['total','total marks','total obtained','grand total','overall total','percentage','percent','result','position','rank','grade','remarks','status','division','signature'];
      const isNonSubjectCol = (col) => {
        if (nonMarkCols.includes(col)) return true;
        const c = String(col || '').trim();
        if (!c || /^__EMPTY/i.test(c)) return true; // blank header column
        const norm = c.toLowerCase().replace(/[^a-z0-9\u0600-\u06FF]+/g, ' ').trim();
        if (skipWords.includes(norm) || /^total\b/.test(norm)) return true;
        return false;
      };
      const parseSubjectHeader = (raw) => {
        const m = String(raw || '').match(/^(.+?)[\s\/]+(\d+)\s*$/);
        return m ? { name: m[1].trim(), total: Number(m[2]) } : { name: String(raw || '').trim(), total: 100 };
      };
      const subjectMap = new Map(); // original column header -> {name, total}
      if (rows.length) {
        Object.keys(rows[0]).forEach(col => {
          if (isNonSubjectCol(col)) return;
          const parsed = parseSubjectHeader(col);
          if (!parsed.name) return; // no subject name could be read from this header — skip it entirely
          subjectMap.set(col, parsed);
        });
      }
      dmcSubjects = Array.from(subjectMap.values());
      saveDMCConfig();

      dmcResults.forEach((r, idx) => {
        const row = rows[idx];
        subjectMap.forEach((subj, col) => {
          if (row[col] === undefined) return;
          r.marks[subj.name] = Number(row[col]) || 0;
        });
      });

      const missingClass = !selectedClass && dmcResults.some(r => !r.class);
      dmcLastUploadMsg = missingClass
        ? `⚠️ Loaded ${dmcResults.length} students, but no class is set — select a class above (or add a "Class" column to your Excel) before printing.`
        : `✓ Loaded ${dmcResults.length} students`;
      document.getElementById('dmc-upload-msg').innerHTML = dmcLastUploadMsg;
      renderDMCEditTable();
      saveDMCUpload();
    } catch (err) {
      dmcLastUploadMsg = `✗ Error: ${esc(err.message)}`;
      document.getElementById('dmc-upload-msg').innerHTML = dmcLastUploadMsg;
    }
  };
  reader.readAsArrayBuffer(file);
}

function generateDMCPreview() {
  if (dmcResults.length === 0) { alert('Please upload Excel file first'); return; }
  if (dmcSubjects.length === 0) { alert('Please configure subjects first'); return; }
  
  let html = '<div style="max-height:600px;overflow-y:auto;">';
  dmcResults.slice(0, 3).forEach(r => {
    html += renderDMCCertificate(r);
  });
  html += `</div><p style="font-size:12px;opacity:.5;margin-top:10px;">Showing first 3 of ${dmcResults.length} certificates</p>`;
  document.getElementById('dmc-preview').innerHTML = html;
}

function dmcSubjectIcon(name) {
  const n = (name || '').toLowerCase();
  if (n.includes('eng')) return '🔤';
  if (n.includes('sci')) return '🧪';
  if (n.includes('math') || n.includes('riyazi')) return '🧮';
  if (n.includes('urdu')) return '📖';
  if (n.includes('islam') || n.includes('quran') || n.includes('deen')) return '🕌';
  if (n.includes('gk') || n.includes('general') || n.includes('social') || n.includes('geo')) return '🌍';
  if (n.includes('comp')) return '💻';
  if (n.includes('art') || n.includes('draw')) return '🎨';
  if (n.includes('phys') || n.includes('sport') || n.includes('pt ')) return '⚽';
  return '📘';
}

function dmcGradeFor(pct) {
  return pct >= 80 ? 'A+' : pct >= 70 ? 'A' : pct >= 60 ? 'B' : pct >= 50 ? 'C' : pct >= 40 ? 'D' : 'F';
}
function dmcRemarkFor(grade) {
  const map = { 'A+':'Outstanding', 'A':'Excellent', 'B':'Very Good', 'C':'Good', 'D':'Satisfactory', 'F':'Needs Improvement' };
  return map[grade] || '';
}
// A color per grade, so the Grade/Remarks shown on the certificate are
// visually color-coded (green for strong grades, fading through gold/orange
// down to a soft red for the lowest one) instead of all one plain color.
function dmcGradeColor(grade) {
  const map = { 'A+':'#2F7D4F', 'A':'#3F7154', 'B':'#3D7A9E', 'C':'#B2871F', 'D':'#B2752F', 'F':'#B24A32' };
  return map[grade] || '#1C2530';
}

// Width (in em) of the school name in the certificate font, measured with the real font so the
// name can always be fitted inside the arch. Falls back to a character-count estimate.
function dmcNameWidthEm(text) {
  try {
    if (!window._dmcMeasureCtx) window._dmcMeasureCtx = document.createElement('canvas').getContext('2d');
    const ctx = window._dmcMeasureCtx;
    ctx.font = "700 100px 'Aref Ruqaa', serif";
    return (ctx.measureText(text || '').width / 100) * 1.05;   // 5% safety margin
  } catch (e) { return (text || '').length * 0.5; }
}
// The first time the certificate is drawn the web font may not be loaded yet (so it would be
// measured with a fallback font). Ask for it once and redraw the preview as soon as it arrives.
function dmcEnsureNameFont() {
  try {
    if (!document.fonts || window._dmcFontAsked) return;
    if (document.fonts.check("700 20px 'Aref Ruqaa'")) return;
    window._dmcFontAsked = true;
    document.fonts.load("700 20px 'Aref Ruqaa'").then(() => {
      try { if (document.getElementById('dmc-preview') && dmcResults.length > 0) generateDMCPreview(); } catch (e) {}
    }).catch(() => {});
  } catch (e) {}
}

function renderDMCCertificate(result) {
  const totalObtained = dmcSubjects.reduce((a, s) => a + (Number(result.marks[s.name]) || 0), 0);
  const totalPossible = dmcSubjects.reduce((a,b) => a+b.total, 0);
  const percentage = totalPossible ? ((totalObtained / totalPossible) * 100).toFixed(1) : 0;
  const grade = dmcGradeFor(percentage);
  const resultStatus = percentage >= 40 ? 'PASS' : 'FAIL';

  // Position in class — dense ranking: a 3-way tie at 1st is followed by
  // 2nd next (not 4th), so ties never skip position numbers.
  const classResults = dmcResults.filter(r => r.class === result.class);
  const classTotals = classResults.map(r => dmcSubjects.reduce((a, s) => a + (Number(r.marks[s.name]) || 0), 0));
  const sortedTotals = [...new Set(classTotals)].sort((a, b) => b - a);
  const position = sortedTotals.indexOf(totalObtained) + 1;
  const ordinal = n => {
    const s = ['th','st','nd','rd'], v = n % 100;
    return n + (s[(v - 20) % 10] || s[v] || s[0]);
  };

  // Design values are per-school (dmcDesign), so the same rendering logic
  // below produces a differently-styled certificate for every school.
  const pc = dmcDesign.primaryColor || '#0F2740';   // primary (navy by default)
  const ac = dmcDesign.accentColor  || '#C9A227';   // accent (gold by default)
  const bg = dmcDesign.bgColor      || '#FAF6EC';   // background (cream by default)
  const acLight = lightenColor(ac, 0.45);           // soft accent tint (was the fixed #E4C765)

  // Full 3D / embossed look applied to every piece of text on the
  // certificate (subject names, student info, marks, summary row, etc),
  // not just the school name. Small variant for compact table/label text,
  // large variant for bigger headings — both stack several offset dark
  // layers plus a soft drop shadow to read as raised/extruded text.
  // NOTE: these are declared before subjectsHtml below — subjectsHtml runs
  // its .map() immediately (it's not a lazy function), so if these constants
  // were declared after it, referencing them inside the map would throw a
  // "Cannot access before initialization" error and silently break the
  // entire certificate (nothing would render or print).
  const shadow3D = '1px 1px 0 rgba(0,0,0,.4),2px 2px 0 rgba(0,0,0,.32),3px 3px 0 rgba(0,0,0,.25),4px 4px 4px rgba(0,0,0,.4)';
  const shadow3Dsm = '0.5px 0.5px 0 rgba(0,0,0,.4),1px 1px 0 rgba(0,0,0,.32),1.5px 1.5px 0 rgba(0,0,0,.25),2px 2px 2px rgba(0,0,0,.4)';

  // The certificate background is now always a plain, auto-generated color
  // (a light tint of the logo's own color — see extractLogoColor), never a
  // busy uploaded image, so a simple plain black + soft 3D pop reads clearly
  // every time and there's no need to guess contrast against an image.
  const nameColor = '#000';
  const nameShadow = '1px 1px 0 rgba(255,255,255,.6),2px 2px 3px rgba(0,0,0,.4),3px 3px 5px rgba(0,0,0,.3)';
  const taglineShadow = '0.5px 0.5px 0 rgba(255,255,255,.6),1px 1px 2px rgba(0,0,0,.4),2px 2px 3px rgba(0,0,0,.3)';
  const panelBg = 'transparent';
  // Soft white halo behind dark text so it stays crisp over the watermark / background picture.
  const glow = '0 0 2px rgba(255,255,255,.95),0 0 5px rgba(255,255,255,.9)';
  const lightPanel = 'background:rgba(255,255,255,.62);-webkit-print-color-adjust:exact;print-color-adjust:exact;';

  const subjectsHtml = dmcSubjects.map((s, i) => {
    const marks = Number(result.marks[s.name]) || 0;
    const subjPct = s.total ? (marks / s.total) * 100 : 0;
    const subjGrade = dmcGradeFor(subjPct);
    return `
      <tr style="border-bottom:1px solid #C9C2A6;${lightPanel}">
        <td style="padding:6px 12px;text-align:center;font-size:15px;font-weight:900;color:#000;text-shadow:${glow};">${i+1}</td>
        <td style="padding:6px 12px;text-align:left;font-size:16px;font-weight:900;color:#000;text-shadow:${glow};">${esc(s.name)}</td>
        <td style="padding:6px 12px;text-align:center;font-size:16px;font-weight:900;color:#000;text-shadow:${glow};">${s.total}</td>
        <td style="padding:6px 12px;text-align:center;font-size:17px;font-weight:900;color:#000;text-shadow:${glow};">${marks}</td>
        <td style="padding:6px 12px;text-align:center;font-size:16px;font-weight:900;color:#000;text-shadow:${glow};">${subjGrade}</td>
      </tr>`;
  }).join('');

  const infoField = (icon, label, value) => `
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;">
      <span style="flex-shrink:0;width:20px;text-align:center;">${icon}</span>
      <span style="flex-shrink:0;width:112px;font-size:15px;font-weight:900;color:#000;text-shadow:${glow};">${esc(label)}</span>
      <span style="font-size:15px;font-weight:900;color:#000;">:</span>
      <span style="flex:1;font-size:17px;font-weight:900;color:#000;text-shadow:${glow};border-bottom:1px solid #8a8466;padding-bottom:2px;">${esc(value || '\u2014')}</span>
    </div>`;


  // Long school names must never be clipped, so the header font size scales
  // down as the name gets longer instead of using a fixed size that overflows.
  const nameLen = (dmcSchoolName || '').length;
  const nameFontSize = nameLen > 42 ? 22 : nameLen > 34 ? 26 : nameLen > 26 ? 30 : nameLen > 18 ? 34 : 40;

  // Mihrab-style arched header: the school name follows a gentle arch instead of a
  // straight line. Each end of the line tilts 20 degrees upward, so the two sides
  // meet at the top at 140 degrees instead of 180 (a flat line).
  // The name ALWAYS fits inside the arch: its font size is calculated from the real text
  // width, and a very long name is split over two arched lines before it gets too small.
  dmcEnsureNameFont();
  const hdrW = 560, hdrX1 = 10, hdrX2 = 550, hdrHalfAng = 20 * Math.PI / 180;
  const hdrR = ((hdrX2 - hdrX1) / 2) / Math.sin(hdrHalfAng);
  const hdrSag = hdrR * (1 - Math.cos(hdrHalfAng));
  const hdrMaxW = 470;                                  // usable text length along the arch
  const hdrBaseFs = Math.round(nameFontSize * 1.3);     // SVG is shown ~25% smaller than its box
  const hdrName = (dmcSchoolName || '').trim();
  const fitFs = txt => Math.max(10, Math.min(hdrBaseFs, Math.floor(hdrMaxW / Math.max(dmcNameWidthEm(txt), 0.1))));
  let hdrLines = [hdrName], hdrFs = fitFs(hdrName);
  if (hdrFs < 26 && /\s/.test(hdrName)) {
    const mid = hdrName.length / 2; let best = -1;
    for (let k = 0; k < hdrName.length; k++) {
      if (/\s/.test(hdrName[k]) && (best < 0 || Math.abs(k - mid) < Math.abs(best - mid))) best = k;
    }
    const l1 = hdrName.slice(0, best).trim(), l2 = hdrName.slice(best).trim();
    const fs2 = Math.min(fitFs(l1), fitFs(l2));
    if (l1 && l2 && fs2 > hdrFs) { hdrLines = [l1, l2]; hdrFs = fs2; }
  }
  const hdrLineGap = Math.round(hdrFs * 1.12);
  const hdrEndY = hdrFs + 12 + hdrSag;
  const hdrUp = Math.round(hdrFs * 0.95 + 8);
  const hdrDown = (hdrLines.length - 1) * hdrLineGap + Math.round(hdrFs * 0.45) + 9;
  const hdrH = Math.ceil(hdrEndY + hdrDown + 3);
  const hdrArcId = 'dmcArc' + Math.random().toString(36).slice(2, 8);
  const f2 = n => Number(n).toFixed(2);
  const hdrArcAt = dy => `M ${hdrX1} ${f2(hdrEndY + dy)} A ${f2(hdrR)} ${f2(hdrR)} 0 0 1 ${hdrX2} ${f2(hdrEndY + dy)}`;
  const hdrBand = `M ${hdrX1} ${f2(hdrEndY - hdrUp)} A ${f2(hdrR)} ${f2(hdrR)} 0 0 1 ${hdrX2} ${f2(hdrEndY - hdrUp)} L ${hdrX2} ${f2(hdrEndY + hdrDown)} A ${f2(hdrR)} ${f2(hdrR)} 0 0 0 ${hdrX1} ${f2(hdrEndY + hdrDown)} Z`;
  const hdrPathsHtml = hdrLines.map((_, k) => `<path id="${hdrArcId}${k}" d="${hdrArcAt(k * hdrLineGap)}"/>`).join('');
  const hdrTextHtml = hdrLines.map((ln, k) => `<text font-family="'Aref Ruqaa',serif" font-weight="900" font-size="${hdrFs}" fill="${nameColor}" stroke="${nameColor}" stroke-width=".4" text-anchor="middle"><textPath href="#${hdrArcId}${k}" startOffset="50%">${esc(ln)}</textPath></text>`).join('');

  return `
    <div class="dmc-cert" style="page-break-inside:avoid;break-inside:avoid;margin-bottom:24px;font-family:Inter,sans-serif;">
      <div style="max-width:800px;margin:0 auto;background:${pc};padding:8px;border-radius:22px;position:relative;overflow:hidden;">
        <div style="background:${bg};border:2px solid ${ac};border-radius:16px;padding:18px 26px 16px;position:relative;z-index:0;overflow:hidden;">
          ${dmcDesign.bgImage ? `<div style="position:absolute;inset:0;z-index:-1;pointer-events:none;background:url('${dmcDesign.bgImage}') center/${dmcDesign.bgImageFit === 'contain' ? 'contain' : 'cover'} no-repeat;opacity:${dmcDesign.bgImageOpacity == null ? 0.25 : dmcDesign.bgImageOpacity};-webkit-print-color-adjust:exact;print-color-adjust:exact;"></div>` : ''}
          ${dmcLogo ? `<div style="position:absolute;inset:0;z-index:-1;display:flex;align-items:center;justify-content:center;pointer-events:none;overflow:hidden;"><img src="${dmcLogo}" style="width:63%;max-width:364px;object-fit:contain;opacity:.13;filter:blur(1px);"></div>` : ''}

          <!-- Header: logo back on the side (as in the original layout), with
               the school name as a plain auto-sizing line so long names never
               get clipped. -->
          <div style="display:flex;align-items:center;justify-content:space-between;gap:14px;">
            <div style="flex-shrink:0;width:62px;height:62px;">
              ${dmcLogo
                ? `<img src="${dmcLogo}" style="width:62px;height:62px;object-fit:contain;border-radius:50%;border:2px solid ${ac};">`
                : `<svg viewBox="0 0 64 64" width="62" height="62"><path d="M32 4 L58 12 V32 C58 46 47 56 32 60 C17 56 6 46 6 32 V12 Z" fill="${pc}" stroke="${ac}" stroke-width="2"/><circle cx="32" cy="26" r="10" fill="none" stroke="${acLight}" stroke-width="1.5"/><path d="M24 40 L40 40" stroke="${acLight}" stroke-width="1.5"/></svg>`}
            </div>
            <div style="flex:1;min-width:0;">
              <svg viewBox="0 0 ${hdrW} ${hdrH}" xmlns="http://www.w3.org/2000/svg" style="display:block;width:100%;height:auto;overflow:visible;-webkit-print-color-adjust:exact;print-color-adjust:exact;">
                <defs>${hdrPathsHtml}</defs>
                <path d="${hdrBand}" fill="rgba(255,255,255,.88)" stroke="${ac}" stroke-width="1.5" stroke-linejoin="round"/>
                ${hdrTextHtml}
              </svg>
            </div>
            <div style="flex-shrink:0;width:42px;height:54px;">
              <svg viewBox="0 0 44 56" width="42" height="54"><path d="M6 0 H38 V34 L22 24 L6 34 Z" fill="${pc}"/><circle cx="22" cy="16" r="12" fill="${acLight}" stroke="${ac}" stroke-width="1.5"/><path d="M16 16 L20 20 L28 11" stroke="${pc}" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </div>
          </div>

          ${dmcTagline ? `<div style="text-align:center;margin-top:9px;"><span style="display:inline-block;max-width:94%;box-sizing:border-box;background:linear-gradient(135deg,#071427 0%,#12305a 45%,#0a1d38 55%,#071427 100%);border:2px solid #D9A93A;border-radius:999px;padding:7px 28px;font-size:15px;font-weight:900;letter-spacing:.14em;line-height:1.35;text-transform:uppercase;color:#FFD36B;text-shadow:0 0 6px rgba(255,205,80,.75),0 0 12px rgba(255,190,40,.45),0 1px 0 #6b4b00;box-shadow:0 0 12px rgba(255,195,60,.55),inset 0 1px 0 rgba(255,255,255,.35),inset 0 -1px 0 rgba(0,0,0,.4);-webkit-print-color-adjust:exact;print-color-adjust:exact;"><span style="color:#FFF1B8;">✦</span> ${esc(dmcTagline.toUpperCase())} <span style="color:#FFF1B8;">✦</span></span></div>` : ''}
          <div style="height:1px;background:linear-gradient(90deg,transparent,${ac},transparent);margin:10px 0 12px;"></div>

          <!-- Title banner -->
          <div style="text-align:center;">
            <div style="display:inline-block;background:${pc};color:#fff;padding:9px 26px;border-radius:6px;font-weight:900;font-size:14px;letter-spacing:.06em;">${esc((dmcDesign.certTitle || 'DETAIL MARKS CERTIFICATE').toUpperCase())}</div>
            ${dmcAcademicSession ? `<div style="margin-top:10px;"><span style="display:inline-block;background:${panelBg};border:1px solid ${ac};color:${pc};padding:4px 18px;border-radius:999px;font-size:11px;font-weight:900;letter-spacing:.03em;">ACADEMIC SESSION: ${esc(dmcAcademicSession)}</span></div>` : ''}
          </div>

          <!-- Student Information section -->
          <div style="margin:14px 0 0;">
            <div style="display:inline-block;background:${pc};color:#fff;padding:7px 18px;font-size:13px;font-weight:900;letter-spacing:.05em;border-radius:4px 10px 4px 4px;">STUDENT INFORMATION</div>
          </div>
          <div style="${lightPanel}border:1px solid ${ac};border-radius:10px;padding:12px 18px 2px;margin-top:8px;">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:0 20px;">
              <div>
                ${infoField('&#128100;','Student Name', result.studentName)}
                ${infoField('&#128100;','Father Name', result.fatherName)}
                ${infoField('&#128203;','Roll No.', result.rollNo)}
              </div>
              <div>
                ${infoField('&#127891;','Class', result.class)}
                ${infoField('&#128101;','Section', dmcBatchSection)}
                ${infoField('&#128197;','Date of Issue', fmtDate(dmcBatchDateOfIssue || todayISO()))}
              </div>
            </div>
          </div>

          <!-- Marks Table -->
          <table style="width:100%;border-collapse:collapse;margin:8px 0;background:${panelBg};">
            <thead>
              <tr style="background:${pc};color:#fff;">
                <th style="padding:8px 12px;text-align:center;font-weight:900;font-size:11px;letter-spacing:.04em;width:44px;">S.NO</th>
                <th style="padding:8px 12px;text-align:left;font-weight:900;font-size:11px;letter-spacing:.04em;">SUBJECT</th>
                <th style="padding:8px 12px;text-align:center;font-weight:900;font-size:11px;letter-spacing:.04em;">TOTAL MARKS</th>
                <th style="padding:8px 12px;text-align:center;font-weight:900;font-size:11px;letter-spacing:.04em;">OBTAINED MARKS</th>
                <th style="padding:8px 12px;text-align:center;font-weight:900;font-size:11px;letter-spacing:.04em;">GRADE</th>
              </tr>
            </thead>
            <tbody>
              ${subjectsHtml}
              <tr style="background:${pc};font-weight:900;-webkit-print-color-adjust:exact;print-color-adjust:exact;">
                <td colspan="2" style="padding:8px 12px;text-align:left;color:#fff;font-size:16px;">TOTAL</td>
                <td style="padding:8px 12px;text-align:center;color:#fff;font-size:18px;">${totalPossible}</td>
                <td style="padding:8px 12px;text-align:center;color:#fff;font-size:18px;">${totalObtained}</td>
                <td style="padding:8px 12px;text-align:center;"><span style="display:inline-block;background:#fff;color:${dmcGradeColor(grade)};padding:1px 14px;border-radius:6px;font-size:16px;-webkit-print-color-adjust:exact;print-color-adjust:exact;">${grade}</span></td>
              </tr>
              <!-- Result summary row: kept column-aligned directly under the TOTAL
                   row above it — Percentage sits under TOTAL MARKS, Position sits
                   under OBTAINED MARKS, Grade sits under GRADE (same last column). -->
              <tr style="border-top:2px solid ${pc};font-weight:900;">
                <td colspan="2" style="padding:8px 12px;text-align:left;vertical-align:top;"><span style="display:inline-block;background:rgba(255,255,255,.92);color:#000;padding:2px 9px;border-radius:5px;font-size:12px;letter-spacing:.04em;-webkit-print-color-adjust:exact;print-color-adjust:exact;">RESULT</span></td>
                <td style="padding:8px 12px;text-align:center;color:${pc};">
                  <div style="font-size:11px;letter-spacing:.04em;font-weight:900;text-shadow:${glow};">%AGE</div>
                  <div style="font-size:16px;line-height:1;margin-top:2px;">&#128200;</div>
                  <div style="font-size:34px;line-height:1;text-shadow:${shadow3D};">${percentage}%</div>
                </td>
                <td style="padding:8px 12px;text-align:center;color:${pc};">
                  <div style="font-size:11px;letter-spacing:.04em;font-weight:900;text-shadow:${glow};">POSITION</div>
                  <div style="font-size:16px;line-height:1;margin-top:2px;">&#129351;</div>
                  <div style="font-size:62px;font-weight:900;line-height:1;-webkit-text-stroke:0.4px ${pc};text-shadow:${shadow3D};">${dmcDesign.showPosition ? ordinal(position) : '\u2014'}</div>
                </td>
                <td style="padding:8px 12px;text-align:center;color:${dmcGradeColor(grade)};">
                  <div style="font-size:11px;letter-spacing:.04em;font-weight:900;text-shadow:${glow};">GRADE</div>
                  <div style="font-size:16px;line-height:1;margin-top:2px;">&#127895;</div>
                  <div style="font-size:32px;line-height:1;text-shadow:${shadow3D};">${grade}</div>
                </td>
              </tr>
            </tbody>
          </table>

          <!-- Remarks -->
          <div style="display:flex;margin-top:10px;border:1px solid ${pc};border-radius:8px;overflow:hidden;">
            <div style="background:${pc};color:#fff;font-weight:900;font-size:13px;letter-spacing:.05em;padding:8px 22px;">REMARKS</div>
            <div style="flex:1;${lightPanel}display:flex;align-items:center;justify-content:center;gap:8px;font-weight:900;font-size:16px;letter-spacing:.05em;text-shadow:${glow};color:${dmcGradeColor(grade)};">${dmcRemarkFor(grade)}</div>
          </div>

          <!-- Footer: signatures -->
          <div style="display:flex;align-items:flex-end;justify-content:space-between;margin-top:10px;gap:12px;padding:0 9% 0 20%;box-sizing:border-box;">
            <div style="text-align:center;flex:1;background:rgba(255,255,255,.92);border:1.5px solid ${pc};border-radius:8px;padding:30px 8px 5px;-webkit-print-color-adjust:exact;print-color-adjust:exact;">
              <div style="border-top:1px solid #000;padding-top:4px;font-size:10px;font-weight:900;color:#000;letter-spacing:.03em;">${esc((dmcDesign.teacherLabel || 'CLASS TEACHER SIGNATURE').toUpperCase())}</div>
            </div>
            ${dmcDesign.showStamp ? `<div style="text-align:center;flex-shrink:0;width:70px;">
              <div style="width:56px;height:56px;border:1px dashed ${ac};border-radius:50%;background:${panelBg};display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:900;color:${pc};opacity:.85;margin:0 auto;">SCHOOL<br>STAMP</div>
            </div>` : ''}
            <div style="text-align:center;flex:1;background:rgba(255,255,255,.92);border:1.5px solid ${pc};border-radius:8px;padding:30px 8px 5px;-webkit-print-color-adjust:exact;print-color-adjust:exact;">
              <div style="border-top:1px solid #000;padding-top:4px;font-size:10px;font-weight:900;color:#000;letter-spacing:.03em;">${esc((dmcDesign.principalLabel || 'PRINCIPAL SIGNATURE').toUpperCase())}</div>
            </div>
          </div>

        </div>
      </div>
    </div>
  `;
}


// Fallback color, used only if a logo's color can't be read (e.g. a fully
// transparent/blank image) — otherwise every school's colors now come from
// their own uploaded logo instead of one fixed color for everyone.
const DMC_FIXED_PRIMARY = '#0F2740';

// Darken a #rrggbb hex color by `pct` (0-1) toward black — the counterpart to
// lightenColor() above. Used to turn the logo's own color into a deeper shade
// for the banner/border (accentColor), while lightenColor() turns it into a
// pale tint for the certificate's background (bgColor).
function darkenColor(hex, pct) {
  const h = (hex || '#0F2740').replace('#', '');
  const num = parseInt(h.length === 3 ? h.split('').map(c => c + c).join('') : h, 16);
  const r = (num >> 16) & 255, g = (num >> 8) & 255, b = num & 255;
  const mix = c => Math.round(c * (1 - pct));
  return `#${[mix(r), mix(g), mix(b)].map(v => v.toString(16).padStart(2, '0')).join('')}`;
}

// Reads the uploaded logo's own average color off a canvas, so the
// certificate's colors can be generated to match it automatically instead of
// requiring a separate manual background upload. Skips near-white/near-black
// pixels (usually padding around the mark, not the mark itself) so the
// average leans toward the logo's actual color rather than its background.
function extractLogoColor(dataUrl, callback) {
  const img = new Image();
  img.onload = () => {
    const size = 48; // a small sample is plenty and keeps this fast
    const canvas = document.createElement('canvas');
    canvas.width = size; canvas.height = size;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0, size, size);
    let r = 0, g = 0, b = 0, n = 0;
    try {
      const data = ctx.getImageData(0, 0, size, size).data;
      for (let i = 0; i < data.length; i += 4) {
        if (data[i + 3] < 128) continue; // skip transparent pixels
        const rr = data[i], gg = data[i + 1], bb = data[i + 2];
        const lum = (rr + gg + bb) / 3;
        if (lum > 240 || lum < 15) continue; // skip near-white/near-black padding
        r += rr; g += gg; b += bb; n++;
      }
    } catch (e) { /* canvas can be tainted for some image sources — fall back below */ }
    if (!n) { callback(DMC_FIXED_PRIMARY); return; }
    r = Math.round(r / n); g = Math.round(g / n); b = Math.round(b / n);
    callback(`#${[r, g, b].map(v => v.toString(16).padStart(2, '0')).join('')}`);
  };
  img.onerror = () => callback(DMC_FIXED_PRIMARY);
  img.src = dataUrl;
}

function handleDMCLogoUpload(file) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    dmcLogo = e.target.result;
    extractLogoColor(dmcLogo, (color) => {
      // Banner/header background: a deeper shade of the logo's color, dark
      // enough for the white header text to stay readable on top of it.
      dmcDesign.primaryColor = darkenColor(color, 0.35);
      // Border trim: the logo's color itself.
      dmcDesign.accentColor = color;
      // Certificate background: a very pale tint of the same color, so the
      // black body text printed on it stays clearly legible.
      dmcDesign.bgColor = lightenColor(color, 0.9);
      saveDMCConfig();
      renderTab();
      renderDMCPreviewIfOpen();
    });
  };
  reader.readAsDataURL(file);
}

// Permanently archives this batch of DMC results (full marks included) to the
// dmc_records table, so a student's certificate can be found and reprinted
// years later by name — unlike dmcResults, which only lives in memory for the
// current session/upload and is lost as soon as the tab closes.
async function saveDMCRecords(results) {
  if (!results.length) return;
  const year = dmcAcademicSession || 'Unspecified';
  const rows = results.map(r => {
    const totalObtained = dmcSubjects.reduce((a, s) => a + (Number(r.marks[s.name]) || 0), 0);
    const totalPossible = dmcSubjects.reduce((a, s) => a + s.total, 0);
    const percentage = totalPossible ? +(totalObtained / totalPossible * 100).toFixed(1) : 0;
    const classTotals = results.filter(x => x.class === r.class)
      .map(x => dmcSubjects.reduce((a, s) => a + (Number(x.marks[s.name]) || 0), 0));
    const position = [...new Set(classTotals)].sort((a, b) => b - a).indexOf(totalObtained) + 1;
    return {
      owner_id: CURRENT_USER.id, academic_year: year, class_name: r.class || '',
      roll_no: r.rollNo || '', student_name: r.studentName || '', father_name: r.fatherName || '',
      section: dmcBatchSection || '', date_of_issue: dmcBatchDateOfIssue || todayISO(),
      marks: r.marks || {}, subjects: dmcSubjects,
      total_obtained: totalObtained, total_possible: totalPossible, percentage,
      grade: dmcGradeFor(percentage), position, updated_at: new Date().toISOString()
    };
  });
  const { error } = await sb.from('dmc_records')
    .upsert(rows, { onConflict: 'owner_id,academic_year,class_name,roll_no,student_name' });
  if (error) console.error('DMC record archive failed:', error.message);
}

// Fetches one archived DMC record and its class cohort (for position ranking),
// temporarily swaps the live DMC globals for that record's own saved values,
// renders the certificate exactly as it looked when issued, then restores the
// live globals so the rest of the app is unaffected.
async function viewSavedDMCRecord(id) {
  const { data: rec, error } = await sb.from('dmc_records').select('*').eq('id', id).eq('owner_id', CURRENT_USER.id).maybeSingle();
  if (error || !rec) { alert('Record not found'); return; }
  const { data: cohort } = await fetchAll(() => sb.from('dmc_records').select('student_name,marks,class_name')
    .eq('owner_id', CURRENT_USER.id).eq('academic_year', rec.academic_year).eq('class_name', rec.class_name));

  const backup = { subjects: dmcSubjects, session: dmcAcademicSession, section: dmcBatchSection, date: dmcBatchDateOfIssue, results: dmcResults };
  dmcSubjects = (rec.subjects && rec.subjects.length) ? rec.subjects : dmcSubjects;
  dmcAcademicSession = rec.academic_year || dmcAcademicSession;
  dmcBatchSection = rec.section || '';
  dmcBatchDateOfIssue = rec.date_of_issue || todayISO();
  dmcResults = (cohort || []).map(c => ({ studentName: c.student_name, class: c.class_name, marks: c.marks }));

  const pseudo = { studentName: rec.student_name, fatherName: rec.father_name, rollNo: rec.roll_no, class: rec.class_name, marks: rec.marks };
  const certHtml = renderDMCCertificate(pseudo);

  dmcSubjects = backup.subjects; dmcAcademicSession = backup.session; dmcBatchSection = backup.section;
  dmcBatchDateOfIssue = backup.date; dmcResults = backup.results;

  closeModal();
  showModal(`${rec.student_name} — ${rec.academic_year}`, `
    <div style="max-height:65vh;overflow-y:auto;">${certHtml}</div>
    <div style="margin-top:12px;">
      <button class="btn-primary" onclick="printSavedDMCRecord('${id}')">🖨️ Print</button>
    </div>
  `);
}

// Same swap-render-restore approach as viewSavedDMCRecord, but opens a print
// window instead of a modal — used for reprinting one archived certificate.
async function printSavedDMCRecord(id) {
  const { data: rec, error } = await sb.from('dmc_records').select('*').eq('id', id).eq('owner_id', CURRENT_USER.id).maybeSingle();
  if (error || !rec) { alert('Record not found'); return; }
  const { data: cohort } = await fetchAll(() => sb.from('dmc_records').select('student_name,marks,class_name')
    .eq('owner_id', CURRENT_USER.id).eq('academic_year', rec.academic_year).eq('class_name', rec.class_name));

  const backup = { subjects: dmcSubjects, session: dmcAcademicSession, section: dmcBatchSection, date: dmcBatchDateOfIssue, results: dmcResults };
  dmcSubjects = (rec.subjects && rec.subjects.length) ? rec.subjects : dmcSubjects;
  dmcAcademicSession = rec.academic_year || dmcAcademicSession;
  dmcBatchSection = rec.section || '';
  dmcBatchDateOfIssue = rec.date_of_issue || todayISO();
  dmcResults = (cohort || []).map(c => ({ studentName: c.student_name, class: c.class_name, marks: c.marks }));

  const pseudo = { studentName: rec.student_name, fatherName: rec.father_name, rollNo: rec.roll_no, class: rec.class_name, marks: rec.marks };
  const certHtml = renderDMCCertificate(pseudo);

  dmcSubjects = backup.subjects; dmcAcademicSession = backup.session; dmcBatchSection = backup.section;
  dmcBatchDateOfIssue = backup.date; dmcResults = backup.results;

  const html = '<html><head><meta charset="utf-8"><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Berkshire+Swash&family=Aref+Ruqaa:wght@400;700&family=Inter:wght@400;500;600;700&display=swap"><style>@page{size:A4;margin:8mm;}*{-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important;color-adjust:exact!important;}body{font-family:Inter,sans-serif;margin:0;padding:10px;}</style></head><body>' + certHtml + '</body></html>';
  const w = window.open('', '', 'height=900,width=800');
  w.document.write(html);
  w.document.close();
  setTimeout(() => w.print(), 500);
}

function printAllDMC() {
  if (dmcResults.length === 0) { alert('No results to print'); return; }
  let html = '<html><head><meta charset="utf-8"><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Berkshire+Swash&family=Aref+Ruqaa:wght@400;700&family=Inter:wght@400;500;600;700&display=swap"><style>@page{size:A4;margin:8mm;}*{-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important;color-adjust:exact!important;}html,body{height:100%;}body{font-family:Inter,sans-serif;margin:0;padding:10px;background:#f5f5f5;}@media print{body{background:#fff;padding:0;}.dmc-cert{page-break-inside:avoid;break-inside:avoid;page-break-after:auto;}}</style></head><body>';
  dmcResults.forEach(r => {
    html += renderDMCCertificate(r);
  });
  html += '</body></html>';
  const w = window.open('', '', 'height=900,width=800');
  w.document.write(html);
  w.document.close();
  setTimeout(() => w.print(), 500);
  dmcResults.forEach(r => logCertificateIssued('DMC', r.studentName, r.class));
  saveDMCRecords(dmcResults);
}

