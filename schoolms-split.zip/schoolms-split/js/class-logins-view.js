/* SchoolMS — class-logins-view.js — split from index.html (lines 7044-7328). Load order matters: see index.html */
// ---------------- Class Logins — owner's read-only view of attendance & marks entered by the class ----------------
// Full month register (same grid pattern as the Teacher Register), one row
// per date, one student pair of AM/PM columns each — so the owner sees the
// whole month at a glance instead of flipping day by day.
let classRegMonth = monthKey();

async function openClassAttendanceView(className) {
  classRegMonth = monthKey();
  showModal(className + ' — ' + t.viewAttendance, `
    <label><span>${esc(t.registerMonth)}</span><input id="cav-month" type="month" value="${classRegMonth}" onchange="classRegMonth=this.value; renderClassAttendanceView('${className.replace(/'/g,"\\'")}')"></label>
    <div id="cav-body">…</div>
  `);
  await renderClassAttendanceView(className);
}

// Counts attendance as hazirian (individual session marks): a present
// Morning session counts as 1, a present Afternoon session counts as 1,
// so a full day present (both sessions) counts as 2 hazirian.
function attendanceDaysCount(records) {
  return records.reduce((sum, r) =>
    sum + (r.status_am === 'present' ? 1 : 0) + (r.status_pm === 'present' ? 1 : 0), 0);
}
function fmtAttendanceDays(n) {
  return n % 1 === 0 ? String(n) : n.toFixed(1);
}

async function renderClassAttendanceView(className) {
  const body = document.getElementById('cav-body');
  if (!body) return;
  body.innerHTML = '…';
  const dates = datesInMonth(classRegMonth);
  const { data, error } = await fetchAll(() => sb.from('student_attendance').select('*')
    .eq('class_name', className)
    .gte('date', dates[0]).lte('date', dates[dates.length-1]));
  if (error) { body.innerHTML = `<div class="err">${esc(error.message)}</div>`; return; }
  // All attendance recorded before this month, for the "Previous Months" total column.
  const { data: prevData, error: prevError } = await fetchAll(() => sb.from('student_attendance').select('*')
    .eq('class_name', className)
    .gte('date', sessionStartISO(dates[0]))
    .lt('date', dates[0]));
  if (prevError) { body.innerHTML = `<div class="err">${esc(prevError.message)}</div>`; return; }
  // Totals of months already rolled up (only meaningful when viewing the current month).
  const rolledTotals = {};
  if (dates[0] >= monthStartISO()) {
    const tr = await fetchAll(() => sb.from('student_attendance_totals').select('student_id,present_days').eq('session_start', sessionStartISO(dates[0])));
    if (!tr.error) (tr.data || []).forEach(r => { rolledTotals[r.student_id] = (rolledTotals[r.student_id] || 0) + (r.present_days || 0); });
  }
  const students = DATA.students.filter(s => s.class_name === className && s.status === 'active');
  if (!students.length) { body.innerHTML = `<div class="empty">${esc(t.noAttendanceRecords)}</div>`; return; }
  const recFor = (studentId, date) => (data || []).find(r => r.student_id === studentId && r.date === date) || {};
  const cellCode = (status) => status === 'present' ? 'P' : status === 'leave' ? 'L' : status === 'absent' ? 'A' : status === 'sick' ? 'S' : '—';
  const dateHead = dates.map(date => {
    const d = new Date(date + 'T00:00:00');
    const holiday = isHoliday(date);
    return `<th style="${holiday?'opacity:.5;':''}">${d.getDate()}</th>`;
  }).join('');
  const rows = students.map(s => {
    const cells = dates.map(date => {
      if (isHoliday(date)) return `<td style="opacity:.35;">—</td>`;
      const rec = recFor(s.id, date);
      return `<td style="padding:3px 2px;line-height:1.25;">
        <div style="font-size:10px;color:${registerCellColor(rec.status_am)};">${esc(cellCode(rec.status_am))}</div>
        <div style="font-size:10px;color:${registerCellColor(rec.status_pm)};">${esc(cellCode(rec.status_pm))}</div>
      </td>`;
    }).join('');
    const prevDays = attendanceDaysCount((prevData || []).filter(r => r.student_id === s.id)) + (rolledTotals[s.id] || 0);
    const thisMonthDays = attendanceDaysCount((data || []).filter(r => r.student_id === s.id));
    const totalDays = prevDays + thisMonthDays;
    return `<tr><td class="date-col" style="text-align:left;white-space:nowrap;">${esc(s.name)}</td>${cells}
      <td style="font-weight:700;">${fmtAttendanceDays(prevDays)}</td>
      <td style="font-weight:700;">${fmtAttendanceDays(thisMonthDays)}</td>
      <td style="font-weight:700;">${fmtAttendanceDays(totalDays)}</td>
    </tr>`;
  }).join('');
  body.innerHTML = `
    <div class="card-table-wrap">
      <table class="reg-physical">
        <thead>
          <tr><th style="text-align:left;">${esc(t.studentName)}</th>${dateHead}
            <th>${esc(t.attRegPrevMonths)}</th><th>${esc(t.attRegThisMonth)}</th><th>${esc(t.attRegTotal)}</th>
          </tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
    </div>
    <p style="font-size:10.5px;opacity:.55;margin-top:8px;">${esc(t.morning)} / ${esc(t.afternoon)} — ${esc(t.registerLegend)}</p>`;
}

// Offline-aware: mirrors the fetched exams into IndexedDB (keyed by class
// name) so this view still opens with the last-synced marks when there's no
// signal at all — same on-demand cache pattern as dmc_config/marks_sheet_data.
async function openClassMarksView(className) {
  showModal(className + ' — ' + t.examMarksTitle, `<div id="cmv-body">…</div>`);
  const body = document.getElementById('cmv-body');
  let data = null, error = null;
  if (navigator.onLine) {
    const res = await fetchAll(() => sb.from('class_exam_marks').select('*').eq('class_name', className).order('updated_at', { ascending: false }));
    data = res.data; error = res.error;
    if (!error && data) await idbPutRow('class_exam_marks', { class_name: className, exams: data });
  } else {
    error = null;
  }
  if (!navigator.onLine || error) {
    const cached = await idbGetAll('class_exam_marks');
    const row = cached.find(r => r.class_name === className);
    data = row ? row.exams : [];
    if (error && (!data || !data.length)) { body.innerHTML = `<div class="err">${esc(error.message)}</div>`; return; }
  }
  if (!data || !data.length) { body.innerHTML = `<div class="empty">${esc(t.noExamsYet)}</div>`; return; }
  body.innerHTML = `<div class="list-card">${data.map(ex => `
    <button type="button" class="list-row" style="width:100%;text-align:left;border:none;background:none;cursor:pointer;" onclick='renderClassMarksDetail(${JSON.stringify(ex.id)})'>
      <div class="nm">${esc(ex.exam_name)}</div><span style="opacity:.5;">›</span>
    </button>`).join('')}</div><div id="cmv-detail"></div>`;
  window.__classExamCache = data;
}

function renderClassMarksDetail(examId) {
  const ex = (window.__classExamCache || []).find(x => x.id === examId);
  const detail = document.getElementById('cmv-detail');
  if (!ex || !detail) return;
  const subjects = ex.subjects || [];
  const marks = ex.marks || {};
  const studentName = (sid) => { const s = DATA.students.find(x => x.id === sid); return s ? s.name : sid; };
  const studentIds = Object.keys(marks);
  detail.innerHTML = `
    <div class="card-table-wrap" style="margin-top:12px;">
      <table class="card-table">
        <thead><tr><th style="text-align:left;">${esc(t.studentName)}</th>${subjects.map(s=>`<th>${esc(s.name)}</th>`).join('')}</tr></thead>
        <tbody>${studentIds.map(sid => `<tr><td class="mo">${esc(studentName(sid))}</td>${subjects.map(s=>`<td>${esc((marks[sid]||{})[s.name] ?? '—')}</td>`).join('')}</tr>`).join('')}</tbody>
      </table>
    </div>`;
}

function openTeacherDetail(id) {
  const tc = DATA.teachers.find(x=>x.id===id);
  const payments = teacherPayments(id).slice().sort((a,b)=> new Date(b.pay_date)-new Date(a.pay_date));
  const totalPaid = payments.reduce((a,b)=>a+Number(b.amount),0);
  const curMonth = monthKey();
  const attInfo = calcAttendanceSalary(id, curMonth);
  showModal(tc.name, `
    <div style="font-size:12px;opacity:.7;margin-bottom:12px;display:flex;flex-wrap:wrap;gap:12px;">
      <span>${esc(t.subject)}: ${esc(tc.subject||'')}</span>
      <span>${esc(t.qualification)}: ${esc(tc.qualification||'')}</span>
      <span>${esc(t.monthlySalary)}: ₨${fmt(tc.monthly_salary)}</span>
    </div>
    <div class="greenbox"><div class="lbl">${esc(t.totalSalariesAllTime)}</div><div class="val">₨${fmt(totalPaid)}</div></div>
    <div class="section-title" style="margin-top:0;">${esc(t.payMonth)}</div>
    <div class="row2">
      <input id="p-month" type="month" value="${curMonth}" onchange="updateAttendanceSalaryInfo('${id}')">
      <label style="margin-bottom:0;"><span>${esc(t.baseSalary)}</span><input id="p-amount" type="number" placeholder="${esc(t.enterAmount)}" value="${attInfo.hasRecords ? attInfo.amount : (tc.monthly_salary||'')}"></label>
    </div>
    <div id="attendance-info" style="font-size:11px;opacity:.7;margin-top:6px;">${attInfo.hasRecords ? `${esc(t.present)}: ${attInfo.present} · ${esc(t.leave)}: ${attInfo.leave} · ${esc(t.absent)}: ${attInfo.absent}${attInfo.deductedDays > 0 ? ` (-${attInfo.deductedDays}d)` : ''} — ${esc(t.suggestedSalary)}: ₨${fmt(attInfo.amount)}` : esc(t.noAttendanceMarked)}</div>
    <div class="row2" style="margin-top:8px;">
      <label style="margin-bottom:0;"><span>${esc(t.attendanceBonus)}</span><input id="p-bonus" type="number" value="0"></label>
      <label style="margin-bottom:0;"><span>${esc(t.extraClass)}</span><input id="p-extra" type="number" value="0"></label>
    </div>
    <div style="margin-top:8px;"><input id="p-date" type="date" value="${todayISO()}"></div>
    <div style="margin-top:8px;"><button class="btn-primary" onclick="guardedSubmit(this, ()=>submitSalaryPayment('${id}'))">+ ${esc(t.save)}</button></div>
    <div class="section-title">${esc(t.salaryLedger)}</div>
    <div class="ledger">
      ${payments.length===0 ? `<div style="padding:10px;text-align:center;font-size:12px;opacity:.5;">—</div>` :
        payments.map(p=>{
          const bonus = Number(p.attendance_bonus||0), extra = Number(p.extra_class_fee||0);
          const breakdown = (bonus || extra)
            ? `<div style="font-size:11px;opacity:.6;">${bonus?esc(t.attendanceBonus)+': ₨'+fmt(bonus)+'  ':''}${extra?esc(t.extraClass)+': ₨'+fmt(extra):''}</div>`
            : '';
          return `
          <div class="ledger-row">
            <div style="font-size:12px;">${esc(monthLabel(p.month))} <span style="opacity:.5;">· ${esc(fmtDate(p.pay_date))}</span>${breakdown}</div>
            <div style="display:flex;align-items:center;gap:8px;">
              <span class="amt-neg">₨${fmt(p.amount)}</span>
              <button class="print-btn" title="${esc(t.print)}" onclick="printSalaryVoucher('${p.id}','${id}')">🖨️</button>
              <button class="del-btn" onclick="deleteSalaryPayment('${p.id}','${id}')">✕</button>
            </div>
          </div>`;}).join('')}
    </div>
    <div style="margin-top:16px;"><button class="btn-ghost danger" onclick="confirmDelete('teacher','${id}')">${esc(t.delete)}</button></div>
  `);
}

function teacherWaLink(phone, message) {
  let digits = (phone||'').replace(/\D/g,'');
  if (!digits) return null;
  if (digits.startsWith('0')) digits = '92' + digits.slice(1);
  else if (!digits.startsWith('92')) digits = '92' + digits;
  return smsUriFromDigits(digits, message);
}
async function submitSalaryPayment(teacherId) {
  const month = document.getElementById('p-month').value;
  const base = Number(document.getElementById('p-amount').value || 0);
  const bonus = Number(document.getElementById('p-bonus').value || 0);
  const extra = Number(document.getElementById('p-extra').value || 0);
  const date = dateVal('p-date');
  const amount = base + bonus + extra;
  if (!amount) return;

  // Looked up from the local cache (works offline too) — doubles as the
  // "before" snapshot for conflict checks when the queue is later replayed.
  const existingRow = DATA.salaryPayments.find(x => x.teacher_id === teacherId && x.month === month) || null;

  const payload = {
    id: existingRow ? existingRow.id : (crypto.randomUUID ? crypto.randomUUID() : `local-${Date.now()}`),
    owner_id: CURRENT_USER.id, teacher_id: teacherId, month,
    amount, attendance_bonus: bonus, extra_class_fee: extra, pay_date: date
  };
  // Root-level duplicate prevention: an atomic upsert keyed on the
  // (teacher_id, month) UNIQUE constraint in the database (same fix, and same
  // one-time SQL migration, as fee_payments above) — makes a duplicate salary
  // entry for the same teacher+month impossible, even under a race condition.
  //
  // Offline-aware: with no signal this is applied to the local copy right
  // away and queued — it syncs automatically once the connection is back
  // (see offlineWrite/flushSyncQueue), with a manual conflict prompt if
  // another device changed this same month's entry in the meantime.
  const { queued, error } = await offlineWrite({
    table: 'salary_payments', action: 'upsert', payload, id: payload.id, onConflict: 'teacher_id,month',
    baseRow: existingRow,
    run: () => sb.from('salary_payments').upsert(payload, { onConflict: 'teacher_id,month' }),
    optimisticApply: () => {
      const idx = DATA.salaryPayments.findIndex(x => x.id === payload.id);
      if (idx >= 0) DATA.salaryPayments[idx] = { ...DATA.salaryPayments[idx], ...payload };
      else DATA.salaryPayments.push(payload);
      idbPutRow('salary_payments', payload);
    }
  });
  if (!queued && reportSaveError(error)) return;
  const tc = DATA.teachers.find(x=>x.id===teacherId);
  // No longer skipped while queued offline — the sms: link opens the phone's
  // own Messages app with no internet needed at all (unlike the old wa.me link).
  if (tc && tc.contact) {
    const parts = [`${t.baseSalary}: ${LANG==='ur'?'روپے':'Rs'} ${fmt(base)}`];
    if (bonus > 0) parts.push(`${t.attendanceBonus}: ${LANG==='ur'?'روپے':'Rs'} ${fmt(bonus)}`);
    if (extra > 0) parts.push(`${t.extraClass}: ${LANG==='ur'?'روپے':'Rs'} ${fmt(extra)}`);
    const breakdown = parts.map(p => `- ${p}`).join('\n');
    const msg = LANG==='ur'
      ? `السلام علیکم ${tc.name}،\nآپ کی تنخواہ ماہ ${monthLabel(month)} کے لیے ادا کر دی گئی ہے:\n${breakdown}\nکل: روپے ${fmt(amount)}\nشکریہ۔`
      : `Assalam-o-Alaikum ${tc.name},\nYour salary for ${monthLabel(month)} has been paid:\n${breakdown}\nTotal: Rs ${fmt(amount)}\nThank you.`;
    const link = teacherWaLink(tc.contact, msg);
    if (link) location.href = link;
  }
  if (!queued) await loadAllData();
  openTeacherDetail(teacherId);
}
async function deleteSalaryPayment(paymentId, teacherId) {
  const baseRow = DATA.salaryPayments.find(x => x.id === paymentId) || null;
  const { queued } = await offlineWrite({
    table: 'salary_payments', action: 'delete', payload: null, id: paymentId, baseRow,
    run: () => sb.from('salary_payments').delete().eq('id', paymentId),
    optimisticApply: () => { DATA.salaryPayments = DATA.salaryPayments.filter(x => x.id !== paymentId); idbDeleteRow('salary_payments', paymentId); }
  });
  if (!queued) await loadAllData();
  openTeacherDetail(teacherId);
}

function printSalaryVoucher(paymentId, teacherId) {
  const tc = DATA.teachers.find(x => x.id === teacherId);
  const p = teacherPayments(teacherId).find(x => x.id === paymentId);
  if (!tc || !p) return;
  const bonus = Number(p.attendance_bonus || 0), extra = Number(p.extra_class_fee || 0);
  const base = Number(p.amount || 0) - bonus - extra;
  const voucherNo = 'SV-' + String(p.id).replace(/-/g, '').slice(0, 8).toUpperCase();
  const title = LANG === 'ur' ? 'تنخواہ ادائیگی واؤچر' : 'Salary Payment Voucher';

  document.getElementById('print-area').innerHTML = `
    <div class="receipt-box">
      <h2>${esc(CURRENT_PROFILE.school_name || 'School')}</h2>
      <div class="sub">${esc(title)} — ${esc(monthLabel(p.month))}</div>
      <table>
        <tr><td class="lbl">${esc(t.voucherNo || (LANG==='ur'?'واؤچر نمبر':'Voucher No'))}</td><td style="text-align:right;">${esc(voucherNo)}</td></tr>
        <tr><td class="lbl">${esc(LANG==='ur'?'ادا شدہ بنام':'Paid To')}</td><td style="text-align:right;">${esc(tc.name)}</td></tr>
        <tr><td class="lbl">${esc(t.subject)}</td><td style="text-align:right;">${esc(tc.subject||'—')}</td></tr>
        <tr><td class="lbl">${esc(t.baseSalary)}</td><td style="text-align:right;">₨${fmt(base)}</td></tr>
        ${bonus ? `<tr><td class="lbl">${esc(t.attendanceBonus)}</td><td style="text-align:right;">₨${fmt(bonus)}</td></tr>` : ''}
        ${extra ? `<tr><td class="lbl">${esc(t.extraClass)}</td><td style="text-align:right;">₨${fmt(extra)}</td></tr>` : ''}
        <tr><td class="lbl">${esc(t.dateCol)}</td><td style="text-align:right;">${esc(fmtDate(p.pay_date)||'')}</td></tr>
        <tr class="total-row"><td>${esc(t.totalAmount)}</td><td style="text-align:right;">₨${fmt(p.amount)}</td></tr>
      </table>
      <div class="foot" style="display:flex;justify-content:space-between;margin-top:40px;">
        <span>${esc(LANG==='ur'?'تیار کردہ دستخط':'Prepared By')} ____________</span>
        <span>${esc(LANG==='ur'?'وصول کنندہ دستخط':'Received By')} ____________</span>
      </div>
    </div>`;
  window.print();
}

