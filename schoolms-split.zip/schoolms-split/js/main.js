/* SchoolMS — main.js — split from index.html (lines 14391-14430). Load order matters: see index.html */
boot();

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').then(reg => {
      // Actively check for a newer sw.js/cache on every load, instead of only
      // whenever the browser feels like it — otherwise a freshly-uploaded
      // index.html can keep getting served from an old cached version for a
      // long time on phones that rarely fully close the browser.
      reg.update();
    }).catch(() => {});
  });
  // A new service worker can finish installing and take over (clients.claim())
  // while this tab is still sitting open with the OLD page already loaded in
  // memory — clients.claim() only changes who answers future network
  // requests, it doesn't refresh what's already on screen. Left alone, that
  // stale in-memory copy is exactly what a phone reopens from if it's ever
  // relaunched while offline. Reloading once, right when control switches
  // over, means an already-open tab picks up the new version immediately
  // instead of waiting for someone to fully close and reopen the app.
  // sessionStorage guards against a reload loop if this ever fires twice.
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (sessionStorage.getItem('sms_sw_reloaded')) return;
    sessionStorage.setItem('sms_sw_reloaded', '1');
    // Don't yank the page out from under an in-progress interaction — typing
    // in a field, or dragging one of the ledger tables (see
    // _regBookDragActive / safeRenderTab above) — that unconditional reload
    // was exactly what looked like the Admission Register table randomly
    // resetting mid-scroll. Wait until the user isn't mid-action, rechecking
    // shortly after, instead of reloading out from under them.
    const tryReload = () => {
      const ae = document.activeElement;
      const typing = ae && (ae.tagName === 'INPUT' || ae.tagName === 'TEXTAREA' || ae.isContentEditable);
      if (typing || _regBookDragActive) { setTimeout(tryReload, 500); return; }
      window.location.reload();
    };
    tryReload();
  });
}

