/* SchoolMS — data.js — split from index.html (lines 2867-3463). Load order matters: see index.html */
// ---------------- Data loading (RLS auto-scopes everything to this school) ----------------
// Student attendance grows every school day and is only ever written by the class
// portal, so re-downloading its whole history after every save wasted Supabase egress.
// Full history is fetched on first load (and again every 30 min); in between, only
// the last two days are fetched and merged into the cached older rows.
let SA_SYNC = { owner: null, ts: 0 };
// Academic session runs Feb-Jan (same rule as the fee card). Student attendance is only
// loaded for the session containing the given date, so old sessions never slow the app down.
// First day of the current month (local). Only this month's attendance is kept as day-by-day
// rows; earlier months are rolled up into per-student totals (student_attendance_totals).
function monthStartISO() { const n = new Date(); return n.getFullYear() + '-' + String(n.getMonth() + 1).padStart(2, '0') + '-01'; }
// Once per month (idempotent), asks the server to fold all earlier months' attendance rows into
// totals and delete those rows. Failure is harmless: the app just keeps working as before.
async function maybeRollupAttendance() {
  try {
    const key = 'sa_rollup_' + CURRENT_USER.id, mk = monthKey();
    if (localStorage.getItem(key) === mk) return;
    const { error } = await sb.rpc('rollup_student_attendance');
    if (!error) localStorage.setItem(key, mk);
  } catch (e) {}
}
function sessionStartISO(iso) {
  const d = iso ? new Date(iso + 'T00:00:00') : new Date();
  const y = (d.getMonth() + 1) >= 2 ? d.getFullYear() : d.getFullYear() - 1;
  return y + '-02-01';
}
// ---------------------------------------------------------------------------
// fetchAll(): Supabase/PostgREST returns at most 1000 rows per request. Plain
// .select('*') therefore SILENTLY dropped everything past row 1000 (fee
// payments, attendance, transactions...), which makes fee balances wrong once
// a school grows. This pulls every page and returns the same { data, error }
// shape the rest of the app already expects. Pass a FUNCTION that builds a
// fresh query each time (a query object can't be reused for a second page).
// ---------------------------------------------------------------------------
async function fetchAll(makeQuery, pageSize = 1000) {
  // Stable ordering (by id) is needed so pages never overlap or skip rows.
  // If a table has no "id" column the server says so; then retry without it.
  let useId = true;
  const all = [];
  const page = (from) => { let q = makeQuery(); if (useId) q = q.order('id'); return q.range(from, from + pageSize - 1); };
  // First page on its own (handles the no-"id"-column fallback).
  let res = await page(0);
  if (res.error && useId && /column|42703|does not exist/i.test((res.error.message || '') + (res.error.code || ''))) {
    useId = false;
    res = await page(0);
  }
  if (res.error) return { data: null, error: res.error };
  let rows = res.data || [];
  all.push(...rows);
  if (rows.length < pageSize) return { data: all, error: null };
  // Remaining pages: 4 at a time instead of one after another (much faster for big tables).
  const WAVE = 4;
  for (let from = pageSize; ; from += pageSize * WAVE) {
    const wave = await Promise.all(Array.from({ length: WAVE }, (_, i) => page(from + i * pageSize)));
    let done = false;
    for (const r of wave) {
      if (r.error) return { data: null, error: r.error };
      const rr = r.data || [];
      all.push(...rr);
      if (rr.length < pageSize) { done = true; break; }
    }
    if (done) break;
  }
  return { data: all, error: null };
}

// After a save, the change is already applied locally (optimisticApply). Re-reading just the
// ONE table that changed confirms it against the server without downloading and re-caching
// all ten tables. If anything goes wrong we fall back to the full reload, so behaviour
// is never worse than before.
const TABLE_RELOAD = {
  fee_payments: { key: 'feePayments', q: () => sb.from('fee_payments').select('*') },
  students:     { key: 'students',    q: () => sb.from('students').select('*').order('created_at') },
};
async function reloadTable(table) {
  const cfg = TABLE_RELOAD[table];
  if (!cfg || !navigator.onLine) return loadAllData();
  try {
    const r = await fetchAll(cfg.q);
    if (r.error || !Array.isArray(r.data)) return loadAllData();
    DATA[cfg.key] = r.data;
    await idbReplaceAll(table, r.data);
    saveOfflineSnapshot();
  } catch (e) { return loadAllData(); }
}

// The localStorage snapshot re-serialises EVERY table, so it must not run on each save.
// Batch bursts of saves into one write a few seconds later (IndexedDB is already updated per row).
let _snapTimer = null;
function saveOfflineSnapshotSoon() {
  clearTimeout(_snapTimer);
  _snapTimer = setTimeout(() => { _snapTimer = null; saveOfflineSnapshot(); }, 4000);
}

// After a fee save, confirm ONLY that student+month row against the server (one tiny query)
// instead of re-downloading the whole fee_payments table. The server row is the truth:
// if another device already created this student+month, the DB keeps THEIR id, so we swap
// our optimistic copy for it. Any problem -> fall back to the old full reload (never worse).
async function reloadFeeRow(studentId, month) {
  if (!navigator.onLine) return;
  try {
    const r = await sb.from('fee_payments').select('*').eq('student_id', studentId).eq('month', month).maybeSingle();
    if (r.error) return reloadTable('fee_payments');
    const row = r.data;
    const stale = DATA.feePayments.filter(x => x.student_id === studentId && x.month === month && (!row || x.id !== row.id));
    if (stale.length) {
      const staleIds = new Set(stale.map(x => x.id));
      DATA.feePayments = DATA.feePayments.filter(x => !staleIds.has(x.id));
      stale.forEach(x => idbDeleteRow('fee_payments', x.id));
    }
    if (row) {
      const i = DATA.feePayments.findIndex(x => x.id === row.id);
      if (i >= 0) DATA.feePayments[i] = row; else DATA.feePayments.push(row);
      idbPutRow('fee_payments', row);
    }
    saveOfflineSnapshotSoon();
  } catch (e) { return reloadTable('fee_payments'); }
}

async function loadAllData() {
  // No signal at all — skip the network round-trip and use the last-synced
  // snapshot straight away instead of waiting for every request to time out.
  if (!navigator.onLine) { await offlineCacheRestore(); renderOfflineBanner(); return; }
  await maybeRollupAttendance();
  let s, fp, tc, sp, tx, ar, ta, hd, cl, sa;
  const saFresh = SA_SYNC.owner === CURRENT_USER.id && (Date.now() - SA_SYNC.ts) < 30 * 60 * 1000
    && Array.isArray(DATA.studentAttendance) && DATA.studentAttendance.length > 0;
  const saCutoff = (() => { const d = new Date(); d.setDate(d.getDate() - 1);
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); })();
  const TIMED_OUT = Symbol('timed-out');
  try {
    const result = await Promise.race([
      Promise.all([
        fetchAll(() => sb.from('students').select('*').order('created_at')),
        fetchAll(() => sb.from('fee_payments').select('*')),
        fetchAll(() => sb.from('teachers').select('*').order('created_at')),
        fetchAll(() => sb.from('salary_payments').select('*')),
        fetchAll(() => sb.from('transactions').select('*').order('txn_date',{ascending:false})),
        // Admission & Withdrawal Register: a standalone record, unrelated to the
        // students/fee-finance tables above — it is never joined or cross-referenced.
        fetchAll(() => sb.from('admission_register').select('*').order('serial_no')),
        fetchAll(() => sb.from('teacher_attendance').select('*')),
        fetchAll(() => sb.from('holidays').select('*')),
        // Class Logins: one login per class, used by teachers on a shared class
        // device (no real Supabase Auth session — see class_login_verify etc.).
        // The owner reads this table directly; only the RPCs can write to it.
        fetchAll(() => sb.from('class_logins').select('*').order('created_at')),
        // Daily student attendance taken via the Class Portal — cached here
        // purely for read access (e.g. the Admission Register's attendance
        // calculator below), never written from the owner side.
        saFresh ? fetchAll(() => sb.from('student_attendance').select('*').gte('date', saCutoff)) : fetchAll(() => sb.from('student_attendance').select('*').gte('date', monthStartISO())),
      ]),
      // navigator.onLine can be true on a signal that's actually too weak to
      // reach the server — without this, that case hangs on "Loading your
      // data…" for as long as the browser's own (often very long) request
      // timeout, instead of falling back to the cache in a few seconds.
      new Promise((resolve) => setTimeout(() => resolve(TIMED_OUT), 35000)),
    ]);
    if (result === TIMED_OUT) { await offlineCacheRestore(); renderOfflineBanner(); return; }
    [s, fp, tc, sp, tx, ar, ta, hd, cl, sa] = result;
    // Supabase-js resolves (never throws) even when an individual query
    // fails server-side — a transient 500, a dropped connection mid-request
    // on a weak signal, a momentary RLS/policy hiccup, etc. Promise.all above
    // only catches a hard network rejection; a query that merely comes back
    // with { data: null, error } sails straight through it. Previously that
    // null was turned into [] by "s.data || []" below and then written to
    // the offline cache as if it were confirmed-empty real data — silently
    // erasing every previously-cached row for that table, permanently, even
    // though nothing was actually deleted on the server. This is the root
    // cause of "all data turns to 0 while offline": one flaky query on a
    // weak connection, while everything else on screen still looked fine.
    // Treat ANY per-query error exactly like the timeout/catch cases above —
    // fall back to the last-known-good cache instead of overwriting it.
    const results = [s, fp, tc, sp, tx, ar, ta, hd, cl, sa];
    const failed = results.find(r => r && r.error);
    if (failed) {
      console.error('loadAllData: partial failure, keeping cached data', failed.error);
      await offlineCacheRestore(); renderOfflineBanner(); return;
    }
    if (saFresh) sa = { data: DATA.studentAttendance.filter(r => r.date < saCutoff).concat(sa.data || []), error: null };
    else SA_SYNC = { owner: CURRENT_USER.id, ts: Date.now() };
  } catch (e) {
    // Request(s) failed mid-flight (signal dropped just now) — same fallback.
    await offlineCacheRestore(); renderOfflineBanner(); return;
  }
  DATA.students = s.data || [];
  DATA.feePayments = fp.data || [];
  DATA.teachers = tc.data || [];
  DATA.salaryPayments = sp.data || [];
  DATA.transactions = tx.data || [];
  DATA.admissionRegister = ar.data || [];
  DATA.teacherAttendance = ta.data || [];
  DATA.holidays = hd.data || [];
  DATA.classLogins = cl.data || [];
  DATA.studentAttendance = sa.data || [];
  CACHE_UNAVAILABLE = false; // fresh data straight from the server — definitely real
  await offlineCacheStore();
  renderOfflineBanner();
  flushSyncQueue();
}

// How many distinct months a student has unpaid dues for, counted directly
// from their fee ledger (the same rows shown in the month-by-month WhatsApp
// breakdown) — NOT the old balance ÷ monthly_fee approach, which overcounted
// whenever a one-time charge (admission fee, exam fee, sports fund) was part
// of the balance: e.g. 1 unpaid month + a one-time Rs 5,000 admission fee on
// top of a Rs 1,000 monthly fee produced "6+ months overdue" for what was
// really just 1 month, which then went straight into the parent-facing
// WhatsApp reminder text.
function monthsOverdue(s) {
  if (!isFeePaying(s)) return 0;
  const { rows } = buildAcademicYearLedger(s.id);
  return rows.filter(r => {
    if (r.blank) return false;
    const monthDue = Number(r.e.school_fee||0) + Number(r.e.sports_fund||0) + Number(r.e.admission_fee||0) + Number(r.e.exam_fee||0) + Number(r.e.other_fee||0) - Number(r.e.amount||0);
    return monthDue > 0;
  }).length;
}

// Prefers the Urdu-script name for a student/school when set (via the student's
// "Name (Urdu)" field or the account's "School Name (Urdu)" setting), falling
// back to whatever name is on file if no Urdu version has been entered yet.
function studentNameUrdu(s) { return (s && s.name_ur) || (s && s.name) || ''; }
function schoolNameUrdu() { return (CURRENT_PROFILE && CURRENT_PROFILE.school_name_ur) || (CURRENT_PROFILE && CURRENT_PROFILE.school_name) || ''; }
// The sign-off used on all Urdu-language parent messages, e.g.
// "دی پرنسپل اف دی اقراء اسلامک ایجوکیشنل سسٹم سکول"
function principalSignOffUrdu() { return `دی پرنسپل اف دی ${schoolNameUrdu()}`; }

function overdueReminderMessage(s) {
  const months = monthsOverdue(s);
  const balance = fmt(studentBalance(s.id));
  return LANG === 'ur'
    ? `محترم سرپرست، ${studentNameUrdu(s)} کی اسکول فیس کے واجبات ${months} مہینوں سے زائد ہو چکے ہیں، رقم: روپے ${balance}۔ براہ کرم جلد ادائیگی کریں۔ شکریہ\n${principalSignOffUrdu()}`
    : `Dear Parent, ${s.name}'s school fee dues are now ${months}+ months overdue, totaling Rs ${balance}. Please clear the balance at your earliest convenience. Thank you - School`;
}

// Month-by-month breakdown of unpaid dues, now itemized by fee category
// (School Fee / Sports Fund / Admission Fee / Exam Fee / Paid / Balance) —
// pulled straight from the same fee-card entry fields shown in "Add Month
// Entry" — rather than just one lump total per month. Built from the same
// academic-year ledger shown on the student's fee card so the figures
// always match what's on screen. A month only appears here if that month's
// own charges weren't fully paid off — not the running cumulative balance.
const UR_MONTH_NAMES = ['جنوری','فروری','مارچ','اپریل','مئی','جون','جولائی','اگست','ستمبر','اکتوبر','نومبر','دسمبر'];
function duesBreakdownLinesUrdu(studentId) {
  const { rows } = buildAcademicYearLedger(studentId);
  const L = T.ur;
  const entryRows = rows.filter(r => !r.blank);

  // Only report the months making up the *current* unpaid streak. r.balance
  // is the running cumulative balance carried month to month (see
  // buildAcademicYearLedger above) — once it's fully cleared (<=0) at some
  // month, everything before that point is settled, even if that particular
  // month's own charges once looked unpaid before a later month's payment
  // caught it up. e.g. February shows a due, March's payment clears the
  // running balance, April has a new due of its own — only April should be
  // listed, not February (which is what was causing the confusion).
  let lastClearedIndex = -1;
  entryRows.forEach((r, i) => { if (r.balance <= 0) lastClearedIndex = i; });
  const activeRows = entryRows.slice(lastClearedIndex + 1);

  return activeRows
    .map(r => {
      const e = r.e;
      const monthDue = Number(e.school_fee||0) + Number(e.sports_fund||0) + Number(e.admission_fee||0) + Number(e.exam_fee||0) + Number(e.other_fee||0) - Number(e.amount||0);
      if (monthDue <= 0) return null;
      const monthNum = Number(r.mk.split('-')[1]);
      const parts = [];
      if (Number(e.school_fee||0) > 0) parts.push(`${L.schoolFeeCol}: روپے ${fmt(e.school_fee)}`);
      if (Number(e.sports_fund||0) > 0) parts.push(`${L.sportsFund}: روپے ${fmt(e.sports_fund)}`);
      if (Number(e.admission_fee||0) > 0) parts.push(`${L.admissionFeeCol}: روپے ${fmt(e.admission_fee)}`);
      if (Number(e.exam_fee||0) > 0) parts.push(`${L.examFeeCol}: روپے ${fmt(e.exam_fee)}`);
      if (Number(e.other_fee||0) > 0) parts.push(`${L.otherFeeCol}: روپے ${fmt(e.other_fee)}`);
      parts.push(`${L.totalPaidCol}: روپے ${fmt(e.amount||0)}`);
      parts.push(`${L.balanceCol}: روپے ${fmt(monthDue)}`);
      return `${UR_MONTH_NAMES[monthNum-1]}:\n` + parts.map(p => `- ${p}`).join('\n');
    })
    .filter(Boolean);
}

// Itemized "payment received" SMS — same principle as duesBreakdownLinesUrdu
// above: don't just say "Rs X received", break it down by fee category
// (School Fee / Sports Fund / Admission Fee / Exam Fee / Other) so the parent
// can see exactly what the payment covered, plus any balance still
// outstanding for that student. e/entry is a fee_payments row (or ledger
// row's .e) with school_fee/sports_fund/admission_fee/exam_fee/other_fee/amount.
function paidReceiptMessage(studentName, monthText, e, remainingBalance) {
  const parts = [];
  if (Number(e.school_fee||0) > 0) parts.push(`School Fee: Rs ${fmt(e.school_fee)}`);
  if (Number(e.sports_fund||0) > 0) parts.push(`Sports Fund: Rs ${fmt(e.sports_fund)}`);
  if (Number(e.admission_fee||0) > 0) parts.push(`Admission Fee: Rs ${fmt(e.admission_fee)}`);
  if (Number(e.exam_fee||0) > 0) parts.push(`Annual Exam Fee: Rs ${fmt(e.exam_fee)}`);
  if (Number(e.other_fee||0) > 0) parts.push(`Other Fee: Rs ${fmt(e.other_fee)}`);
  const breakdown = parts.length ? ('\n' + parts.map(p => `- ${p}`).join('\n')) : '';
  const balLine = remainingBalance > 0 ? `\nBalance Remaining: Rs ${fmt(remainingBalance)}` : '';
  return `Dear Parent, fee payment of Rs ${fmt(e.amount||0)} received for ${studentName} (${monthText}).${breakdown}${balLine}\nThank you. - School`;
}

// Wrapper for the 💬 button on a fee-card row: looked up by studentId+month
// (rather than building the message text inline in the onclick attribute)
// so the multi-line breakdown text never has to survive being embedded in an
// HTML attribute string.
function sendPaidReceiptSms(studentId, month) {
  const s = DATA.students.find(x => x.id === studentId);
  if (!s) return;
  const [my, mm] = month.split('-').map(Number);
  const academicYearOf = (year, mon) => (mon >= 2 ? year : year - 1);
  const { rows } = buildAcademicYearLedger(studentId, academicYearOf(my, mm));
  const row = rows.find(r => !r.blank && r.mk === month);
  if (!row) return;
  const msg = paidReceiptMessage(s.name, monthLabel(month), row.e, row.balance);
  openFatherWhatsapp(s.contact || '', msg);
}

// Always in Urdu regardless of the site's current display language, since parents
// are the intended recipients.
function duesReminderMessageUrdu(s) {
  const lines = duesBreakdownLinesUrdu(s.id);
  const breakdown = lines.length ? ('\n\n' + lines.join('\n\n')) : '';
  const total = fmt(Math.max(0, studentBalance(s.id)));
  return `محترم سرپرست،\n${studentNameUrdu(s)} کی فیس کے واجبات درج ذیل ہیں:${breakdown}\nکل بقایا رقم: روپے ${total}\nبراہ کرم جلد از جلد ادائیگی کریں۔ شکریہ\n${principalSignOffUrdu()}`;
}

// Opens WhatsApp with the father's number and the Urdu dues-breakdown message pre-filled.
function sendOverdueReminderWhatsapp(id) {
  const s = DATA.students.find(x => x.id === id);
  if (!s) return;
  openFatherWhatsapp(s.contact, duesReminderMessageUrdu(s));
}

// General fee-request: same month-by-month breakdown message, but available for
// ANY student with a pending balance (not just those 2+ months overdue).
function sendFeeRequestWhatsapp(id) {
  const s = DATA.students.find(x => x.id === id);
  if (!s) return;
  openFatherWhatsapp(s.contact, duesReminderMessageUrdu(s));
}

function openFeeRequestReminders() {
  const due = DATA.students
    .filter(s => s.status !== 'inactive' && isFeePaying(s) && studentBalance(s.id) > 0)
    .sort((a, b) => studentBalance(b.id) - studentBalance(a.id));
  const rows = due.length === 0
    ? `<div class="empty">${esc(t.noDueStudents)}</div>`
    : due.map(s => `
      <div class="card-btn" style="cursor:default;">
        <div>
          <div class="nm">${esc(s.name)}</div>
          <div class="sub">${esc(t.fatherName)}: ${esc(s.father_name||'')} · ₨${fmt(studentBalance(s.id))} ${esc(t.due)}</div>
        </div>
        <button class="btn-primary" style="padding:6px 14px;" onclick="sendFeeRequestWhatsapp('${s.id}')">${esc(t.send)}</button>
      </div>`).join('');
  showModal(t.feeRequestTitle, `
    <div style="font-size:13px;opacity:.75;margin-bottom:14px;">${esc(t.feeRequestDesc)}</div>
    ${rows}
  `);
}

// Lookup indexes. The dashboard calls studentPayments()/teacherPayments() for every
// student/teacher several times per render; each call used to scan the WHOLE payments
// array (students x payments = tens of millions of comparisons for a big school, freezing
// phones). Now each array is grouped once and reused until it changes. It rebuilds when the
// array is replaced, its length changes, or bumpIdx() is called (offlineWrite does this
// right after every optimistic edit, so in-place updates are covered too).
let _IDX_EPOCH = 0;
function bumpIdx() { _IDX_EPOCH++; }
const _IDX = {};
function _groupBy(arr, key) { const m = new Map(); for (const r of arr) { const k = r[key]; const a = m.get(k); if (a) a.push(r); else m.set(k, [r]); } return m; }
function _indexed(name, arr, key) {
  const c = _IDX[name];
  if (!c || c.arr !== arr || c.len !== arr.length || c.epoch !== _IDX_EPOCH) { _IDX[name] = { arr, len: arr.length, epoch: _IDX_EPOCH, map: _groupBy(arr, key) }; }
  return _IDX[name].map;
}
function studentPayments(id){ return (_indexed('fp', DATA.feePayments, 'student_id').get(id) || []).slice(); }
function teacherPayments(id){ return (_indexed('sp', DATA.salaryPayments, 'teacher_id').get(id) || []).slice(); }

// Running ledger balance for a student (positive = amount still due, negative = credit)
function studentBalance(id) {
  const entries = studentPayments(id).slice().sort((a,b)=> (a.month>b.month?1:a.month<b.month?-1:0) || (new Date(a.pay_date)-new Date(b.pay_date)));
  let running = 0;
  entries.forEach(e => {
    const totalDues = running + Number(e.school_fee||0) + Number(e.sports_fund||0) + Number(e.admission_fee||0) + Number(e.exam_fee||0) + Number(e.other_fee||0);
    running = money2(totalDues - Number(e.amount||0));
  });
  return running;
}

// ---------------- Stats ----------------
function computeStats() {
  const cur = monthKey();
  const active = DATA.students.filter(s=>s.status!=='inactive');
  let feesCollectedThisMonth=0, feesDueThisMonth=0, otherFeeThisMonth=0;
  let payingCount=0, freeCount=0, orphanCount=0;
  active.forEach(s=>{
    const curEntries = studentPayments(s.id).filter(p=>p.month===cur);
    const paid = curEntries.reduce((a,b)=>a+Number(b.amount),0);
    feesCollectedThisMonth += paid;
    // Other (hostel/transport) fee IS counted in the fee card's own Total
    // Dues/Balance (studentBalance, the printed card, receipts, WhatsApp dues
    // breakdown) — but it deliberately stays OUT of this Dashboard's
    // this-month figures (feesCollectedThisMonth/feesDueThisMonth below),
    // since those are meant to reflect the school's own this-month cash
    // flow, not third-party (hostel/transport) money passing through.
    otherFeeThisMonth += curEntries.reduce((a,e)=>a+Number(e.other_fee||0),0);
    // "Due (this month)" must reflect ONLY this calendar month's own charges that
    // remain unpaid — NOT studentBalance(), which is the all-time running balance
    // including every earlier carried-forward month. Using studentBalance() here
    // previously made this card silently show each student's total lifetime dues
    // under a "this month" label, which could be badly misread by school staff.
    // Total all-time dues are shown separately under "Dues Outstanding" in Reports.
    if (isFeePaying(s)) {
      const monthCharge = curEntries.reduce((a,e)=>a+Number(e.school_fee||0)+Number(e.sports_fund||0)+Number(e.admission_fee||0)+Number(e.exam_fee||0),0);
      feesDueThisMonth += Math.max(0, monthCharge - paid);
      payingCount++;
    }
    else if ((s.student_type)==='orphan') orphanCount++;
    else freeCount++;
  });
  let salaryPaidThisMonth=0;
  DATA.teachers.forEach(tc=>{ salaryPaidThisMonth += teacherPayments(tc.id).filter(p=>p.month===cur).reduce((a,b)=>a+Number(b.amount),0); });

  // Other (non-salary) expenses recorded this calendar month, plus salaries
  // paid this month — together the "Expenses (this month)" figure that
  // mirrors the existing this-month Fees Collected / Fees Due cards.
  const otherExpenseThisMonth = DATA.transactions
    .filter(x => x.type === 'expense' && String(x.txn_date||'').slice(0,7) === cur)
    .reduce((a,b)=>a+Number(b.amount),0);
  const totalExpenseThisMonth = salaryPaidThisMonth + otherExpenseThisMonth;

  let totalCollectedAllTime=0;
  active.forEach(s=>{ totalCollectedAllTime += studentPayments(s.id).reduce((a,b)=>a+Number(b.amount),0); });
  let totalSalariesAllTime=0;
  DATA.teachers.forEach(tc=>{ totalSalariesAllTime += teacherPayments(tc.id).reduce((a,b)=>a+Number(b.amount),0); });
  const totalOtherIncomeAllTime = DATA.transactions.filter(x=>x.type==='income').reduce((a,b)=>a+Number(b.amount),0);
  const totalOtherExpenseAllTime = DATA.transactions.filter(x=>x.type==='expense').reduce((a,b)=>a+Number(b.amount),0);
  const totalIncomeAllTime = totalCollectedAllTime + totalOtherIncomeAllTime;
  const totalExpenseAllTime = totalSalariesAllTime + totalOtherExpenseAllTime;
  const netBalance = totalIncomeAllTime - totalExpenseAllTime;

  // Sum of every fee-paying active student's outstanding running balance —
  // the all-time counterpart to "Fees Due (this month)" above.
  let totalDuesAllTime = 0;
  active.forEach(s=>{ if (isFeePaying(s)) totalDuesAllTime += Math.max(0, studentBalance(s.id)); });

  return { activeCount:active.length, feesCollectedThisMonth, feesDueThisMonth, salaryPaidThisMonth, totalExpenseThisMonth, otherFeeThisMonth,
    totalCollectedAllTime, totalSalariesAllTime, totalOtherIncomeAllTime, totalOtherExpenseAllTime,
    totalIncomeAllTime, totalExpenseAllTime, netBalance, totalDuesAllTime, payingCount, freeCount, orphanCount };
}

// ---------------- App shell render ----------------
function renderApp() {
  document.getElementById('auth-root').innerHTML = '';
  document.getElementById('app').classList.remove('hidden');
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="sidebar" id="sidebar"></div>
    <div class="app-content">
      <header class="top">
        <div class="glow"></div>
        <div class="top-row">
          <div>
            <div class="eyebrow">${esc(CURRENT_PROFILE.school_name || 'My School')}</div>
            <div class="title">${esc(t.appName)}</div>
          </div>
          <div class="top-actions">
            <button class="pill-btn lock" id="alerts-bell-btn" onclick="openAlertsModal()" title="${esc(LANG==='ur' ? 'اہم الرٹس' : 'Important Alerts')}" style="position:relative;">🔔<span id="alerts-bell-badge"></span></button>
            <button class="pill-btn lock" onclick="openGlobalSearch()" title="${esc(t.globalSearch)}">🔍</button>
            <button class="pill-btn lang" onclick="toggleLangApp()">${esc(t.langToggle)}</button>
            <button class="pill-btn lock" onclick="openSettings()">⚙</button>
          </div>
        </div>
      </header>
      <main id="main"></main>
      <nav class="bottom"><div class="bar" id="navbar"></div></nav>
      <div id="modal-root"></div>
    </div>
  `;
  renderNav();
  renderSidebar();
  renderTab();
}

function toggleLangApp() {
  LANG = LANG === 'en' ? 'ur' : 'en';
  localStorage.setItem('sms_lang', LANG);
  t = T[LANG];
  document.body.className = LANG === 'ur' ? 'ur' : '';
  renderApp();
}

const NAV_ICONS = {
  notices: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 11v2a1 1 0 001 1h2l5 4V6L6 10H4a1 1 0 00-1 1z"/><path d="M15.5 8.5a5 5 0 010 7M18.5 6a9 9 0 010 12"/></svg>`,
  dashboard: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/></svg>`,
  students: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>`,
  teachers: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="7" r="4"/><path d="M2 21v-2a4 4 0 014-4h6a4 4 0 014 4v2"/><circle cx="17" cy="7" r="3"/></svg>`,
  finance: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2"/></svg>`,
  reports: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>`,
  dmc: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 5c0-1 0-2 1-2h16c1 0 1 1 1 2v14c0 1 0 2-1 2H4c-1 0-1-1-1-2V5z"/><path d="M7 10h10M7 14h8M7 18h6"/></svg>`,
  marksSheet: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="18" rx="2"/><path d="M9 8h6M3 13h18M3 18h18"/></svg>`,
  admissionRegister: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/><path d="M9 7h7M9 11h7"/></svg>`,
  timetable: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M3 9h18M9 4v18"/></svg>`,
  datesheet: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18M8 15h3M8 18h6"/></svg>`,
  admin: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-4z"/></svg>`,
  suggestions: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18h6M10 22h4M12 2a6 6 0 00-4 10.5c.6.6 1 1.4 1 2.5h6c0-1.1.4-1.9 1-2.5A6 6 0 0012 2z"/></svg>`,
  papers: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><path d="M14 2v6h6"/><path d="M9 13h1M9 17h1M14 13h1M14 17h1"/></svg>`,
};

// Icons used only in the desktop sidebar (attendance hub, settings, logout —
// these aren't TAB values, so they don't belong in NAV_ICONS above).
const SIDE_ICONS = {
  attendance: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/><path d="M9 16l2 2 4-4"/></svg>`,
  settings: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 008.6 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H2a2 2 0 010-4h.09A1.65 1.65 0 003.6 8.6a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06a1.65 1.65 0 001.82.33H8a1.65 1.65 0 001-1.51V2a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V8a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>`,
  logout: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/></svg>`,
};

// Desktop sidebar (see CSS @media min-width:960px). Mirrors the requested
// menu — Dashboard, Students, Teachers, Attendance, Fees, Exams & Marks,
// DMC/Certificates, Reports, Settings, Logout — as the primary group.
// Existing tabs that weren't in that list (Admission Register, Suggestions,
// Admin) are kept reachable in a smaller "More" group underneath, so no
// existing functionality is lost — just deprioritized visually.
function renderSidebar() {
  const el = document.getElementById('sidebar');
  if (!el) return;
  const link = (key, label, icon, action, tabMatch) => `
    <button class="side-link ${tabMatch && TAB===tabMatch ? 'active' : ''}" onclick="${action}">
      <span class="side-ic">${icon}</span><span>${esc(label)}</span>
    </button>`;

  const mainLinks = [
    link('dashboard', t.dashboard, NAV_ICONS.dashboard, "setTab('dashboard')", 'dashboard'),
    link('students', t.students, NAV_ICONS.students, "setTab('students')", 'students'),
    link('teachers', t.teachers, NAV_ICONS.teachers, "setTab('teachers')", 'teachers'),
    link('attendance', t.navAttendance, SIDE_ICONS.attendance, "openAttendanceHub()", null),
    link('fees', t.navFees, NAV_ICONS.finance, "setTab('finance')", 'finance'),
    link('marksSheet', t.navExamsMarks, NAV_ICONS.marksSheet, "setTab('marksSheet')", 'marksSheet'),
    link('dmc', t.dmc, NAV_ICONS.dmc, "setTab('dmc')", 'dmc'),
    link('reports', t.reports, NAV_ICONS.reports, "setTab('reports')", 'reports'),
  ].join('');

  const moreLinks = [
    link('admissionRegister', t.admissionRegister, NAV_ICONS.admissionRegister, "setTab('admissionRegister')", 'admissionRegister'),
    link('papers', t.papers, NAV_ICONS.papers, "setTab('papers')", 'papers'),
    link('timetable', LANG==='ur' ? 'ٹائم ٹیبل' : 'Timetable', NAV_ICONS.timetable, "setTab('timetable')", 'timetable'),
    link('datesheet', qt('Date Sheet & Slips', 'ڈیٹ شیٹ اور سلپس'), NAV_ICONS.datesheet, "setTab('datesheet')", 'datesheet'),
    link('notices', qt('Notice Board', 'نوٹس بورڈ'), NAV_ICONS.notices, "setTab('notices')", 'notices'),
    (CURRENT_PROFILE && CURRENT_PROFILE.is_admin) ? link('admin', t.admin, NAV_ICONS.admin, "setTab('admin')", 'admin') : '',
  ].join('');

  el.innerHTML = `
    <div class="side-brand">
      <div class="side-brand-name">${esc((CURRENT_PROFILE && CURRENT_PROFILE.school_name) || t.appName)}</div>
      <div class="side-brand-sub">${esc(t.appName)}</div>
    </div>
    <div class="side-group">${mainLinks}</div>
    <div class="side-divider"></div>
    <div class="side-group side-more">${moreLinks}</div>
    <div class="side-spacer"></div>
    <div class="side-group side-bottom">
      <button class="side-link" onclick="openSettings()"><span class="side-ic">${SIDE_ICONS.settings}</span><span>${esc(t.navSettings)}</span></button>
      <button class="side-link side-logout" onclick="confirmSidebarLogout()"><span class="side-ic">${SIDE_ICONS.logout}</span><span>${esc(t.logOut)}</span></button>
    </div>
  `;
}

// Attendance in the sidebar is a hub, not a single screen, because the app
// already has three separate entry points for it (mark teacher attendance,
// review the register, approve requests) scattered as icon buttons on the
// Teachers tab. This just surfaces the same existing functions in one place.
function openAttendanceHub() {
  showModal(t.navAttendance, `
    <p style="font-size:12px;opacity:.65;margin:0 0 14px;">${esc(t.navAttendanceDesc)}</p>
    <button class="btn-primary" style="width:100%;margin-bottom:10px;" onclick="closeModal();openMarkAttendance();">${esc(t.markAttendance)}</button>
    <button class="btn-ghost" style="width:100%;margin-bottom:10px;" onclick="closeModal();openTeacherRegister();">${esc(t.teacherRegister)}</button>
    <button class="btn-ghost" style="width:100%;" onclick="closeModal();openStaffRequests();">🔔 ${esc(qt('Teacher Requests', 'اساتذہ کی درخواستیں'))}</button>
  `);
}

function confirmSidebarLogout() {
  if (confirm(t.logOut + '?')) logOut();
}

function renderNav() {
  const tabs = ['dashboard','students','teachers','finance','reports','dmc','marksSheet','admissionRegister','papers','timetable','datesheet','notices'];
  if (CURRENT_PROFILE && CURRENT_PROFILE.is_admin) tabs.push('admin');
  document.getElementById('navbar').innerHTML = tabs.map(k => `
    <button class="${TAB===k?'active':''}" onclick="setTab('${k}')">
      ${NAV_ICONS[k]}<span>${k==='timetable' ? (LANG==='ur'?'ٹائم ٹیبل':'Timetable') : k==='datesheet' ? esc(qt('Date Sheet','ڈیٹ شیٹ')) : k==='notices' ? esc(qt('Notices','نوٹس')) : esc(t[k] || t.admin)}</span>
    </button>`).join('');
}

function setTab(k){
  TAB = k; renderNav(); renderSidebar(); renderTab();
  const main = document.getElementById('main');
  main.classList.remove('tab-fade'); void main.offsetWidth; main.classList.add('tab-fade');
}

