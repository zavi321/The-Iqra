/* SchoolMS — finance.js — split from index.html (lines 7329-7946). Load order matters: see index.html */
// ---------------- Finance ----------------
// Monthly Income vs Expense — built from the Finance tab's own transactions
// (the income/expense entries logged here), last 6 calendar months.
function monthlyIncomeExpenseSeries(n) {
  n = n || 6;
  const now = new Date();
  const months = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    months.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
  }
  return months.map(mk => {
    const rows = DATA.transactions.filter(x => String(x.txn_date || '').slice(0, 7) === mk);
    const income = rows.filter(x => x.type === 'income').reduce((a, b) => a + Number(b.amount || 0), 0);
    const expense = rows.filter(x => x.type === 'expense').reduce((a, b) => a + Number(b.amount || 0), 0);
    return { month: mk, income, expense };
  });
}
function tplIncomeExpenseChart() {
  const series = monthlyIncomeExpenseSeries(6);
  const hasData = series.some(s => s.income || s.expense);
  if (!hasData) return '';
  const max = Math.max(1, ...series.map(s => Math.max(s.income, s.expense)));
  const chartH = 130, barW = 14, gap = 8, groupGap = 24;
  const groupW = barW * 2 + gap;
  const chartW = series.length * (groupW + groupGap);
  const bars = series.map((s, i) => {
    const x0 = i * (groupW + groupGap);
    const incH = Math.round((s.income / max) * chartH);
    const expH = Math.round((s.expense / max) * chartH);
    return `
      <g>
        <rect x="${x0}" y="${chartH - incH}" width="${barW}" height="${Math.max(incH,1)}" rx="3" fill="var(--sage)"/>
        <rect x="${x0 + barW + gap}" y="${chartH - expH}" width="${barW}" height="${Math.max(expH,1)}" rx="3" fill="var(--rust)"/>
        <text x="${x0 + barW + gap / 2}" y="${chartH + 16}" text-anchor="middle" font-size="9" fill="var(--ink)" opacity=".65">${esc(monthLabel(s.month))}</text>
      </g>`;
  }).join('');
  return `
    <div class="card chart-card">
      <div class="chart-head">
        <div class="section-title" style="margin:0;">${esc(t.monthlyChartTitle)}</div>
        <div class="chart-legend">
          <span><i style="background:var(--sage)"></i>${esc(t.income)}</span>
          <span><i style="background:var(--rust)"></i>${esc(t.expense)}</span>
        </div>
      </div>
      <svg viewBox="0 0 ${chartW} ${chartH + 28}" style="width:100%;height:auto;display:block;margin-top:10px;" preserveAspectRatio="xMidYMid meet">
        ${bars}
      </svg>
    </div>`;
}
function tplFinance() {
  return `
    <div style="padding-top:16px;">
      <div style="display:flex;justify-content:flex-end;margin-bottom:12px;">
        <button class="btn-primary" style="width:auto;padding:9px 16px;" onclick="openAddTxn()">+ ${esc(t.addTransaction)}</button>
      </div>
      ${finPanel()}
      ${tplIncomeExpenseChart()}
      ${DATA.transactions.length===0 ? `<div class="empty">${esc(t.noTransactions)}</div>` :
        `<div class="list-card">` + DATA.transactions.map(x=>`
          <div class="list-row">
            <div><div class="nm">${esc(x.description||'')}</div><div class="sub">${esc(x.category||'')} · ${esc(fmtDate(x.txn_date)||'')}</div></div>
            <div style="display:flex;align-items:center;gap:8px;">
              <span class="${x.type==='income'?'amt-pos':'amt-neg'}">${x.type==='income'?'+':'−'}₨${fmt(x.amount)}</span>
              <button class="print-btn" title="${esc(t.print)}" onclick="printTxnVoucher('${x.id}')">🖨️</button>
              <button class="del-btn" onclick="deleteTxn('${x.id}')">✕</button>
            </div>
          </div>`).join('') + `</div>`}
    </div>`;
}

let txnType = 'expense';
let txnItems = [];
function openAddTxn() {
  txnType = 'expense';
  txnItems = [{ name: '', price: '' }];
  showModal(t.addTransaction, `
    <div class="type-toggle">
      <button id="btn-income" onclick="setTxnType('income')">${esc(t.income)}</button>
      <button id="btn-expense" class="on-expense" onclick="setTxnType('expense')">${esc(t.expense)}</button>
    </div>
    <div id="txn-items"></div>
    <div class="field-box"><label><span>${esc(t.category)}</span><select id="f-cat"></select></label></div>
    ${finAccountSelectHtml()}
    <div class="field-box"><label><span>${esc(t.date)}</span><input id="f-date" type="date" value="${todayISO()}"></label></div>
    <div class="flexgap">
      <button class="btn-ghost" onclick="closeModal()">${esc(t.cancel)}</button>
      <button class="btn-primary" style="flex:1" onclick="guardedSubmit(this, submitAddTxn)">${esc(t.save)}</button>
    </div>
  `);
  fillCatOptions();
  renderTxnItems();
}
function setTxnType(type) {
  txnType = type;
  document.getElementById('btn-income').className = type==='income' ? 'on-income' : '';
  document.getElementById('btn-expense').className = type==='expense' ? 'on-expense' : '';
  fillCatOptions();
}
function fillCatOptions() {
  const base = txnType==='income' ? INCOME_CATS : EXPENSE_CATS;
  const cats = base.concat(FIN.heads.filter(h => h.type === txnType && !base.includes(h.name)).map(h => h.name));
  document.getElementById('f-cat').innerHTML = cats.map(c=>`<option>${c}</option>`).join('');
}
function txnItemsTotal() {
  return txnItems.reduce((a,b)=>a+Number(b.price||0),0);
}
function renderTxnItems() {
  const el = document.getElementById('txn-items');
  if (!el) return;
  const itemLabel = LANG==='ur' ? 'چیز کا نام' : 'Item';
  const priceLabel = LANG==='ur' ? 'قیمت' : 'Price';
  el.innerHTML = txnItems.map((it, i) => `
    <div class="field-box" style="display:flex;gap:8px;align-items:flex-end;">
      <label style="flex:2;margin-bottom:0;"><span>${esc(itemLabel)}</span><input id="txn-item-name-${i}" value="${esc(it.name)}" oninput="updateTxnItem(${i},'name',this.value)"></label>
      <label style="flex:1;margin-bottom:0;"><span>${esc(priceLabel)}</span><input id="txn-item-price-${i}" type="number" value="${esc(it.price)}" oninput="updateTxnItem(${i},'price',this.value)"></label>
      ${txnItems.length>1 ? `<button class="del-btn" style="margin-bottom:10px;" onclick="removeTxnItem(${i})">✕</button>` : ''}
    </div>`).join('') +
    `<div id="txn-total-display" style="font-size:12px;opacity:.7;text-align:right;margin:-4px 4px 12px;">${esc(t.totalAmount)}: ₨${fmt(txnItemsTotal())}</div>`;
}
function updateTxnItem(i, field, val) {
  txnItems[i][field] = val;
  const isLast = i === txnItems.length - 1;
  if (field === 'price' && isLast && val !== '' && Number(val) > 0) {
    // A price was just entered on the last row — open a fresh row for the
    // next item automatically, per the requested "add another box" flow.
    // This rebuilds #txn-items (every input's DOM node gets torn down and
    // recreated), which on mobile yanks focus off the field the user is
    // still typing in and closes the keyboard. Capture the caret position
    // on the field that triggered this and restore focus + caret to that
    // SAME field id after the rebuild so the keyboard stays open.
    const activeId = document.activeElement ? document.activeElement.id : null;
    const selStart = document.activeElement ? document.activeElement.selectionStart : null;
    const selEnd = document.activeElement ? document.activeElement.selectionEnd : null;
    txnItems.push({ name: '', price: '' });
    renderTxnItems();
    if (activeId) {
      const newEl = document.getElementById(activeId);
      if (newEl) {
        newEl.focus({ preventScroll: true });
        if (selStart != null && newEl.setSelectionRange) {
          try { newEl.setSelectionRange(selStart, selEnd); } catch (e) {}
        }
      }
    }
  } else {
    const totalEl = document.getElementById('txn-total-display');
    if (totalEl) totalEl.textContent = `${t.totalAmount}: ₨${fmt(txnItemsTotal())}`;
  }
}
function removeTxnItem(i) {
  txnItems.splice(i, 1);
  if (txnItems.length === 0) txnItems.push({ name: '', price: '' });
  renderTxnItems();
}
async function submitAddTxn() {
  const validItems = txnItems.filter(it => it.name.trim() !== '' && it.price !== '' && Number(it.price) > 0);
  if (validItems.length === 0) return;
  const desc = validItems.map(it => `${it.name.trim()} (₨${fmt(Number(it.price))})`).join('; ');
  const amt = validItems.reduce((a,b)=>a+Number(b.price),0);
  const payload = {
    id: crypto.randomUUID ? crypto.randomUUID() : `local-${Date.now()}`,
    owner_id: CURRENT_USER.id,
    type: txnType, category: document.getElementById('f-cat').value, description: desc,
    amount: amt, txn_date: dateVal('f-date'),
    ...(document.getElementById('f-acc') && document.getElementById('f-acc').value ? { account_id: document.getElementById('f-acc').value } : {})
  };
  // Offline-aware: a brand-new transaction, so there's nothing on the server
  // yet to conflict with — safe to just insert once the connection is back.
  const { queued, error } = await offlineWrite({
    table: 'transactions', action: 'insert', payload, id: payload.id, baseRow: null,
    run: () => sb.from('transactions').insert(payload),
    optimisticApply: () => { DATA.transactions.push(payload); idbPutRow('transactions', payload); }
  });
  if (!queued && reportSaveError(error)) return;
  closeModal(); if (!queued) await loadAllData(); renderTab();
}
async function deleteTxn(id) {
  const baseRow = DATA.transactions.find(x => x.id === id) || null;
  const { queued } = await offlineWrite({
    table: 'transactions', action: 'delete', payload: null, id, baseRow,
    run: () => sb.from('transactions').delete().eq('id', id),
    optimisticApply: () => { DATA.transactions = DATA.transactions.filter(x => x.id !== id); idbDeleteRow('transactions', id); }
  });
  if (!queued) await loadAllData(); renderTab();
}

function parseItemizedTxnDesc(desc) {
  if (!desc) return null;
  const parts = desc.split('; ');
  const items = [];
  for (const p of parts) {
    const m = p.match(/^(.*) \(₨([\d,]+)\)$/);
    if (!m) return null;
    items.push({ name: m[1], price: Number(m[2].replace(/,/g, '')) });
  }
  return items.length ? items : null;
}

function printTxnVoucher(id) {
  const x = DATA.transactions.find(r => r.id === id);
  if (!x) return;
  const isIncome = x.type === 'income';
  const title = isIncome
    ? (LANG === 'ur' ? 'رسید واؤچر' : 'Receipt Voucher')
    : (LANG === 'ur' ? 'ادائیگی واؤچر' : 'Payment Voucher');
  const partyLabel = isIncome
    ? (LANG === 'ur' ? 'موصول شدہ از' : 'Received From')
    : (LANG === 'ur' ? 'ادا شدہ بنام' : 'Paid To');
  const voucherNo = 'V-' + String(x.id).replace(/-/g, '').slice(0, 8).toUpperCase();
  const items = parseItemizedTxnDesc(x.description);
  const itemRows = items
    ? items.map(it => `<tr><td class="lbl">${esc(it.name)}</td><td style="text-align:right;">₨${fmt(it.price)}</td></tr>`).join('')
    : `<tr><td class="lbl">${esc(partyLabel)}</td><td style="text-align:right;">${esc(x.description||'—')}</td></tr>`;

  document.getElementById('print-area').innerHTML = `
    <div class="receipt-box">
      <h2>${esc(CURRENT_PROFILE.school_name || 'School')}</h2>
      <div class="sub">${esc(title)}</div>
      <table>
        <tr><td class="lbl">${esc(t.voucherNo || (LANG==='ur'?'واؤچر نمبر':'Voucher No'))}</td><td style="text-align:right;">${esc(voucherNo)}</td></tr>
        ${itemRows}
        <tr><td class="lbl">${esc(t.category)}</td><td style="text-align:right;">${esc(x.category||'—')}</td></tr>
        <tr><td class="lbl">${esc(t.dateCol)}</td><td style="text-align:right;">${esc(fmtDate(x.txn_date)||'')}</td></tr>
        <tr class="total-row"><td>${esc(t.totalAmount)}</td><td style="text-align:right;">₨${fmt(x.amount)}</td></tr>
      </table>
      <div class="foot" style="display:flex;justify-content:space-between;margin-top:40px;">
        <span>${esc(LANG==='ur'?'تیار کردہ دستخط':'Prepared By')} ____________</span>
        <span>${esc(LANG==='ur'?'منظور شدہ دستخط':'Approved By')} ____________</span>
      </div>
    </div>`;
  window.print();
}

// ---------------- Accounts module: custom heads, cash/bank accounts, Day Book, P&L ----------------
const FIN = { heads: [], accounts: [], loaded: false, err: false };
let FINR = { kind: 'daybook', from: '', to: '', acct: 'all' };
async function finLoad() {
  FIN.loaded = true;
  try {
    const [h, a] = await Promise.all([
      sb.from('fin_heads').select('*').order('name'),
      sb.from('fin_accounts').select('*').order('created_at')
    ]);
    FIN.err = !!(h.error || a.error);
    FIN.heads = h.data || []; FIN.accounts = a.data || [];
  } catch (e) { FIN.err = true; }
}
function finAccName(id) { const a = FIN.accounts.find(x => x.id === id); return a ? a.name : '—'; }
function finAccBalance(a) {
  return DATA.transactions.filter(x => x.account_id === a.id)
    .reduce((s, x) => s + (x.type === 'income' ? 1 : -1) * Number(x.amount || 0), Number(a.opening_balance || 0));
}
function finAccountSelectHtml() {
  if (!FIN.accounts.length) return '';
  return `<div class="field-box"><label><span>${esc(qt('Account (Cash / Bank)', 'اکاؤنٹ (کیش / بینک)'))}</span><select id="f-acc">` +
    FIN.accounts.map(a => `<option value="${a.id}">${esc(a.name)} (${a.kind === 'bank' ? qt('Bank', 'بینک') : qt('Cash', 'کیش')})</option>`).join('') + `</select></label></div>`;
}
function finPanel() {
  if (!FIN.loaded) finLoad().then(() => { if (TAB === 'finance') renderTab(); });
  const cards = FIN.accounts.map(a => `<div class="card" style="padding:10px 14px;min-width:130px;flex:1;">
      <div style="font-size:11px;opacity:.65;">${a.kind === 'bank' ? '🏦' : '💵'} ${esc(a.name)}</div>
      <div style="font-weight:700;color:var(--navy);">₨${fmt(finAccBalance(a))}</div></div>`).join('');
  const btn = (label, fn) => `<button class="btn-ghost" style="flex:none;padding:8px 12px;font-size:13px;" onclick="${fn}">${label}</button>`;
  return `<div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px;">
      ${btn('📈 ' + esc(qt('Dashboard', 'ڈیش بورڈ')), 'openFinDashboard()')}
      ${btn('🤝 ' + esc(qt('Vendors', 'وینڈرز')), 'openFinVendors()')}
      ${btn('📒 ' + esc(qt('Day Book', 'روزنامچہ')), "openFinReport('daybook')")}
      ${btn('📊 ' + esc(qt('Profit & Loss', 'منافع و نقصان')), "openFinReport('pl')")}
      ${btn('🏷️ ' + esc(qt('Heads', 'مدات')), 'openFinHeads()')}
      ${btn('🏦 ' + esc(qt('Accounts', 'اکاؤنٹس')), 'openFinAccounts()')}
    </div>${cards ? `<div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px;">${cards}</div>` : ''}`;
}
function finSetupNote() {
  return FIN.err ? `<div class="err">${esc(qt('Accounts tables are not set up yet. Run the "ONE-TIME SETUP for Accounts" SQL (top of index.html) in Supabase.', 'اکاؤنٹس ٹیبل ابھی نہیں بنے۔ index.html کے شروع میں دی گئی SQL سپابیس میں چلائیں۔'))}</div>` : '';
}
// ---- Custom heads ----
function openFinHeads() {
  const row = h => `<div class="list-row"><div><div class="nm">${esc(h.name)}</div><div class="sub">${h.type === 'income' ? esc(t.income) : esc(t.expense)}</div></div>
    <button class="del-btn" onclick="finDelete('fin_heads','${h.id}')">✕</button></div>`;
  showModal(qt('Custom Heads', 'اپنی مدات'), `${finSetupNote()}
    <div class="type-toggle"><button id="fh-income" onclick="finHeadType('income')">${esc(t.income)}</button><button id="fh-expense" class="on-expense" onclick="finHeadType('expense')">${esc(t.expense)}</button></div>
    <div class="field-box"><label><span>${esc(qt('Head name', 'مد کا نام'))}</span><input id="fh-name"></label></div>
    <button class="btn-primary" onclick="guardedSubmit(this, finAddHead)">+ ${esc(qt('Add Head', 'مد شامل کریں'))}</button>
    <div class="list-card" style="margin-top:12px;">${FIN.heads.map(row).join('') || `<div class="empty">${esc(qt('No custom heads yet.', 'ابھی کوئی مد نہیں۔'))}</div>`}</div>`);
}
let finHT = 'expense';
function finHeadType(ty) { finHT = ty; document.getElementById('fh-income').className = ty === 'income' ? 'on-income' : ''; document.getElementById('fh-expense').className = ty === 'expense' ? 'on-expense' : ''; }
async function finAddHead() {
  const name = (document.getElementById('fh-name').value || '').trim(); if (!name) return;
  const { error } = await sb.from('fin_heads').insert({ owner_id: CURRENT_USER.id, name, type: finHT });
  if (reportSaveError(error)) return;
  await finLoad(); openFinHeads();
}
async function finDelete(table, id) {
  if (!confirm(qt('Delete this?', 'حذف کریں؟'))) return;
  const { error } = await sb.from(table).delete().eq('id', id);
  if (reportSaveError(error)) return;
  if (table === 'fin_accounts') DATA.transactions.forEach(x => { if (x.account_id === id) x.account_id = null; });
  await finLoad(); table === 'fin_heads' ? openFinHeads() : openFinAccounts();
}
// ---- Cash / bank accounts ----
function openFinAccounts() {
  const row = a => `<div class="list-row"><div><div class="nm">${a.kind === 'bank' ? '🏦' : '💵'} ${esc(a.name)}</div>
    <div class="sub">${esc(qt('Opening', 'ابتدائی'))} ₨${fmt(a.opening_balance)} · ${esc(qt('Balance', 'بیلنس'))} ₨${fmt(finAccBalance(a))}</div></div>
    <button class="del-btn" onclick="finDelete('fin_accounts','${a.id}')">✕</button></div>`;
  showModal(qt('Cash & Bank Accounts', 'کیش اور بینک اکاؤنٹس'), `${finSetupNote()}
    <div class="field-box"><label><span>${esc(qt('Account name', 'اکاؤنٹ کا نام'))}</span><input id="fa-name"></label></div>
    <div class="field-box"><label><span>${esc(qt('Type', 'قسم'))}</span><select id="fa-kind"><option value="cash">${esc(qt('Cash in Hand', 'کیش ان ہینڈ'))}</option><option value="bank">${esc(qt('Bank', 'بینک'))}</option></select></label></div>
    <div class="field-box"><label><span>${esc(qt('Opening balance (Rs)', 'ابتدائی بیلنس (روپے)'))}</span><input id="fa-open" type="number" value="0"></label></div>
    <button class="btn-primary" onclick="guardedSubmit(this, finAddAccount)">+ ${esc(qt('Add Account', 'اکاؤنٹ شامل کریں'))}</button>
    <div class="list-card" style="margin-top:12px;">${FIN.accounts.map(row).join('') || `<div class="empty">${esc(qt('No accounts yet.', 'ابھی کوئی اکاؤنٹ نہیں۔'))}</div>`}</div>`);
}
async function finAddAccount() {
  const name = (document.getElementById('fa-name').value || '').trim(); if (!name) return;
  const { error } = await sb.from('fin_accounts').insert({ owner_id: CURRENT_USER.id, name,
    kind: document.getElementById('fa-kind').value, opening_balance: Number(document.getElementById('fa-open').value || 0) });
  if (reportSaveError(error)) return;
  await finLoad(); openFinAccounts();
}
// ---- Day Book & Profit/Loss ----
function finEntries(from, to, acct) {
  const inR = d => { d = String(d || '').slice(0, 10); return d >= from && d <= to; };
  const out = [];
  DATA.transactions.forEach(x => { if (inR(x.txn_date) && (acct === 'all' || x.account_id === acct))
    out.push({ d: String(x.txn_date).slice(0, 10), type: x.type, head: x.category || '—', desc: x.description || '', amt: Number(x.amount || 0), acc: finAccName(x.account_id) }); });
  if (acct === 'all') {
    DATA.feePayments.forEach(p => { if (inR(p.pay_date)) { const s = DATA.students.find(z => z.id === p.student_id);
      out.push({ d: String(p.pay_date).slice(0, 10), type: 'income', head: qt('Fee Collection', 'فیس وصولی'), desc: s ? s.name : '', amt: Number(p.amount || 0), acc: '—' }); } });
    DATA.salaryPayments.forEach(p => { if (inR(p.pay_date)) { const tc = DATA.teachers.find(z => z.id === p.teacher_id);
      out.push({ d: String(p.pay_date).slice(0, 10), type: 'expense', head: qt('Salaries', 'تنخواہیں'), desc: tc ? tc.name : '', amt: Number(p.amount || 0), acc: '—' }); } });
  }
  return out.sort((a, b) => a.d < b.d ? -1 : a.d > b.d ? 1 : 0);
}
function finReportHtml() {
  const { kind, from, to, acct } = FINR, rows = finEntries(from, to, acct);
  const inc = rows.filter(r => r.type === 'income'), exp = rows.filter(r => r.type === 'expense');
  const sum = a => a.reduce((s, r) => s + r.amt, 0);
  const th = 'style="text-align:left;"', num = 'style="text-align:right;"';
  if (kind === 'daybook') {
    return `<table><tr><th ${th}>${esc(t.dateCol)}</th><th ${th}>${esc(qt('Head', 'مد'))}</th><th ${th}>${esc(qt('Details', 'تفصیل'))}</th><th ${th}>${esc(qt('Account', 'اکاؤنٹ'))}</th><th ${num}>${esc(qt('Receipt', 'آمد'))}</th><th ${num}>${esc(qt('Payment', 'خرچ'))}</th></tr>` +
      (rows.map(r => `<tr><td>${esc(fmtDate(r.d))}</td><td>${esc(r.head)}</td><td>${esc(r.desc)}</td><td>${esc(r.acc)}</td><td ${num}>${r.type === 'income' ? fmt(r.amt) : ''}</td><td ${num}>${r.type === 'expense' ? fmt(r.amt) : ''}</td></tr>`).join('') ||
        `<tr><td colspan="6" style="text-align:center;">${esc(t.noTransactions)}</td></tr>`) +
      `<tr style="font-weight:700;"><td colspan="4">${esc(qt('Total', 'کل'))}</td><td ${num}>${fmt(sum(inc))}</td><td ${num}>${fmt(sum(exp))}</td></tr></table>`;
  }
  const group = a => { const m = {}; a.forEach(r => m[r.head] = (m[r.head] || 0) + r.amt); return Object.entries(m).sort((x, y) => y[1] - x[1]); };
  const sec = (title, a) => `<tr><th colspan="2" ${th}>${esc(title)}</th></tr>` + group(a).map(([h, v]) => `<tr><td>${esc(h)}</td><td ${num}>${fmt(v)}</td></tr>`).join('') +
    `<tr style="font-weight:700;"><td>${esc(qt('Total', 'کل'))}</td><td ${num}>${fmt(sum(a))}</td></tr>`;
  const net = sum(inc) - sum(exp);
  return `<table>${sec(qt('Income', 'آمدنی'), inc)}${sec(qt('Expenses', 'اخراجات'), exp)}
    <tr style="font-weight:700;"><td>${esc(net >= 0 ? qt('Net Profit', 'خالص منافع') : qt('Net Loss', 'خالص نقصان'))}</td><td ${num}>${fmt(Math.abs(net))}</td></tr></table>`;
}
function openFinReport(kind) {
  const d = new Date(), y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, '0');
  FINR = { kind, from: `${y}-${m}-01`, to: todayISO(), acct: 'all' };
  const title = kind === 'daybook' ? qt('Day Book', 'روزنامچہ') : qt('Profit & Loss', 'منافع و نقصان');
  showModal(title, `
    <div style="display:flex;gap:8px;"><div class="field-box" style="flex:1"><label><span>${esc(qt('From', 'سے'))}</span><input id="fr-from" type="date" value="${FINR.from}" onchange="finRefresh()"></label></div>
    <div class="field-box" style="flex:1"><label><span>${esc(qt('To', 'تک'))}</span><input id="fr-to" type="date" value="${FINR.to}" onchange="finRefresh()"></label></div></div>
    <div class="field-box"><label><span>${esc(qt('Account', 'اکاؤنٹ'))}</span><select id="fr-acct" onchange="finRefresh()"><option value="all">${esc(qt('All', 'تمام'))}</option>${FIN.accounts.map(a => `<option value="${a.id}">${esc(a.name)}</option>`).join('')}</select></label></div>
    <div id="fr-body" class="fin-report" style="overflow-x:auto;margin-bottom:12px;"></div>
    <button class="btn-primary" onclick="printFinReport()">🖨️ ${esc(qt('Print / Save PDF', 'پرنٹ / پی ڈی ایف'))}</button>
    <button class="btn-ghost" style="width:100%;margin-top:8px;" onclick="exportFinReport()">📥 ${esc(qt('Download Excel', 'ایکسل ڈاؤن لوڈ'))}</button>`);
  finRefresh();
}
function finRefresh() {
  FINR.from = document.getElementById('fr-from').value; FINR.to = document.getElementById('fr-to').value; FINR.acct = document.getElementById('fr-acct').value;
  document.getElementById('fr-body').innerHTML = finReportHtml();
}
function printFinReport() {
  const title = FINR.kind === 'daybook' ? qt('Day Book', 'روزنامچہ') : qt('Profit & Loss Statement', 'منافع و نقصان کا گوشوارہ');
  const acc = FINR.acct === 'all' ? qt('All accounts', 'تمام اکاؤنٹس') : finAccName(FINR.acct);
  document.getElementById('print-area').innerHTML = `<div class="fin-print">
    <h2>${esc(CURRENT_PROFILE.school_name || 'School')}</h2>
    <div class="sub">${esc(title)} · ${esc(fmtDate(FINR.from))} – ${esc(fmtDate(FINR.to))} · ${esc(acc)}</div>
    ${finReportHtml()}
    <div class="foot" style="display:flex;justify-content:space-between;margin-top:40px;"><span>${esc(qt('Prepared By', 'تیار کردہ'))} ____________</span><span>${esc(qt('Approved By', 'منظور کردہ'))} ____________</span></div></div>`;
  // Not cleared on afterprint: Android Chrome fires it as soon as the print preview opens, which emptied the page before the PDF was made.
  window.print();
}
// ---- Excel export + Accounts dashboard (single-entry) ----
function exportFinReport() {
  if (typeof XLSX === 'undefined') { alert(qt('Excel library is not loaded yet. Connect to the internet once and try again.', 'ایکسل لائبریری لوڈ نہیں ہوئی۔ ایک بار انٹرنیٹ سے جڑ کر دوبارہ کوشش کریں۔')); return; }
  const { kind, from, to, acct } = FINR, rows = finEntries(from, to, acct);
  const inc = rows.filter(r => r.type === 'income'), exp = rows.filter(r => r.type === 'expense');
  const sum = a => a.reduce((s, r) => s + r.amt, 0);
  let aoa;
  if (kind === 'daybook') {
    aoa = [['Date', 'Head', 'Details', 'Account', 'Income', 'Expense']];
    rows.forEach(r => aoa.push([fmtDate(r.d), r.head, r.desc, r.acc, r.type === 'income' ? r.amt : '', r.type === 'expense' ? r.amt : '']));
    aoa.push(['Total', '', '', '', sum(inc), sum(exp)]);
  } else {
    const group = a => { const m = {}; a.forEach(r => m[r.head] = (m[r.head] || 0) + r.amt); return Object.entries(m).sort((x, y) => y[1] - x[1]); };
    const net = sum(inc) - sum(exp);
    aoa = [['Income', 'Amount']];
    group(inc).forEach(([h, v]) => aoa.push([h, v]));
    aoa.push(['Total Income', sum(inc)], [], ['Expenses', 'Amount']);
    group(exp).forEach(([h, v]) => aoa.push([h, v]));
    aoa.push(['Total Expenses', sum(exp)], [], [net >= 0 ? 'Net Profit' : 'Net Loss', Math.abs(net)]);
  }
  const wb = XLSX.utils.book_new(), ws = XLSX.utils.aoa_to_sheet(aoa);
  ws['!cols'] = [{ wch: 18 }, { wch: 24 }, { wch: 30 }, { wch: 16 }, { wch: 12 }, { wch: 12 }];
  XLSX.utils.book_append_sheet(wb, ws, kind === 'daybook' ? 'Day Book' : 'Profit and Loss');
  const schoolPart = (CURRENT_PROFILE.school_name || 'school').replace(/[^a-z0-9]+/gi, '_');
  XLSX.writeFile(wb, `${schoolPart}_${kind === 'daybook' ? 'DayBook' : 'ProfitLoss'}_${from}_to_${to}.xlsx`);
}
async function openFinDashboard() {
  if (!FIN.loaded) await finLoad();
  if (!FINV.loaded) await finvLoad();
  const vt = finvTotals();
  const now = new Date(), months = [];
  for (let i = 11; i >= 0; i--) { const d = new Date(now.getFullYear(), now.getMonth() - i, 1); months.push(d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0')); }
  const rows = finEntries(months[0] + '-01', todayISO(), 'all');
  const sum = a => a.reduce((s, r) => s + r.amt, 0);
  const inc = rows.filter(r => r.type === 'income'), exp = rows.filter(r => r.type === 'expense');
  const net = sum(inc) - sum(exp);
  const mi = {}, me = {};
  months.forEach(k => { mi[k] = 0; me[k] = 0; });
  rows.forEach(r => { const k = r.d.slice(0, 7); if (k in mi) { if (r.type === 'income') mi[k] += r.amt; else me[k] += r.amt; } });
  const mx = Math.max(1, ...months.map(k => Math.max(mi[k], me[k])));
  const MN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const bars = months.map(k => `<div style="flex:1;min-width:0;text-align:center;">
      <div style="height:100px;display:flex;align-items:flex-end;justify-content:center;gap:2px;">
        <div title="${fmt(mi[k])}" style="width:42%;height:${Math.round(mi[k] / mx * 100)}px;background:#2e9e5b;border-radius:3px 3px 0 0;"></div>
        <div title="${fmt(me[k])}" style="width:42%;height:${Math.round(me[k] / mx * 100)}px;background:#d9534f;border-radius:3px 3px 0 0;"></div>
      </div><div style="font-size:9px;opacity:.7;margin-top:3px;">${MN[Number(k.slice(5)) - 1]}</div></div>`).join('');
  const m = {}; exp.forEach(r => m[r.head] = (m[r.head] || 0) + r.amt);
  let cats = Object.entries(m).sort((a, b) => b[1] - a[1]);
  if (cats.length > 6) { const rest = cats.slice(5).reduce((s, c) => s + c[1], 0); cats = cats.slice(0, 5).concat([[qt('Others', 'دیگر'), rest]]); }
  const COL = ['#1f4e8c', '#e8a33d', '#2e9e5b', '#d9534f', '#8e5bb5', '#17a2b8'];
  const tot = Math.max(1, sum(exp)); let acc = 0;
  const stops = cats.map((c, i) => { const a = acc / tot * 100; acc += c[1]; return `${COL[i % 6]} ${a}% ${acc / tot * 100}%`; }).join(',');
  const legend = cats.map((c, i) => `<div style="display:flex;align-items:center;gap:6px;font-size:12px;margin:3px 0;"><span style="width:10px;height:10px;border-radius:2px;background:${COL[i % 6]};flex:none;"></span><span style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;">${esc(c[0])}</span><b>${fmt(c[1])}</b></div>`).join('');
  const bal = k => FIN.accounts.filter(a => (a.kind === 'bank') === k).reduce((s, a) => s + finAccBalance(a), 0);
  const card = (label, val, color) => `<div class="card" style="padding:10px 12px;flex:1;min-width:120px;"><div style="font-size:11px;opacity:.65;">${esc(label)}</div><div style="font-weight:700;color:${color || 'var(--navy)'};">Rs${fmt(val)}</div></div>`;
  let dues = 0; try { dues = computeStats().totalDuesAllTime || 0; } catch (e) { }
  showModal(qt('Accounts Dashboard', 'اکاؤنٹس ڈیش بورڈ'), `
    <div style="font-size:11px;opacity:.65;margin-bottom:6px;">${esc(qt('Last 12 months', 'پچھلے 12 مہینے'))}</div>
    <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:8px;">
      ${card(qt('Total Income', 'کل آمدن'), sum(inc), '#2e9e5b')}${card(qt('Total Expense', 'کل اخراجات'), sum(exp), '#d9534f')}${card(net >= 0 ? qt('Net Profit', 'خالص منافع') : qt('Net Loss', 'خالص نقصان'), Math.abs(net))}</div>
    <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px;">
      ${card(qt('Cash Balance', 'کیش بیلنس'), bal(false))}${card(qt('Bank Balance', 'بینک بیلنس'), bal(true))}${card(qt('Fee Receivable', 'فیس وصولی باقی'), dues, '#e8a33d')}${FINV.err ? '' : card(qt('Vendor Payable', 'وینڈرز کو ادا کرنا'), vt.pay, '#d9534f')}</div>
    <div style="font-weight:700;font-size:13px;margin-bottom:6px;">${esc(qt('Monthly Cash Flow', 'ماہانہ کیش فلو'))} <span style="font-weight:400;font-size:11px;"><span style="color:#2e9e5b;">■</span> ${esc(qt('Income', 'آمدن'))} <span style="color:#d9534f;">■</span> ${esc(qt('Expense', 'اخراجات'))}</span></div>
    <div style="display:flex;gap:3px;margin-bottom:14px;">${bars}</div>
    <div style="font-weight:700;font-size:13px;margin-bottom:6px;">${esc(qt('Expense Categories', 'اخراجات کی اقسام'))}</div>
    ${cats.length ? `<div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap;"><div style="width:110px;height:110px;border-radius:50%;background:conic-gradient(${stops});flex:none;"></div><div style="flex:1;min-width:150px;">${legend}</div></div>` : `<div style="font-size:12px;opacity:.7;">${esc(t.noTransactions)}</div>`}`);
}
// ---- Vendors / Suppliers / Agents: payable & receivable (single-entry) ----
const FINV = { vendors: [], entries: [], loaded: false, err: false };
let FINV_TYPE = 'bill', FINV_CUR = null;
async function finvLoad() {
  FINV.loaded = true;
  try {
    const [v, e] = await Promise.all([
      sb.from('fin_vendors').select('*').order('name'),
      sb.from('fin_vendor_entries').select('*').order('entry_date').order('created_at')
    ]);
    FINV.err = !!(v.error || e.error);
    FINV.vendors = v.data || []; FINV.entries = e.data || [];
  } catch (err) { FINV.err = true; }
}
function finvSum(id, type) { return FINV.entries.filter(x => x.vendor_id === id && x.entry_type === type).reduce((s, x) => s + Number(x.amount || 0), 0); }
function finvBalance(id) { return Math.round((finvSum(id, 'bill') - finvSum(id, 'payment')) * 100) / 100; }
function finvTotals() { let pay = 0, rec = 0; FINV.vendors.forEach(v => { const b = finvBalance(v.id); if (b > 0) pay += b; else rec -= b; }); return { pay, rec }; }
function finvKindLabel(k) { return k === 'supplier' ? qt('Supplier', 'سپلائر') : k === 'agent' ? qt('Agent', 'ایجنٹ') : qt('Vendor', 'وینڈر'); }
function finvSetupNote() {
  return FINV.err ? `<div class="err">${esc(qt('Vendor tables are not set up yet. Run the "ONE-TIME SETUP for Vendors" SQL (top of index.html) in Supabase.', 'وینڈر ٹیبل ابھی نہیں بنے۔ index.html کے شروع میں دی گئی Vendors والی SQL سپابیس میں چلائیں۔'))}</div>` : '';
}
async function openFinVendors() {
  if (!FINV.loaded) await finvLoad();
  const tt = finvTotals();
  const row = v => {
    const b = finvBalance(v.id);
    const lbl = b > 0 ? qt('Payable', 'ادا کرنا ہے') : b < 0 ? qt('Receivable', 'وصول کرنا ہے') : qt('Settled', 'برابر');
    const col = b > 0 ? '#d9534f' : b < 0 ? '#2e9e5b' : 'inherit';
    return `<div class="list-row" style="cursor:pointer;" onclick="openFinVendor('${v.id}')"><div><div class="nm">${esc(v.name)}</div><div class="sub">${esc(finvKindLabel(v.kind))}${v.contact ? ' · ' + esc(v.contact) : ''}</div></div>
      <div style="text-align:right;margin-left:auto;"><div style="font-weight:700;color:${col};">Rs${fmt(Math.abs(b))}</div><div class="sub">${esc(lbl)}</div></div>
      <button class="del-btn" onclick="event.stopPropagation();finvDeleteVendor('${v.id}')">✕</button></div>`;
  };
  const card = (label, val, color) => `<div class="card" style="padding:10px 12px;flex:1;min-width:120px;"><div style="font-size:11px;opacity:.65;">${esc(label)}</div><div style="font-weight:700;color:${color};">Rs${fmt(val)}</div></div>`;
  showModal(qt('Vendors / Suppliers / Agents', 'وینڈرز / سپلائرز / ایجنٹس'), `${finvSetupNote()}
    <div style="display:flex;gap:8px;margin-bottom:10px;">${card(qt('Net Payable', 'کل ادا کرنا ہے'), tt.pay, '#d9534f')}${card(qt('Net Receivable', 'کل وصول کرنا ہے'), tt.rec, '#2e9e5b')}</div>
    <div class="field-box"><label><span>${esc(qt('Name', 'نام'))}</span><input id="vn-name"></label></div>
    <div style="display:flex;gap:8px;"><div class="field-box" style="flex:1"><label><span>${esc(qt('Type', 'قسم'))}</span><select id="vn-kind"><option value="vendor">${esc(finvKindLabel('vendor'))}</option><option value="supplier">${esc(finvKindLabel('supplier'))}</option><option value="agent">${esc(finvKindLabel('agent'))}</option></select></label></div>
    <div class="field-box" style="flex:1"><label><span>${esc(qt('Phone (optional)', 'فون (اختیاری)'))}</span><input id="vn-contact"></label></div></div>
    <button class="btn-primary" onclick="guardedSubmit(this, finvAddVendor)">+ ${esc(qt('Add', 'شامل کریں'))}</button>
    <div class="list-card" style="margin-top:12px;">${FINV.vendors.map(row).join('') || `<div class="empty">${esc(qt('No vendors yet.', 'ابھی کوئی وینڈر نہیں۔'))}</div>`}</div>
    ${FINV.vendors.length ? `<button class="btn-ghost" style="width:100%;margin-top:10px;" onclick="exportVendorsSummary()">📥 ${esc(qt('Download Excel', 'ایکسل ڈاؤن لوڈ'))}</button>` : ''}`);
}
async function finvAddVendor() {
  const name = (document.getElementById('vn-name').value || '').trim(); if (!name) return;
  const { error } = await sb.from('fin_vendors').insert({ owner_id: CURRENT_USER.id, name, kind: document.getElementById('vn-kind').value, contact: (document.getElementById('vn-contact').value || '').trim() || null });
  if (reportSaveError(error)) return;
  await finvLoad(); openFinVendors();
}
async function finvDeleteVendor(id) {
  if (!confirm(qt('Delete this vendor and all its entries? (Payments already in the Day Book stay there.)', 'یہ وینڈر اور اس کی تمام اندراجات حذف کریں؟ (ڈے بک میں درج ادائیگیاں رہیں گی۔)'))) return;
  const { error } = await sb.from('fin_vendors').delete().eq('id', id);
  if (reportSaveError(error)) return;
  await finvLoad(); openFinVendors();
}
function finvType(ty) {
  FINV_TYPE = ty;
  document.getElementById('vd-bill').className = ty === 'bill' ? 'on-expense' : '';
  document.getElementById('vd-pay').className = ty === 'payment' ? 'on-income' : '';
  const a = document.getElementById('vd-accbox'); if (a) a.style.display = ty === 'payment' ? '' : 'none';
}
async function openFinVendor(id) {
  if (!FIN.loaded) await finLoad();
  const v = FINV.vendors.find(x => x.id === id); if (!v) return;
  FINV_CUR = id; FINV_TYPE = 'bill';
  let run = 0;
  const rows = FINV.entries.filter(x => x.vendor_id === id).map(x => {
    run += (x.entry_type === 'bill' ? 1 : -1) * Number(x.amount || 0);
    return `<div class="list-row"><div><div class="nm">${x.entry_type === 'bill' ? esc(qt('Bill', 'بل')) : esc(qt('Paid', 'ادائیگی'))} · Rs${fmt(x.amount)}</div>
      <div class="sub">${esc(fmtDate(x.entry_date))}${x.note ? ' · ' + esc(x.note) : ''} · ${esc(qt('Balance', 'بیلنس'))} Rs${fmt(Math.round(run * 100) / 100)}</div></div>
      <button class="del-btn" onclick="finvDeleteEntry('${x.id}')">✕</button></div>`;
  }).reverse();
  const b = finvBalance(id);
  const lbl = b > 0 ? qt('Payable', 'ادا کرنا ہے') : b < 0 ? qt('Receivable', 'وصول کرنا ہے') : qt('Settled', 'برابر');
  const accOpts = FIN.accounts.map(a => `<option value="${a.id}">${esc(a.name)} (${a.kind === 'bank' ? esc(qt('Bank', 'بینک')) : esc(qt('Cash', 'کیش'))})</option>`).join('')
    + `<option value="__none">${esc(qt('Day Book only (no account)', 'صرف ڈے بک (اکاؤنٹ کے بغیر)'))}</option><option value="__skip">${esc(qt('Do not record in Day Book', 'ڈے بک میں درج نہ کریں'))}</option>`;
  showModal(v.name, `${finvSetupNote()}
    <div class="sub" style="margin-bottom:6px;">${esc(finvKindLabel(v.kind))}${v.contact ? ' · ' + esc(v.contact) : ''}</div>
    <div class="card" style="padding:10px 12px;margin-bottom:10px;"><div style="font-size:11px;opacity:.65;">${esc(lbl)}</div><div style="font-weight:700;font-size:18px;color:${b > 0 ? '#d9534f' : b < 0 ? '#2e9e5b' : 'inherit'};">Rs${fmt(Math.abs(b))}</div></div>
    <div class="type-toggle"><button id="vd-bill" class="on-expense" onclick="finvType('bill')">${esc(qt('Bill (we owe)', 'بل (ہم نے دینا ہے)'))}</button><button id="vd-pay" onclick="finvType('payment')">${esc(qt('Payment (we paid)', 'ادائیگی (ہم نے دی)'))}</button></div>
    <div style="display:flex;gap:8px;"><div class="field-box" style="flex:1"><label><span>${esc(qt('Amount (Rs)', 'رقم (روپے)'))}</span><input id="vd-amt" type="number" inputmode="decimal"></label></div>
    <div class="field-box" style="flex:1"><label><span>${esc(qt('Date', 'تاریخ'))}</span><input id="vd-date" type="date" value="${todayISO()}"></label></div></div>
    <div class="field-box"><label><span>${esc(qt('Note (optional)', 'نوٹ (اختیاری)'))}</span><input id="vd-note"></label></div>
    <div class="field-box" id="vd-accbox" style="display:none;"><label><span>${esc(qt('Paid from', 'کہاں سے ادا کی'))}</span><select id="vd-acc">${accOpts}</select></label></div>
    <button class="btn-primary" onclick="guardedSubmit(this, finvAddEntry)">+ ${esc(qt('Save Entry', 'اندراج محفوظ کریں'))}</button>
    <div class="list-card" style="margin-top:12px;">${rows.join('') || `<div class="empty">${esc(qt('No entries yet.', 'ابھی کوئی اندراج نہیں۔'))}</div>`}</div>
    <div style="display:flex;gap:8px;margin-top:10px;"><button class="btn-ghost" style="flex:1;" onclick="printVendorStatement()">🖨️ ${esc(qt('Print', 'پرنٹ'))}</button><button class="btn-ghost" style="flex:1;" onclick="exportVendorStatement()">📥 Excel</button></div>
    <button class="btn-ghost" style="width:100%;margin-top:8px;" onclick="openFinVendors()">← ${esc(qt('All vendors', 'تمام وینڈرز'))}</button>`);
}
async function finvAddEntry() {
  const amt = Number(document.getElementById('vd-amt').value || 0); if (!(amt > 0)) return;
  const date = document.getElementById('vd-date').value || todayISO();
  const note = (document.getElementById('vd-note').value || '').trim() || null;
  const v = FINV.vendors.find(x => x.id === FINV_CUR); if (!v) return;
  let txn_id = null;
  if (FINV_TYPE === 'payment') {
    const sel = document.getElementById('vd-acc').value;
    if (sel !== '__skip') {
      const payload = { owner_id: CURRENT_USER.id, type: 'expense', category: qt('Vendor Payments', 'وینڈر ادائیگیاں'), description: v.name + (note ? ' - ' + note : ''), amount: amt, txn_date: date };
      if (sel && sel !== '__none') payload.account_id = sel;
      const r = await sb.from('transactions').insert(payload).select('id').single();
      if (reportSaveError(r.error)) return;
      txn_id = r.data ? r.data.id : null;
    }
  }
  const { error } = await sb.from('fin_vendor_entries').insert({ owner_id: CURRENT_USER.id, vendor_id: FINV_CUR, entry_type: FINV_TYPE, amount: amt, entry_date: date, note, txn_id });
  if (reportSaveError(error)) { if (txn_id) await sb.from('transactions').delete().eq('id', txn_id); return; }
  await finvLoad(); if (txn_id) await loadAllData();
  openFinVendor(FINV_CUR);
}
async function finvDeleteEntry(id) {
  const e = FINV.entries.find(x => x.id === id); if (!e) return;
  if (!confirm(qt('Delete this entry?', 'یہ اندراج حذف کریں؟') + (e.txn_id ? '\n' + qt('Its Day Book payment will also be removed.', 'ڈے بک کی ادائیگی بھی ہٹ جائے گی۔') : ''))) return;
  const { error } = await sb.from('fin_vendor_entries').delete().eq('id', id);
  if (reportSaveError(error)) return;
  if (e.txn_id) { await sb.from('transactions').delete().eq('id', e.txn_id); await loadAllData(); }
  await finvLoad(); openFinVendor(FINV_CUR);
}
function finvStatementRows(id) {
  let run = 0;
  return FINV.entries.filter(x => x.vendor_id === id).map(x => {
    const bill = x.entry_type === 'bill' ? Number(x.amount) : 0, paid = x.entry_type === 'payment' ? Number(x.amount) : 0;
    run = Math.round((run + bill - paid) * 100) / 100;
    return { d: String(x.entry_date).slice(0, 10), note: x.note || '', bill, paid, bal: run };
  });
}
function printVendorStatement() {
  const v = FINV.vendors.find(x => x.id === FINV_CUR); if (!v) return;
  const rows = finvStatementRows(v.id), b = finvBalance(v.id);
  const num = 'style="text-align:right;"';
  document.getElementById('print-area').innerHTML = `<div class="fin-print">
    <h2>${esc(CURRENT_PROFILE.school_name || 'School')}</h2>
    <div class="sub">${esc(qt('Account Statement', 'اکاؤنٹ اسٹیٹمنٹ'))} · ${esc(v.name)} (${esc(finvKindLabel(v.kind))})${v.contact ? ' · ' + esc(v.contact) : ''}</div>
    <table><tr><th style="text-align:left;">${esc(qt('Date', 'تاریخ'))}</th><th style="text-align:left;">${esc(qt('Details', 'تفصیل'))}</th><th ${num}>${esc(qt('Bill', 'بل'))}</th><th ${num}>${esc(qt('Paid', 'ادائیگی'))}</th><th ${num}>${esc(qt('Balance', 'بیلنس'))}</th></tr>
    ${rows.map(r => `<tr><td>${esc(fmtDate(r.d))}</td><td>${esc(r.note)}</td><td ${num}>${r.bill ? fmt(r.bill) : ''}</td><td ${num}>${r.paid ? fmt(r.paid) : ''}</td><td ${num}>${fmt(r.bal)}</td></tr>`).join('')}
    <tr style="font-weight:700;"><td colspan="4">${esc(b > 0 ? qt('Payable', 'ادا کرنا ہے') : b < 0 ? qt('Receivable', 'وصول کرنا ہے') : qt('Settled', 'برابر'))}</td><td ${num}>${fmt(Math.abs(b))}</td></tr></table>
    <div class="foot" style="display:flex;justify-content:space-between;margin-top:40px;"><span>${esc(qt('Prepared By', 'تیار کردہ'))} ____________</span><span>${esc(qt('Approved By', 'منظور کنندہ'))} ____________</span></div></div>`;
  window.print();
}
function finvXlsxOk() {
  if (typeof XLSX === 'undefined') { alert(qt('Excel library is not loaded yet. Connect to the internet once and try again.', 'ایکسل لائبریری لوڈ نہیں ہوئی۔ ایک بار انٹرنیٹ سے جڑ کر دوبارہ کوشش کریں۔')); return false; }
  return true;
}
function exportVendorStatement() {
  const v = FINV.vendors.find(x => x.id === FINV_CUR); if (!v || !finvXlsxOk()) return;
  const aoa = [['Date', 'Details', 'Bill', 'Paid', 'Balance']];
  finvStatementRows(v.id).forEach(r => aoa.push([fmtDate(r.d), r.note, r.bill || '', r.paid || '', r.bal]));
  const b = finvBalance(v.id);
  aoa.push([b > 0 ? 'Payable' : b < 0 ? 'Receivable' : 'Settled', '', '', '', Math.abs(b)]);
  const wb = XLSX.utils.book_new(), ws = XLSX.utils.aoa_to_sheet(aoa);
  ws['!cols'] = [{ wch: 14 }, { wch: 30 }, { wch: 12 }, { wch: 12 }, { wch: 12 }];
  XLSX.utils.book_append_sheet(wb, ws, 'Statement');
  const schoolPart = (CURRENT_PROFILE.school_name || 'school').replace(/[^a-z0-9]+/gi, '_');
  XLSX.writeFile(wb, `${schoolPart}_Vendor_${v.name.replace(/[^a-z0-9]+/gi, '_')}.xlsx`);
}
function exportVendorsSummary() {
  if (!finvXlsxOk()) return;
  const aoa = [['Name', 'Type', 'Phone', 'Billed', 'Paid', 'Balance', 'Status']];
  FINV.vendors.forEach(v => { const b = finvBalance(v.id); aoa.push([v.name, v.kind, v.contact || '', finvSum(v.id, 'bill'), finvSum(v.id, 'payment'), Math.abs(b), b > 0 ? 'Payable' : b < 0 ? 'Receivable' : 'Settled']); });
  const tt = finvTotals();
  aoa.push([], ['Net Payable', '', '', '', '', tt.pay], ['Net Receivable', '', '', '', '', tt.rec]);
  const wb = XLSX.utils.book_new(), ws = XLSX.utils.aoa_to_sheet(aoa);
  ws['!cols'] = [{ wch: 24 }, { wch: 12 }, { wch: 14 }, { wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 12 }];
  XLSX.utils.book_append_sheet(wb, ws, 'Vendors');
  const schoolPart = (CURRENT_PROFILE.school_name || 'school').replace(/[^a-z0-9]+/gi, '_');
  XLSX.writeFile(wb, `${schoolPart}_Vendors_${fmtDate(todayISO())}.xlsx`);
}
(function () { const s = document.createElement('style');
  s.textContent = '.fin-report table,.fin-print table{width:100%;border-collapse:collapse;}.fin-report th,.fin-report td,.fin-print th,.fin-print td{border:1px solid #bbb;padding:5px 7px;font-size:12px;}.fin-report th,.fin-print th{background:#0F2740;color:#E4C765;}.fin-print h2{font-family:Fraunces,serif;color:#0F2740;margin:0 0 2px;}.fin-print .sub{color:#555;font-size:12px;margin-bottom:10px;}';
  document.head.appendChild(s); })();

