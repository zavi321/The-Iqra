/* SchoolMS — notices.js — split from index.html (lines 12440-13882). Load order matters: see index.html */
// =====================================================================
// NOTICE BOARD
// The owner writes a text notice and taps who it is for: Teachers,
// Parents, or both. Teachers (class + diary portals) and parents read it
// through the notice_list_* functions created by notice_board.sql.
// Text only (no photos/videos) so it is very light on Supabase egress.
// =====================================================================
let NOTICES = [];
let NOTICE_AUD = 'teachers';
let NOTICE_EDIT_ID = null;

// Keeps only simple formatting (bold / italic / underline / line breaks / lists).
// Everything else (scripts, links, styles, attributes) is stripped, so a notice can never inject code.
function noticeClean(html) {
  const allowed = { B:1, STRONG:1, I:1, EM:1, U:1, BR:1, DIV:1, P:1, UL:1, OL:1, LI:1 };
  const doc = new DOMParser().parseFromString('<body>' + String(html || '') + '</body>', 'text/html');
  const walk = (node) => {
    let out = '';
    node.childNodes.forEach(ch => {
      if (ch.nodeType === 3) { out += esc(ch.nodeValue); return; }
      if (ch.nodeType !== 1) return;
      const tag = ch.tagName;
      if (tag === 'SCRIPT' || tag === 'STYLE') return;
      const inner = walk(ch);
      if (tag === 'BR') out += '<br>';
      else if (allowed[tag]) { const tg = tag.toLowerCase(); out += '<' + tg + '>' + inner + '</' + tg + '>'; }
      else out += inner;
    });
    return out;
  };
  return walk(doc.body);
}
function noticeToText(html) {
  const d = document.createElement('div');
  d.innerHTML = noticeClean(html).replace(/<br\s*\/?>/gi, '\n').replace(/<\/(div|p|li)>/gi, '\n');
  return (d.textContent || '').replace(/\n{3,}/g, '\n\n').trim();
}
function noticeAudLabel(a) {
  return a === 'teachers' ? qt('Teachers', 'اساتذہ') : a === 'parents' ? qt('Parents', 'والدین') : qt('Teachers & Parents', 'اساتذہ اور والدین');
}
function noticeAudColor(a) { return a === 'teachers' ? '#2f6fab' : a === 'parents' ? '#2e8b57' : '#b8860b'; }

// ---------- Owner side ----------
function tplNotices() {
  const chip = (k) => `<button type="button" id="nt-aud-${k}" onclick="noticeSetAud('${k}')" style="flex:1;padding:10px 6px;border-radius:10px;font-weight:700;font-size:13px;cursor:pointer;border:2px solid ${noticeAudColor(k)};background:${NOTICE_AUD === k ? noticeAudColor(k) : 'transparent'};color:${NOTICE_AUD === k ? '#fff' : noticeAudColor(k)};">${esc(noticeAudLabel(k))}</button>`;
  const tb = (cmd, label, style) => `<button type="button" onmousedown="event.preventDefault()" onclick="document.execCommand('${cmd}')" style="flex:none;width:38px;padding:6px 0;border-radius:8px;border:1px solid var(--line);background:transparent;color:inherit;cursor:pointer;${style}">${label}</button>`;
  return `
    <h2>${esc(qt('Notice Board', 'نوٹس بورڈ'))}</h2>
    <p class="desc">${esc(qt('Write a notice and tap who it is for. It appears in the Teachers\' or Parents\' portal.', 'نوٹس لکھیں اور منتخب کریں کہ یہ کس کے لیے ہے۔ یہ اساتذہ یا والدین کے پورٹل میں نظر آئے گا۔'))}</p>
    <button class="btn-primary" style="width:100%;margin-bottom:12px;" onclick="chOpen('owner')">💬 ${esc(qt('Chat & voice message', 'چیٹ اور وائس میسج'))}</button>
    <div class="card">
      <div id="notice-form-title" class="section-title" style="margin-top:0;">${esc(qt('New notice', 'نیا نوٹس'))}</div>
      <div style="font-size:12px;opacity:.7;margin-bottom:6px;">${esc(qt('Send to', 'بھیجیں'))}</div>
      <div style="display:flex;gap:8px;margin-bottom:12px;">${chip('teachers')}${chip('parents')}${chip('both')}</div>
      <label><span>${esc(qt('Topic', 'عنوان'))}</span><input id="notice-topic" maxlength="100" oninput="noticeDraftSave()" placeholder="${esc(qt('e.g. Holiday on Friday', 'مثلاً جمعہ کی چھٹی'))}"></label>
      <div style="font-size:12px;opacity:.7;margin:10px 0 6px;">${esc(qt('Details', 'تفصیل'))}</div>
      <div style="display:flex;gap:6px;margin-bottom:6px;">${tb('bold', '<b>B</b>', '')}${tb('italic', '<i>I</i>', '')}${tb('underline', '<u>U</u>', '')}</div>
      <div id="notice-details" contenteditable="true" oninput="noticeCount();noticeDraftSave()" onpaste="event.preventDefault();document.execCommand('insertText',false,(event.clipboardData||window.clipboardData).getData('text'))" style="min-height:120px;max-height:260px;overflow:auto;padding:10px 12px;border:1px solid var(--line);border-radius:10px;font-size:14px;line-height:1.5;outline:none;"></div>
      <div id="notice-count" style="text-align:right;font-size:11px;opacity:.6;margin:4px 0 10px;">0 / 1000</div>
      <button class="btn-primary" id="notice-publish-btn" style="width:100%;" onclick="noticePublish()">${esc(qt('Publish notice', 'نوٹس شائع کریں'))}</button>
      <button class="btn-ghost hidden" id="notice-cancel-btn" style="width:100%;margin-top:8px;" onclick="noticeCancelEdit()">${esc(qt('Cancel editing', 'ایڈیٹ منسوخ کریں'))}</button>
      <div id="notice-msg" style="margin-top:8px;"></div>
    </div>
    <div class="section-title" style="margin-top:16px;">${esc(qt('Published notices', 'شائع شدہ نوٹس'))}</div>
    <div id="notice-list"><div class="empty">…</div></div>
    <div class="section-title" style="margin-top:16px;">${esc(qt('Messages from parents', 'والدین کے پیغامات'))}</div>
    <div id="pm-owner-list"><div class="empty">…</div></div>
  `;
}

function noticeUuid() {
  if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => { const r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 3 | 8)).toString(16); });
}
function noticeDraftKey() { return 'notice_draft_' + (CURRENT_USER ? CURRENT_USER.id : ''); }
function noticeOwnerKey() { return 'notices_owner_' + (CURRENT_USER ? CURRENT_USER.id : ''); }
// A half-written notice is kept on the phone, so nothing is lost if the page reloads or the app is closed.
function noticeDraftSave() {
  if (NOTICE_EDIT_ID) return;
  const t0 = document.getElementById('notice-topic'), d0 = document.getElementById('notice-details');
  if (!t0 || !d0) return;
  try { localStorage.setItem(noticeDraftKey(), JSON.stringify({ aud: NOTICE_AUD, topic: t0.value, details: d0.innerHTML })); } catch (e) {}
}
function noticeDraftClear() { try { localStorage.removeItem(noticeDraftKey()); } catch (e) {} }
function noticeInit() {
  NOTICE_EDIT_ID = null;
  try {
    const dr = JSON.parse(localStorage.getItem(noticeDraftKey()) || 'null');
    if (dr) {
      if (dr.aud) { NOTICE_AUD = dr.aud; noticePaintAud(); }
      const t0 = document.getElementById('notice-topic'), d0 = document.getElementById('notice-details');
      if (t0) t0.value = dr.topic || '';
      if (d0) d0.innerHTML = noticeClean(dr.details || '');
      noticeCount();
    }
  } catch (e) {}
  noticeLoad();
}

function noticePaintAud() {
  ['teachers', 'parents', 'both'].forEach(k => {
    const b = document.getElementById('nt-aud-' + k); if (!b) return;
    b.style.background = NOTICE_AUD === k ? noticeAudColor(k) : 'transparent';
    b.style.color = NOTICE_AUD === k ? '#fff' : noticeAudColor(k);
  });
}
function noticeSetAud(k) { NOTICE_AUD = k; noticePaintAud(); noticeDraftSave(); }

function noticeCount() {
  const ed = document.getElementById('notice-details'), c = document.getElementById('notice-count');
  if (!ed || !c) return;
  const n = (ed.textContent || '').length;
  c.textContent = n + ' / 1000';
  c.style.color = n > 1000 ? '#c0392b' : '';
  c.style.opacity = n > 1000 ? '1' : '.6';
}

function noticeSaveCache() {
  try { localStorage.setItem(noticeOwnerKey(), JSON.stringify(NOTICES.map(n => { const c = Object.assign({}, n); delete c._pending; return c; }))); } catch (e) {}
}
// Notices written while offline wait in the app's sync queue; show them (marked) until they are sent.
async function noticeMergePending(list) {
  let q = [];
  try { q = (await idbGetAll('sync_queue')) || []; } catch (e) {}
  q = q.filter(x => x.table === 'notices').sort((a, b) => (a.ts || 0) - (b.ts || 0));
  let out = list.slice();
  q.forEach(it => {
    if (it.action === 'insert' && it.payload) {
      const i = out.findIndex(n => n.id === it.payload.id);
      if (i < 0) out.unshift(Object.assign({ _pending: true }, it.payload));
      else out[i] = Object.assign({}, out[i], it.payload, { _pending: true });
    } else if (it.action === 'update' && it.payload) {
      const i = out.findIndex(n => n.id === it.id);
      if (i >= 0) out[i] = Object.assign({}, out[i], it.payload, { _pending: true });
    } else if (it.action === 'delete') {
      out = out.filter(n => n.id !== it.id);
    }
  });
  out.sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)));
  return out;
}
async function noticeLoad() {
  const box = document.getElementById('notice-list'); if (!box) return;
  let list = null, err = null;
  if (navigator.onLine) {
    try {
      const { data, error } = await sb.from('notices').select('*').eq('owner_id', CURRENT_USER.id).order('created_at', { ascending: false }).limit(50);
      if (error) err = error; else list = data || [];
    } catch (e) { err = e; }
  }
  if (list === null) {
    try { list = JSON.parse(localStorage.getItem(noticeOwnerKey()) || 'null'); } catch (e) {}
    if (!list && err && !isNetworkError(err)) {
      const m = (err.message || '');
      const missing = /notices/.test(m) && /(does not exist|schema cache|relation)/i.test(m);
      box.innerHTML = `<div class="err">${esc(missing ? qt('Notice Board is not set up yet (run notice_board.sql in Supabase).', 'نوٹس بورڈ ابھی سیٹ اپ نہیں ہوا (Supabase میں notice_board.sql چلائیں)۔') : m)}</div>`;
      return;
    }
    list = list || [];
  } else {
    try { localStorage.setItem(noticeOwnerKey(), JSON.stringify(list)); } catch (e) {}
  }
  NOTICES = await noticeMergePending(list);
  // Repaint only when something actually changed, so the page never jumps while the owner is typing.
  const sig = JSON.stringify(NOTICES);
  if (box.dataset.painted === '1' && box.dataset.sig === sig) return;
  box.dataset.sig = sig; box.dataset.painted = '1';
  noticeRenderList();
}

function noticeRenderList() {
  const box = document.getElementById('notice-list'); if (!box) return;
  if (!NOTICES.length) { box.innerHTML = `<div class="empty">${esc(qt('No notices yet.', 'ابھی کوئی نوٹس نہیں۔'))}</div>`; return; }
  box.innerHTML = NOTICES.map(n => `
    <div class="card" style="margin-bottom:10px;">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:6px;">
        <span style="font-size:11px;font-weight:700;color:#fff;background:${noticeAudColor(n.audience)};padding:3px 10px;border-radius:999px;">${esc(noticeAudLabel(n.audience))}</span>
        <span style="font-size:11px;opacity:.6;">${n._pending ? '⏳ ' + esc(qt('Waiting for internet', 'انٹرنیٹ کا انتظار')) + ' · ' : ''}${esc(fmtDate((n.created_at || '').slice(0, 10)) || '')}</span>
      </div>
      <div style="font-weight:700;font-size:15px;margin-bottom:6px;">${esc(n.topic)}</div>
      <div style="font-size:13px;line-height:1.5;">${noticeClean(n.details)}</div>
      <div style="display:flex;gap:8px;margin-top:12px;">
        <button class="btn-ghost" style="flex:1;padding:8px 6px;font-size:12px;" onclick="noticeEdit('${n.id}')">✏️ ${esc(qt('Edit', 'ایڈیٹ'))}</button>
        <button class="btn-ghost" style="flex:1;padding:8px 6px;font-size:12px;" onclick="noticeShareWA('${n.id}')">WhatsApp</button>
        <button class="btn-ghost" style="flex:1;padding:8px 6px;font-size:12px;" onclick="noticeDelete('${n.id}')">🗑 ${esc(qt('Delete', 'حذف'))}</button>
      </div>
    </div>`).join('');
}

async function noticePublish() {
  const topicEl = document.getElementById('notice-topic'), ed = document.getElementById('notice-details'), msg = document.getElementById('notice-msg'), btn = document.getElementById('notice-publish-btn');
  if (!topicEl || !ed || !msg) return;
  const topic = topicEl.value.trim();
  const plainLen = (ed.textContent || '').trim().length;
  const details = noticeClean(ed.innerHTML).trim();
  if (!topic) { msg.innerHTML = `<div class="err">${esc(qt('Please write a topic.', 'براہ کرم عنوان لکھیں۔'))}</div>`; return; }
  if (!plainLen) { msg.innerHTML = `<div class="err">${esc(qt('Please write the notice details.', 'براہ کرم نوٹس کی تفصیل لکھیں۔'))}</div>`; return; }
  if (plainLen > 1000 || details.length > 6000) { msg.innerHTML = `<div class="err">${esc(qt('Details are too long (max 1000 characters).', 'تفصیل بہت لمبی ہے (زیادہ سے زیادہ 1000 حروف)۔'))}</div>`; return; }
  if (btn) btn.disabled = true;
  const wasEdit = !!NOTICE_EDIT_ID;
  let res;
  try {
    if (wasEdit) {
      const id = NOTICE_EDIT_ID;
      const payload = { audience: NOTICE_AUD, topic, details, updated_at: new Date().toISOString() };
      res = await offlineWrite({
        table: 'notices', action: 'update', payload, id, baseRow: null,
        run: () => sb.from('notices').update(payload).eq('id', id),
        optimisticApply: () => { NOTICES = NOTICES.map(n => n.id === id ? Object.assign({}, n, payload) : n); noticeSaveCache(); }
      });
    } else {
      const payload = { id: noticeUuid(), owner_id: CURRENT_USER.id, audience: NOTICE_AUD, topic, details, created_at: new Date().toISOString() };
      res = await offlineWrite({
        table: 'notices', action: 'insert', payload, id: payload.id, baseRow: null,
        run: () => sb.from('notices').insert(payload),
        optimisticApply: () => { NOTICES.unshift(Object.assign({}, payload)); noticeSaveCache(); }
      });
    }
  } catch (e) { res = { error: e }; }
  if (btn) btn.disabled = false;
  if (res && res.error) {
    msg.innerHTML = `<div class="err">${esc(res.error.message || String(res.error))}</div>`;
    noticeLoad();   // undo the preview of a notice the server refused
    return;
  }
  noticeDraftClear();
  noticeCancelEdit(true);
  const queued = !!(res && res.queued);
  msg.innerHTML = `<div class="ok">${esc(queued
    ? qt('Saved on this phone. It will be sent automatically when internet is back.', 'فون میں محفوظ ہو گیا۔ انٹرنیٹ آتے ہی خود بخود بھیج دیا جائے گا۔')
    : (wasEdit ? qt('Notice updated.', 'نوٹس اپڈیٹ ہو گیا۔') : qt('Notice published.', 'نوٹس شائع ہو گیا۔')))}</div>`;
  setTimeout(() => { const m = document.getElementById('notice-msg'); if (m) m.innerHTML = ''; }, queued ? 6000 : 3000);
  noticeLoad();
}

function noticeEdit(id) {
  const n = NOTICES.find(x => x.id === id); if (!n) return;
  NOTICE_EDIT_ID = id; NOTICE_AUD = n.audience; noticePaintAud();
  const topicEl = document.getElementById('notice-topic'), ed = document.getElementById('notice-details');
  if (topicEl) topicEl.value = n.topic;
  if (ed) ed.innerHTML = noticeClean(n.details);
  noticeCount();
  const ttl = document.getElementById('notice-form-title'); if (ttl) ttl.textContent = qt('Edit notice', 'نوٹس ایڈیٹ کریں');
  const pb = document.getElementById('notice-publish-btn'); if (pb) pb.textContent = qt('Save changes', 'تبدیلیاں محفوظ کریں');
  const cb = document.getElementById('notice-cancel-btn'); if (cb) cb.classList.remove('hidden');
  if (topicEl) topicEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function noticeCancelEdit(keepMsg) {
  NOTICE_EDIT_ID = null;
  const topicEl = document.getElementById('notice-topic'), ed = document.getElementById('notice-details');
  if (topicEl) topicEl.value = '';
  if (ed) ed.innerHTML = '';
  noticeCount();
  const ttl = document.getElementById('notice-form-title'); if (ttl) ttl.textContent = qt('New notice', 'نیا نوٹس');
  const pb = document.getElementById('notice-publish-btn'); if (pb) pb.textContent = qt('Publish notice', 'نوٹس شائع کریں');
  const cb = document.getElementById('notice-cancel-btn'); if (cb) cb.classList.add('hidden');
  if (!keepMsg) { const m = document.getElementById('notice-msg'); if (m) m.innerHTML = ''; }
}

async function noticeDelete(id) {
  if (!confirm(qt('Delete this notice?', 'کیا یہ نوٹس حذف کریں؟'))) return;
  let res;
  try {
    res = await offlineWrite({
      table: 'notices', action: 'delete', payload: null, id, baseRow: null,
      run: () => sb.from('notices').delete().eq('id', id),
      optimisticApply: () => { NOTICES = NOTICES.filter(n => n.id !== id); noticeSaveCache(); }
    });
  } catch (e) { res = { error: e }; }
  if (res && res.error) { alert(res.error.message || String(res.error)); noticeLoad(); return; }
  if (NOTICE_EDIT_ID === id) noticeCancelEdit();
  noticeLoad();
}

function noticeShareWA(id) {
  const n = NOTICES.find(x => x.id === id); if (!n) return;
  const txt = '*' + n.topic + '*\n\n' + noticeToText(n.details);
  window.open('https://wa.me/?text=' + encodeURIComponent(txt), '_blank');
}

// ---------- Teachers (class + diary portals) and parents ----------
const NOTICE_ST = {};   // kind -> { items, more, loading }

function noticeCred(kind) {
  if (kind === 'class') {
    const s = getClassSession(); if (!s) return null;
    return { school: s.schoolCode, fn: 'notice_list_class', args: { p_school_code: s.schoolCode, p_login_id: s.loginId, p_password: s.password } };
  }
  if (kind === 'diary') {
    const s = getDiarySession(); if (!s) return null;
    return { school: s.schoolCode, fn: 'notice_list_diary', args: { p_school_code: s.schoolCode, p_password: s.password } };
  }
  const c = getPpCache(); if (!c) return null;
  return { school: c.schoolCode, fn: 'notice_list_parent', args: { p_school_code: c.schoolCode, p_roll: String(c.roll), p_pin: String(c.pin) } };
}
function noticeCacheKey(kind) {
  const c = noticeCred(kind);
  return 'notices_cache_' + kind + '_' + String((c && c.school) || '').toUpperCase();
}

async function noticeFetch(kind, before, limit) {
  const c = noticeCred(kind); if (!c) return null;
  const args = Object.assign({}, c.args, { p_limit: limit });
  if (before) args.p_before = before;
  try {
    const { data, error } = await sb.rpc(c.fn, args);
    if (error) return null;
    return data || [];
  } catch (e) { return null; }
}

function noticeRowHtml(n) {
  return `
    <div class="list-row" style="cursor:pointer;flex-direction:column;align-items:stretch;" onclick="toggleNoticeRow('${n.id}')">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;">
        <div class="nm">${esc(n.topic)}</div>
        <div style="display:flex;align-items:center;gap:8px;flex:none;">
          <div class="sub">${esc(fmtDate((n.created_at || '').slice(0, 10)) || '')}</div>
          <span style="opacity:.5;">▾</span>
        </div>
      </div>
      <div id="nt-${n.id}" class="hidden" style="margin-top:8px;font-size:13px;line-height:1.5;">${noticeClean(n.details)}</div>
    </div>`;
}
function toggleNoticeRow(id) { const el = document.getElementById('nt-' + id); if (el) el.classList.toggle('hidden'); }

function noticePaint(elId, kind) {
  const el = document.getElementById(elId); if (!el) return;
  const st = NOTICE_ST[kind] || { items: [], more: false, loading: true };
  if (!st.items.length) {
    el.innerHTML = `<p class="desc" style="margin:0;">${st.loading ? '…' : esc(qt('No notices yet.', 'ابھی کوئی نوٹس نہیں۔'))}</p>`;
    return;
  }
  el.innerHTML = `<div class="list-card">${st.items.map(noticeRowHtml).join('')}</div>` +
    (st.more ? `<button class="btn-ghost" style="width:100%;margin-top:8px;" onclick="noticeMore('${kind}','${elId}')">${esc(qt('Show older notices', 'پرانے نوٹس دیکھیں'))}</button>` : '');
}

async function noticeRefresh(elId, kind, limit) {
  let cached = null;
  try { cached = JSON.parse(localStorage.getItem(noticeCacheKey(kind)) || 'null'); } catch (e) {}
  NOTICE_ST[kind] = { items: (cached && cached.items) || [], more: false, loading: true };
  noticePaint(elId, kind);
  if (!navigator.onLine) { NOTICE_ST[kind].loading = false; noticePaint(elId, kind); return; }
  const items = await noticeFetch(kind, null, limit);
  if (items === null) { NOTICE_ST[kind].loading = false; noticePaint(elId, kind); return; }
  NOTICE_ST[kind] = { items, more: items.length >= limit, loading: false };
  try { localStorage.setItem(noticeCacheKey(kind), JSON.stringify({ ts: Date.now(), items })); } catch (e) {}
  noticePaint(elId, kind);
}

async function noticeMore(kind, elId) {
  const st = NOTICE_ST[kind]; if (!st || !st.items.length) return;
  const more = await noticeFetch(kind, st.items[st.items.length - 1].created_at, 20);
  if (more === null) return;
  st.items = st.items.concat(more); st.more = more.length >= 20;
  noticePaint(elId, kind);
}

// Full-page Notice Board inside the class portal / diary portal (teachers)
function noticeOpenScreen(kind) {
  const body = document.getElementById(kind === 'class' ? 'class-portal-body' : 'diary-portal-body');
  if (!body) return;
  if (kind === 'class') CLASS_PORTAL_SCREEN = 'notices'; else DIARY_SCREEN = 'notices';
  const back = kind === 'class' ? 'renderClassPortalMenu()' : 'renderDiaryMenu()';
  body.innerHTML = `
    <button class="btn-ghost" style="padding:9px 14px;margin-bottom:10px;" onclick="${back}">‹ ${esc(qt('Back', 'واپس'))}</button>
    <h2 style="margin-top:0;">${esc(qt('Notice Board', 'نوٹس بورڈ'))}</h2>
    <div id="notice-portal-list"></div>`;
  noticeRefresh('notice-portal-list', kind, 20);
}

// =====================================================================
// PARENT MESSAGES — parents write to the school from the parent portal and tap
// Teacher / Principal / Both. Teachers read them in the class portal, the owner
// in the Notice Board tab. Needs parent_messages.sql to be run once in Supabase.
// =====================================================================
function ppContactBoxHtml() {
  const btn = (k, label) => `<button type="button" class="btn-primary pp-send-btn" style="flex:1;padding:10px 4px;font-size:13px;" onclick="ppSendMessage('${k}')">${label}</button>`;
  return `
    <div class="section-title" style="margin-top:6px;">${esc(qt('Contact school', 'اسکول سے رابطہ'))}</div>
    <div class="card" style="margin-bottom:14px;">
      <textarea id="pp-msg-text" maxlength="500" rows="3" style="width:100%;box-sizing:border-box;" placeholder="${esc(qt('Write your message here…', 'اپنا پیغام یہاں لکھیں…'))}"></textarea>
      <select id="pp-msg-subject" style="width:100%;margin-top:8px;">
        <option value="">${esc(qt('Subject: General / Other', 'مضمون: عمومی / دیگر'))}</option>
        ${DIARY_DEFAULT_SUBJECTS.map(s => `<option value="${esc(s)}">${esc(s)}</option>`).join('')}
      </select>
      <div style="font-size:12px;opacity:.7;margin:8px 0 6px;">${esc(qt('Send to', 'بھیجیں'))}</div>
      <div style="display:flex;gap:8px;">
        ${btn('teacher', '👩‍🏫 ' + esc(qt('Teacher', 'استاد')))}
        ${btn('owner', '🏫 ' + esc(qt('Principal', 'پرنسپل')))}
        ${btn('both', '👥 ' + esc(qt('Both', 'دونوں')))}
      </div>
      <div id="pp-contact-status" style="font-size:12px;margin-top:8px;"></div>
      <button type="button" class="btn-primary" style="width:100%;margin-top:10px;" onclick="chOpen('parent')">💬 ${esc(qt('Chat & voice message', 'چیٹ اور وائس میسج'))}</button>
      <button type="button" class="btn-ghost" style="width:100%;margin-top:10px;" onclick="ppToggleMyMsgs()">📜 ${esc(qt('My messages', 'میرے پیغامات'))}<span id="pp-my-badge"></span></button>
      <div id="pp-my-list" class="hidden" style="margin-top:8px;"></div>
    </div>`;
}

async function ppSendMessage(target) {
  const box = document.getElementById('pp-msg-text'), out = document.getElementById('pp-contact-status');
  if (!box || !out) return;
  const text = box.value.trim();
  const bad = m => { out.innerHTML = `<div class="err">${esc(m)}</div>`; };
  if (!text) { bad(qt('Please write a message first.', 'پہلے پیغام لکھیں۔')); return; }
  const c = getPpCache(); if (!c) return;
  const subj = (target === 'owner') ? null : ((document.getElementById('pp-msg-subject') || {}).value || null);
  if (!navigator.onLine) { ppQueueMsg(c, text, target, subj); box.value = ''; out.innerHTML = `<span class="ok">✓ ${esc(qt('Saved. It will be sent automatically when internet returns.', 'محفوظ ہو گیا۔ انٹرنیٹ آتے ہی خود بھیج دیا جائے گا۔'))}</span>`; return; }
  const btns = document.querySelectorAll('.pp-send-btn');
  btns.forEach(b => b.disabled = true);
  out.textContent = '…';
  try {
    const { error } = await sb.rpc('parent_message_send', {
      p_school_code: c.schoolCode, p_roll: String(c.roll), p_pin: String(c.pin), p_message: text,
      p_to_teacher: target !== 'owner', p_to_owner: target !== 'teacher',
      p_subject: target === 'owner' ? null : ((document.getElementById('pp-msg-subject') || {}).value || null)
    });
    if (error) {
      const m = String(error.message || '');
      if (/too_many/.test(m)) bad(qt('Too many messages today. Please try again tomorrow.', 'آج بہت زیادہ پیغامات بھیج دیے ہیں۔ کل دوبارہ کوشش کریں۔'));
      else if (/does not exist|could not find the function|schema cache/i.test(m)) bad(qt('Messaging is not set up yet. Please tell the school.', 'پیغام کی سہولت ابھی سیٹ اپ نہیں ہوئی۔ اسکول کو بتائیں۔'));
      else if (pmIsNet(error)) { ppQueueMsg(c, text, target, subj); box.value = ''; out.innerHTML = `<span class="ok">✓ ${esc(qt('Saved. It will be sent automatically when internet returns.', 'محفوظ ہو گیا۔ انٹرنیٹ آتے ہی خود بھیج دیا جائے گا۔'))}</span>`; }
      else bad(qt('Could not send. Please try again.', 'پیغام نہیں بھیجا جا سکا۔ دوبارہ کوشش کریں۔'));
    } else {
      box.value = '';
      const who = target === 'teacher' ? qt('Teacher', 'استاد') : target === 'owner' ? qt('Principal', 'پرنسپل') : qt('Teacher and Principal', 'استاد اور پرنسپل');
      out.innerHTML = `<span class="ok">✓ ${esc(qt('Sent to', 'بھیج دیا گیا:'))} ${esc(who)}</span>`;
      const myl = document.getElementById('pp-my-list'); if (myl && !myl.classList.contains('hidden')) { myl.classList.add('hidden'); ppToggleMyMsgs(); }
    }
  } catch (e) { bad(qt('Could not send. Please check your connection.', 'پیغام نہیں بھیجا جا سکا۔ انٹرنیٹ چیک کریں۔')); }
  btns.forEach(b => b.disabled = false);
}

function pmSetupMissing(msg) { return /parent_message|teacher_read_at|owner_read_at/.test(msg || '') && /(does not exist|schema cache|relation|could not find|column)/i.test(msg || ''); }
function pmSetupErr() { return `<div class="err">${esc(qt('Not set up yet (run parent_messages_v2.sql in Supabase).', 'ابھی سیٹ اپ نہیں ہوا (Supabase میں parent_messages_v2.sql چلائیں)۔'))}</div>`; }
function pmRoleLabel(r) { return r === 'owner' ? qt('Principal', 'پرنسپل') : qt('Teacher', 'استاد'); }
function pmNewTag() { return `<span style="background:#d33;color:#fff;border-radius:8px;font-size:10px;padding:1px 6px;margin-inline-start:6px;">${esc(qt('NEW', 'نیا'))}</span>`; }
function pmRepliesHtml(m, seen) {
  const rs = m.replies || [];
  if (!rs.length) return '';
  return `<div style="margin-top:8px;border-inline-start:3px solid var(--line);padding-inline-start:8px;">${rs.map(r => `
    <div style="font-size:12px;margin-top:4px;"><b>${esc(pmRoleLabel(r.from_role))}:</b> <span style="white-space:pre-wrap;">${esc(r.reply)}</span>
      <span class="sub">${esc(fmtDate((r.created_at || '').slice(0, 10)) || '')}</span>${seen !== undefined && new Date(r.created_at).getTime() > seen ? pmNewTag() : ''}</div>`).join('')}</div>`;
}

// role = 'teacher' (class portal) or 'owner' (Notice Board tab)
function pmRowHtml(m, role) {
  const who = m.to_teacher && m.to_owner ? qt('Teacher + Principal', 'استاد + پرنسپل') : m.to_owner ? qt('Principal', 'پرنسپل') : qt('Teacher', 'استاد');
  const unread = role === 'owner' ? !m.owner_read_at : !m.teacher_read_at;
  return `
    <div class="list-row" style="flex-direction:column;align-items:stretch;">
      <div style="display:flex;justify-content:space-between;gap:8px;">
        <div class="nm">${esc(m.student_name || '')}${role === 'owner' && m.class_name ? ' · ' + esc(m.class_name) : ''}${unread ? pmNewTag() : ''}</div>
        <div class="sub" style="flex:none;">${esc(fmtDate((m.created_at || '').slice(0, 10)) || '')}</div>
      </div>
      <div class="sub">${m.father_name ? esc(t.fatherName) + ': ' + esc(m.father_name) + ' · ' : ''}${esc(who)}</div>
      <div style="margin-top:6px;font-size:13px;line-height:1.5;white-space:pre-wrap;">${esc(m.message || '')}</div>
      ${pmRepliesHtml(m)}
      <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:6px;">
        <button class="btn-ghost" style="flex:none;padding:4px 12px;font-size:12px;" onclick="pmToggleReply('${m.id}')">↩ ${esc(qt('Reply', 'جواب'))}</button>
        <button class="btn-ghost" style="flex:none;padding:4px 12px;font-size:12px;" onclick="${role === 'owner' ? 'pmOwnerDelete' : 'pmTeacherDelete'}('${m.id}')">${esc(qt('Delete', 'حذف کریں'))}</button>
      </div>
      <div id="pm-rbox-${m.id}" class="hidden" style="margin-top:6px;">
        <textarea id="pm-rtxt-${m.id}" maxlength="500" rows="2" style="width:100%;box-sizing:border-box;" placeholder="${esc(qt('Write your reply…', 'اپنا جواب لکھیں…'))}"></textarea>
        <button class="btn-primary" style="width:100%;margin-top:6px;" onclick="pmSendReply('${m.id}','${role}')">${esc(qt('Send reply', 'جواب بھیجیں'))}</button>
        <div id="pm-rst-${m.id}" style="font-size:12px;margin-top:6px;"></div>
      </div>
    </div>`;
}
function pmToggleReply(id) { const b = document.getElementById('pm-rbox-' + id); if (b) b.classList.toggle('hidden'); }

async function pmSendReply(id, role) {
  const ta = document.getElementById('pm-rtxt-' + id), st = document.getElementById('pm-rst-' + id);
  if (!ta || !st) return;
  const text = ta.value.trim();
  const bad = m => { st.innerHTML = `<div class="err">${esc(m)}</div>`; };
  if (!text) { bad(qt('Please write a reply first.', 'پہلے جواب لکھیں۔')); return; }
  if (!navigator.onLine) {
    if (role === 'owner') { bad(qt('You are offline — connect to the internet to send.', 'آپ آف لائن ہیں — بھیجنے کے لیے انٹرنیٹ سے جڑیں۔')); return; }
    const s0 = getClassSession(); if (!s0) return;
    queueClassWrite({ type: 'pm_reply', schoolCode: s0.schoolCode, loginId: s0.loginId, password: s0.password, messageId: id, text });
    pmCacheAddReply('cp_pm_cache_' + s0.schoolCode + '_' + s0.loginId, id, text);
    renderClassPortalParentMsgs(); return;
  }
  st.textContent = '…';
  try {
    let res;
    if (role === 'owner') {
      res = await sb.rpc('parent_message_reply_owner', { p_message_id: id, p_text: text });
    } else {
      const s = getClassSession(); if (!s) return;
      res = await sb.rpc('parent_message_reply_class', { p_school_code: s.schoolCode, p_login_id: s.loginId, p_password: s.password, p_message_id: id, p_text: text });
    }
    if (res.error) {
      const m = String(res.error.message || '');
      bad(pmSetupMissing(m) ? qt('Not set up yet (run parent_messages_v2.sql in Supabase).', 'ابھی سیٹ اپ نہیں ہوا۔') : /too_many/.test(m) ? qt('Too many replies on this message.', 'اس پیغام پر بہت زیادہ جوابات ہو چکے ہیں۔') : qt('Could not send. Please try again.', 'جواب نہیں بھیجا جا سکا۔ دوبارہ کوشش کریں۔'));
      return;
    }
    if (role === 'owner') { const ob = document.getElementById('pm-owner-list'); if (ob) { ob.dataset.sig = ''; } ta.value = ''; pmOwnerLoad(); } else renderClassPortalParentMsgs();
  } catch (e) { bad(qt('Could not send. Please check your connection.', 'جواب نہیں بھیجا جا سکا۔ انٹرنیٹ چیک کریں۔')); }
}

// ---- Teacher side (class portal) ----
function pmTeacherArgs(s) { return { p_school_code: s.schoolCode, p_login_id: s.loginId, p_password: s.password }; }
async function pmTeacherBadge() {
  const s = getClassSession();
  if (!s || !navigator.onLine || !document.getElementById('cp-pm-badge')) return;
  try {
    const { data, error } = await sb.rpc('parent_message_unread_class', pmTeacherArgs(s));
    if (error) return;
    const el = document.getElementById('cp-pm-badge');
    const n = Number(data) || 0;
    if (el) el.textContent = n > 0 ? ' (' + n + ')' : '';
    try { const r = await sb.rpc('parent_message_list_class', Object.assign(pmTeacherArgs(s), { p_limit: 50 })); if (!r.error) pmCacheSet('cp_pm_cache_' + s.schoolCode + '_' + s.loginId, r.data || []); } catch (e2) {}
  } catch (e) {}
}
async function renderClassPortalParentMsgs() {
  CLASS_PORTAL_SCREEN = 'parentMsgs';
  const s = getClassSession();
  const body = document.getElementById('class-portal-body');
  if (!s || !body) return;
  const ck = 'cp_pm_cache_' + s.schoolCode + '_' + s.loginId;
  body.innerHTML = `
    <button class="btn-ghost" style="padding:9px 14px;margin-bottom:10px;" onclick="CLASS_PORTAL_SCREEN='menu'; renderClassPortalMenu()">‹ ${esc(t.classPortalBackToMenu)}</button>
    <h2 style="margin-top:0;">${esc(qt('Parent Messages', 'والدین کے پیغامات'))}</h2>
    <div id="cp-pm-list"><p class="desc">…</p></div>`;
  const box = document.getElementById('cp-pm-list');
  const showList = (list, offline) => {
    box.innerHTML = (offline ? `<p class="desc">📴 ${esc(qt('Offline — showing saved messages.', 'آف لائن — محفوظ پیغامات دکھائے جا رہے ہیں۔'))}</p>` : '')
      + (list.length ? `<div class="list-card">${list.map(m => pmRowHtml(m, 'teacher')).join('')}</div>` : `<p class="desc">${esc(qt('No messages yet.', 'ابھی کوئی پیغام نہیں۔'))}</p>`);
  };
  const offlineFallback = () => {
    const c = pmCacheGet(ck);
    if (c) showList(c, true);
    else box.innerHTML = `<div class="err">${esc(qt('You are offline. Open this once with internet to save messages.', 'آپ آف لائن ہیں۔ پیغامات محفوظ کرنے کے لیے ایک بار انٹرنیٹ پر کھولیں۔'))}</div>`;
  };
  if (!navigator.onLine) { offlineFallback(); return; }
  try {
    const { data, error } = await sb.rpc('parent_message_list_class', Object.assign(pmTeacherArgs(s), { p_limit: 50 }));
    if (error) {
      if (pmIsNet(error)) { offlineFallback(); return; }
      box.innerHTML = pmSetupMissing(error.message) ? pmSetupErr() : `<div class="err">${esc(qt('Could not load messages.', 'پیغامات لوڈ نہیں ہو سکے۔'))}</div>`; return;
    }
    const list = data || [];
    pmCacheSet(ck, list);
    showList(list, false);
    if (list.some(m => !m.teacher_read_at)) { try { await sb.rpc('parent_message_mark_read_class', pmTeacherArgs(s)); } catch (e) {} }
  } catch (e) { offlineFallback(); }
}

// ---- Owner side (Notice Board tab) ----
let PM_OWNER_UNREAD = 0, PM_BADGE_TS = 0;
function pmPaintNavBadge() {
  document.querySelectorAll('[onclick="setTab(\'notices\')"]').forEach(el => {
    const host = el.querySelector('span') || el;
    let b = host.querySelector('.pm-nav-badge');
    if (PM_OWNER_UNREAD > 0) {
      if (!b) { b = document.createElement('b'); b.className = 'pm-nav-badge'; b.style.cssText = 'background:#d33;color:#fff;border-radius:9px;font-size:10px;padding:1px 6px;margin-inline-start:6px;'; host.appendChild(b); }
      b.textContent = PM_OWNER_UNREAD > 9 ? '9+' : String(PM_OWNER_UNREAD);
    } else if (b) b.remove();
  });
}
async function pmOwnerBadgeRefresh(force) {
  pmPaintNavBadge();
  if (!CURRENT_USER || !navigator.onLine) return;
  if (!force && Date.now() - PM_BADGE_TS < 60000) return;
  PM_BADGE_TS = Date.now();
  try {
    const { count, error } = await sb.from('parent_messages').select('id', { count: 'exact', head: true }).eq('owner_id', CURRENT_USER.id).eq('to_owner', true).is('owner_read_at', null);
    if (error) return;
    PM_OWNER_UNREAD = count || 0;
    pmPaintNavBadge();
  } catch (e) {}
}
async function pmOwnerLoad() {
  const box = document.getElementById('pm-owner-list'); if (!box || !CURRENT_USER) return;
  if (!navigator.onLine) { if (!box.dataset.sig) box.innerHTML = `<p class="desc">${esc(qt('You are offline.', 'آپ آف لائن ہیں۔'))}</p>`; return; }
  try {
    const { data, error } = await sb.from('parent_messages').select('*, parent_message_replies(*)').eq('owner_id', CURRENT_USER.id).eq('to_owner', true).order('created_at', { ascending: false }).limit(50);
    if (error) { box.innerHTML = pmSetupMissing(error.message) ? pmSetupErr() : `<div class="err">${esc(error.message || '')}</div>`; return; }
    const list = (data || []).map(m => Object.assign({}, m, { replies: (m.parent_message_replies || []).slice().sort((a, b) => String(a.created_at).localeCompare(String(b.created_at))) }));
    // Background syncs call this often. Repaint ONLY when the messages really changed, and never while the
    // owner is typing a reply — replacing the HTML would remove the textarea and close the keyboard.
    const sig = LANG + '|' + JSON.stringify(list.map(m => [m.id, (m.replies || []).length]));
    const typing = Array.from(box.querySelectorAll('textarea')).some(x => x === document.activeElement || x.value.trim());
    if (!typing && box.dataset.sig !== sig) {
      box.innerHTML = list.length ? `<div class="list-card">${list.map(m => pmRowHtml(m, 'owner')).join('')}</div>` : `<p class="desc">${esc(qt('No messages yet.', 'ابھی کوئی پیغام نہیں۔'))}</p>`;
      box.dataset.sig = sig;
    }
    if (list.some(m => !m.owner_read_at)) {
      await sb.from('parent_messages').update({ owner_read_at: new Date().toISOString() }).eq('owner_id', CURRENT_USER.id).eq('to_owner', true).is('owner_read_at', null);
      PM_OWNER_UNREAD = 0; pmPaintNavBadge();
    }
  } catch (e) { if (!box.dataset.sig) box.innerHTML = `<p class="desc">…</p>`; }
}
async function pmOwnerDelete(id) {
  if (!confirm(qt('Delete this message?', 'یہ پیغام حذف کریں؟'))) return;
  try { await sb.from('parent_messages').delete().eq('id', id).eq('owner_id', CURRENT_USER.id); } catch (e) {}
  const ob = document.getElementById('pm-owner-list'); if (ob) ob.dataset.sig = '';
  pmOwnerLoad();
}

// ---- Parent side: "My messages" with replies ----
let PP_MY = null;
function ppMyKey() { const c = getPpCache(); return 'pp_reply_seen_' + (c ? c.schoolCode + '_' + c.roll : ''); }
function ppMySeen() { return Number(localStorage.getItem(ppMyKey()) || 0); }
// ---- Offline helpers for Parent Messages (saved copy on this phone) ----
function pmCacheGet(k) { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (e) { return null; } }
function pmCacheSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
function pmIsNet(e) { return /fetch|network|load failed|offline/i.test(String((e && e.message) || e || '')); }
function pmCacheAddReply(k, id, text) {
  const l = pmCacheGet(k); if (!l) return;
  const m = l.find(x => x.id === id); if (!m) return;
  (m.replies = m.replies || []).push({ from_role: 'teacher', reply: text, created_at: new Date().toISOString() });
  pmCacheSet(k, l);
}
const PP_MSGQ_KEY = 'sms_pp_msg_queue';
let PP_MSGQ_BUSY = false;
function ppQueueMsg(c, text, target, subj) {
  const q = pmCacheGet(PP_MSGQ_KEY) || [];
  q.push({ schoolCode: c.schoolCode, roll: String(c.roll), pin: String(c.pin), text, toTeacher: target !== 'owner', toOwner: target !== 'teacher', subject: subj || null, ts: Date.now() });
  pmCacheSet(PP_MSGQ_KEY, q);
}
async function ppFlushMsgQueue() {
  if (PP_MSGQ_BUSY || !navigator.onLine) return;
  const q = pmCacheGet(PP_MSGQ_KEY) || []; if (!q.length) return;
  PP_MSGQ_BUSY = true;
  const keep = [];
  try {
    for (const it of q) {
      try {
        const { error } = await sb.rpc('parent_message_send', {
          p_school_code: it.schoolCode, p_roll: it.roll, p_pin: it.pin, p_message: it.text,
          p_to_teacher: it.toTeacher, p_to_owner: it.toOwner, p_subject: it.subject
        });
        if (error && !/too_many|bad_message|invalid_parent|no_recipient|does not exist|could not find/i.test(String(error.message || ''))) keep.push(it);
      } catch (e) { keep.push(it); }
    }
  } finally {
    const cur = pmCacheGet(PP_MSGQ_KEY) || [];
    const added = cur.filter(x => !q.some(y => y.ts === x.ts && y.text === x.text));
    pmCacheSet(PP_MSGQ_KEY, keep.concat(added));
    PP_MSGQ_BUSY = false;
  }
}
window.addEventListener('online', ppFlushMsgQueue);
setInterval(ppFlushMsgQueue, 20000);

async function ppFetchMy() {
  const c = getPpCache(); if (!c) return null;
  const ck = 'pp_my_cache_' + c.schoolCode + '_' + c.roll;
  if (!navigator.onLine) return pmCacheGet(ck);
  try {
    const { data, error } = await sb.rpc('parent_message_list_parent', { p_school_code: c.schoolCode, p_roll: String(c.roll), p_pin: String(c.pin), p_limit: 20 });
    if (error) return pmCacheGet(ck);
    PP_MY = data || []; pmCacheSet(ck, PP_MY); return PP_MY;
  } catch (e) { return pmCacheGet(ck); }
}
function ppMyNewCount(list, seen) {
  let n = 0; (list || []).forEach(m => (m.replies || []).forEach(r => { if (new Date(r.created_at).getTime() > seen) n++; })); return n;
}
async function ppMyBadge() {
  const list = await ppFetchMy(); const el = document.getElementById('pp-my-badge');
  if (!el || !list) return;
  const n = ppMyNewCount(list, ppMySeen());
  el.textContent = n > 0 ? ' · ' + n + ' ' + qt('new reply', 'نیا جواب') : '';
  el.style.color = '#d33';
}
async function ppDeleteMy(id) {
  if (!confirm(qt('Delete this message?', 'کیا یہ پیغام حذف کریں؟'))) return;
  const cr = ppQuizCreds(); if (!cr || !navigator.onLine) { alert(qt('Internet is needed.', 'انٹرنیٹ ضروری ہے۔')); return; }
  try {
    const { error } = await sb.rpc('parent_message_delete_parent', Object.assign({}, cr, { p_message_id: id }));
    if (error) { alert(/does not exist|schema cache|could not find/i.test(String(error.message)) ? qt('Not set up yet (run parent_messages_delete.sql in Supabase).', 'ابھی سیٹ اپ نہیں ہوا (Supabase میں parent_messages_delete.sql چلائیں)۔') : qt('Could not delete.', 'حذف نہیں ہو سکا۔')); return; }
    const b = document.getElementById('pp-my-list'); if (b) b.classList.add('hidden');
    await ppToggleMyMsgs();
  } catch (e) { alert(qt('Could not delete.', 'حذف نہیں ہو سکا۔')); }
}
async function pmTeacherDelete(id) {
  const s = getClassSession(); if (!s) return;
  if (!confirm(qt('Delete this message?', 'کیا یہ پیغام حذف کریں؟'))) return;
  if (!navigator.onLine) { alert(qt('Internet is needed.', 'انٹرنیٹ ضروری ہے۔')); return; }
  try {
    const { error } = await sb.rpc('parent_message_delete_class', Object.assign(pmTeacherArgs(s), { p_message_id: id }));
    if (error) { alert(/does not exist|schema cache|could not find/i.test(String(error.message)) ? qt('Not set up yet (run parent_messages_delete.sql in Supabase).', 'ابھی سیٹ اپ نہیں ہوا (Supabase میں parent_messages_delete.sql چلائیں)۔') : qt('Could not delete.', 'حذف نہیں ہو سکا۔')); return; }
    renderClassPortalParentMsgs();
  } catch (e) { alert(qt('Could not delete.', 'حذف نہیں ہو سکا۔')); }
}
async function ppToggleMyMsgs() {
  const box = document.getElementById('pp-my-list'); if (!box) return;
  if (!box.classList.contains('hidden')) { box.classList.add('hidden'); return; }
  box.classList.remove('hidden'); box.innerHTML = '<p class="desc">…</p>';
  const list = await ppFetchMy();
  if (list === null) { box.innerHTML = `<div class="err">${esc(qt('Could not load. Check your connection.', 'لوڈ نہیں ہو سکا۔ انٹرنیٹ چیک کریں۔'))}</div>`; return; }
  const seen = ppMySeen();
  box.innerHTML = list.length ? `<div class="list-card">${list.map(m => {
    const who = m.to_teacher && m.to_owner ? qt('Teacher + Principal', 'استاد + پرنسپل') : m.to_owner ? qt('Principal', 'پرنسپل') : qt('Teacher', 'استاد');
    return `<div class="list-row" style="flex-direction:column;align-items:stretch;">
      <div style="display:flex;justify-content:space-between;gap:8px;"><div class="sub">${esc(qt('To', 'بنام'))}: ${esc(who)}</div><div class="sub" style="flex:none;">${esc(fmtDate((m.created_at || '').slice(0, 10)) || '')}</div></div>
      <div style="margin-top:4px;font-size:13px;line-height:1.5;white-space:pre-wrap;">${esc(m.message || '')}</div>
      ${pmRepliesHtml(m, seen)}
      <div style="display:flex;justify-content:flex-end;margin-top:6px;"><button class="btn-ghost" style="flex:none;padding:4px 12px;font-size:12px;" onclick="ppDeleteMy('${m.id}')">${esc(qt('Delete', 'حذف کریں'))}</button></div>
    </div>`; }).join('')}</div>` : `<p class="desc">${esc(qt('You have not sent any message yet.', 'آپ نے ابھی تک کوئی پیغام نہیں بھیجا۔'))}</p>`;
  let mx = seen; list.forEach(m => (m.replies || []).forEach(r => { const ts = new Date(r.created_at).getTime(); if (ts > mx) mx = ts; }));
  try { localStorage.setItem(ppMyKey(), String(mx)); } catch (e) {}
  const b = document.getElementById('pp-my-badge'); if (b) b.textContent = '';
}

// Section shown at the top of the parent portal
function noticeParentBoxHtml() {
  return `<div class="section-title" style="margin-top:6px;">${esc(qt('Notices from school', 'اسکول کے نوٹس'))}</div><div id="pp-notices" style="margin-bottom:14px;"></div>`;
}

function renderClassPortalMenu() {
  cpSyncUrl();
  const session = getClassSession();
  const body = document.getElementById('class-portal-body');
  if (!session || !body) return;
  const queue = getClassQueue();
  body.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;">
      <h2 style="margin:0;">${esc(session.className)}</h2>
      <button class="btn-ghost" style="flex:none;padding:7px 12px;font-size:12px;" onclick="classPortalLogout()">${esc(t.classPortalLogout)}</button>
    </div>
    ${session.teacherName ? `<p class="desc" style="margin-top:0;">${esc(t.classTeacherName)}: ${esc(session.teacherName)}</p>` : ''}
    <p class="desc">${session.students.length} ${esc(t.studentsCount)}</p>
    <button class="btn-primary" style="width:100%;margin-bottom:10px;" onclick="renderClassPortalAttendance()">${esc(t.classPortalMenuAttendance)}</button>
    <button class="btn-primary" style="width:100%;margin-bottom:10px;" onclick="renderClassPortalRegister()">${esc(t.classPortalMenuRegister)}</button>
    <button class="btn-primary" style="width:100%;margin-bottom:10px;" onclick="renderClassPortalMarks()">${esc(t.classPortalMenuMarks)}</button>
    <button class="btn-primary" style="width:100%;margin-bottom:10px;" onclick="renderClassPortalMarksView()">${esc(t.classPortalMenuMarksView)}</button>
    <button class="btn-primary" style="width:100%;margin-bottom:10px;" onclick="noticeOpenScreen('class')">📢 ${esc(qt('Notice Board', 'نوٹس بورڈ'))}</button>
    <button class="btn-primary" style="width:100%;margin-bottom:10px;" onclick="renderClassPortalParentMsgs()">📩 ${esc(qt('Parent Messages', 'والدین کے پیغامات'))}<span id="cp-pm-badge"></span></button>
    <button class="btn-primary" style="width:100%;margin-bottom:10px;" onclick="chOpen('teacher')">💬 ${esc(qt('Chat & voice message', 'چیٹ اور وائس میسج'))}</button>
    <button class="btn-ghost" style="width:100%;margin-bottom:10px;" onclick="renderClassPortalAddStudent()">${esc(t.classPortalMenuAddStudent)}</button>
    <button class="btn-ghost" style="width:100%;" onclick="renderClassPortalManageStudents()">${esc(t.classPortalMenuManageStudents)}</button>
    ${queue.length ? `<p style="font-size:11px;opacity:.6;margin-top:14px;">${esc(t.classPortalOffline)} (${queue.length})</p>` : ''}
  `;
  pmTeacherBadge();
}

// ---- Register (read-only month view — same grid the owner sees, so the
// teacher can check past days without needing the admin app) ----
let classPortalRegMonth = monthKey();

async function renderClassPortalRegister() {
  CLASS_PORTAL_SCREEN = 'register';
  const session = getClassSession();
  const body = document.getElementById('class-portal-body');
  if (!session || !body) return;
  body.innerHTML = `
    <button class="btn-ghost" style="padding:9px 14px;margin-bottom:10px;" onclick="renderClassPortalMenu()">‹ ${esc(t.classPortalBackToMenu)}</button>
    <h2 style="margin-top:0;">${esc(t.classPortalMenuRegister)}</h2>
    <label><span>${esc(t.registerMonth)}</span><input type="month" value="${classPortalRegMonth}" onchange="classPortalRegMonth=this.value; renderClassPortalRegisterBody()"></label>
    <div id="cp-reg-body">…</div>
  `;
  await renderClassPortalRegisterBody();
}

async function renderClassPortalRegisterBody() {
  const session = getClassSession();
  const body = document.getElementById('cp-reg-body');
  if (!session || !body) return;
  if (!navigator.onLine) { body.innerHTML = `<div class="err">${esc(t.classPortalOfflineNoList)}</div>`; return; }
  body.innerHTML = '…';
  const { data, error } = await sb.rpc('class_attendance_register', {
    p_school_code: session.schoolCode, p_login_id: session.loginId, p_password: session.password, p_month: classPortalRegMonth
  });
  if (error) { body.innerHTML = `<div class="err">${esc(t.classPortalInvalid)}</div>`; return; }
  const students = session.students.slice().sort((a,b)=>Number(a.roll_no||0)-Number(b.roll_no||0));
  if (!students.length) { body.innerHTML = `<div class="empty">${esc(t.classPortalNoStudents)}</div>`; return; }
  const dates = datesInMonth(classPortalRegMonth);
  const recFor = (studentId, date) => (data || []).find(r => r.student_id === studentId && r.date === date) || {};
  const cellCode = (status) => status === 'present' ? 'P' : status === 'leave' ? 'L' : status === 'absent' ? 'A' : status === 'sick' ? 'S' : '—';
  const dateHead = dates.map(date => `<th>${new Date(date + 'T00:00:00').getDate()}</th>`).join('');
  const rows = students.map(s => {
    const cells = dates.map(date => {
      const rec = recFor(s.id, date);
      return `<td style="padding:3px 2px;line-height:1.25;">
        <div style="font-size:10px;color:${registerCellColor(rec.status_am)};">${esc(cellCode(rec.status_am))}</div>
        <div style="font-size:10px;color:${registerCellColor(rec.status_pm)};">${esc(cellCode(rec.status_pm))}</div>
      </td>`;
    }).join('');
    // This-month hazirian total (AM + PM present each count as 1, so a
    // full day present counts as 2) — same counting rule as the owner's
    // Class Attendance View.
    const thisMonthDays = attendanceDaysCount((data || []).filter(r => r.student_id === s.id));
    return `<tr><td class="date-col" style="text-align:left;white-space:nowrap;">${esc(s.name)}</td>${cells}
      <td style="font-weight:700;">${fmtAttendanceDays(thisMonthDays)}</td>
    </tr>`;
  }).join('');
  body.innerHTML = `
    <div class="card-table-wrap">
      <table class="reg-physical">
        <thead><tr><th style="text-align:left;">${esc(t.studentName)}</th>${dateHead}<th>${esc(t.attRegTotal)}</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
    </div>
    <p style="font-size:10.5px;opacity:.55;margin-top:8px;">${esc(t.morning)} / ${esc(t.afternoon)} — ${esc(t.registerLegend)}</p>`;
}

// ---- Marks Sheet (read-only view of a saved exam — student x subject grid —
// with buttons to download it as an Excel file or share that file straight
// into WhatsApp via the device's native share sheet.) ----
let classPortalExams = [];
let classPortalSelectedExam = '';

async function renderClassPortalMarksView() {
  CLASS_PORTAL_SCREEN = 'marksView';
  const session = getClassSession();
  const body = document.getElementById('class-portal-body');
  if (!session || !body) return;
  body.innerHTML = `
    <button class="btn-ghost" style="padding:9px 14px;margin-bottom:10px;" onclick="renderClassPortalMenu()">‹ ${esc(t.classPortalBackToMenu)}</button>
    <h2 style="margin-top:0;">${esc(t.classPortalMenuMarksView)}</h2>
    <div id="cp-marksview-body">…</div>
  `;
  await renderClassPortalMarksViewBody();
}

async function renderClassPortalMarksViewBody() {
  const session = getClassSession();
  const body = document.getElementById('cp-marksview-body');
  if (!session || !body) return;
  if (!navigator.onLine) { body.innerHTML = `<div class="err">${esc(t.classPortalOfflineNoList)}</div>`; return; }
  body.innerHTML = '…';
  const { data, error } = await sb.rpc('class_exam_marks_list', {
    p_school_code: session.schoolCode, p_login_id: session.loginId, p_password: session.password
  });
  if (error) { body.innerHTML = `<div class="err">${esc(t.classPortalInvalid)}</div>`; return; }
  classPortalExams = data || [];
  if (!classPortalExams.length) { body.innerHTML = `<div class="empty">${esc(t.classPortalNoExams)}</div>`; return; }
  if (!classPortalSelectedExam || !classPortalExams.some(e => e.exam_name === classPortalSelectedExam)) {
    classPortalSelectedExam = classPortalExams[0].exam_name;
  }
  body.innerHTML = `
    <label><span>${esc(t.classPortalSelectExam)}</span>
      <select onchange="classPortalSelectedExam=this.value; renderClassPortalMarksViewGrid();">
        ${classPortalExams.map(e => `<option value="${esc(e.exam_name)}" ${e.exam_name === classPortalSelectedExam ? 'selected' : ''}>${esc(e.exam_name)}</option>`).join('')}
      </select>
    </label>
    <div id="cp-marksview-grid"></div>
  `;
  renderClassPortalMarksViewGrid();
}

function renderClassPortalMarksViewGrid() {
  const session = getClassSession();
  const grid = document.getElementById('cp-marksview-grid');
  if (!grid || !session) return;
  const exam = classPortalExams.find(e => e.exam_name === classPortalSelectedExam);
  if (!exam) { grid.innerHTML = ''; return; }
  const subjects = exam.subjects || [];
  const marks = exam.marks || {};
  const students = session.students.slice().sort((a,b)=>Number(a.roll_no||0)-Number(b.roll_no||0));
  const grandTotal = subjects.reduce((sum,s)=>sum+Number(s.total||0),0);
  const stTotals = students.map(st => {
    const r = marks[st.id] || {};
    let any = false, tot = 0;
    subjects.forEach(s => { const v = r[s.name]; if (v !== undefined && v !== null && v !== '') { any = true; tot += Number(v) || 0; } });
    return any ? tot : null;
  });
  const stRanks = msComputeRanks(stTotals);
  const showFather = students.some(st => (st.father_name || '').trim());
  const gradeLbl = LANG==='ur' ? 'گریڈ' : 'Grade', posLbl = LANG==='ur' ? 'پوزیشن' : 'Position';
  const rows = students.map((st, si) => {
    const row = marks[st.id] || {};
    let total = 0;
    const cells = subjects.map(s => {
      const v = row[s.name];
      if (v !== undefined && v !== null) total += Number(v) || 0;
      return `<td style="text-align:center;">${v === undefined || v === null ? '—' : esc(v)}</td>`;
    }).join('');
    return `<tr><td class="mo">${st.roll_no?'#'+esc(st.roll_no)+' ':''}${esc(st.name)}</td>${showFather ? `<td>${esc(st.father_name||'')}</td>` : ''}${cells}<td style="text-align:center;font-weight:600;">${total}/${grandTotal}</td><td style="text-align:center;font-weight:600;">${stTotals[si] === null || !grandTotal ? '—' : dmcGradeFor(stTotals[si] / grandTotal * 100)}</td><td style="text-align:center;font-weight:600;">${stRanks[si] === null ? '—' : stRanks[si]}</td></tr>`;
  }).join('');
  const _oldWrap = grid.querySelector('.card-table-wrap');
  const _keepLeft = (_oldWrap && grid.dataset.exam === classPortalSelectedExam) ? _oldWrap.scrollLeft : 0;
  grid.innerHTML = `
    <div class="card-table-wrap" style="margin-top:8px;direction:ltr;">
      <table class="card-table cp-big">
        <thead><tr><th style="text-align:left;">${esc(t.studentName)}</th>${showFather ? `<th style="text-align:left;">${esc(t.fatherName)}</th>` : ''}${subjects.map(s=>`<th>${esc(s.name)}</th>`).join('')}<th>${esc(t.classPortalTotal)}</th><th>${gradeLbl}</th><th>${posLbl}</th></tr></thead>
        <tbody>${rows || `<tr><td colspan="${subjects.length + 4 + (showFather ? 1 : 0)}">${esc(t.classPortalNoStudents)}</td></tr>`}</tbody>
      </table>
    </div>
    <div style="display:flex;gap:8px;margin-top:12px;">
      <button class="btn-ghost" style="flex:1;" onclick="exportClassMarksExcel()">📊 ${esc(t.classPortalDownloadExcel)}</button>
      <button class="btn-primary" style="flex:1;" onclick="shareClassMarksWhatsapp()">💬 ${esc(t.classPortalSendWhatsapp)}</button>
    </div>
  `;
  grid.dataset.exam = classPortalSelectedExam;
  const _newWrap = grid.querySelector('.card-table-wrap');
  if (_newWrap && _keepLeft) _newWrap.scrollLeft = _keepLeft;
}

function buildClassMarksWorkbook() {
  const session = getClassSession();
  const exam = classPortalExams.find(e => e.exam_name === classPortalSelectedExam);
  if (!exam || !session) return null;
  const subjects = exam.subjects || [];
  const marks = exam.marks || {};
  const students = session.students.slice().sort((a,b)=>Number(a.roll_no||0)-Number(b.roll_no||0));
  const grandTotal = subjects.reduce((sum,s)=>sum+Number(s.total||0),0);
  const stTotals = students.map(st => {
    const r = marks[st.id] || {};
    let any = false, tot = 0;
    subjects.forEach(s => { const v = r[s.name]; if (v !== undefined && v !== null && v !== '') { any = true; tot += Number(v) || 0; } });
    return any ? tot : null;
  });
  const stRanks = msComputeRanks(stTotals);
  const showFather = students.some(st => (st.father_name || '').trim());
  const rows = students.map((st, si) => {
    const row = marks[st.id] || {};
    const out = { [t.studentName]: st.name };
    if (showFather) out[t.fatherName] = st.father_name || '';
    let total = 0;
    subjects.forEach(s => {
      const v = row[s.name];
      out[s.name] = (v === undefined || v === null) ? '' : Number(v);
      total += Number(v) || 0;
    });
    out[`${t.classPortalTotal} /${grandTotal}`] = total;
    out['Grade'] = (stTotals[si] === null || !grandTotal) ? '' : dmcGradeFor(stTotals[si] / grandTotal * 100);
    out['Position'] = stRanks[si] === null ? '' : stRanks[si];
    return out;
  });
  const ws = XLSX.utils.json_to_sheet(rows);
  const range = XLSX.utils.decode_range(ws['!ref']);
  for (let c = range.s.c; c <= range.e.c; c++) {
    const addr = XLSX.utils.encode_cell({ r: 0, c });
    if (ws[addr]) ws[addr].s = { font: { bold: true } };
  }
  ws['!cols'] = [{ wch: 24 }, ...(showFather ? [{ wch: 20 }] : []), ...subjects.map(() => ({ wch: 12 })), { wch: 12 }, { wch: 8 }, { wch: 10 }];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, (exam.exam_name || 'Marks Sheet').slice(0, 31));
  return wb;
}

function classMarksFileName() {
  const session = getClassSession();
  const classPart = (session?.className || 'Class').replace(/[^a-zA-Z0-9]/g, '_');
  const examPart = (classPortalSelectedExam || 'Marks').replace(/[^a-zA-Z0-9]/g, '_');
  return `${classPart}_${examPart}_${fmtDate(todayISO())}.xlsx`;
}

function exportClassMarksExcel() {
  const wb = buildClassMarksWorkbook();
  if (!wb) return;
  XLSX.writeFile(wb, classMarksFileName(), { cellStyles: true });
}

// Tries the device's native share sheet so the Excel file lands directly
// inside a WhatsApp chat (works on Android/iOS Chrome & Safari, and on
// WhatsApp desktop if the OS share sheet supports it). If the browser
// doesn't support sharing files, it falls back to just downloading the
// file and opening WhatsApp so the teacher can attach it manually.
async function shareClassMarksWhatsapp() {
  const wb = buildClassMarksWorkbook();
  if (!wb) return;
  const fileName = classMarksFileName();
  try {
    const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array', cellStyles: true });
    const blob = new Blob([wbout], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const file = new File([blob], fileName, { type: blob.type });
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      await navigator.share({ files: [file], title: fileName });
      return;
    }
  } catch (e) { /* user cancelled, or share isn't supported — fall through */ }
  XLSX.writeFile(wb, fileName, { cellStyles: true });
  window.open(`https://wa.me/?text=${encodeURIComponent(t.classPortalWhatsappFallbackMsg)}`, '_blank');
}

// ---- Manage Students (teacher can mark a student who left the school as
// struck off — hides them from the class roster/attendance/marks without
// deleting their record, which stays intact for the admin to see) ----
function renderClassPortalManageStudents() {
  CLASS_PORTAL_SCREEN = 'manageStudents';
  const session = getClassSession();
  const body = document.getElementById('class-portal-body');
  if (!session || !body) return;
  const students = (session.students || []).slice().sort((a,b) => (a.name||'').localeCompare(b.name||''));
  body.innerHTML = `
    <button class="btn-ghost" style="padding:9px 14px;margin-bottom:10px;" onclick="renderClassPortalMenu()">‹ ${esc(t.classPortalBackToMenu)}</button>
    <h2 style="margin-top:0;">${esc(t.classPortalMenuManageStudents)}</h2>
    <p class="desc">${esc(t.classPortalManageStudentsDesc)}</p>
    <div id="cp-manage-msg" style="font-size:12px;margin:8px 0;"></div>
    ${students.length ? students.map(st => `
      <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;border-bottom:1px solid var(--line);padding:10px 0;">
        <div style="font-size:13px;font-weight:600;">${esc(st.name)}</div>
        <button class="btn-ghost danger" style="flex:none;padding:6px 12px;font-size:11px;" onclick="confirmClassPortalStrikeOff('${st.id}','${escJs(st.name)}')">${esc(t.strikeOffStudent)}</button>
      </div>`).join('') : `<p class="desc">${esc(t.classPortalNoStudents)}</p>`}
  `;
}

function confirmClassPortalStrikeOff(studentId, studentName) {
  showModal(t.strikeOffStudent, `
    <p style="font-size:14px;">${esc(t.confirmStrikeOff)}</p>
    <div class="flexgap">
      <button class="btn-ghost" onclick="closeModal()">${esc(t.no)}</button>
      <button class="btn-primary" style="flex:1;background:var(--rust);" onclick="guardedSubmit(this, ()=>submitClassPortalStrikeOff('${studentId}'))">${esc(t.yes)}</button>
    </div>
  `);
}

async function submitClassPortalStrikeOff(studentId) {
  const session = getClassSession();
  if (!session) return;
  if (!navigator.onLine) { alert(LANG==='ur' ? 'یہ کام آف لائن نہیں ہو سکتا۔ براہ کرم انٹرنیٹ سے جڑ کر دوبارہ کوشش کریں۔' : 'This needs an internet connection. Please try again once online.'); return; }
  try {
    const { data, error } = await sb.rpc('class_strike_off_student', {
      p_school_code: session.schoolCode, p_login_id: session.loginId, p_password: session.password, p_student_id: studentId
    });
    closeModal();
    if (error || !data) { alert(t.classPortalInvalid); return; }
    session.students = (session.students || []).filter(s => s.id !== studentId);
    setClassSession(session);
    renderClassPortalManageStudents();
  } catch(e) {
    closeModal();
    alert(LANG==='ur' ? 'خرابی پیش آئی، دوبارہ کوشش کریں۔' : 'Something went wrong, please try again.');
  }
}

// ---- Add Student (teacher can add a new student to their own class) ----
function renderClassPortalAddStudent() {
  CLASS_PORTAL_SCREEN = 'addStudent';
  const body = document.getElementById('class-portal-body');
  if (!body) return;
  body.innerHTML = `
    <button class="btn-ghost" style="padding:9px 14px;margin-bottom:10px;" onclick="renderClassPortalMenu()">‹ ${esc(t.classPortalBackToMenu)}</button>
    <h2 style="margin-top:0;">${esc(t.classPortalAddStudentTitle)}</h2>
    <p class="desc">${esc(t.classPortalAddStudentDesc)}</p>
    <label><span>${esc(t.classPortalStudentNamePlaceholder)}</span><input id="cp-add-name" placeholder="${esc(t.classPortalStudentNamePlaceholder)}"></label>
    <label><span>${esc(t.fatherName)} <small style="opacity:.6;">(${LANG==='ur'?'اختیاری':'optional'})</small></span><input id="cp-add-father" placeholder="${esc(t.fatherName)}"></label>
    <label><span>${esc(t.contact)} <small style="opacity:.6;">(${LANG==='ur'?'اختیاری':'optional'})</small></span><input id="cp-add-phone" type="tel" placeholder="03XXXXXXXXX"></label>
    <div id="cp-add-msg" style="font-size:12px;margin:8px 0;"></div>
    <button class="btn-primary" style="width:100%;" onclick="submitClassPortalAddStudent()">${esc(t.classPortalMenuAddStudent)}</button>
  `;
}

function queueOfflineAddStudent(session, name, fatherName, phone, msg, nameInput, fatherInput, phoneInput) {
  const tempId = 'local-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8);
  session.students = session.students || [];
  session.students.push({ id: tempId, name, father_name: fatherName, contact: phone });
  setClassSession(session);
  queueClassWrite({ type: 'addStudent', tempId, schoolCode: session.schoolCode, loginId: session.loginId, password: session.password, name, fatherName, phone });
  msg.innerHTML = `<span class="ok">${esc(t.classPortalOffline)}</span>`;
  if (nameInput) nameInput.value = '';
  if (fatherInput) fatherInput.value = '';
  if (phoneInput) phoneInput.value = '';
}

async function submitClassPortalAddStudent() {
  const session = getClassSession();
  const msg = document.getElementById('cp-add-msg');
  const nameInput = document.getElementById('cp-add-name');
  const fatherInput = document.getElementById('cp-add-father');
  const phoneInput = document.getElementById('cp-add-phone');
  const name = nameInput ? nameInput.value.trim() : '';
  const fatherName = fatherInput ? fatherInput.value.trim() : '';
  const phone = phoneInput ? phoneInput.value.trim() : '';
  if (!session || !name) return;
  msg.textContent = '…';
  if (!navigator.onLine) { queueOfflineAddStudent(session, name, fatherName, phone, msg, nameInput, fatherInput, phoneInput); return; }
  try {
    const { data, error } = await sb.rpc('class_add_student', {
      p_school_code: session.schoolCode, p_login_id: session.loginId, p_password: session.password, p_name: name, p_father_name: fatherName, p_phone: phone
    });
    if (error || !data || !data.length) { msg.innerHTML = `<div class="err">${esc(t.classPortalInvalid)}</div>`; return; }
    session.students = session.students || [];
    session.students.push({ id: data[0].id, name: data[0].name, father_name: data[0].father_name || fatherName, contact: data[0].contact || phone });
    setClassSession(session);
    msg.innerHTML = `<span class="ok">✓ ${esc(t.classPortalAddStudentSaved)}</span>`;
    if (nameInput) nameInput.value = '';
    if (fatherInput) fatherInput.value = '';
    if (phoneInput) phoneInput.value = '';
  } catch(e) {
    // navigator.onLine said we were online but the request itself failed
    // mid-flight (weak signal) — queue it the same way instead of losing
    // what was typed.
    queueOfflineAddStudent(session, name, fatherName, phone, msg, nameInput, fatherInput, phoneInput);
  }
}

// ---- Attendance (today only, same Present/Leave/Absent x AM/PM pattern as the Teachers tab) ----
let classAttendanceDraft = {}; // { studentId: { am, pm } }

function renderClassPortalAttendance() {
  CLASS_PORTAL_SCREEN = 'attendance';
  const session = getClassSession();
  const body = document.getElementById('class-portal-body');
  if (!session || !body) return;
  classAttendanceDraft = {};
  const date = todayISO();
  if (!session.students.length) {
    body.innerHTML = `
      <button class="btn-ghost" style="padding:9px 14px;margin-bottom:10px;" onclick="renderClassPortalMenu()">‹ ${esc(t.classPortalBackToMenu)}</button>
      <div class="empty">${esc(t.classPortalNoStudents)}</div>`;
    return;
  }
  body.innerHTML = `
    <button class="btn-ghost" style="padding:9px 14px;margin-bottom:10px;" onclick="renderClassPortalMenu()">‹ ${esc(t.classPortalBackToMenu)}</button>
    <h2 style="margin-top:0;">${esc(t.markAttendance)}</h2>
    <label><span>${esc(t.attendanceDate)}</span><input type="date" id="cp-att-date" value="${date}" max="${todayISO()}"></label>
    <div id="cp-att-roster">${classPortalRosterHtml(session)}</div>
    <div id="cp-att-msg" style="font-size:12px;margin:10px 0;"></div>
    <button class="btn-primary" style="width:100%;" onclick="submitClassPortalAttendance()">${esc(t.saveAttendance)}</button>
  `;
}

function classPortalRosterHtml(session) {
  const opt = (id, session_, val, label, color) => {
    const cur = (classAttendanceDraft[id] || {})[session_];
    return `<button type="button" onclick="setClassAttendanceMark('${id}','${session_}','${val}')" style="flex:1;padding:6px 3px;border-radius:8px;font-size:10.5px;font-weight:600;border:1.5px solid ${cur===val?color:'var(--line)'};background:${cur===val?color:'#fff'};color:${cur===val?'#fff':'var(--ink)'};">${esc(label)}</button>`;
  };
  return session.students.slice().sort((a,b)=>Number(a.roll_no||0)-Number(b.roll_no||0)).map(st => {
    const isAbsent = (classAttendanceDraft[st.id] || {}).am === 'absent' || (classAttendanceDraft[st.id] || {}).pm === 'absent';
    return `
    <div style="border-bottom:1px solid var(--line);padding:8px 0;">
      <div style="font-size:13px;font-weight:600;margin-bottom:6px;">${st.roll_no ? '#'+esc(st.roll_no)+' — ' : ''}${esc(st.name)}</div>
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:5px;">
        <div style="width:56px;font-size:10.5px;opacity:.65;">${esc(t.morning)}</div>
        <div style="display:flex;gap:5px;flex:1;">${opt(st.id,'am','present',t.present,'var(--sage)')}${opt(st.id,'am','leave',t.leave,'var(--gold)')}${opt(st.id,'am','absent',t.absent,'var(--rust)')}${opt(st.id,'am','sick',t.sick,'#3B6FA0')}</div>
      </div>
      <div style="display:flex;align-items:center;gap:6px;">
        <div style="width:56px;font-size:10.5px;opacity:.65;">${esc(t.afternoon)}</div>
        <div style="display:flex;gap:5px;flex:1;">${opt(st.id,'pm','present',t.present,'var(--sage)')}${opt(st.id,'pm','leave',t.leave,'var(--gold)')}${opt(st.id,'pm','absent',t.absent,'var(--rust)')}${opt(st.id,'pm','sick',t.sick,'#3B6FA0')}</div>
      </div>
      ${isAbsent ? `<button type="button" onclick="sendAbsentSms('${st.id}')" style="margin-top:6px;width:100%;padding:6px;border-radius:8px;font-size:11px;font-weight:600;border:1.5px solid var(--rust);background:#fff;color:var(--rust);">📩 ${esc(LANG==='ur'?'والدین کو SMS بھیجیں':"Send SMS to Parent")}</button>` : ''}
    </div>`;
  }).join('');
}

// Opens the phone's own Messages app (no internet needed) with the absence
// message pre-filled for this student's parent, using the number captured
// when the student was added in the Class Portal. The teacher still has to
// tap Send themselves — one message at a time, same as the fee-reminder SMS
// elsewhere in the app; there is no automatic/background SMS sending here.
function sendAbsentSms(studentId) {
  const session = getClassSession();
  const st = session && session.students && session.students.find(s => s.id === studentId);
  if (!st) return;
  if (!st.contact) { alert(LANG==='ur' ? 'اس طالب علم کا موبائل نمبر موجود نہیں۔' : 'No mobile number on file for this student.'); return; }
  const msg = `${fmtDate(todayISO())}: محترم سرپرست، آپ کا بچہ ${st.name} آج اسکول میں غیر حاضر ہے۔ نہ آنے کا اگر کوئی معقول وجہ ہو تو سکول سے رابطہ کریں، ورنہ غیر حاضر تصور ہوگا۔ شکریہ - ${session.schoolName || 'سکول'}`;
  openFatherWhatsapp(st.contact, msg);
}

function setClassAttendanceMark(studentId, session_, status) {
  if (!classAttendanceDraft[studentId]) classAttendanceDraft[studentId] = {};
  const rec = classAttendanceDraft[studentId];
  rec[session_] = rec[session_] === status ? undefined : status;
  const el = document.getElementById('cp-att-roster');
  if (el) el.innerHTML = classPortalRosterHtml(getClassSession());
}

async function submitClassPortalAttendance() {
  const session = getClassSession();
  const msg = document.getElementById('cp-att-msg');
  const dateInput = document.getElementById('cp-att-date');
  const date = (dateInput && dateInput.value) ? dateInput.value : todayISO();
  const entries = [];
  Object.keys(classAttendanceDraft).forEach(studentId => {
    const rec = classAttendanceDraft[studentId];
    if (rec.am) entries.push({ studentId, session: 'am', status: rec.am });
    if (rec.pm) entries.push({ studentId, session: 'pm', status: rec.pm });
  });
  if (!entries.length) return;
  if (msg) msg.textContent = '…';
  let anyFailed = false;
  for (const e of entries) {
    if (!navigator.onLine) { queueClassWrite({ type:'attendance', schoolCode:session.schoolCode, loginId:session.loginId, password:session.password, studentId:e.studentId, date, session:e.session, status:e.status }); continue; }
    try {
      const { data, error } = await sb.rpc('class_attendance_mark', {
        p_school_code: session.schoolCode, p_login_id: session.loginId, p_password: session.password,
        p_student_id: e.studentId, p_date: date, p_session: e.session, p_status: e.status
      });
      if (error || data !== true) throw new Error('failed');
    } catch(err) {
      queueClassWrite({ type:'attendance', schoolCode:session.schoolCode, loginId:session.loginId, password:session.password, studentId:e.studentId, date, session:e.session, status:e.status });
      anyFailed = true;
    }
  }
  if (msg) msg.innerHTML = anyFailed ? `<span class="ok">${esc(t.classPortalOffline)}</span>` : `<span class="ok">✓ ${esc(t.classPortalAttendanceSaved)}</span>`;
}

// ---- Exam marks (exam name + dynamic subjects + a mark per student per subject) ----
let classMarksDraft = { examName: '', subjects: [], marks: {} }; // subjects: [{name,total}], marks: { studentId: { subjectName: score } }

async function renderClassPortalMarks() {
  CLASS_PORTAL_SCREEN = 'marks';
  const session = getClassSession();
  const body = document.getElementById('class-portal-body');
  if (!session || !body) return;
  classMarksDraft = cpDraftLoad() || { examName: '', subjects: [], marks: {} };
  let savedExams = [];
  if (navigator.onLine) {
    try {
      const { data } = await fetchAll(() => sb.from('class_exam_marks').select('exam_name,marks,subjects')
        .eq('owner_id', session.ownerId).eq('class_name', session.className));
      // A class login has no table SELECT rights of its own (see RLS policy —
      // only the owner can read directly), so this will simply come back
      // empty for the class device; kept here in case that policy is ever
      // widened. New/edited exams still save fine via the RPC below either way.
      savedExams = data || [];
    } catch(e) {}
  }
  body.innerHTML = `
    <button class="btn-ghost" style="padding:9px 14px;margin-bottom:10px;" onclick="renderClassPortalMenu()">‹ ${esc(t.classPortalBackToMenu)}</button>
    <h2 style="margin-top:0;">${esc(t.classPortalMenuMarks)}</h2>
    <label><span>${esc(t.classPortalExamName)}</span><input id="cp-exam-name" placeholder="${esc(t.classPortalExamNamePlaceholder)}" value="${esc(classMarksDraft.examName)}" oninput="classMarksDraft.examName=this.value;cpDraftSave()"></label>
    <div id="cp-subjects">${classPortalSubjectsHtml()}</div>
    <button class="btn-ghost" style="width:100%;margin:8px 0;" onclick="addClassSubject()">${esc(t.classPortalAddSubject)}</button>
    <div id="cp-marks-grid">${classPortalMarksGridHtml(session)}</div>
    <div id="cp-marks-msg" style="font-size:12px;margin:10px 0;"></div>
    <button class="btn-primary" style="width:100%;" onclick="submitClassPortalMarks()">${esc(t.classPortalSaveMarks)}</button>
    <button class="btn-ghost" style="width:100%;margin-top:10px;" onclick="cpDraftClear()">🗑 ${LANG==='ur' ? 'صاف کریں / نئی شیٹ' : 'Clear / New sheet'}</button>
  `;
}

// ---- Teacher portal: marks being entered are kept on this device ----
// Same idea as the Question Paper draft: written on every change, restored when
// the Marks screen opens, and only removed when the teacher taps Clear.
function cpDraftKey() {
  const ses = getClassSession();
  return ses ? 'cpMarksDraft_v1_' + [ses.schoolCode, ses.loginId, ses.className].join('_') : null;
}
let cpSaveWarned = false;
function cpDraftSave() {
  const k = cpDraftKey(); if (!k) return;
  try { localStorage.setItem(k, JSON.stringify(classMarksDraft)); cpSaveWarned = false; }
  catch (e) {
    if (!cpSaveWarned) {
      cpSaveWarned = true;
      alert(LANG==='ur' ? '⚠️ نمبر فون میں محفوظ نہیں ہو سکے (جگہ ختم ہو سکتی ہے)۔ ابھی "نمبر محفوظ کریں" دبا دیں اور فون میں جگہ خالی کریں۔' : '⚠️ Marks could not be saved on this phone (storage may be full). Tap Save marks now and free some space.');
    }
  }
}
// After the marks are saved (or queued offline) offer to clear the sheet so the next exam starts fresh.
function cpAfterSavePrompt() {
  setTimeout(() => {
    if (confirm(LANG==='ur' ? 'نمبر محفوظ ہو گئے۔ کیا اب شیٹ صاف کر دیں تاکہ اگلا امتحان نئے سرے سے شروع ہو؟' : 'Marks saved. Clear this sheet now so the next exam starts fresh?')) {
      const k = cpDraftKey();
      if (k) { try { localStorage.removeItem(k); } catch (e) {} }
      renderClassPortalMarks();
    }
  }, 60);
}
function cpDraftLoad() {
  const k = cpDraftKey(); if (!k) return null;
  try {
    const o = JSON.parse(localStorage.getItem(k) || 'null');
    if (o && Array.isArray(o.subjects) && o.marks && typeof o.marks === 'object') return { examName: o.examName || '', subjects: o.subjects, marks: o.marks };
  } catch (e) {}
  return null;
}
function cpDraftClear() {
  if (!confirm(LANG==='ur' ? 'اس اسکرین کے تمام درج شدہ نمبر اور مضامین صاف کر دیں؟' : 'Clear all marks and subjects entered on this screen?')) return;
  const k = cpDraftKey();
  if (k) { try { localStorage.removeItem(k); } catch (e) {} }
  renderClassPortalMarks();
}
function cpLiveMark(studentId, subjectName, value) {
  if (!classMarksDraft.marks[studentId]) classMarksDraft.marks[studentId] = {};
  if (value === '') delete classMarksDraft.marks[studentId][subjectName];
  else classMarksDraft.marks[studentId][subjectName] = Number(value);
  cpDraftSave();
}
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden' && CLASS_PORTAL_SCREEN === 'marks') cpDraftSave(); });
window.addEventListener('pagehide', () => { if (CLASS_PORTAL_SCREEN === 'marks') cpDraftSave(); });

function classPortalSubjectsHtml() {
  if (!classMarksDraft.subjects.length) return `<p style="font-size:12px;opacity:.6;">${esc(t.classPortalNoSubjects)}</p>`;
  return classMarksDraft.subjects.map((s, i) => `
    <div class="row2" style="margin-bottom:6px;align-items:end;">
      <label style="margin:0;"><span>${esc(t.classPortalSubjectName)}</span><input value="${esc(s.name)}" oninput="renameClassSubject(${i},this.value)"></label>
      <div style="display:flex;gap:6px;">
        <label style="margin:0;flex:1;"><span>${esc(t.classPortalSubjectTotal)}</span><input type="number" value="${s.total}" oninput="retotalClassSubject(${i},this.value)"></label>
        <button type="button" style="flex:none;background:none;border:none;color:var(--rust);font-size:16px;" onclick="removeClassSubject(${i})">✕</button>
      </div>
    </div>`).join('');
}

function addClassSubject() {
  classMarksDraft.subjects.push({ name: '', total: 100 });
  cpDraftSave();
  document.getElementById('cp-subjects').innerHTML = classPortalSubjectsHtml();
  document.getElementById('cp-marks-grid').innerHTML = classPortalMarksGridHtml(getClassSession());
}
function removeClassSubject(i) {
  classMarksDraft.subjects.splice(i, 1);
  cpDraftSave();
  document.getElementById('cp-subjects').innerHTML = classPortalSubjectsHtml();
  document.getElementById('cp-marks-grid').innerHTML = classPortalMarksGridHtml(getClassSession());
}
function renameClassSubject(i, val) {
  const oldName = classMarksDraft.subjects[i].name;
  classMarksDraft.subjects[i].name = val;
  // Carry any already-entered marks over to the renamed subject key.
  Object.keys(classMarksDraft.marks).forEach(sid => {
    const row = classMarksDraft.marks[sid];
    if (row && oldName in row) { row[val] = row[oldName]; delete row[oldName]; }
  });
  cpDraftSave();
  document.getElementById('cp-marks-grid').innerHTML = classPortalMarksGridHtml(getClassSession());
}
function retotalClassSubject(i, val) {
  classMarksDraft.subjects[i].total = Number(val || 0);
  cpDraftSave();
}

function classPortalMarksGridHtml(session) {
  if (!session || !session.students.length) return `<div class="empty">${esc(t.classPortalNoStudents)}</div>`;
  if (!classMarksDraft.subjects.length) return '';
  const students = session.students.slice().sort((a,b)=>Number(a.roll_no||0)-Number(b.roll_no||0));
  return `
    <div class="card-table-wrap" style="margin-top:8px;">
      <table class="card-table">
        <thead><tr><th style="text-align:left;">${esc(t.studentName)}</th>${classMarksDraft.subjects.map(s=>`<th>${esc(s.name||'—')} /${esc(s.total)}</th>`).join('')}</tr></thead>
        <tbody>${students.map(st => `
          <tr><td class="mo">${st.roll_no?'#'+esc(st.roll_no)+' ':''}${esc(st.name)}</td>
          ${classMarksDraft.subjects.map(s => `<td style="padding:3px;"><input type="number" style="width:56px;text-align:center;padding:5px 2px;" value="${(classMarksDraft.marks[st.id]||{})[s.name] ?? ''}" oninput="cpLiveMark('${st.id}','${esc(s.name).replace(/'/g,"\\'")}',this.value)" onchange="setClassMark('${st.id}','${esc(s.name).replace(/'/g,"\\'")}',this.value,${s.total})"></td>`).join('')}
          </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
}

function setClassMark(studentId, subjectName, value, total) {
  let v = value === '' ? null : Number(value);
  if (v !== null && total && v > Number(total)) { alert(t.classPortalMarksExceed); v = Number(total); }
  if (!classMarksDraft.marks[studentId]) classMarksDraft.marks[studentId] = {};
  if (v === null) delete classMarksDraft.marks[studentId][subjectName];
  else classMarksDraft.marks[studentId][subjectName] = v;
  cpDraftSave();
}

async function submitClassPortalMarks() {
  const session = getClassSession();
  const msg = document.getElementById('cp-marks-msg');
  const examName = (classMarksDraft.examName || '').trim();
  if (!examName || !classMarksDraft.subjects.length) return;
  const payload = { schoolCode: session.schoolCode, loginId: session.loginId, password: session.password, examName, marks: classMarksDraft.marks, subjects: classMarksDraft.subjects };
  if (msg) msg.textContent = '…';
  if (!navigator.onLine) {
    queueClassWrite({ type:'marks', ...payload });
    if (msg) msg.innerHTML = `<span class="ok">${esc(t.classPortalOffline)}</span>`;
    cpAfterSavePrompt();
    return;
  }
  try {
    const { data, error } = await sb.rpc('class_exam_marks_save', {
      p_school_code: session.schoolCode, p_login_id: session.loginId, p_password: session.password,
      p_exam_name: examName, p_marks: classMarksDraft.marks, p_subjects: classMarksDraft.subjects
    });
    if (error || data !== true) throw new Error('failed');
    if (msg) msg.innerHTML = `<span class="ok">✓ ${esc(t.classPortalMarksSaved)}</span>`;
    cpAfterSavePrompt();
  } catch(e) {
    queueClassWrite({ type:'marks', ...payload });
    if (msg) msg.innerHTML = `<span class="ok">${esc(t.classPortalOffline)}</span>`;
    cpAfterSavePrompt();
  }
}

function queueClassWrite(item) {
  const q = getClassQueue();
  q.push({ ...item, ts: Date.now() });
  setClassQueue(q);
}

// If an attendance/marks entry was queued offline against a not-yet-synced
// student's temporary local id, this swaps that temporary id for the real,
// server-assigned one once the student itself has synced — so those entries
// land on the right student instead of silently referencing an id the
// server has never seen.
function rewriteQueueStudentId(items, tempId, realId) {
  return items.map(i => {
    if (i.studentId === tempId) return { ...i, studentId: realId };
    if (i.marks && Object.prototype.hasOwnProperty.call(i.marks, tempId)) {
      const marks = { ...i.marks };
      marks[realId] = marks[tempId];
      delete marks[tempId];
      return { ...i, marks };
    }
    return i;
  });
}

async function flushClassQueue() {
  if (!navigator.onLine) return;
  let q = getClassQueue();
  if (!q.length) return;
  // Students added offline are synced first, so any attendance/marks entries
  // queued afterward for that same student (still offline, same session) can
  // have their temporary id rewritten to the real one before being sent.
  let rest = q.filter(i => i.type !== 'addStudent');
  const remaining = [];
  for (const item of q.filter(i => i.type === 'addStudent')) {
    try {
      const { data, error } = await sb.rpc('class_add_student', {
        p_school_code: item.schoolCode, p_login_id: item.loginId, p_password: item.password,
        p_name: item.name, p_father_name: item.fatherName, p_phone: item.phone
      });
      if (error || !data || !data.length) { remaining.push(item); continue; }
      const realId = data[0].id;
      const session = getClassSession();
      if (session && session.students) {
        session.students = session.students.map(s => s.id === item.tempId
          ? { id: realId, name: data[0].name, father_name: data[0].father_name || item.fatherName, contact: data[0].contact || item.phone }
          : s);
        setClassSession(session);
      }
      rest = rewriteQueueStudentId(rest, item.tempId, realId);
    } catch(e) { remaining.push(item); }
  }
  for (const item of rest) {
    try {
      if (item.type === 'attendance') {
        const { error } = await sb.rpc('class_attendance_mark', {
          p_school_code: item.schoolCode, p_login_id: item.loginId, p_password: item.password,
          p_student_id: item.studentId, p_date: item.date, p_session: item.session, p_status: item.status
        });
        if (error) remaining.push(item);
      } else if (item.type === 'marks') {
        const { error } = await sb.rpc('class_exam_marks_save', {
          p_school_code: item.schoolCode, p_login_id: item.loginId, p_password: item.password,
          p_exam_name: item.examName, p_marks: item.marks, p_subjects: item.subjects
        });
        if (error) remaining.push(item);
      } else if (item.type === 'pm_reply') {
        const { error } = await sb.rpc('parent_message_reply_class', {
          p_school_code: item.schoolCode, p_login_id: item.loginId, p_password: item.password,
          p_message_id: item.messageId, p_text: item.text
        });
        if (error && !/invalid_login|not_found|bad_message|too_many_replies/.test(error.message || '')) remaining.push(item);
      }
    } catch(e) { remaining.push(item); }
  }
  setClassQueue(remaining);
  const body = document.getElementById('class-portal-body');
  if (body && CLASS_PORTAL_SCREEN === 'menu') renderClassPortalMenu();
}

