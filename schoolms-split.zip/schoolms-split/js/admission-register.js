/* SchoolMS — admission-register.js — split from index.html (lines 8105-8140). Load order matters: see index.html */
// ---------------- Admission & Withdrawal Register ----------------
// A standalone digitized copy of the school's physical Admission & Withdrawal
// Register book. It reads/writes its own Supabase table (admission_register)
// and is never joined, cross-referenced, or matched against the Students or
// Finance data above — the two live side by side in the same app but are
// otherwise unrelated.
let registerSearch = '';
let registerPage = 1;
let registerSubTab = 'dashboard'; // 'dashboard' | 'admitted' | 'slc'
const REGISTER_PAGE_SIZE = 20;
// Tracks which Admission Register rows are checked for print, by id — kept as a
// Set so selections survive across pages and search filtering (a school might
// search, tick a few, clear the search, and tick a few more before printing).
let REGISTER_SELECTED = new Set();
function toggleRegisterSelect(id) {
  if (REGISTER_SELECTED.has(id)) REGISTER_SELECTED.delete(id); else REGISTER_SELECTED.add(id);
  renderTab();
}
function clearRegisterSelection() { REGISTER_SELECTED.clear(); renderTab(); }
function setRegisterSearch(v) { registerSearch = v; registerPage = 1; reFocusAfterRender('register-search-input'); }
function setRegisterPage(p) { registerPage = p; renderTab(); }
function setRegisterSubTab(k) { registerSubTab = k; registerSearch = ''; registerPage = 1; renderTab(); }

// 'admitted' = currently enrolled (no withdrawal date yet); 'slc' = has left / SLC issued.
function filteredRegisterList() {
  const q = registerSearch.trim().toLowerCase();
  return DATA.admissionRegister
    .filter(r => registerSubTab==='admitted' ? !r.withdrawal_date : registerSubTab==='slc' ? !!r.withdrawal_date : true)
    .filter(r => !q
      || (r.student_name||'').toLowerCase().includes(q)
      || (r.father_name||'').toLowerCase().includes(q)
      || String(r.serial_no||'').includes(registerSearch.trim()))
    .slice()
    .sort((a,b) => Number(a.serial_no||0) - Number(b.serial_no||0));
}

