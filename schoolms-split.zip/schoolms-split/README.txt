SchoolMS - split version (TEST ONLY, abhi upload mat karen)

index.html  : sirf dhancha (head, config, script tags)
css/style.css, css/paper.css : styles
js/         : code, har feature ki alag file

Load order (index.html me yehi tartib hai, badalna nahi):
core, auth, data, search-alerts, settings, dashboard, students, teachers,
timetable, class-logins-view, finance, reports, admission-register,
datesheet, dmc, marks-sheet, papers, class-portal, notices, diary-portal,
parent-portal, chat, main (boot() aur service worker sab se aakhir me)

IMPORTANT: sw.js ki cache list me nayi files (css/*.css, js/*.js) add karni hongi,
warna offline me app nahi khulegi. Upload se pehle sw.js bhej den.
Purani index.html ka backup zaroor rakhen.
Copy aap ki purani manifest.json, sw.js, icons yahin isi folder me rakhen.
